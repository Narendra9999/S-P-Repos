from datetime import datetime
from pyspark.sql.functions import lit, current_timestamp, col
from delta.tables import DeltaTable

config_data =  {
    "target_to_source_mapping": {
      "PHOENIX_ID": "PHOENIX_ID",
      "PHOENIX_PLAN_ID": "PHOENIX_PLAN_ID",
      "SECTOR_NAME": "SECTOR_NAME",
      "PER_TYPE_NAME": "PER_TYPE_NAME",
      "MEASURE_DATE": "MEASURE_DATE",
      "PERIOD_END_DATE": "PERIOD_END_DATE",
      "PERIOD_MONTHS": "PERIOD_MONTHS",
      "STATEMENT_BASIS_NAME": "STATEMENT_BASIS_NAME",
      "ACCOUNT_BASIS_NAME": "ACCOUNT_BASIS_NAME",
      "APR_ACCEPTABLE": "APR_ACCEPTABLE",
      "SOURCE_FILE_CREATE_DATE": "SOURCE_FILE_CREATE_DATE",
      "SRC_DE_UNIQ_ID_TEXT": "SRC_DE_UNIQ_ID_TEXT",
      "DP_VALUE": "DP_VALUE",
      "REPORT_ID": "REPORT_ID",
      "DELETE_FLAG": "DELETE_FLAG",
      "ACTION": "ACTION",
      "WORK_TYPE": "WORK_TYPE", 
      "KEYWORD_NAME": "KEYWORD_NAME"
    },
    "keys": "SRC_DE_UNIQ_ID_TEXT,PHOENIX_ID,REPORT_ID",
    "partition_order": "PERIOD_END_DATE,SECTOR_NAME",
    "audit_columns": [
      "actv_ind",
      "create_usr_id",
      "last_upd_usr_id",
      "create_dttm", 
      "last_upd_dttm",
      "run_id"
    ],
    "ignorable_columns": "",
    "raw_catalog": "idf_raw_dev",
    "raw_schema": "uspf",
    "raw_table": "t_dc_transaction_dp_load",
    "curated_catalog": "idf_curated_dev",
    "curated_schema": "uspf",
    "curated_table": "t_dc_transaction_dp_load",
    "curation_template": "scd_type_1"
  }


# Function to merge incremental data dynamically
def merge_data(batch_df, batch_id):
    curated_table = DeltaTable.forName(spark, curated_table_name)

    # Build dynamic merge condition based on JSON keys
    merge_condition = " AND ".join([f"target.{key} = source.{key}" for key in merge_keys])

    # Define values dynamically for insert/update operations
    mapped_values = {target_col: col(f"source.{source_col}") for target_col, source_col in target_to_source_mapping.items()}
    
    # Perform Merge Operation
    curated_table.alias("target").merge(
        batch_df.alias("source"),
        merge_condition
    ).whenMatchedUpdate(condition="source._change_type = 'update'", 
        set={
            **mapped_values,
            
            # Audit Columns
            "target.actv_ind": "'Y'",
            "target.create_usr_id": col("target.create_usr_id"),  # Keep old value
            "target.last_upd_usr_id": "current_user()",
            "target.create_dttm": col("target.create_dttm"),  # Keep old value
            "target.last_upd_dttm": current_timestamp(),
            "target.run_id": lit(run_id_value)
        }
    ).whenMatchedUpdate(condition="source._change_type = 'delete'", 
        set={
            "target.actv_ind": "'N'",
            "target.create_usr_id": col("target.create_usr_id"),  # Keep old value
            "target.last_upd_usr_id": "current_user()",
            "target.create_dttm": col("target.create_dttm"),  # Keep old value
            "target.last_upd_dttm": current_timestamp(),
            "target.run_id": lit(run_id_value)
        }
    ).whenNotMatchedInsert(
        values={
            **mapped_values,

            # Audit Columns
            "actv_ind": "'Y'",
            "create_usr_id": "current_user()",
            "last_upd_usr_id": "current_user()",
            "create_dttm": current_timestamp(),
            "last_upd_dttm": current_timestamp(),
            "run_id": lit(run_id_value)
        } 
    ).execute()

def run_curated_dpload():

    # Generate run_id in YYYYMMDDHHmmSS format as an integer
    run_id_value = int(datetime.now().strftime("%Y%m%d%H%M%S"))
    # Extract table details from JSON
    raw_table_name = f"{config_data['raw_catalog']}.{config_data['raw_schema']}.{config_data['raw_table']}"
    curated_table_name = f"{config_data['curated_catalog']}.{config_data['curated_schema']}.{config_data['curated_table']}"

    # Extract mappings, keys, partitions, and audit columns
    target_to_source_mapping = config_data["target_to_source_mapping"]
    merge_keys = config_data["keys"].split(",")

    raw_changes_df = spark.readStream \
    .format("delta") \
    .option("readChangeFeed", "true") \
    .table(raw_table_name)

    query = raw_changes_df.writeStream \
        .foreachBatch(merge_data) \
        .option("checkpointLocation", f"s3://spr-idf-dev-platform-engineered/catalog/uspf/curated/checkpoint/{curated_table_name}/") \
        .start()

    query.awaitTermination(60) # Waits for 60 seconds before terminating the streaming query.

    query.stop()