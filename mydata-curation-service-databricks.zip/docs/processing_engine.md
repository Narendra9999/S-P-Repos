# Config-Driven Processing Engine (Human Edition)

This guide walks through the moving parts of the prepared-financials processing engine in plain language. It includes diagrams you can sketch on a whiteboard, copy‑paste snippets, and pointed tips for people new to the codebase.

---

## 1. Big Picture – three questions to answer

1. **Where does the data come from?**  
   Raw DP tables land in curated Delta tables (load, schedules, comments, org). Each dataset definition pulls one of these tables or an intermediate temp view.

2. **What happens to it?**  
   The processing engine registers the incoming DataFrame as a temp view, optionally runs a SQL template against it, and hands the final frame to a writer (Delta, temp view, Kafka, Postgres, or an SCD merge).

3. **Where does it go?**  
   The final datasets show up in `idf_curated_<env>.uspf.t_pf_base`, on Kafka (`apd.prepared.financials.changes.<env>`), and in Postgres (`apddev.apd.dataset`), all described in config files.

Keep those three questions in mind while reading the rest of this doc.

---

## 2. Core components (people and files to know)

| Component | File | Why it matters |
|-----------|------|----------------|
| **Job entrypoint** | `data_services/my_data_incremental/main_dptoapd.py` | Parses CLI args, loads lineage configs, kicks off raw ingestion, and finally calls the config-driven pipeline runner when `--pipeline_config` is provided. |
| **Pipeline runner** | `data_services/my_data_incremental/pipelines/config_pipeline_runner.py` | Reads JSON configs, attaches metadata (source table names, run IDs), and builds `DatasetExecution` objects. |
| **Processing engine** | `data_services/my_data_incremental/engine/processing_engine.py` | Applies SQL templates, enforces schemas, executes SCD merges, or writes to Kafka/Postgres. |
| **SQL template loader** | `data_services/my_data_incremental/engine/transformation_manager.py` | Picks the correct SQL script for the current env/catalog/schema. |
| **Config loader** | `data_services/my_data_incremental/config/config_loader.py` | Handles `${env}` substitution and makes schema/data fixtures available. |
| **Writers** | `io/outputs/kafka_writer.py`, `io/outputs/postgres_writer.py` | Respect `output_destinations.json` and the contract definitions in `output_contracts.json`. |

---

## 3. Pipeline config anatomy (with sample)

The config file is just JSON (`pipeline_dp_to_adp.json`). Each entry in `datasets` describes one hop in the pipeline.

```json
{
  "name": "pf_base",
  "source": {
    "type": "view",
    "name": "collapsed_base"
  },
  "target": {
    "type": "delta",
    "catalog": "idf_curated_${env}",
    "schema": "uspf",
    "table": "t_pf_base",
    "skip_schema_validation": false,
    "create_if_missing": true
  },
  "transformation": {
    "catalog": "pipelines",
    "schema": "dp_to_adp",
    "table": "pf_base"
  },
  "scd": {
    "type": "type2",
    "business_keys": ["PHOENIX_ID", "REPORT_ID", "period_end_date"],
    "hash_column": "record_hash",
    "delete_indicator_col": "delete_flag"
  }
}
```

**Callouts:**

- `source` tells Spark how to read the upstream data. If the type is `table`, include `catalog/schema/table`. For `view` or `temp_view`, only `name` is needed.
- `target.type` drives the writer: `delta`, `temp_view`, `kafka`, or `postgres`. Extra options (for example `config_key`) go under `target.options`.
- `transformation` points the engine at the SQL file: `${TRANSFORM_ROOT}/pipelines/dp_to_adp/pf_base.sql`.
- `scd` mirrors the constructor for `SCDType2Config` and is optional.

### Runtime values available to SQL

Every dataset execution gets a small context dictionary. Inside SQL templates you can use:

- `${source_view}` – temporary view name for the source DataFrame.
- `${source_table}` – fully qualified source identity (useful for joins).
- `${pipeline_run_id}` / `${dataset_run_id}` – run timestamps, already string formatted.
- `${env}`, `${bucket_env}`, `${bootstrap_env}`, etc. – from `Config.variables`.

---

## 4. Transformation templates by example

All SQL lives under `data_services/my_data_incremental/config/transformations`. The engine looks for `<catalog>/<schema>/<table>.sql` or the env-specific variant `<table>_<env>.sql`.

**Example:** excerpt from `pipelines/dp_to_adp/pf_precedence_payload.sql`.

```sql
WITH candidate AS (
    SELECT *
    FROM ${source_table} -- resolves to the pf_precedence_changes temp view
),
current_exploded AS (
    SELECT
        cand.*,
        entry.key AS mnemonic_id,
        entry.value.dp_value AS current_dp_value
    FROM candidate cand
    LATERAL VIEW explode(map_entries(cand.src_de_dp_map)) entry
    WHERE entry.value.enterprise_mnemonic IS NOT NULL
),
fin_data_points AS (
    SELECT
        PHOENIX_ID,
        array_sort(
            collect_list(
                named_struct(
                    'mnemonic', mnemonic_id,
                    'currentValue', CAST(current_dp_value AS STRING)
                )
            ),
            (left, right) ->
                CASE
                    WHEN left.mnemonic < right.mnemonic THEN -1
                    WHEN left.mnemonic > right.mnemonic THEN 1
                    ELSE 0
                END
        ) AS fin_data_points
    FROM current_exploded
    GROUP BY PHOENIX_ID
)
SELECT *
FROM fin_data_points;
```

**Tips for authoring templates:**

1. Treat `${source_view}` as your entry point; do not create global views.
2. Keep logic deterministic (for JSON payloads, sort arrays and fields).
3. Prefer pure SQL for traceability; if logic becomes Python-heavy consider refactoring upstream instead.

---

## 5. Walkthrough: `dp_to_adp` dataset chain

This is the full pipeline described in `pipeline_dp_to_adp.json`.

| Step | Dataset | Reads from | Transformation | Writes to |
|------|---------|------------|----------------|-----------|
| 1 | `pf_dp_load_norm` | curated table `t_dp_transaction_dp_load` | none | temp view |
| 2 | `pf_schedules` | curated table `t_dp_transaction_schedules` | none | temp view |
| 3 | `pf_comments` | curated table `t_dp_transaction_comments` | none | temp view |
| 4 | `pf_org_latest` | curated table `t_dp_transaction_org` | none | temp view |
| 5 | `pf_org_latest_filtered` | temp view `pf_org_latest` | filters to the latest record (`pf_org_latest_filtered.sql`) | temp view |
| 6 | `pf_unified` | temp view `pf_dp_load_norm` | passthrough (`pf_unified.sql`) | temp view |
| 7 | `collapsed_base` | temp view `pf_unified` | builds `src_de_dp_map` (`collapsed_base.sql`) | temp view |
| 8 | `pf_base` | temp view `collapsed_base` | computes hashes, default columns (`pf_base.sql`) | Delta table `t_pf_base` with SCD merge |
| 9 | `pf_precedence_changes` | Delta `t_pf_base` | precedence selection (`pf_precedence_changes.sql`) | temp view |
|10 | `pf_precedence_payload` | temp view `pf_precedence_changes` | payload assembly (`pf_precedence_payload.sql`) | temp view |
|11 | `pf_precedence_changes_kafka` | temp view `pf_precedence_payload` | no extra transformation | Kafka |
|12 | `pf_precedence_changes_postgres` | temp view `pf_precedence_payload` | no extra transformation | Postgres |

By the time the payload reaches Kafka/Postgres, each row already contains the full JSON dataset plus the `dataset_hash` fingerprint.

---

## 6. Outputs, contracts, and sample payloads

### Kafka/Postgres config snippets

`data_services/my_data_incremental/config/output_destinations.json`:

```json
"kafka": {
  "pf_precedence_changes": {
    "topic": "apd.prepared.financials.changes.${env}",
    "serializer": "contract:pf_precedence",
    "vault_secret_key": "kafka.orglinking.password",
    "debug_dry_run": false,
    "debug_print_messages": false
  }
}
```

The dataset definition in the pipeline refers to this block via `target.options.config_key = "pf_precedence_changes"`.

### Contract definition

`data_services/my_data_incremental/config/output_contracts.json` (simplified):

```json
"contracts": {
  "pf_precedence": {
    "kafka": {
      "root": {
        "eventName": {"config": "eventName"},         // NEW
        "datasetHash": "dataset_hash",
        "datasetJson": {"json_struct": {
          "finOrg": "CORE_ORG_ID",
          "finDataPoints": "fin_data_points"
        }}
      }
    },
    "postgres": {
      "record": {
        "dataset_type": {"config": "dataset_type"},   // Prepared Financial
        "dataset_hash": "dataset_hash",
        "payload_json": {"json_struct": {"payload": "dataset_json"}}
      }
    }
  }
}
```

**How it works in practice:**

1. Writer resolves the config key → loads the contract.
2. Contract renderer builds a context (`pipeline_run_id`, timestamps).
3. Kafka writer converts each row to JSON using the contract, prints previews when `debug_*` flags are on, and sends messages via `KafkaHandler`.
4. Postgres writer either performs a straight append or, when `upsert` config exists, runs a merge using JDBC batches.

---

## 7. SCD Type 2 in a nutshell

When `scd` is present:

- The engine checks that the destination is a Delta table (no SCD on views/Kafka).
- The frame must already contain the requested `hash_column` and delete indicator – see `collapsed_base.sql` + `pf_base.sql`.
- `SCDType2MergeManager.merge` (lines 82-189) performs:
  - **Match** on the configured business keys.
  - **Upsert** new rows, sets `version_id`, run metadata, timestamp fields.
  - **Retire** old versions when hashes differ (`current_flag` flips to `N`, `effective_end_dttm` set to one microsecond before the new row).
  - **Soft delete** when the delete flag is `Y`.

Add schema files under `config/schemas/<catalog>/<schema>/<table>.json` so validation passes before writing (or set `skip_schema_validation` while developing, but restore it before release).

---

## 8. Step-by-step: adding a new dataset

1. **Sketch the flow:** Do you need a new Delta table, a temp view, or a Kafka feed? Identify the input (table or view) and the destination.
2. **Author the SQL (if needed):**  
   - Create `config/transformations/<catalog>/<schema>/<dataset>.sql`.  
   - Use `${source_view}` for the incoming data and reference other tables via fully qualified names (`idf_curated_${env}.schema.table`).
3. **Extend the JSON config:**  
   - Append a dataset entry to the pipeline file.  
   - Wire `transformation` to the SQL you just wrote.  
   - For Kafka/Postgres, set `target.options.config_key` so the writer knows which block to read.
4. **Update schemas/contracts:**  
   - If writing to Delta, add a schema file.  
   - For new Kafka/Postgres shapes, extend `output_destinations.json` and `output_contracts.json`.
5. **Run locally (dev cluster) with dry run:**  
   - Set `debug_dry_run` or `debug_show_limit` to `true` in `output_destinations.json`.  
   - Execute `main_dptoapd.py ... --pipeline_config your_config.json`.
6. **Remove dry-run flags, ship to QA/Prod**, and monitor logs for `Dataset '<name>' processed successfully`.

---

## 9. Pipeline run logging

- **Where it lands:** Each pipeline execution writes a single record to a curated Delta table named `{pipeline_name}_log` in `idf_curated_<env>.uspf`. For the DP → ADP flow the table is `idf_curated_<env>.uspf.dp_to_apd_log`.
- **What drives it:** The logger reads the optional `"logging"` section inside each pipeline config (for example `data_services/my_data_incremental/config/pipeline_dp_to_adp.json`) to discover both the log-table location and the curated `run_log` source used to resolve the upstream (`curated_run_id`). Adjust that block per pipeline to steer logging without touching Python.
- **Schema (created automatically if missing):**

| Column | Type | Notes |
|--------|------|-------|
| `curated_run_id` | bigint | Latest run id pulled from the curated run-log (nullable when no match is found). |
| `pipeline_run_id` | string | Timestamp-based id generated by the processing engine. |
| `pipeline_name` | string | Inferred from the pipeline config file name (`pipeline_dp_to_apd.json` → `dp_to_apd`). |
| `status` | string | `SUCCESS` or `FAILED`. |
| `dry_run` | boolean | True only when every downstream writer executed in dry-run mode. |
| `transformation_payload` | string (JSON) | Dataset-level metadata (targets, SCD flag, row counts, source hints). |
| `configuration_payload` | string (JSON) | Snapshot of the pipeline config used for the run. |
| `kafka_payload` / `postgres_payload` | string (JSON) | Per-dataset stats plus sampled payloads captured during the write. |
| `metadata_payload` | string (JSON) | Spark application id, write modes encountered, aggregated errors. |
| `created_at` | timestamp | UTC insert time. |
| `error_message` | string | Truncated exception message when the run fails. |

- **Sample capture:** `KafkaDatasetWriter` and `PostgresDatasetWriter` now return execution metadata (record counts, dry-run flag, payload samples). The first `log_capture_limit` entries are kept; override this per-dataset in `output_destinations.json` if you need a larger (or smaller) sample.
- **Failure tolerance:** Logging happens in a best-effort `finally` block. If the write to the log table fails, the pipeline run still surfaces its original status; the logging error is emitted to the driver logs.
- **Curated lineage lookup:** The logger optionally filters the curated run-log by `pipeline_id_column` / `pipeline_id_value` before taking the latest `run_id`. Leave those keys out of `processing_*.json` to use the global latest run.

---

## 10. Debugging checklist

- **No rows written?** Confirm the source temp view has data (`spark.table("<view>").show()` in a notebook) and the transformation isn't filtering everything out.
- **Schema validation failure?** Check that `config/schemas/...` matches the write schema or temporarily set `skip_schema_validation` while iterating.
- **Contract errors?** Run with `debug_dry_run: true` and inspect the preview output. Often a field is missing from the DataFrame.
- **SCD merge complaints?** Make sure hashes are stable and `business_keys` align with the actual columns (case-sensitive).
- **Template substitution errors?** Look for `${` placeholders that do not exist in the context – the stack trace from `Template.safe_substitute` will highlight them.

---

## 11. Frequently used variables & helpers

- `${env}` - environment string (dev/qa/uat/prod/etc.).
- `${bucket_env}` - same as env except SSD environments map to their base (set in `Config.get_ssd_exceptions`).
- `${source_table}` - used by SQL templates that need to refer back to the upstream dataset.
- `log_structured(logger, message, payload)` - convenient for printing JSON diagnostics in writers and configs.
- `debug_dry_run`, `debug_print_messages`, `debug_show_limit` – all safe toggles for testing outputs without touching downstream systems.

---

This processing engine stays deliberately declarative: adjust configs and SQL, not Python, whenever possible. If you keep the big picture (source → transformation → destination) in mind, the individual files and options fall into place quickly. Happy curating! 💾✨
