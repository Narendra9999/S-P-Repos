# MyData Curation Service - Master Agentic AI Instructions

## Mission-Critical Understanding

You are an **expert AI agent** for a sophisticated **Databricks-based financial data pipeline**. This system ingests raw financial data from S3/Kafka, curates it through multiple transformation stages, and publishes datasets to Delta tables, Kafka topics, and Postgres using a **config-driven declarative architecture**.

**Master this architecture pattern:** Traditional imperative pipelines use Python/Java code to define every transformation. This codebase inverts that paradigm—**JSON configurations declare what to do, and a generic engine executes those declarations**. Your role is to understand, debug, expand, and optimize this engine.

### Core Data Flow (DP to ADP Pipeline)
```
S3 Files (DP Kafka messages)
    ↓
[Raw Ingestion] → idf_raw_{env}.uspf.t_dp_transaction_*
    ↓
[Conditional Curation] → idf_curated_{env}.uspf.t_dp_transaction_*
    ↓
[Config-Driven Pipeline: pipeline_dp_to_adp.json]
    ├─ Temp Views (normalization, enrichment)
    ├─ Delta Tables (t_pf_base with SCD Type 2)
    ├─ Kafka (apd.prepared.financials.changes.{env})
    └─ Postgres (apddev.apd.dataset)
```

**Critical distinction:** "DP" = Data Provider (source system). "ADP" = Analytics Data Platform (destination). The pipeline transforms vendor financial reports into standardized analytics datasets.

---

## Architecture Deep Dive: The Config-Driven Engine

### 1. The Three-Layer Architecture

**Layer 1: Entry Points & Orchestration**
- `main_dptoapd.py`: DP pipeline orchestrator
  - Parses CLI args (`--env`, `--process_mode`, `--pipeline_config`)
  - Loads environment-specific configs with template substitution
  - Executes raw data ingestion from S3
  - Conditionally runs curation based on **file types detected**
  - Triggers config-driven downstream pipeline if `--pipeline_config` specified
  
**Layer 2: Config Processing & Execution Planning**
- `config/config_loader.py`: Template variable substitution engine
  - Handles `${env}`, `${bucket_env}`, `${bootstrap_env}`, `${ssd_opt_path_env}`
  - **Critical SSD logic**: Environments like `ssddev` map to `bucket_env=dev` but keep `ssd_opt_path_env=/ssddev`
  - Bootstrap mapping: `uat→qa`, `prod/dr→pde` for shared config lookups
  
- `pipelines/config_pipeline_runner.py`: Declarative pipeline executor
  - Reads `pipeline_dp_to_adp.json` and constructs `DatasetExecution` objects
  - Resolves source DataFrames (tables, views, temp_views)
  - Builds `DatasetTarget` with write mode, schema validation, SCD config
  - Injects runtime context: `pipeline_run_id`, `dataset_run_id`, `source_table`

**Layer 3: Processing Engine & Writers**
- `engine/processing_engine.py`: Core transformation and persistence engine
  - Schema validation against `config/schemas/{catalog}/{schema}/{table}.json`
  - SQL transformation resolution via `TransformationManager`
  - Delta writes with optional SCD Type 2 merge
  - Kafka/Postgres writes via contract-based serialization
  
- `engine/transformation_manager.py`: SQL template resolver
  - Search hierarchy: `{table}_{env}.sql` → `{table}.sql`
  - Catalog/schema folder mapping with sanitization
  - Template variables available: `${source_view}`, `${source_table}`, `${pipeline_run_id}`, `${dataset_run_id}`, `${env}`

### 2. The Dataset Configuration Anatomy

**Every dataset in `pipeline_dp_to_adp.json` follows this structure:**

```json
{
  "name": "dataset_identifier",
  "source": {
    "type": "table|view|temp_view",
    "catalog": "idf_curated_${env}",    // Only for type=table
    "schema": "uspf",                   // Only for type=table
    "table": "t_source_table",          // Only for type=table
    "name": "temp_view_name",           // Only for type=view/temp_view
    "read_mode": "full|latest"          // "latest" filters to max(run_id)
  },
  "target": {
    "type": "delta|temp_view|kafka|postgres",
    "catalog": "idf_curated_${env}",
    "schema": "uspf",
    "table": "t_target_table",
    "name": "view_name",                // For temp_view targets
    "config_key": "kafka_config_key",   // For kafka/postgres targets
    "skip_schema_validation": false,
    "create_if_missing": true,
    "mode": "append|overwrite"          // Optional, default based on type
  },
  "transformation": {
    "catalog": "pipelines",             // Maps to folder: transformations/pipelines/
    "schema": "dp_to_adp",              // Maps to subfolder: dp_to_adp/
    "table": "dataset_sql_file"         // Maps to file: dataset_sql_file.sql
  },
  "apply_transformations": true,        // Set false to skip SQL, use raw source
  "scd": {                              // OPTIONAL: SCD Type 2 merge configuration
    "type": "type2",
    "business_keys": ["PHOENIX_ID", "REPORT_ID", "period_end_date"],
    "hash_column": "record_hash",
    "delete_indicator_col": "delete_flag",
    "current_flag_col": "is_current",
    "active_flag_col": "actv_ind",
    "effective_start_col": "effective_start_dttm",
    "effective_end_col": "effective_end_dttm",
    "run_id_col": "run_id",
    "version_col": "version_id",
    "created_col": "create_dttm",
    "updated_col": "last_upd_dttm",
    "created_user_col": "create_usr_id",
    "updated_user_col": "last_upd_usr_id"
  },
  "effective_timestamp_column": "processing_timestamp"  // Used for SCD effective dates
}
```

**Execution Flow for a Single Dataset:**
1. **Resolve Source**: Load DataFrame from table/view
2. **Register Temp View**: Create `{table}_pre` temp view from source
3. **Apply Transformation**: Execute SQL template with variable substitution
4. **Validate Schema**: Ensure `config/schemas/` definition exists (unless skip_schema_validation)
5. **Execute Write**:
   - **Delta**: Standard write OR SCD Type 2 merge
   - **Temp View**: Register in Spark catalog for downstream consumption
   - **Kafka**: Serialize via contract, send to topic
   - **Postgres**: Serialize via contract, JDBC write/upsert
6. **Log Summary**: Record to `dp_to_apd_log` table

### 3. The DP to ADP Pipeline Execution Sequence

**Understanding the cascading dataset chain in `pipeline_dp_to_adp.json`:**

| Step | Dataset | Source | Transformation | Target | Purpose |
|------|---------|--------|----------------|--------|---------|
| 1 | `pf_dp_load_norm` | `t_dp_transaction_dp_load` (latest) | Passthrough normalization | Temp view | Load raw DP load data |
| 2 | `pf_schedules` | `t_dp_transaction_schedules` (latest) | Passthrough | Temp view | Load schedule data |
| 3 | `pf_comments` | `t_dp_transaction_comments` (latest) | Passthrough | Temp view | Load comment data |
| 4 | `pf_org_latest` | `t_dp_transaction_org` (latest) | Passthrough | Temp view | Load org master data |
| 5 | `pf_org_latest_filtered` | `pf_org_latest` view | Filter latest org records | Temp view | Dedupe org data |
| 6 | `pf_unified` | `pf_dp_load_norm` view | Unify DP load structure | Temp view | Normalize schema |
| 7 | `collapsed_base` | `pf_unified` view | **JOIN schedules, comments, org; BUILD src_de_dp_map** | Temp view | **CRITICAL: Collapse rows by mnemonic into MAP structure** |
| 8 | `pf_base` | `collapsed_base` view | **Compute hashes, add SCD columns** | Delta `t_pf_base` **WITH SCD Type 2 MERGE** | **Golden record with full history** |
| 9 | `pf_precedence_changes` | `t_pf_base` table | Apply precedence rules, detect changes | Temp view | Identify changed records |
| 10 | `pf_precedence_payload` | `pf_precedence_changes` view | Build JSON payload, history trail | Temp view | Prepare for publishing |
| 11 | `pf_precedence_changes_kafka` | `pf_precedence_payload` view | No transformation | Kafka topic | Publish to event stream |
| 12 | `pf_precedence_changes_postgres` | `pf_precedence_payload` view | No transformation | Postgres table | Mirror to RDBMS |
| 13 | `pf_validation_warnings` | `t_dp_transaction_dp_load` (latest) | Extract validation errors | Delta `t_pf_validation_warnings` | Audit data quality |

**KEY INSIGHT: The MAP structure (`src_de_dp_map`)**
- Step 7 (`collapsed_base.sql`) is THE transformation that collapses normalized rows into a denormalized MAP
- Each financial report has multiple data points (mnemonics like "REVENUE", "ASSETS")
- Source has one row per mnemonic: `{PHOENIX_ID, REPORT_ID, SRC_DE_UNIQ_ID_TEXT, DP_VALUE}`
- Target has one row per report with: `{PHOENIX_ID, REPORT_ID, src_de_dp_map: MAP<mnemonic, struct<dp_value, schedules, comments>>}`
- This enables downstream systems to retrieve "REVENUE for PHOENIX_ID=123, REPORT_ID=456" in O(1) time

### 4. SCD Type 2 Merge Deep Dive

**What SCD Type 2 Does:**
- Maintains **full history** of every record change
- Uses **business keys** to identify the same logical entity across versions
- Computes **hash** of payload to detect changes
- Sets **effective date ranges** and **current flags**

**Merge Logic in `prepared_financials/scd.py`:**

```python
# 1. Match on business keys
merge_condition = "target.PHOENIX_ID = source.PHOENIX_ID 
                   AND target.REPORT_ID = source.REPORT_ID 
                   AND target.period_end_date = source.period_end_date"

# 2. Handle DELETES (if delete_flag = 'Y')
.whenMatchedUpdate(
    condition="target.is_current = 'Y' AND source.delete_flag = 'Y'",
    set={
        "is_current": "N",
        "actv_ind": "N",
        "effective_end_dttm": "source.processing_timestamp",
        "run_id": run_id
    }
)

# 3. Handle UPDATES (hash changed)
.whenMatchedUpdate(
    condition="target.is_current = 'Y' AND target.record_hash <> source.record_hash",
    set={
        "is_current": "N",  # Retire old version
        "effective_end_dttm": "source.processing_timestamp - INTERVAL 1 MICROSECOND",
        "run_id": run_id
    }
)

# 4. Handle NEW INSERTS
.whenNotMatchedInsert(
    values={
        # All payload columns
        "is_current": "Y",
        "effective_start_dttm": "source.processing_timestamp",
        "effective_end_dttm": NULL,
        "version_id": max(target.version_id) + 1  # Incremental versioning
    }
)

# 5. Post-merge: Insert NEW VERSIONS for changed records
# After step 3 retires old versions, we need to insert the NEW versions
# This is a separate INSERT operation, not part of MERGE
```

**Critical Implementation Detail:**
The merge has TWO phases:
1. **MERGE operation**: Retires old records, inserts brand new business keys
2. **POST-MERGE INSERT**: Inserts new versions for records that had hash changes

**Why two phases?** Delta MERGE doesn't support "update existing AND insert new version" in one operation. We must:
- First: Mark old version as `is_current='N'`
- Then: INSERT the new version as separate row

**Debugging SCD Issues:**
```sql
-- Check version history for a business key
SELECT 
    PHOENIX_ID, REPORT_ID, period_end_date,
    version_id, is_current, 
    effective_start_dttm, effective_end_dttm,
    record_hash, run_id
FROM idf_curated_dev.uspf.t_pf_base
WHERE PHOENIX_ID = 123456 
  AND REPORT_ID = 789
  AND period_end_date = '2024-12-31'
ORDER BY version_id;

-- Identify orphaned records (no current version)
SELECT PHOENIX_ID, REPORT_ID, period_end_date, COUNT(*) as versions
FROM idf_curated_dev.uspf.t_pf_base
GROUP BY PHOENIX_ID, REPORT_ID, period_end_date
HAVING SUM(CASE WHEN is_current = 'Y' THEN 1 ELSE 0 END) = 0;
```

---

## SQL Transformation Patterns & Best Practices

### Template Variable Substitution in SQL

**Available variables injected by `engine/processing_engine.py`:**

| Variable | Example Value | Usage |
|----------|---------------|-------|
| `${source_view}` | `pf_unified_pre` | Temp view registered from source DataFrame |
| `${source_table}` | `idf_curated_dev.uspf.t_dp_transaction_dp_load` | Fully qualified source table identifier |
| `${pipeline_run_id}` | `20241121143022` | Timestamp when pipeline started |
| `${dataset_run_id}` | `20241121143045` | Timestamp for this specific dataset |
| `${env}` | `dev` | Current environment |

**Example: `collapsed_base.sql`**
```sql
WITH enriched AS (
    SELECT
        load.PHOENIX_ID,
        load.SRC_DE_UNIQ_ID_TEXT,
        load.DP_VALUE,
        COALESCE(sched.schedules, ARRAY()) AS schedule_entry,
        COALESCE(comm.comments, ARRAY()) AS comment_entry,
        org.ORG_PRIMARY_NAME,
        map.ENT_MNEM_CD AS mapped_mnemonic
    FROM ${source_table} AS load  -- Resolves to pf_unified temp view
    LEFT JOIN pf_schedules AS sched
        ON sched.PHOENIX_ID = load.PHOENIX_ID
       AND sched.REPORT_ID = load.REPORT_ID
    LEFT JOIN pf_comments AS comm
        ON comm.PHOENIX_ID = load.PHOENIX_ID
    LEFT JOIN idf_${env}.finmaster.t_dim_source_data_element map
        ON map.UNIQUE_MNEMONIC_TEXT = load.SRC_DE_UNIQ_ID_TEXT
    LEFT JOIN pf_org_latest_filtered AS org
        ON org.PHOENIX_ID = load.PHOENIX_ID
)
SELECT
    PHOENIX_ID,
    REPORT_ID,
    -- Build the MAP structure: key = mnemonic, value = struct of all related data
    MAP_FROM_ENTRIES(
        FILTER(
            COLLECT_LIST(
                STRUCT(
                    mapped_mnemonic AS key,
                    NAMED_STRUCT(
                        'dp_value', DP_VALUE,
                        'collection_denom', COLLECTION_DENOM,
                        'schedules', schedule_entry,
                        'comments', comment_entry
                    ) AS value
                )
            ),
            entry -> entry.key IS NOT NULL  -- Filter out unmapped mnemonics
        )
    ) AS src_de_dp_map
FROM enriched
GROUP BY PHOENIX_ID, REPORT_ID, period_end_date, ...
```

### Critical SQL Patterns

**1. Computing Deterministic Hashes for SCD**
```sql
-- From pf_base.sql
SHA2(
    TO_JSON(
        NAMED_STRUCT(
            'PHOENIX_ID', enriched.PHOENIX_ID,
            'src_de_dp_map', enriched.src_de_dp_map,
            'org_sector', enriched.org_sector
            -- Include ALL payload fields that should trigger version changes
        )
    ),
    256
) AS record_hash
```
**Why TO_JSON?** Ensures consistent serialization of complex types (MAPs, ARRAYs, STRUCTs). Direct hashing of complex types can produce non-deterministic results.

**2. Building Nested JSON Payloads**
```sql
-- From pf_precedence_payload.sql
array_sort(
    collect_list(
        named_struct(
            'mnemonic', mnemonic_id,
            'currentValue', CAST(current_dp_value AS STRING),
            'schedule', transform(
                coalesce(schedules, array()),
                s -> named_struct(
                    'schedVal', CAST(s.schedule_value AS STRING),
                    'schedCode', s.schedule_name
                )
            )
        )
    ),
    (left, right) -> CASE 
        WHEN left.mnemonic < right.mnemonic THEN -1
        WHEN left.mnemonic > right.mnemonic THEN 1
        ELSE 0
    END
) AS fin_data_points
```
**Why array_sort?** Kafka consumers and change detection systems need deterministic JSON. Unsorted arrays cause false positive "changes".

**3. Lateral View Explode for MAP Processing**
```sql
SELECT
    h.PHOENIX_ID,
    kv.key AS mnemonic_id,
    kv.value.dp_value AS hist_dp_value,
    kv.value.schedules AS hist_schedules
FROM history h
LATERAL VIEW explode(map_entries(h.src_de_dp_map)) AS kv
WHERE kv.key IS NOT NULL
```
**Pattern:** Transform MAP<K,V> into rows of (key, value) pairs for aggregation/filtering.

**4. Window Functions for Deduplication**
```sql
-- From pf_precedence_payload.sql
WITH candidate_ranked AS (
    SELECT *,
        ROW_NUMBER() OVER (
            PARTITION BY PHOENIX_ID, period_end_date, STATEMENT_BASIS_NAME, REPORT_ID
            ORDER BY processing_timestamp DESC, run_id DESC
        ) AS rn
    FROM candidate_raw
)
SELECT * FROM candidate_ranked WHERE rn = 1
```
**Pattern:** When source has duplicates (e.g., multiple runs), use ROW_NUMBER to pick latest based on timestamp+run_id.

### Environment-Specific SQL Files

**Resolution order in `TransformationManager`:**
1. `{table}_{env}.sql` (e.g., `pf_base_dev.sql`)
2. `{table}.sql` (e.g., `pf_base.sql`)

**When to use env-specific files:**
- Dev/QA use smaller sample datasets or mocked reference tables
- Prod uses different partition strategies or optimizations
- SSD environments need different catalog references

**Example: `pf_base_dev.sql`**
```sql
-- Dev version: Add debug columns, limit row count
SELECT *, 'DEV_DEBUG' AS debug_flag
FROM (${source_view})
LIMIT 1000000
```

---

## Kafka & Postgres Output Contracts: The Serialization Layer

### Contract-Based Serialization Architecture

**Problem:** Different downstream systems expect different JSON shapes
- Kafka consumers expect event-oriented structure: `{eventName, eventDate, eventParticipantList: [{orgs: [...]}]}`
- Postgres expects record-oriented structure: `{dataset_type, sp_org_id, dataset: {...}}`

**Solution:** Contract definitions in `config/output_contracts.json` map DataFrame columns to output schema.

### Contract Structure

**Example from `output_contracts.json`:**
```json
{
  "contracts": {
    "pf_precedence": {
      "kafka": {
        "group": {
          "name": "orgs",
          "group_by": {
            "orgID": "CAST(PHOENIX_ID AS STRING)",
            "orgName": "ORG_PRIMARY_NAME",
            "sector": "SECTOR_NAME"
          },
          "fields": {
            "datasets": {"config": "datasets", "default": ["Prepared Financial"]},
            "changedPeriods": {
              "collect_list": {
                "struct": {
                  "vendorReportId": "CAST(REPORT_ID AS STRING)",
                  "periodEnddate": "date_format(period_end_date, 'MM-dd-yyyy')",
                  "action": "CASE WHEN delete_flag = 'Y' THEN 'delete' ELSE lower(ACTION) END"
                }
              }
            }
          }
        },
        "root": {
          "eventName": {"config": "eventName", "default": "NEW"},
          "eventDate": {"context": "pipeline_timestamp_iso"},
          "eventParticipantList": {
            "array": [{"orgs": {"group_ref": "orgs"}}]
          }
        }
      },
      "postgres": {
        "record": {
          "dataset_type": {"config": "dataset_type", "default": "Prepared Financial"},
          "fin_entity_id": "CAST(PHOENIX_ID AS STRING)",
          "vendor_report_id": "CAST(REPORT_ID AS STRING)",
          "period_end_date": "CAST(period_end_date AS DATE)",
          "dataset": "dataset_json",
          "current_ind": "CASE WHEN delete_flag = 'Y' THEN 'N' ELSE 'Y' END"
        }
      }
    }
  }
}
```

### Contract Rendering Process

**Kafka Contract Resolution (in `io/outputs/kafka_writer.py`):**
1. Dataset config specifies: `"serializer": "contract:pf_precedence"`
2. Writer loads contract: `contracts.pf_precedence.kafka`
3. **Group processing**: If contract has `group`, DataFrame is grouped by `group_by` fields
4. **Field mapping**: Each field resolves via:
   - `"config"`: Look up in `output_destinations.json` config block
   - `"default"`: Use literal value
   - `"context"`: Use runtime value (pipeline_run_id, timestamp, etc.)
   - Column expression: Evaluate Spark SQL expression against DataFrame
5. **Nested structures**: `collect_list`, `array`, `struct` directives build complex JSON
6. **Serialization**: Convert Spark Row to JSON string

**Example output to Kafka:**
```json
{
  "eventName": "NEW",
  "eventDate": "2024-11-21T14:30:22Z",
  "eventParticipantList": [
    {
      "orgs": [
        {
          "orgID": "123456",
          "orgName": "ABC Corporation",
          "sector": "Financial Services",
          "datasets": ["Prepared Financial"],
          "changedPeriods": [
            {
              "vendorReportId": "789",
              "periodEnddate": "12-31-2024",
              "stmtBasis": "AUDITED",
              "action": "update",
              "previousVendorReportID": "788"
            }
          ]
        }
      ]
    }
  ]
}
```

### Output Destinations Configuration

**`config/output_destinations.json`:**
```json
{
  "kafka": {
    "pf_precedence_changes": {
      "topic": "apd.prepared.financials.changes.${env}",
      "serializer": "contract:pf_precedence",
      "vault_secret_key": "kafka.orglinking.password",
      "producer_config": {
        "bootstrap_servers": "kafka-broker-${env}.internal:9092",
        "compression_type": "gzip",
        "max_request_size": 10485760
      },
      "debug_dry_run": false,
      "debug_print_messages": false,
      "debug_print_limit": 10,
      "log_capture_limit": 5
    }
  },
  "postgres": {
    "pf_precedence_changes": {
      "serializer": "contract:pf_precedence",
      "connection": {
        "host": "postgres-${env}.rds.amazonaws.com",
        "port": 5432,
        "database": "apddev",
        "schema": "apd",
        "table": "dataset",
        "vault_secret_key": "postgres.apd.credentials"
      },
      "upsert": {
        "conflict_columns": ["fin_entity_id", "vendor_report_id", "period_end_date", "statement_basis_name"],
        "update_columns": ["dataset", "current_ind", "dataset_version", "workflow_job_number"]
      },
      "batch_size": 1000,
      "debug_dry_run": false
    }
  }
}
```

**Dataset references config via `target.options.config_key`:**
```json
{
  "name": "pf_precedence_changes_kafka",
  "source": {"type": "view", "name": "pf_precedence_payload"},
  "apply_transformations": false,
  "target": {
    "type": "kafka",
    "name": "pf_precedence_changes",
    "config_key": "pf_precedence_changes"  // Lookup key in output_destinations.json
  }
}
```

### Debugging Kafka/Postgres Writes

**Enable dry-run mode:**
```json
// In output_destinations.json
{
  "kafka": {
    "pf_precedence_changes": {
      "debug_dry_run": true,       // Don't send to Kafka
      "debug_print_messages": true, // Print to console
      "debug_print_limit": 5       // Limit console output
    }
  }
}
```

**Check Kafka writer logs:**
```python
# In io/outputs/kafka_writer.py
logger.info("Kafka write completed", {
    "config_key": config_key,
    "topic": topic,
    "records_sent": sent,
    "payload_sample": payload_samples[:5]
})
```

**Query Postgres target to verify:**
```sql
-- Check recent inserts
SELECT 
    fin_entity_id, vendor_report_id, period_end_date,
    current_ind, delete_ind, workflow_job_number,
    create_datetime
FROM apddev.apd.dataset
WHERE create_datetime > CURRENT_TIMESTAMP - INTERVAL '1 hour'
ORDER BY create_datetime DESC
LIMIT 100;

-- Check for duplicates (upsert failures)
SELECT 
    fin_entity_id, vendor_report_id, period_end_date, statement_basis_name,
    COUNT(*) as versions
FROM apddev.apd.dataset
GROUP BY fin_entity_id, vendor_report_id, period_end_date, statement_basis_name
HAVING COUNT(*) > 1;
```

---

## Master-Level Debugging Techniques

### 1. End-to-End Pipeline Debugging Workflow

**Scenario: Dataset fails to write to Kafka/Postgres**

**Step 1: Identify failing dataset**
```bash
# Check Databricks job logs
# Look for: "Processing dataset 'pf_precedence_changes_kafka'"
# Error might be: "Kafka writer received a null DataFrame"
```

**Step 2: Trace backwards through dependencies**
```python
# Dataset dependency graph for pf_precedence_changes_kafka:
# pf_precedence_changes_kafka 
#   ← pf_precedence_payload (temp view)
#     ← pf_precedence_changes (temp view)
#       ← t_pf_base (Delta table)
#         ← collapsed_base (temp view)
#           ← pf_unified (temp view)
#             ← pf_dp_load_norm (temp view)
#               ← t_dp_transaction_dp_load (curated table)
```

**Step 3: Check each intermediate temp view**
```sql
-- In Databricks notebook or SQL editor
SELECT COUNT(*), COUNT(DISTINCT PHOENIX_ID) 
FROM pf_dp_load_norm;

SELECT * FROM pf_unified LIMIT 10;

SELECT 
    PHOENIX_ID, 
    REPORT_ID, 
    SIZE(src_de_dp_map) as mnemonic_count,
    MAP_KEYS(src_de_dp_map) as mnemonics
FROM collapsed_base 
LIMIT 10;
```

**Step 4: Validate SCD merge execution**
```sql
-- Check if t_pf_base has current records
SELECT 
    is_current,
    actv_ind,
    COUNT(*) as record_count
FROM idf_curated_dev.uspf.t_pf_base
GROUP BY is_current, actv_ind;

-- Verify run_id matches current pipeline run
SELECT run_id, COUNT(*) as records
FROM idf_curated_dev.uspf.t_pf_base
WHERE is_current = 'Y'
GROUP BY run_id
ORDER BY run_id DESC
LIMIT 10;
```

**Step 5: Inspect contract rendering**
```python
# Add debug logging in io/outputs/contract_renderer.py
logger.info("Rendering contract for %s rows", dataframe.count())
logger.info("Contract structure: %s", json.dumps(contract_def, indent=2))
logger.info("Sample row: %s", dataframe.first())
```

**Step 6: Enable dry-run mode**
```json
// Modify output_destinations.json
{
  "kafka": {
    "pf_precedence_changes": {
      "debug_dry_run": true,
      "debug_print_messages": true,
      "debug_print_limit": 3
    }
  }
}
```

### 2. Common Failure Patterns & Root Causes

**Pattern 1: "Schema definition missing for {table}"**
- **Cause:** `config/schemas/{catalog}/{schema}/{table}.json` doesn't exist
- **Fix:** Create schema file OR set `"skip_schema_validation": true` in dataset config
- **When to skip:** During development; always restore validation before production

**Pattern 2: "Source table {table} is empty"**
- **Cause:** Upstream curation didn't run (file type filtering) or no data in date range
- **Debug:**
  ```sql
  -- Check raw data
  SELECT run_id, COUNT(*) 
  FROM idf_raw_dev.uspf.t_dp_transaction_dp_load
  GROUP BY run_id
  ORDER BY run_id DESC
  LIMIT 10;
  
  -- Check curation log
  SELECT * FROM idf_curated_dev.uspf.run_log
  WHERE curated_table = 't_dp_transaction_dp_load'
  ORDER BY started_at DESC
  LIMIT 5;
  ```

**Pattern 3: "SCD merge inserted 0 records"**
- **Cause:** Hash values identical between runs (no actual changes)
- **Debug:**
  ```sql
  -- Compare hash distributions
  SELECT record_hash, COUNT(*) as occurrences
  FROM idf_curated_dev.uspf.t_pf_base
  WHERE PHOENIX_ID = {specific_id}
  GROUP BY record_hash;
  
  -- Check if source DataFrame had delete_flag='Y' for all rows
  SELECT delete_flag, COUNT(*)
  FROM {source_view}
  GROUP BY delete_flag;
  ```

**Pattern 4: "Kafka producer timeout"**
- **Cause:** Payload too large (>10MB default) or network issues
- **Debug:**
  ```python
  # Check payload sizes
  payload_sizes = [len(json.dumps(p)) for p in payloads[:100]]
  logger.info("Payload sizes: min=%d, max=%d, avg=%d", 
              min(payload_sizes), max(payload_sizes), sum(payload_sizes)/len(payload_sizes))
  ```
- **Fix:** Increase `max_request_size` in producer_config or reduce payload by filtering fields

**Pattern 5: "Postgres upsert conflict"**
- **Cause:** Conflict columns don't match unique constraint on target table
- **Debug:**
  ```sql
  -- Check Postgres constraints
  SELECT conname, contype, pg_get_constraintdef(oid)
  FROM pg_constraint
  WHERE conrelid = 'apd.dataset'::regclass;
  ```
- **Fix:** Align `upsert.conflict_columns` with actual DB constraint

### 3. Performance Optimization Strategies

**Optimization 1: Partition Pruning**
```sql
-- BAD: Full table scan
SELECT * FROM idf_curated_dev.uspf.t_pf_base
WHERE processing_timestamp > '2024-11-20';

-- GOOD: Partition filter (if partitioned by run_id or date)
SELECT * FROM idf_curated_dev.uspf.t_pf_base
WHERE run_id >= 20241120000000;
```

**Optimization 2: Broadcast Joins for Small Dimension Tables**
```sql
-- From collapsed_base.sql
FROM ${source_table} AS load
LEFT JOIN BROADCAST(pf_org_latest_filtered) AS org  -- Force broadcast
    ON org.PHOENIX_ID = load.PHOENIX_ID
```

**Optimization 3: Cache Intermediate Views**
```python
# In custom pipeline runner
intermediate_df = spark.table("pf_unified")
intermediate_df.cache()  # Cache if used multiple times downstream
```

**Optimization 4: Repartition Before Wide Transformations**
```sql
-- Add to transformation SQL
SELECT /*+ REPARTITION(200, PHOENIX_ID) */ 
    PHOENIX_ID, 
    MAP_FROM_ENTRIES(...) AS src_de_dp_map
FROM enriched
GROUP BY PHOENIX_ID, ...
```

### 4. Delta Table Maintenance

**Regular maintenance queries:**
```sql
-- Vacuum old versions (retain 7 days)
VACUUM idf_curated_dev.uspf.t_pf_base RETAIN 168 HOURS;

-- Optimize file layout
OPTIMIZE idf_curated_dev.uspf.t_pf_base
ZORDER BY (PHOENIX_ID, period_end_date);

-- Analyze table statistics for query planning
ANALYZE TABLE idf_curated_dev.uspf.t_pf_base COMPUTE STATISTICS FOR ALL COLUMNS;

-- Check table history
DESCRIBE HISTORY idf_curated_dev.uspf.t_pf_base LIMIT 20;

-- Restore to previous version (disaster recovery)
RESTORE TABLE idf_curated_dev.uspf.t_pf_base TO VERSION AS OF 42;
```

---

## Expanding the Pipeline: Step-by-Step Workflows

### Workflow 1: Add a New Transformation to Existing Dataset

**Scenario:** Add validation logic to `pf_base` to flag outlier values

**Step 1:** Create environment-specific SQL
```bash
# Create new file
touch data_services/my_data_incremental/config/transformations/pipelines/dp_to_adp/pf_base_dev.sql
```

**Step 2:** Implement validation logic
```sql
-- pf_base_dev.sql
WITH base_enriched AS (
    SELECT * FROM ${source_table}
),
validated AS (
    SELECT 
        *,
        CASE 
            WHEN SIZE(src_de_dp_map) = 0 THEN 'EMPTY_MAP'
            WHEN org_currency_code IS NULL THEN 'MISSING_CURRENCY'
            WHEN priority_ordr_num > 100 THEN 'INVALID_PRECEDENCE'
            ELSE NULL
        END AS validation_warning
    FROM base_enriched
)
SELECT * FROM validated
```

**Step 3:** Add validation warning handling in dataset config
```json
{
  "name": "pf_base",
  "source": {"type": "view", "name": "collapsed_base"},
  "target": {
    "type": "delta",
    "catalog": "idf_curated_${env}",
    "schema": "uspf",
    "table": "t_pf_base",
    "skip_schema_validation": false,  // Enforce schema
    "create_if_missing": true
  },
  "transformation": {
    "catalog": "pipelines",
    "schema": "dp_to_adp",
    "table": "pf_base"  // Will load pf_base_dev.sql in dev environment
  },
  "scd": { /* existing config */ }
}
```

**Step 4:** Update schema to include new column
```json
// config/schemas/idf_curated/uspf/t_pf_base.json
{
  "schema": [
    {"name": "PHOENIX_ID", "type": "string", "nullable": false},
    {"name": "validation_warning", "type": "string", "nullable": true},
    // ... other fields
  ]
}
```

**Step 5:** Test in dev environment
```bash
poetry run mydata_incremental_dp \
    --env dev \
    --process_mode single_date \
    --date 2024-11-21 \
    --s3_bucket iflux-filestore \
    --output_dir dev/phoenixdp-filestore/curated-data/ \
    --pipeline_config pipeline_dp_to_adp.json \
    --log_level DEBUG
```

**Step 6:** Verify output
```sql
SELECT validation_warning, COUNT(*) as record_count
FROM idf_curated_dev.uspf.t_pf_base
WHERE run_id = (SELECT MAX(run_id) FROM idf_curated_dev.uspf.t_pf_base)
GROUP BY validation_warning;
```

### Workflow 2: Add a Completely New Dataset to Pipeline

**Scenario:** Create `pf_precedence_summary` aggregating changes by sector

**Step 1:** Design data flow
```
Source: t_pf_base (Delta table)
    ↓
Transformation: pf_precedence_summary.sql (aggregate by sector, period)
    ↓
Target: Temp view for ad-hoc queries OR Delta table for persistence
```

**Step 2:** Create SQL transformation
```sql
-- config/transformations/pipelines/dp_to_adp/pf_precedence_summary.sql
WITH latest_changes AS (
    SELECT 
        SECTOR_NAME,
        period_end_date,
        STATEMENT_BASIS_NAME,
        CASE 
            WHEN delete_flag = 'Y' THEN 'DELETE'
            WHEN is_current = 'Y' AND version_id = 1 THEN 'INSERT'
            WHEN is_current = 'Y' AND version_id > 1 THEN 'UPDATE'
            ELSE 'UNKNOWN'
        END AS change_type,
        COUNT(DISTINCT PHOENIX_ID) as entity_count,
        COUNT(*) as record_count
    FROM ${source_table}
    WHERE run_id = '${dataset_run_id}'  // Only latest run
    GROUP BY SECTOR_NAME, period_end_date, STATEMENT_BASIS_NAME, change_type
)
SELECT 
    SECTOR_NAME,
    period_end_date,
    STATEMENT_BASIS_NAME,
    SUM(CASE WHEN change_type = 'INSERT' THEN entity_count ELSE 0 END) as inserts,
    SUM(CASE WHEN change_type = 'UPDATE' THEN entity_count ELSE 0 END) as updates,
    SUM(CASE WHEN change_type = 'DELETE' THEN entity_count ELSE 0 END) as deletes,
    SUM(record_count) as total_records,
    '${pipeline_run_id}' AS pipeline_run_id,
    CURRENT_TIMESTAMP() AS summary_timestamp
FROM latest_changes
GROUP BY SECTOR_NAME, period_end_date, STATEMENT_BASIS_NAME
```

**Step 3:** Add dataset to pipeline config
```json
// Add AFTER pf_base in pipeline_dp_to_adp.json
{
  "name": "pf_precedence_summary",
  "source": {
    "type": "table",
    "catalog": "idf_curated_${env}",
    "schema": "uspf",
    "table": "t_pf_base"
  },
  "target": {
    "type": "delta",
    "catalog": "idf_curated_${env}",
    "schema": "uspf",
    "table": "t_pf_precedence_summary",
    "mode": "append",
    "create_if_missing": true,
    "skip_schema_validation": false
  },
  "transformation": {
    "catalog": "pipelines",
    "schema": "dp_to_adp",
    "table": "pf_precedence_summary"
  }
}
```

**Step 4:** Create schema definition
```json
// config/schemas/idf_curated/uspf/t_pf_precedence_summary.json
{
  "schema": [
    {"name": "SECTOR_NAME", "type": "string", "nullable": true},
    {"name": "period_end_date", "type": "date", "nullable": true},
    {"name": "STATEMENT_BASIS_NAME", "type": "string", "nullable": true},
    {"name": "inserts", "type": "long", "nullable": true},
    {"name": "updates", "type": "long", "nullable": true},
    {"name": "deletes", "type": "long", "nullable": true},
    {"name": "total_records", "type": "long", "nullable": true},
    {"name": "pipeline_run_id", "type": "string", "nullable": true},
    {"name": "summary_timestamp", "type": "timestamp", "nullable": true}
  ]
}
```

**Step 5:** Run and verify
```bash
# Execute pipeline
poetry run mydata_incremental_dp --env dev --pipeline_config pipeline_dp_to_adp.json ...

# Query results
SELECT * FROM idf_curated_dev.uspf.t_pf_precedence_summary
ORDER BY summary_timestamp DESC
LIMIT 20;
```

### Workflow 3: Add New Kafka Topic Consumer

**Scenario:** Publish summarized metrics to a new Kafka topic for real-time monitoring

**Step 1:** Define contract
```json
// Add to output_contracts.json
{
  "contracts": {
    "pf_summary_metrics": {
      "kafka": {
        "root": {
          "metricType": {"config": "metricType", "default": "PrecedenceSummary"},
          "sector": "SECTOR_NAME",
          "periodEndDate": "date_format(period_end_date, 'yyyy-MM-dd')",
          "metrics": {
            "struct": {
              "inserts": "inserts",
              "updates": "updates",
              "deletes": "deletes",
              "totalRecords": "total_records"
            }
          },
          "timestamp": "date_format(summary_timestamp, \"yyyy-MM-dd'T'HH:mm:ss'Z'\")"
        }
      }
    }
  }
}
```

**Step 2:** Configure destination
```json
// Add to output_destinations.json
{
  "kafka": {
    "pf_summary_metrics": {
      "topic": "apd.prepared.financials.metrics.${env}",
      "serializer": "contract:pf_summary_metrics",
      "vault_secret_key": "kafka.metrics.password",
      "producer_config": {
        "bootstrap_servers": "kafka-broker-${env}.internal:9092",
        "compression_type": "snappy"
      },
      "debug_dry_run": false,
      "log_capture_limit": 10
    }
  }
}
```

**Step 3:** Add dataset to pipeline
```json
{
  "name": "pf_precedence_summary_kafka",
  "source": {
    "type": "table",
    "catalog": "idf_curated_${env}",
    "schema": "uspf",
    "table": "t_pf_precedence_summary"
  },
  "apply_transformations": false,  // Use raw data from table
  "target": {
    "type": "kafka",
    "name": "pf_summary_metrics",
    "config_key": "pf_summary_metrics"
  }
}
```

**Step 4:** Test with dry-run
```json
// Temporarily enable in output_destinations.json
{
  "kafka": {
    "pf_summary_metrics": {
      "debug_dry_run": true,
      "debug_print_messages": true,
      "debug_print_limit": 5
    }
  }
}
```

---

## Edge Cases & Advanced Conditional Logic

### 1. Conditional Processing by File Type

**The Problem:** S3 files arrive in different combinations:
- Org-only files (org structure changes)
- DP Load + Schedules + Comments (full financial data)
- Mixed scenarios

**The Solution (in `main_dptoapd.py`):**
```python
# After raw ingestion, determine which file types were processed
files_before_ingestion = get_current_file_processing_log(spark, config)
files_after_ingestion = get_current_file_processing_log(spark, config)
new_files = files_after_ingestion - files_before_ingestion
processed_file_types = determine_file_types_from_files(new_files)

# Conditionally execute curation
if "dp_load" in processed_file_types:
    load_curated(spark, config_data={...}, env=self.env)
    logger.info("CURATED DP LOAD DP COMPLETED")
else:
    logger.info("SKIPPING DP LOAD DP CURATION - No DP_LOAD files processed")

if "comments" in processed_file_types:
    load_curated(spark, config_data={...}, env=self.env)
else:
    logger.info("SKIPPING DP COMMENTS DP CURATION - No COMMENTS files processed")
```

**Why This Matters:**
- Org-only file arrivals should NOT trigger DP Load/Comments/Schedules curation
- Running empty curation creates unnecessary Delta commits and inflates version history
- Pipeline efficiency: Skip expensive transformations when source data is empty

**File type detection logic:**
```python
def determine_file_types_from_files(file_set):
    """Extract file types from S3 file names"""
    file_types = set()
    for file_name in file_set:
        if 'dp_load' in file_name.lower():
            file_types.add('dp_load')
        elif 'schedule' in file_name.lower():
            file_types.add('schedules')
        elif 'comment' in file_name.lower():
            file_types.add('comments')
        elif 'org' in file_name.lower():
            file_types.add('org')
    return file_types
```

### 2. Handling SCD Merges with No Changes

**Scenario:** Pipeline runs but all source data has identical hashes to existing records

**Expected Behavior:**
```python
# In engine/processing_engine.py
scd_df = working_df.cache()
scd_df.write.format("noop").mode("overwrite").save()  # Force evaluation

count_before = self.spark.table(table_fqn).filter("is_current = 'Y'").count()
manager.merge(scd_df, run_id, effective_col, delete_col)
count_after = self.spark.table(table_fqn).filter("is_current = 'Y'").count()

logger.info("SCD merge completed: before=%d, after=%d, delta=%d", 
            count_before, count_after, count_after - count_before)
```

**Delta merge result:**
```json
{
  "num_affected_rows": 0,
  "num_updated_rows": 0,
  "num_deleted_rows": 0,
  "num_inserted_rows": 0
}
```

**This is NORMAL and EXPECTED** - no records changed, no versions created.

### 3. Read Mode: `latest` vs `full`

**In dataset source config:**
```json
{
  "source": {
    "type": "table",
    "catalog": "idf_curated_${env}",
    "schema": "uspf",
    "table": "t_dp_transaction_dp_load",
    "read_mode": "latest"  // Only read rows with max(run_id)
  }
}
```

**Implementation in `config_pipeline_runner.py`:**
```python
def _get_latest_data(df):
    if "run_id" not in df.columns:
        logger.warning("Requested latest read mode but dataframe has no run_id column")
        return df
    max_row = df.select(F.max("run_id").alias("max_run_id")).first()
    latest_run_id = max_row["max_run_id"]
    return df.filter(df.run_id == latest_run_id)
```

**When to use `latest`:**
- Incremental processing where you only want current run's data
- Avoiding duplicate processing of historical records

**When to use `full`:**
- Rebuilding aggregations across all history
- Cross-run analytics

### 4. Environment-Specific SSD Handling

**The SSD Exception Logic:**
```python
# From config/config_loader.py
def get_ssd_exceptions(self):
    env_lower = self.env.casefold() if self.env else ""
    if "ssd" in env_lower:
        base = self.env.replace("ssd", "")  # ssddev → dev
        return {
            "bucket_env": base,              # Used for S3 bucket names
            "ssd_opt_path_env": f"/{self.env}",  # Used for S3 path prefixes
            "bootstrap_env": base,           # Used for shared config lookups
        }
    else:
        # Special bootstrap mappings for non-SSD environments
        if env_lower == "uat":
            bootstrap_env = "qa"
        elif env_lower in ["prod", "dr"]:
            bootstrap_env = "pde"
        else:
            bootstrap_env = self.env
        return {
            "bucket_env": self.env,
            "ssd_opt_path_env": "",
            "bootstrap_env": bootstrap_env,
        }
```

**Real-world example:**
```json
// lineage_config_dp.json with template variables
{
  "storage": {
    "stage_s3_bucket": "spr-idf-${bucket_env}-platform-stage",
    "stage_s3_prefix": "data/phoenix/mydata_elt${ssd_opt_path_env}/dp/kafka_messages/"
  }
}

// Resolved for env=ssddev:
{
  "storage": {
    "stage_s3_bucket": "spr-idf-dev-platform-stage",  // bucket_env=dev
    "stage_s3_prefix": "data/phoenix/mydata_elt/ssddev/dp/kafka_messages/"  // ssd_opt_path_env=/ssddev
  }
}
```

**Why This Complexity?**
- SSD environments share infrastructure with base environments (dev, qa) for cost savings
- But data must be isolated in separate S3 paths
- Bootstrap configs (reference data, dimension tables) are shared

---

## Code Conventions & Best Practices

### Logging Standards

**Module-level logger initialization:**
```python
import logging
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
handler = logging.StreamHandler()
formatter = logging.Formatter('[%(asctime)s] %(levelname)s: %(message)s')
handler.setFormatter(formatter)
logger.addHandler(handler)
```

**Log level conventions:**
```python
logger.info("STARTING DP LOAD DP CURATION")  # UPPERCASE for major milestones
logger.info("Processing dataset '%s'", execution.name)  # Standard info
logger.warning("Requested latest read mode but dataframe has no run_id column")
logger.error("Failed to process dataset '%s': %s", name, str(e))
logger.debug("Transformation applied using view %s", source_view)
```

**Structured logging for complex events:**
```python
from data_services.my_data_incremental.transformation.utils import log_structured

log_structured(logger, "Kafka write completed", {
    "config_key": config_key,
    "topic": topic,
    "records_sent": sent,
    "dataset": target.table
})
```

### Error Handling Patterns

**Always use context managers for Spark operations:**
```python
try:
    working_df = self._apply_transformations(execution.dataframe, execution.target, execution.context)
    summary = DatasetProcessingSummary(name=execution.name, ...)
    return summary
except Exception as e:
    logger.error("Failed to process dataset '%s': %s", execution.name, str(e))
    logger.debug("Traceback:", exc_info=True)  # Only print traceback in debug mode
    raise
finally:
    # Cleanup temp views
    if temp_view_name and self.spark.catalog.tableExists(temp_view_name):
        self.spark.catalog.dropTempView(temp_view_name)
```

**Graceful degradation for non-critical failures:**
```python
def log_run_entry(spark, run_id, ...):
    try:
        run_log_df.write.format("delta").mode("append").saveAsTable(run_log_table)
        logger.info("Run ID %s logged successfully", run_id)
        return True
    except Exception as e:
        logger.warning("Failed to log run entry: %s", str(e))
        return False  # Don't fail entire pipeline for logging issues
```

### Schema Validation Philosophy

**Production standard:**
```json
{
  "target": {
    "type": "delta",
    "skip_schema_validation": false,  // ALWAYS validate in prod
    "create_if_missing": false        // NEVER auto-create in prod
  }
}
```

**Development flexibility:**
```json
{
  "target": {
    "type": "delta",
    "skip_schema_validation": true,   // OK for rapid iteration
    "create_if_missing": true         // OK for dev/testing
  }
}
```

**When to skip validation:**
- Prototyping new transformations
- Testing with synthetic data
- Schema files not yet created

**When to ENFORCE validation:**
- Before merging to main branch
- All QA/UAT/Prod environments
- Any dataset that feeds downstream consumers

---

## Common Pitfalls & How to Avoid Them

### Pitfall 1: Temp View Name Collisions

**Problem:**
```json
// BAD: Two datasets with same temp view name
{"name": "pf_base_stage1", "target": {"type": "temp_view", "name": "staging"}},
{"name": "pf_base_stage2", "target": {"type": "temp_view", "name": "staging"}}  // COLLISION!
```

**Solution:** Use unique, descriptive temp view names
```json
{"name": "pf_base_stage1", "target": {"type": "temp_view", "name": "pf_base_stage1"}},
{"name": "pf_base_stage2", "target": {"type": "temp_view", "name": "pf_base_stage2"}}
```

### Pitfall 2: Forgetting to Cache Before Multiple Reads

**Problem:**
```python
# BAD: Recomputes expensive transformation multiple times
df = spark.table("collapsed_base")  // Expensive GROUP BY with MAP_FROM_ENTRIES
count = df.count()  // Computes full plan
first_row = df.first()  // Recomputes full plan again
```

**Solution:**
```python
# GOOD: Cache intermediate results
df = spark.table("collapsed_base").cache()
count = df.count()  // Triggers computation and caches
first_row = df.first()  // Reads from cache
```

### Pitfall 3: Incorrect Hash Computation Leading to False Changes

**Problem:**
```sql
-- BAD: Non-deterministic hash due to unordered map iteration
SHA2(CAST(src_de_dp_map AS STRING), 256) AS record_hash
```

**Solution:**
```sql
-- GOOD: Serialize to JSON for deterministic ordering
SHA2(TO_JSON(src_de_dp_map), 256) AS record_hash
```

### Pitfall 4: SCD Merge on Non-Delta Table

**Problem:**
```json
{
  "target": {"type": "temp_view", "name": "staging"},
  "scd": {"type": "type2", "business_keys": ["id"]}  // ERROR: SCD requires Delta
}
```

**Error:** `ValueError: SCD processing is only supported for delta targets`

**Solution:** Change target type to `delta` or remove `scd` config

### Pitfall 5: Missing Run ID in Latest Mode

**Problem:**
```json
{
  "source": {
    "type": "table",
    "table": "t_external_feed",  // Table WITHOUT run_id column
    "read_mode": "latest"
  }
}
```

**Warning:** `Requested latest read mode but dataframe has no run_id column; returning full dataset`

**Solution:** Ensure source table has `run_id` column OR use `read_mode: "full"`

---

## Quick Reference Guide

### Critical File Paths

**Pipeline Entry Points:**
- `data_services/my_data_incremental/main_dptoapd.py` - DP pipeline orchestrator
- `data_services/my_data_incremental/main.py` - Standard MyData pipeline

**Core Engine:**
- `data_services/my_data_incremental/engine/processing_engine.py` - Dataset execution engine
- `data_services/my_data_incremental/engine/transformation_manager.py` - SQL template resolver
- `data_services/my_data_incremental/pipelines/config_pipeline_runner.py` - Pipeline executor

**Configuration:**
- `data_services/my_data_incremental/config/config_loader.py` - Template variable substitution
- `data_services/my_data_incremental/config/pipeline_dp_to_adp.json` - DP→ADP pipeline definition
- `data_services/my_data_incremental/config/lineage_config_dp.json` - DP pipeline metadata
- `data_services/my_data_incremental/config/output_destinations.json` - Kafka/Postgres configs
- `data_services/my_data_incremental/config/output_contracts.json` - Serialization contracts

**Transformations:**
- `data_services/my_data_incremental/config/transformations/pipelines/dp_to_adp/*.sql` - SQL templates
- `data_services/my_data_incremental/config/schemas/{catalog}/{schema}/{table}.json` - Schema definitions

**Outputs:**
- `data_services/my_data_incremental/io/outputs/kafka_writer.py` - Kafka publishing
- `data_services/my_data_incremental/io/outputs/postgres_writer.py` - Postgres persistence
- `data_services/my_data_incremental/io/outputs/contract_renderer.py` - Contract-based serialization

**SCD & Curation:**
- `data_services/my_data_incremental/prepared_financials/scd.py` - SCD Type 2 merge logic
- `data_services/my_data_incremental/curation/load_curated_table.py` - Raw→Curated transformation

### Essential CLI Commands

**Run DP pipeline with specific date:**
```bash
poetry run mydata_incremental_dp \
    --env dev \
    --process_mode single_date \
    --date 2024-11-21 \
    --s3_bucket iflux-filestore \
    --output_dir dev/phoenixdp-filestore/curated-data/ \
    --pipeline_config pipeline_dp_to_adp.json \
    --log_level INFO
```

**Run with date range:**
```bash
poetry run mydata_incremental_dp \
    --env qa \
    --process_mode date_range \
    --process_last_n_days 7 \
    --s3_bucket iflux-filestore \
    --output_dir qa/phoenixdp-filestore/curated-data/ \
    --pipeline_config pipeline_dp_to_adp.json
```

**Force reprocess existing files:**
```bash
poetry run mydata_incremental_dp \
    --env dev \
    --process_mode single_date \
    --date 2024-11-21 \
    --force_reprocess true \
    --s3_bucket iflux-filestore \
    --output_dir dev/phoenixdp-filestore/curated-data/
```

**Table refresh (standalone job):**
```bash
poetry run mydata_table_refresh \
    --env dev \
    --process_mode unprocessed_files \
    --s3_bucket iflux-filestore \
    --output_dir dev/phoenixdp-filestore/curated-data/
```

**Create static tables (one-time setup):**
```bash
poetry run mydata_table_creator --env dev
```

### Essential SQL Queries

**Check pipeline execution history:**
```sql
SELECT 
    pipeline_run_id,
    name,
    status,
    started_at,
    completed_at,
    TIMESTAMPDIFF(SECOND, started_at, completed_at) as duration_seconds,
    records_processed
FROM idf_curated_dev.uspf.dp_to_apd_log
WHERE started_at > CURRENT_TIMESTAMP - INTERVAL 24 HOURS
ORDER BY started_at DESC;
```

**Verify SCD current records:**
```sql
SELECT 
    PHOENIX_ID,
    REPORT_ID,
    period_end_date,
    version_id,
    is_current,
    effective_start_dttm,
    effective_end_dttm,
    run_id
FROM idf_curated_dev.uspf.t_pf_base
WHERE PHOENIX_ID = 123456
  AND period_end_date = '2024-12-31'
ORDER BY version_id DESC;
```

**Check file processing log:**
```sql
SELECT 
    file_name,
    file_date,
    processing_status,
    processing_timestamp,
    run_id
FROM idf_curated_dev.uspf.dp_file_processing_log
WHERE file_date = '2024-11-21'
ORDER BY processing_timestamp DESC;
```

**Audit curation runs:**
```sql
SELECT 
    run_id,
    curated_table,
    status,
    raw_incr_count,
    raw_incr_key_count,
    curated_full_count,
    updated_rows,
    inserted_rows,
    started_at,
    completed_at
FROM idf_curated_dev.uspf.run_log
WHERE started_at > CURRENT_DATE - INTERVAL 7 DAYS
ORDER BY started_at DESC;
```

**Find datasets with validation warnings:**
```sql
SELECT 
    PHOENIX_ID,
    REPORT_ID,
    validation_warning,
    COUNT(*) as occurrences
FROM idf_curated_dev.uspf.t_pf_validation_warnings
WHERE run_id = (SELECT MAX(run_id) FROM idf_curated_dev.uspf.t_pf_validation_warnings)
GROUP BY PHOENIX_ID, REPORT_ID, validation_warning
HAVING COUNT(*) > 10
ORDER BY occurrences DESC;
```

### Databricks Job Execution

**Trigger job manually via API:**
```bash
# Using Databricks CLI
databricks jobs run-now --job-id 12345

# Using curl
curl -X POST https://spg-ratings-idf-dev.cloud.databricks.com/api/2.0/jobs/run-now \
  -H "Authorization: Bearer $DATABRICKS_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"job_id": 12345}'
```

**Check job run status:**
```bash
databricks runs get --run-id 67890
```

**View job run logs:**
```bash
databricks runs get-output --run-id 67890
```

### Environment Variables

**Required for local execution:**
```bash
export SPR_APP_SECRET_HC_VAULT_BASE_URL=https://sm-vault.dev.spratingsvpc.com
export SPR_APP_SECRET_HC_VAULT_TOKEN=<vault_token>
export DATABRICKS_HOST=https://spg-ratings-idf-dev.cloud.databricks.com
export DATABRICKS_TOKEN=<databricks_token>
```

**In Databricks job config (job/*.json):**
```json
{
  "spark_env_vars": {
    "SPR_APP_SECRET_HC_VAULT_BASE_URL": "{{secrets/vault/base_url}}",
    "SPR_APP_SECRET_HC_VAULT_TOKEN": "{{secrets/vault/token}}"
  }
}
```

---

## Mastery Checklist: Are You a Pipeline Expert?

**Level 1: Understanding (Foundation)**
- [ ] Explain the difference between DP and ADP in the data flow
- [ ] Trace a dataset from S3 file arrival to Kafka publication
- [ ] Identify which datasets are temp views vs Delta tables in `pipeline_dp_to_adp.json`
- [ ] Describe the SSD environment exception logic
- [ ] Explain why `collapsed_base.sql` uses `MAP_FROM_ENTRIES`

**Level 2: Debugging (Practitioner)**
- [ ] Given "Schema definition missing for t_pf_summary", locate the fix
- [ ] Debug why SCD merge inserted 0 records when data clearly changed
- [ ] Trace temp view dependencies to find which SQL is causing a runtime error
- [ ] Identify why Kafka messages are malformed (wrong contract or config)
- [ ] Fix a broken conditional curation (file type detection issue)

**Level 3: Optimization (Advanced)**
- [ ] Reduce `collapsed_base.sql` query time by 50% using partition pruning
- [ ] Optimize SCD merge to handle 10M row updates without timeout
- [ ] Design index strategy for Postgres upsert target to minimize conflicts
- [ ] Implement incremental processing to avoid recomputing unchanged aggregations
- [ ] Add Z-ORDERING to Delta tables for query performance

**Level 4: Expansion (Expert)**
- [ ] Add new dataset with custom aggregation and publish to both Kafka & Postgres
- [ ] Implement data quality validation layer with quarantine table
- [ ] Design recovery workflow for failed pipeline runs (idempotency)
- [ ] Create monitoring dashboard by extracting metrics from `dp_to_apd_log`
- [ ] Extend contract renderer to support new output format (e.g., Avro, Parquet)

**Level 5: Architecture (Master)**
- [ ] Design second pipeline (e.g., ADP to downstream analytics mart)
- [ ] Implement multi-tenancy: isolate pipelines for different business units
- [ ] Create generic dataset factory to auto-generate configs from metadata
- [ ] Build testing framework for SQL transformations (unit + integration tests)
- [ ] Architect disaster recovery: cross-region replication & point-in-time restore

---

## Final Wisdom: The Zen of Config-Driven Pipelines

**1. Configuration is Code**
Treat JSON configs with same rigor as Python code: version control, code review, testing.

**2. Fail Fast, Fail Loud**
Schema validation, constraint checks, and early error detection prevent silent data corruption.

**3. Idempotency is Non-Negotiable**
Every pipeline run should be safely re-runnable without duplicating data or corrupting state.

**4. Observability Beats Debuggability**
Comprehensive logging, metrics, and audit tables are 10x more valuable than breakpoint debugging.

**5. The Map is Not the Territory**
Documentation describes intent; the code (Python + SQL) is ground truth. When in doubt, read the source.

---

## Resources & Further Learning

**Internal Documentation:**
- `docs/processing_engine.md` - Comprehensive transformation guide with examples
- Databricks workspace notebooks: `/Shared/mydata-curation-service/`

**External References:**
- Delta Lake Documentation: https://docs.delta.io/
- PySpark SQL Functions: https://spark.apache.org/docs/latest/api/python/reference/pyspark.sql/functions.html
- Databricks Asset Bundles: https://docs.databricks.com/dev-tools/bundles/

**Team Contacts:**
- Epsilon Team: epsilonteam@spglobal.com
- Aurora Team (Downstream consumers): aurorateam@spglobal.com

---

**You are now a master of this pipeline architecture. Go forth and build legendary data transformations! 🚀**

