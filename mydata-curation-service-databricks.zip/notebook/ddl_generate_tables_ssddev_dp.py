# COMMAND ----------

%sql


CREATE TABLE IF NOT EXISTS idf_raw_ssddev.uspf.t_dp_transaction_dp_load (

            PHOENIX_ID STRING,
            PHOENIX_PLAN_ID STRING,
            SECTOR_NAME STRING,
            CORE_ORG_ID STRING,
            PER_TYPE_NAME STRING,
            MEASURE_DATE STRING,
            PERIOD_END_DATE STRING,
            PERIOD_MONTHS STRING,
            STATEMENT_BASIS_NAME STRING,
            ACCOUNT_BASIS_NAME STRING,
            APR_ACCEPTABLE STRING,
            SOURCE_FILE_CREATE_DATE STRING,
            SRC_DE_UNIQ_ID_TEXT STRING,
            DP_VALUE STRING,
            REPORT_ID STRING,
            DELETE_FLAG STRING,
            ACTION STRING,
            COLLECTION_DENOM STRING,
            processing_timestamp TIMESTAMP,
            source_file STRING,
            source_bucket STRING,
            process_date STRING,
            created_at TIMESTAMP,
            updated_at TIMESTAMP
        
)
USING DELTA
PARTITIONED BY (SECTOR_NAME, process_date)
LOCATION 's3://spr-idf-dev-platform-landing/catalog/uspf/ssddev_t_dp_transaction_dp_load_v1'
TBLPROPERTIES (
  'delta.checkpoint.writeStatsAsJson' = 'false',
  'delta.checkpoint.writeStatsAsStruct' = 'true',
  'delta.columnMapping.mode' = 'name',
  'delta.feature.appendOnly' = 'supported',
  'delta.feature.invariants' = 'supported',
  'delta.minReaderVersion' = '1',
  'delta.minWriterVersion' = '2',
  'delta.feature.allowColumnDefaults' = 'supported'
);



# COMMAND ----------

%sql


CREATE TABLE IF NOT EXISTS idf_raw_ssddev.uspf.t_dp_transaction_comments (

            PHOENIX_ID STRING,
            PHOENIX_PLAN_ID STRING,
            SECTOR_NAME STRING,
            CORE_ORG_ID STRING,
            PER_TYPE_NAME STRING,
            MEASURE_DATE STRING,
            PERIOD_END_DATE STRING,
            PERIOD_MONTHS STRING,
            STATEMENT_BASIS_NAME STRING,
            ACCOUNT_BASIS_NAME STRING,
            APR_ACCEPTABLE STRING,
            SOURCE_FILE_CREATE_DATE STRING,
            SRC_DE_UNIQ_ID_TEXT STRING,
            REPORT_ID STRING,
            COMMENTS STRING,
            COMMENT_BY STRING,
            COMMENT_DATE_TIME STRING,
            processing_timestamp TIMESTAMP,
            source_file STRING,
            source_bucket STRING,
            process_date STRING,
            created_at TIMESTAMP,
            updated_at TIMESTAMP
        
)
USING DELTA
PARTITIONED BY (SECTOR_NAME, process_date)
LOCATION 's3://spr-idf-dev-platform-landing/catalog/uspf/ssddev_t_dp_transaction_comments_v1'
TBLPROPERTIES (
  'delta.checkpoint.writeStatsAsJson' = 'false',
  'delta.checkpoint.writeStatsAsStruct' = 'true',
  'delta.columnMapping.mode' = 'name',
  'delta.feature.appendOnly' = 'supported',
  'delta.feature.invariants' = 'supported',
  'delta.minReaderVersion' = '1',
  'delta.minWriterVersion' = '2',
  'delta.feature.allowColumnDefaults' = 'supported'
);


# COMMAND ----------

%sql

CREATE TABLE IF NOT EXISTS idf_raw_ssddev.uspf.t_dp_transaction_schedules (

            PHOENIX_ID STRING,
            PHOENIX_PLAN_ID STRING,
            SECTOR_NAME STRING,
            CORE_ORG_ID STRING,
            PER_TYPE_NAME STRING,
            MEASURE_DATE STRING,
            PERIOD_END_DATE STRING,
            PERIOD_MONTHS STRING,
            STATEMENT_BASIS_NAME STRING,
            ACCOUNT_BASIS_NAME STRING,
            APR_ACCEPTABLE STRING,
            SOURCE_FILE_CREATE_DATE STRING,
            SRC_DE_UNIQ_ID_TEXT STRING,
            REPORT_ID STRING,
            SCHEDULE_NAME STRING,
            SCHEDULE_VALUE STRING,
            ACTION STRING,
            SCHEDULE_FRMLA_TEXT STRING,
            VALUE STRING,
            ORDER_ID STRING,
            processing_timestamp TIMESTAMP,
            source_file STRING,
            source_bucket STRING,
            process_date STRING,
            created_at TIMESTAMP,
            updated_at TIMESTAMP
        
)
USING DELTA
PARTITIONED BY (SECTOR_NAME, process_date)
LOCATION 's3://spr-idf-dev-platform-landing/catalog/uspf/ssddev_t_dp_transaction_schedules_v1'
TBLPROPERTIES (
  'delta.checkpoint.writeStatsAsJson' = 'false',
  'delta.checkpoint.writeStatsAsStruct' = 'true',
  'delta.columnMapping.mode' = 'name',
  'delta.feature.appendOnly' = 'supported',
  'delta.feature.invariants' = 'supported',
  'delta.minReaderVersion' = '1',
  'delta.minWriterVersion' = '2',
  'delta.feature.allowColumnDefaults' = 'supported'
);


# COMMAND ----------

%sql



CREATE TABLE IF NOT EXISTS idf_raw_ssddev.uspf.t_dp_transaction_org (

            PHOENIX_ID STRING,
            SECTOR STRING,
            CORE_ORG_ID STRING,
            ORG_PRIMARY_NAME STRING,
            STATE STRING,
            SOURCE_FILE_CREATE_DATE STRING,
            COUNTRY_CODE STRING,
            CURRENCY_CODE STRING,
            DEAL_NAME_DESCRIPTOR STRING,
            FIN_REVENUE_TYPE STRING,
            FIN_REVENUE_SUBTYPE STRING,
            FYE STRING,
            processing_timestamp TIMESTAMP,
            source_file STRING,
            source_bucket STRING,
            process_date STRING,
            created_at TIMESTAMP,
            updated_at TIMESTAMP
        
)
USING DELTA
PARTITIONED BY (SECTOR, process_date)
LOCATION 's3://spr-idf-dev-platform-landing/catalog/uspf/ssddev_t_dp_transaction_org_v1'
TBLPROPERTIES (
  'delta.checkpoint.writeStatsAsJson' = 'false',
  'delta.checkpoint.writeStatsAsStruct' = 'true',
  'delta.columnMapping.mode' = 'name',
  'delta.feature.appendOnly' = 'supported',
  'delta.feature.invariants' = 'supported',
  'delta.minReaderVersion' = '1',
  'delta.minWriterVersion' = '2',
  'delta.feature.allowColumnDefaults' = 'supported'
);

# COMMAND ----------

%sql



CREATE TABLE IF NOT EXISTS idf_curated_ssddev.uspf.t_dp_transaction_dp_load (

            PHOENIX_ID STRING,
            PHOENIX_PLAN_ID STRING,
            SECTOR_NAME STRING,
            CORE_ORG_ID STRING,
            PER_TYPE_NAME STRING,
            MEASURE_DATE STRING,
            PERIOD_END_DATE STRING,
            PERIOD_MONTHS STRING,
            STATEMENT_BASIS_NAME STRING,
            ACCOUNT_BASIS_NAME STRING,
            APR_ACCEPTABLE STRING,
            SOURCE_FILE_CREATE_DATE STRING,
            SRC_DE_UNIQ_ID_TEXT STRING,
            DP_VALUE STRING,
            REPORT_ID STRING,
            DELETE_FLAG STRING,
            ACTION STRING,
            COLLECTION_DENOM STRING,
            actv_ind STRING,
            create_usr_id STRING,
            last_upd_usr_id STRING,
            create_dttm TIMESTAMP,
            last_upd_dttm TIMESTAMP,
            run_id BIGINT,
            record_hash STRING
        
)
USING delta
LOCATION 's3://spr-idf-dev-platform-engineered/catalog/uspf/ssddev_t_dp_transaction_dp_load_v1'
TBLPROPERTIES (
  'delta.checkpoint.writeStatsAsJson' = 'false',
  'delta.checkpoint.writeStatsAsStruct' = 'true',
  'delta.columnMapping.mode' = 'name',
  'delta.enableChangeDataFeed' = 'true',
  'delta.feature.changeDataFeed' = 'supported',
  'delta.feature.invariants' = 'supported',
  'delta.feature.allowColumnDefaults' = 'supported'
);


# COMMAND ----------

%sql

CREATE TABLE IF NOT EXISTS idf_curated_ssddev.uspf.t_dp_transaction_comments (

            PHOENIX_ID STRING,
            PHOENIX_PLAN_ID STRING,
            SECTOR_NAME STRING,
            CORE_ORG_ID STRING,
            PER_TYPE_NAME STRING,
            MEASURE_DATE STRING,
            PERIOD_END_DATE STRING,
            PERIOD_MONTHS STRING,
            STATEMENT_BASIS_NAME STRING,
            ACCOUNT_BASIS_NAME STRING,
            APR_ACCEPTABLE STRING,
            SOURCE_FILE_CREATE_DATE STRING,
            SRC_DE_UNIQ_ID_TEXT STRING,
            REPORT_ID STRING,
            COMMENTS STRING,
            COMMENT_BY STRING,
            COMMENT_DATE_TIME STRING,
            actv_ind STRING,
            create_usr_id STRING,
            last_upd_usr_id STRING,
            create_dttm TIMESTAMP,
            last_upd_dttm TIMESTAMP,
            run_id BIGINT,
            record_hash STRING
        
)
USING delta
LOCATION 's3://spr-idf-dev-platform-engineered/catalog/uspf/ssddev_t_dp_transaction_comments_v1'
TBLPROPERTIES (
  'delta.checkpoint.writeStatsAsJson' = 'false',
  'delta.checkpoint.writeStatsAsStruct' = 'true',
  'delta.columnMapping.mode' = 'name',
  'delta.enableChangeDataFeed' = 'true',
  'delta.feature.changeDataFeed' = 'supported',
  'delta.feature.invariants' = 'supported',
  'delta.feature.allowColumnDefaults' = 'supported'
);

# COMMAND ----------

%sql

CREATE TABLE IF NOT EXISTS idf_curated_ssddev.uspf.t_dp_transaction_schedules (

            PHOENIX_ID STRING,
            PHOENIX_PLAN_ID STRING,
            SECTOR_NAME STRING,
            CORE_ORG_ID STRING,
            PER_TYPE_NAME STRING,
            MEASURE_DATE STRING,
            PERIOD_END_DATE STRING,
            PERIOD_MONTHS STRING,
            STATEMENT_BASIS_NAME STRING,
            ACCOUNT_BASIS_NAME STRING,
            APR_ACCEPTABLE STRING,
            SOURCE_FILE_CREATE_DATE STRING,
            SRC_DE_UNIQ_ID_TEXT STRING,
            REPORT_ID STRING,
            SCHEDULE_NAME STRING,
            SCHEDULE_VALUE STRING,
            ACTION STRING,
            SCHEDULE_FRMLA_TEXT STRING,
            VALUE STRING,
            ORDER_ID STRING,
            actv_ind STRING,
            create_usr_id STRING,
            last_upd_usr_id STRING,
            create_dttm TIMESTAMP,
            last_upd_dttm TIMESTAMP,
            run_id BIGINT,
            record_hash STRING
        
)
USING delta
LOCATION 's3://spr-idf-dev-platform-engineered/catalog/uspf/ssddev_t_dp_transaction_schedules_v1'
TBLPROPERTIES (
  'delta.checkpoint.writeStatsAsJson' = 'false',
  'delta.checkpoint.writeStatsAsStruct' = 'true',
  'delta.columnMapping.mode' = 'name',
  'delta.enableChangeDataFeed' = 'true',
  'delta.feature.changeDataFeed' = 'supported',
  'delta.feature.invariants' = 'supported',
  'delta.feature.allowColumnDefaults' = 'supported'
);



# COMMAND ----------

%sql

CREATE TABLE IF NOT EXISTS idf_curated_ssddev.uspf.t_dp_transaction_org (

            PHOENIX_ID STRING,
            SECTOR STRING,
            CORE_ORG_ID STRING,
            ORG_PRIMARY_NAME STRING,
            STATE STRING,
            SOURCE_FILE_CREATE_DATE STRING,
            COUNTRY_CODE STRING,
            CURRENCY_CODE STRING,
            DEAL_NAME_DESCRIPTOR STRING,
            FIN_REVENUE_TYPE STRING,
            FIN_REVENUE_SUBTYPE STRING,
            FYE STRING,
            actv_ind STRING,
            create_usr_id STRING,
            last_upd_usr_id STRING,
            create_dttm TIMESTAMP,
            last_upd_dttm TIMESTAMP,
            run_id BIGINT,
            record_hash STRING
        
)
USING delta
LOCATION 's3://spr-idf-dev-platform-engineered/catalog/uspf/ssddev_t_dp_transaction_org_v1'
TBLPROPERTIES (
  'delta.checkpoint.writeStatsAsJson' = 'false',
  'delta.checkpoint.writeStatsAsStruct' = 'true',
  'delta.columnMapping.mode' = 'name',
  'delta.enableChangeDataFeed' = 'true',
  'delta.feature.changeDataFeed' = 'supported',
  'delta.feature.invariants' = 'supported',
  'delta.feature.allowColumnDefaults' = 'supported'
);