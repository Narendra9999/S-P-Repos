# Databricks notebook source
# Rename camelCase columns in t_dc_transaction_dp_load back to underscore format

# COMMAND ----------

# MAGIC %sql
# MAGIC -- SSDDEV / other environments: adjust columns that were previously added in camelCase
# MAGIC ALTER TABLE idf_raw_${env:aws_env}.uspf.t_dc_transaction_dp_load
# MAGIC   RENAME COLUMN dueDate TO DUE_DATE;
# MAGIC ALTER TABLE idf_raw_${env:aws_env}.uspf.t_dc_transaction_dp_load
# MAGIC   RENAME COLUMN fdmDueDate TO FDM_DUE_DATE;
# MAGIC ALTER TABLE idf_raw_${env:aws_env}.uspf.t_dc_transaction_dp_load
# MAGIC   RENAME COLUMN finalDueDate TO FINAL_DUE_DATE;
# MAGIC ALTER TABLE idf_raw_${env:aws_env}.uspf.t_dc_transaction_dp_load
# MAGIC   RENAME COLUMN finalTime TO FINAL_TIME;
# MAGIC ALTER TABLE idf_raw_${env:aws_env}.uspf.t_dc_transaction_dp_load
# MAGIC   RENAME COLUMN dcCompletionDate TO DC_COMPLETION_DATE;
# MAGIC ALTER TABLE idf_raw_${env:aws_env}.uspf.t_dc_transaction_dp_load
# MAGIC   RENAME COLUMN taggedFilenames TO TAGGED_FILES;
# MAGIC ALTER TABLE idf_raw_${env:aws_env}.uspf.t_dc_transaction_dp_load
# MAGIC   RENAME COLUMN taggedFilepath TO REFERENCE_FILES;
# MAGIC
# MAGIC ALTER TABLE idf_curated_${env:aws_env}.uspf.t_dc_transaction_dp_load
# MAGIC   RENAME COLUMN dueDate TO DUE_DATE;
# MAGIC ALTER TABLE idf_curated_${env:aws_env}.uspf.t_dc_transaction_dp_load
# MAGIC   RENAME COLUMN fdmDueDate TO FDM_DUE_DATE;
# MAGIC ALTER TABLE idf_curated_${env:aws_env}.uspf.t_dc_transaction_dp_load
# MAGIC   RENAME COLUMN finalDueDate TO FINAL_DUE_DATE;
# MAGIC ALTER TABLE idf_curated_${env:aws_env}.uspf.t_dc_transaction_dp_load
# MAGIC   RENAME COLUMN finalTime TO FINAL_TIME;
# MAGIC ALTER TABLE idf_curated_${env:aws_env}.uspf.t_dc_transaction_dp_load
# MAGIC   RENAME COLUMN dcCompletionDate TO DC_COMPLETION_DATE;
# MAGIC ALTER TABLE idf_curated_${env:aws_env}.uspf.t_dc_transaction_dp_load
# MAGIC   RENAME COLUMN taggedFilenames TO TAGGED_FILES;
# MAGIC ALTER TABLE idf_curated_${env:aws_env}.uspf.t_dc_transaction_dp_load
# MAGIC   RENAME COLUMN taggedFilepath TO REFERENCE_FILES;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Ensure period merge tables include the new reference columns before renaming
# MAGIC ALTER TABLE idf_curated_${env:aws_env}.uspf.period_merge_staging
# MAGIC   ADD COLUMNS (
# MAGIC     taggedFiles STRING,
# MAGIC     referenceFiles STRING,
# MAGIC     dueDate STRING,
# MAGIC     fdmDueDate STRING,
# MAGIC     finalDueDate STRING,
# MAGIC     finalTime STRING,
# MAGIC     dcCompletionDate STRING
# MAGIC   );
# MAGIC ALTER TABLE idf_curated_${env:aws_env}.uspf.period_merge
# MAGIC   ADD COLUMNS (
# MAGIC     taggedFiles STRING,
# MAGIC     referenceFiles STRING,
# MAGIC     dueDate STRING,
# MAGIC     fdmDueDate STRING,
# MAGIC     finalDueDate STRING,
# MAGIC     finalTime STRING,
# MAGIC     dcCompletionDate STRING
# MAGIC   );

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Upgrade Delta protocol and rename columns in period merge tables
# MAGIC ALTER TABLE idf_curated_${env:aws_env}.uspf.period_merge_staging
# MAGIC   SET TBLPROPERTIES (
# MAGIC     'delta.columnMapping.mode' = 'name',
# MAGIC     'delta.minReaderVersion' = '2',
# MAGIC     'delta.minWriterVersion' = '5'
# MAGIC   );
# MAGIC
# MAGIC
# MAGIC ALTER TABLE idf_curated_${env:aws_env}.uspf.period_merge
# MAGIC   SET TBLPROPERTIES (
# MAGIC     'delta.columnMapping.mode' = 'name',
# MAGIC     'delta.minReaderVersion' = '2',
# MAGIC     'delta.minWriterVersion' = '5'
# MAGIC   );
# MAGIC
# MAGIC
# MAGIC -- ALTER TABLE idf_curated_${env:aws_env}.uspf.fin_group_linked_scd2
# MAGIC --   RENAME COLUMN taggedFilenames TO taggedFiles;
# MAGIC -- ALTER TABLE idf_curated_${env:aws_env}.uspf.fin_group_linked_scd2
# MAGIC --   RENAME COLUMN taggedFilepath TO referenceFiles;

# COMMAND ----------

# MAGIC %sql
# MAGIC ALTER TABLE idf_curated_${env:aws_env}.uspf.fin_group_linked_scd2
# MAGIC   ADD COLUMNS (
# MAGIC     taggedFiles STRING,
# MAGIC     referenceFiles STRING,
# MAGIC     dueDate STRING,
# MAGIC     fdmDueDate STRING,
# MAGIC     finalDueDate STRING,
# MAGIC     finalTime STRING,
# MAGIC     dcCompletionDate STRING
# MAGIC   );
