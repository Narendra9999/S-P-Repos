# Databricks notebook source
# Add missing columns to t_dc_transaction_dp_load in all environments (raw + curated)
# Columns: DUEDATE, FDM_DUE_DATE, FINAL_DUE_DATE, FINAL_TIME, DC_COMPLETION_DATE

# COMMAND ----------

# MAGIC %sql
# MAGIC -- SSDDEV
# MAGIC ALTER TABLE idf_raw_${env:aws_env}.uspf.t_dc_transaction_dp_load
# MAGIC   ADD COLUMNS (
# MAGIC     dueDate STRING,
# MAGIC     fdmDueDate STRING,
# MAGIC     finalDueDate STRING,
# MAGIC     finalTime STRING,
# MAGIC     dcCompletionDate STRING,
# MAGIC     taggedFilenames STRING,
# MAGIC     taggedFilepath STRING
# MAGIC     
# MAGIC   );
# MAGIC
# MAGIC ALTER TABLE idf_curated_${env:aws_env}.uspf.t_dc_transaction_dp_load
# MAGIC   ADD COLUMNS (
# MAGIC     dueDate STRING,
# MAGIC     fdmDueDate STRING,
# MAGIC     finalDueDate STRING,
# MAGIC     finalTime STRING,
# MAGIC     dcCompletionDate STRING,
# MAGIC     taggedFilenames STRING,
# MAGIC     taggedFilepath STRING
# MAGIC   );
