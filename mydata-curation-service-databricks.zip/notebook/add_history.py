from pyspark.sql import functions as F
from pyspark.sql import Window

env = 'dev'
silver_table = f"idf_raw_{env}.uspf_migration.t_finmaster_history_v2"
staging_table = f"idf_curated_{env}.uspf.period_merge_staging"


# ----------------------------------------------------
# 1. LOAD RAW HISTORICAL DATA
# ----------------------------------------------------
def load_historical():
    df = spark.table(silver_table)
    print(f"Extracted historical records: {df.count()}")
    return df


# ----------------------------------------------------
# 2. FLATTEN + MAP TO period_merge_staging SCHEMA
# ----------------------------------------------------
def flatten_finDataPoints(df):
    exploded = (df
    .withColumn("fdp", F.explode("finDataPoints"))
    )

    flattened = exploded.select(

        # Convert to period_merge_staging-compatible schema
        F.col("entityId").cast("string").alias("entityId"),
        F.col("finOrgName").alias("orgPrimaryName"),
        F.col("sectorName").alias("subProductName"),

        # ID mapping
        F.col("sp_org_id").cast("string").alias("spOrgId"),
        F.col("asid_list").cast("array<string>").alias("mappedAsid"),

        # Period fields
        F.col("financialPeriod.periodEndDate").alias("periodEndDate"),
        F.col("financialPeriod.accountingBasis").alias("statementBasis"),
        F.col("financialPeriod.periodType").alias("periodType"),
        F.lit(None).cast("string").alias("periodMonths"),
        F.col("financialPeriod.accountingBasis").alias("accountingBasis"),
        F.col("financialPeriod.aprAcceptable").alias("aprAcceptable"),

        # Other t_finmaster_history_v2 fields
        F.col("state").alias("state"),
        F.col("countryCd").alias("countryCode"),
        F.col("ccy_cd").alias("currencyCode"),

        # Report & mnemonic data
        F.col("report_id").alias("reportId"),
        F.col("fdp.sourceMnemonicName").alias("keywordName"),
        F.lit(None).alias("workType"),
        F.lit(None).alias("receivedDate"),
        F.lit(None).alias("taggedDate"),
        F.col("fdp.sourceMnemonic").alias("mnemonic"),

        # Value
        F.col("fdp.currentValue").alias("value"),
        F.col("fdp.sourceUnitType").alias("unitType"),

        # schedules (we map fdp.currentSchedule into schedules)
        F.expr("""
                transform(
                    arrays_zip(
                        fdp.currentSchedule.schedCode,
                        fdp.currentSchedule.schedVal,
                        fdp.currentSchedule.scheduleFormula
                    ),
                    x -> struct(
                        x.schedCode       AS scheduleName,
                        x.schedVal        AS scheduleValueResult,
                        x.scheduleFormula AS scheduleValue,
                        null              AS remark,
                        null              AS orderId
                    )
                )
                """).alias("schedules"),

        # comments (fdp.commentTrail → comments)
        F.expr("""
                transform(
                    fdp.commentTrail,
                    x -> struct(
                        x.commentText    AS comments,
                        x.commentAsOf    AS created_Date,
                        x.commentUser    AS userName
                    )
                )
                """).alias("comments"),

        # temp_periodEndDate required for merge logic
        F.col("financialPeriod.periodEndDate").alias("temp_periodEndDate"),

        # PRIORITY_ORDR_NUM added later
        # Metadata fields
        F.current_timestamp().alias("processing_ts"),

        F.lit(None).alias("pm_id"),
        F.lit(None).alias("taggedFiles"),
        F.lit(None).alias("referenceFiles"),
        F.lit(None).alias("dueDate"),
        F.lit(None).alias("fdmDueDate"),
        F.lit(None).alias("finalDueDate"),
        F.lit(None).alias("finalTime"),
        F.lit(None).alias("dcCompletionDate"),

        # Additional fields from finDataPoints
        F.col("fdp.valueAsOf").alias("valueAsOf")
    )

    # print(f"Flattened record count: {flattened.count()}")
    return flattened


# ----------------------------------------------------
# 3. VALIDATE REQUIRED KEYS
# ----------------------------------------------------
def validate_columns(df):
    required = [
        "entityId", "subProductName", "mnemonic",
        "reportId", "temp_periodEndDate"
    ]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise Exception(f"Missing required columns: {missing}")
    print("Column validation OK")


# ----------------------------------------------------
# 4. PRIORITY_ORDR_NUM
# ----------------------------------------------------
def assign_priority(df):
    df2 = df.withColumn(
        "PRIORITY_ORDR_NUM",
        F.row_number().over(
            Window.partitionBy(
                "entityId", "subProductName",
                "mnemonic", "reportId",
                "temp_periodEndDate"
            ).orderBy(F.col("valueAsOf").desc_nulls_last())
        )
    )
    print("Assigned PRIORITY_ORDR_NUM")
    return df2


# ----------------------------------------------------
# 5. MERGE INTO STAGING
# ----------------------------------------------------
def merge_into_staging(df):
    df.createOrReplaceTempView("hist_src")

    merge_sql = f"""
    MERGE INTO {staging_table} AS tgt
    USING hist_src AS src
      ON tgt.entityId           = src.entityId
     AND tgt.subProductName     = src.subProductName
     AND tgt.mnemonic           = src.mnemonic
     AND tgt.reportId           = src.reportId
     AND tgt.temp_periodEndDate = src.temp_periodEndDate
     
    WHEN NOT MATCHED THEN INSERT *
    """

    spark.sql(merge_sql)
    # staged_count = spark.table(staging_table).count()
    print(f"Merge ended succesfully into {staging_table}")


# ----------------------------------------------------
# EXECUTION PIPELINE
# ----------------------------------------------------
df = load_historical()
df = flatten_finDataPoints(df)
validate_columns(df)
df = assign_priority(df)
# df.display(5)
merge_into_staging(df)
