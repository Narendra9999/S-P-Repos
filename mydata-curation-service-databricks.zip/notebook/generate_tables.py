# Databricks notebook source

import os

aws_env = os.environ.get("aws_env")

# COMMAND ----------
# Determine platform
if aws_env in ["qa", "ssdqa"]:
    platform = "spr-idf-qa-platform"
elif aws_env in ["dev", "ssddev"]:
    platform = "spr-idf-dev-platform"
else:
    platform = f"spr-idf-{aws_env}-platform"

# COMMAND ----------
# Determine environments to generate
if aws_env == "dev":
    envs = ["dev", "ssddev"]
elif aws_env == "qa":
    envs = ["qa", "ssdqa"]
else:
    envs = [aws_env]

# COMMAND ----------
RAW_TABLES = [
    {
        "name": "t_dc_transaction_dp_load",
        "columns": """
            PHOENIX_ID STRING,
            PHOENIX_PLAN_ID STRING,
            SECTOR_NAME STRING,
            PER_TYPE_NAME STRING,
            MEASURE_DATE STRING,
            PERIOD_END_DATE STRING,
            PERIOD_MONTHS STRING,
            STATEMENT_BASIS_NAME STRING,
            ACCOUNT_BASIS_NAME STRING,
            APR_ACCEPTABLE STRING,
            SOURCE_FILE_CREATE_DATE STRING,
            SRC_DE_UNIQ_ID_TEXT STRING,
            DP_VALUE STRING,
            REPORT_ID STRING,
            DELETE_FLAG STRING,
            ACTION STRING,
            WORK_TYPE STRING,
            KEYWORD_NAME STRING,
            RECEIVED_DATE STRING,
            TAGGED_DATE STRING,
            COLLECTION_DENOM STRING,
            processing_timestamp TIMESTAMP,
            source_file STRING,
            source_bucket STRING,
            process_date STRING,
            created_at TIMESTAMP,
            updated_at TIMESTAMP
        """,
        "partition": "SECTOR_NAME, process_date"
    },
    {
        "name": "t_dc_transaction_comments",
        "columns": """
            PHOENIX_ID STRING,
            PHOENIX_PLAN_ID STRING,
            SECTOR_NAME STRING,
            PER_TYPE_NAME STRING,
            MEASURE_DATE STRING,
            PERIOD_END_DATE STRING,
            PERIOD_MONTHS STRING,
            STATEMENT_BASIS_NAME STRING,
            ACCOUNT_BASIS_NAME STRING,
            APR_ACCEPTABLE STRING,
            SOURCE_FILE_CREATE_DATE STRING,
            SRC_DE_UNIQ_ID_TEXT STRING,
            REPORT_ID STRING,
            COMMENTS STRING,
            VALUE STRING,
            COMMENT_BY STRING,
            COMMENT_DATE_TIME STRING,
            processing_timestamp TIMESTAMP,
            source_file STRING,
            source_bucket STRING,
            process_date STRING,
            created_at TIMESTAMP,
            updated_at TIMESTAMP
        """,
        "partition": "SECTOR_NAME, process_date"
    },
    {
        "name": "t_dc_transaction_schedules",
        "columns": """
            PHOENIX_ID STRING,
            PHOENIX_PLAN_ID STRING,
            SECTOR_NAME STRING,
            PER_TYPE_NAME STRING,
            MEASURE_DATE STRING,
            PERIOD_END_DATE STRING,
            PERIOD_MONTHS STRING,
            STATEMENT_BASIS_NAME STRING,
            ACCOUNT_BASIS_NAME STRING,
            APR_ACCEPTABLE STRING,
            SOURCE_FILE_CREATE_DATE STRING,
            SRC_DE_UNIQ_ID_TEXT STRING,
            REPORT_ID STRING,
            SCHEDULE_NAME STRING,
            SCHEDULE_VALUE STRING,
            ACTION STRING,
            SCHEDULE_FRMLA_TEXT STRING,
            VALUE STRING,
            ORDER_ID STRING,
            REMARKS STRING,
            SCHEDULE_BY STRING,
            SCHEDULE_DATE_TIME STRING,
            processing_timestamp TIMESTAMP,
            source_file STRING,
            source_bucket STRING,
            process_date STRING,
            created_at TIMESTAMP,
            updated_at TIMESTAMP
        """,
        "partition": "SECTOR_NAME, process_date"
    },
    {
        "name": "t_dc_transaction_org",
        "columns": """
            PHOENIX_ID STRING,
            SECTOR STRING,
            ORG_PRIMARY_NAME STRING,
            STATE STRING,
            SOURCE_FILE_CREATE_DATE STRING,
            COUNTRY_CODE STRING,
            CURRENCY_CODE STRING,
            DEAL_NAME_DESCRIPTOR STRING,
            FIN_REVENUE_TYPE STRING,
            FIN_REVENUE_SUBTYPE STRING,
            FYE STRING,
            processing_timestamp TIMESTAMP,
            source_file STRING,
            source_bucket STRING,
            process_date STRING,
            created_at TIMESTAMP,
            updated_at TIMESTAMP
        """,
        "partition": "SECTOR, process_date"
    },
    
    {
        "name": "dp_date_processing_log",
        "columns": """
            process_date STRING,
            started_at TIMESTAMP,
            completed_at TIMESTAMP,
            status STRING,
            message_count INT,
            file_count INT,
            error_count INT
        """,
        "partition": None
    },
    {
        "name": "dp_file_processing_log",
        "columns": """
            file_path STRING,
            file_name STRING,
            bucket_name STRING,
            target_table STRING,
            phoenix_id STRING,
            report_id STRING,
            message_key STRING,
            processed_at TIMESTAMP,
            process_date STRING,
            status STRING
        """,
        "partition": None
    },
    {
        "name": "t_asid_org_linking",
        "columns": """
            ASID STRING,
            PHOENIX_ID STRING,
            SP_ORG_ID STRING,
            FINANCIAL_SECTOR STRING,
            FIN_REVENUE_TYPE STRING,
            FIN_REVENUE_SUBTYPE STRING,
            DEAL_NAME_DESCRIPTOR STRING,
            UPDATE_DATE TIMESTAMP,
            CSID STRING 
        """,
        "partition": None
    },
    {
        "name": "t_asid_mapping_reference",
        "columns": """
            ASID BIGINT,
            DISPLAY_NAME STRING,
            STATE STRING,
            CORE_OBLIGOR STRING,
            OBLIGOR_ORG_ID STRING,
            SP_ORG_NAME STRING,
            SP_ORG_ID BIGINT,
            ASID_ACTIVE_FLAG STRING,
            ASID_CREATE_DATE DATE,
            EXPECTED_FINANCIAL_SECTOR STRING,
            DEPENDENCY_TYP_NAME STRING,
            PORTFOLIO STRING,
            SECURITY STRING,
            SUBSECURITY STRING,
            DEPENDENCY_BUCKET STRING,
            MRS STRING
        """,
        "partition": None
    },
    {
        "name": "t_org_table_linking_stage",
        "columns": """
            message_key STRING,
            org_primary_name STRING,
            sp_org_id STRING,
            phoenix_id STRING,
            status STRING,
            error_message STRING,
            process_time TIMESTAMP,
            etl_timestamp STRING,
            financial_sector STRING,
            display_name STRING,
            state STRING,
            portfolio STRING
        """,
        "partition": None
    },
    {
        "name": "t_dc_statement_basis_precedence",
        "columns": """
            TEMPLT_SECTOR_NAME STRING,
            SCENARIO_CD STRING,
            SCENARIO_NAME STRING,
            PRIORITY_ORDR_NUM INT
        """,
        "partition": None
    },
    {
        "name": "t_org_finorgid_phoenixid_map",
        "columns": """
            finorg_id INT,
            phoenix_entity_id INT,
            START_DTTM DATE,
            END_DTTM DATE,
            CUR_IND STRING,
            ACTV_IND STRING,
            CREATE_USR_ID STRING,
            CREATE_DTTM DATE,
            LAST_UPD_USR_ID STRING,
            LAST_UPD_DTTM DATE,
            CONSTRAINT `finorg_phoenixid_pk` PRIMARY KEY (`finorg_id`, `START_DTTM`)
        """,
        "partition": None
    },
    {
        "name":"t_org_linking_responses",
        "columns": """
            topic STRING,
            topic_partition INT,
            topic_offset BIGINT,
            topic_timestamp BIGINT,
            message_key STRING,
            message_value STRING,
            process_time TIMESTAMP        
        """,
        "partition": None
    },
]

CURATED_TABLES = [
    {
        "name": "t_dc_transaction_dp_load",
        "columns": """
            PHOENIX_ID STRING,
            PHOENIX_PLAN_ID STRING,
            SECTOR_NAME STRING,
            PER_TYPE_NAME STRING,
            MEASURE_DATE STRING,
            PERIOD_END_DATE STRING,
            PERIOD_MONTHS STRING,
            STATEMENT_BASIS_NAME STRING,
            ACCOUNT_BASIS_NAME STRING,
            APR_ACCEPTABLE STRING,
            SOURCE_FILE_CREATE_DATE STRING,
            SRC_DE_UNIQ_ID_TEXT STRING,
            DP_VALUE STRING,
            REPORT_ID STRING,
            DELETE_FLAG STRING,
            ACTION STRING,
            WORK_TYPE string,
            KEYWORD_NAME string,
            RECEIVED_DATE STRING,
            TAGGED_DATE STRING,
            COLLECTION_DENOM STRING,
            actv_ind string,
            create_usr_id string,
            last_upd_usr_id string,
            create_dttm timestamp,
            last_upd_dttm timestamp,
            run_id bigint,
            record_hash STRING
        """,
        "partition": "PERIOD_END_DATE, SECTOR_NAME"
    },
    {
        "name": "t_dc_transaction_comments",
        "columns": """
            PHOENIX_ID STRING,
            PHOENIX_PLAN_ID STRING,
            SECTOR_NAME STRING,
            PER_TYPE_NAME STRING,
            MEASURE_DATE STRING,
            PERIOD_END_DATE STRING,
            PERIOD_MONTHS STRING,
            STATEMENT_BASIS_NAME STRING,
            ACCOUNT_BASIS_NAME STRING,
            APR_ACCEPTABLE STRING,
            SOURCE_FILE_CREATE_DATE STRING,
            SRC_DE_UNIQ_ID_TEXT STRING,
            REPORT_ID STRING,
            COMMENTS STRING,
            VALUE STRING,
            COMMENT_BY STRING,
            COMMENT_DATE_TIME STRING,
            actv_ind STRING,
            create_usr_id STRING,
            last_upd_usr_id STRING,
            create_dttm TIMESTAMP,
            last_upd_dttm TIMESTAMP,
            run_id BIGINT,
            record_hash STRING
        """,
        "partition": "PERIOD_END_DATE, SECTOR_NAME"
    },
    {
        "name": "t_dc_transaction_schedules",
        "columns": """
            PHOENIX_ID STRING,
            PHOENIX_PLAN_ID STRING,
            SECTOR_NAME STRING,
            PER_TYPE_NAME STRING,
            MEASURE_DATE STRING,
            PERIOD_END_DATE STRING,
            PERIOD_MONTHS STRING,
            STATEMENT_BASIS_NAME STRING,
            ACCOUNT_BASIS_NAME STRING,
            APR_ACCEPTABLE STRING,
            SOURCE_FILE_CREATE_DATE STRING,
            SRC_DE_UNIQ_ID_TEXT STRING,
            REPORT_ID STRING,
            SCHEDULE_NAME STRING,
            SCHEDULE_VALUE STRING,
            ACTION STRING,
            SCHEDULE_FRMLA_TEXT STRING,
            VALUE STRING,
            ORDER_ID STRING,
            REMARKS STRING,
            SCHEDULE_BY STRING,
            SCHEDULE_DATE_TIME STRING,
            actv_ind STRING,
            create_usr_id STRING,
            last_upd_usr_id STRING,
            create_dttm TIMESTAMP,
            last_upd_dttm TIMESTAMP,
            run_id BIGINT,
            record_hash STRING
        """,
        "partition": "PERIOD_END_DATE, SECTOR_NAME"
    },
    {
        "name": "t_dc_transaction_org",
        "columns": """
            PHOENIX_ID STRING,
            SECTOR STRING,
            ORG_PRIMARY_NAME STRING,
            STATE STRING,
            SOURCE_FILE_CREATE_DATE STRING,
            COUNTRY_CODE STRING,
            CURRENCY_CODE STRING,
            DEAL_NAME_DESCRIPTOR STRING,
            FIN_REVENUE_TYPE STRING,
            FIN_REVENUE_SUBTYPE STRING,
            FYE STRING,
            actv_ind STRING,
            create_usr_id STRING,
            last_upd_usr_id STRING,
            create_dttm TIMESTAMP,
            last_upd_dttm TIMESTAMP,
            run_id BIGINT,
            record_hash STRING
        """,
        "partition": "SECTOR"
    },
    {
        "name":"run_log",
        "columns": """
            run_id STRING,
            curated_table STRING,
            raw_table STRING,
            raw_processed_ts TIMESTAMP,
            status STRING,
            started_at TIMESTAMP,
            completed_at TIMESTAMP,
            raw_incr_count BIGINT,
            raw_incr_key_count BIGINT,
            raw_full_key_count BIGINT,
            curated_full_count BIGINT,
            updated_rows BIGINT DEFAULT 0 COMMENT 'Number of rows updated during merge operation',
            inserted_rows BIGINT DEFAULT 0 COMMENT 'Number of rows inserted during merge operation',
            affected_rows BIGINT DEFAULT 0 COMMENT 'Total number of rows affected during merge operation'
        """,
        "partition": None
    }
]

# COMMAND ----------
def raw_table_sql(table, columns, partition=None, env=None):
    partition_str = f"PARTITIONED BY ({partition})\n" if partition else ""
    return f"""
CREATE TABLE IF NOT EXISTS idf_raw_{env}.uspf.{table} (
{columns}
)
USING DELTA
{partition_str}LOCATION 's3://{platform}-landing/{env}/catalog/raw/uspf/{table}_v4'
TBLPROPERTIES (
  'delta.checkpoint.writeStatsAsJson' = 'false',
  'delta.checkpoint.writeStatsAsStruct' = 'true',
  'delta.columnMapping.mode' = 'name',
  'delta.feature.appendOnly' = 'supported',
  'delta.feature.invariants' = 'supported',
  'delta.minReaderVersion' = '1',
  'delta.minWriterVersion' = '2',
  'delta.feature.allowColumnDefaults' = 'supported'
);
"""

# COMMAND ----------
def curated_table_sql(table, columns, partition=None, env=None):
    partition_str = f"PARTITIONED BY ({partition})\n" if partition else ""
    return f"""
CREATE TABLE IF NOT EXISTS idf_curated_{env}.uspf.{table} (
{columns}
)
USING delta
{partition_str}LOCATION 's3://{platform}-engineered/{env}/catalog/curated/uspf/{table}_v4'
TBLPROPERTIES (
  'delta.checkpoint.writeStatsAsJson' = 'false',
  'delta.checkpoint.writeStatsAsStruct' = 'true',
  'delta.columnMapping.mode' = 'name',
  'delta.enableChangeDataFeed' = 'true',
  'delta.feature.changeDataFeed' = 'supported',
  'delta.feature.invariants' = 'supported',
  'delta.feature.allowColumnDefaults' = 'supported'
);
"""

# COMMAND ----------
if __name__ == "__main__":
    for env in envs:
        print(f"-- RAW TABLES for {env} --")
        for tbl in RAW_TABLES:
            sql_statement = raw_table_sql(tbl["name"], tbl["columns"], tbl["partition"], env=env)
            print(sql_statement)
            spark.sql(sql_statement)
        print(f"-- CURATED TABLES for {env} --")
        for tbl in CURATED_TABLES:
            sql_statement = curated_table_sql(tbl["name"], tbl["columns"], tbl["partition"], env=env)
            print(sql_statement)
            spark.sql(sql_statement)
    # To execute in Databricks, use: spark.sql(sql_statement)
