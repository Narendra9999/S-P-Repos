
%sql

ALTER TABLE idf_raw_uat.uspf.t_asid_org_linking
ADD COLUMNS (
  CSID STRING  
);