# Databricks notebook source
import os

aws_env = os.environ.get("aws_env")

# COMMAND ----------

# Determine platform
if aws_env in ["qa", "ssdqa"]:
    platform = "spr-idf-qa-platform"
elif aws_env in ["dev", "ssddev"]:
    platform = "spr-idf-dev-platform"
else:
    platform = f"spr-idf-{aws_env}-platform"

# COMMAND ----------

# Determine environments to generate
if aws_env == "dev":
    envs = ["dev", "ssddev"]
elif aws_env == "qa":
    envs = ["qa", "ssdqa"]
else:
    envs = [aws_env]


# COMMAND ----------

print("aws_env:", aws_env)
print("platform:", platform)
print("envs:", envs)

# COMMAND ----------

def column_exists(table_full_name, column_name):
    df = spark.sql(f"DESCRIBE TABLE {table_full_name}")
    return column_name in [row['col_name'] for row in df.collect()]


# COMMAND ----------

schema = "uspf" 

# COMMAND ----------

if __name__ == "__main__":
    for env in envs:
        catalog = f"idf_raw_{env}"
        date_log_table = f"{catalog}.{schema}.dp_date_processing_log"
        file_log_table = f"{catalog}.{schema}.dp_file_processing_log"

        has_pipeline_type_date = column_exists(date_log_table, "pipeline_type")
        has_pipeline_type_file = column_exists(file_log_table, "pipeline_type")

        print(f"[{env}] pipeline_type in dp_date_processing_log: {has_pipeline_type_date}")
        print(f"[{env}] pipeline_type in dp_file_processing_log: {has_pipeline_type_file}")

        if not has_pipeline_type_date:
            spark.sql(f"ALTER TABLE {date_log_table} ADD COLUMNS (pipeline_type Boolean)")
            print(f"[{env}] Added pipeline_type column to {date_log_table}")
        else:
            print(f"[{env}] pipeline_type column already exists in {date_log_table}")

        if not has_pipeline_type_file:
            spark.sql(f"ALTER TABLE {file_log_table} ADD COLUMNS (pipeline_type Boolean)")
            print(f"[{env}] Added pipeline_type column to {file_log_table}")
        else:
            print(f"[{env}] pipeline_type column already exists in {file_log_table}")