
%sql

ALTER TABLE idf_raw_ssdqa.uspf.t_asid_org_linking
ADD COLUMNS (
  CSID STRING  
);
ALTER TABLE idf_raw_qa.uspf.t_asid_org_linking
ADD COLUMNS (
  CSID STRING  
);
