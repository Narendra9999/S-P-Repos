# Databricks notebook source

# COMMAND ----------

%sql



CREATE TABLE IF NOT EXISTS idf_raw_${env:aws_env}.uspf.t_dc_transaction_dp_load (

            PHOENIX_ID STRING,
            PHOENIX_PLAN_ID STRING,
            SECTOR_NAME STRING,
            PER_TYPE_NAME STRING,
            MEASURE_DATE STRING,
            PERIOD_END_DATE STRING,
            PERIOD_MONTHS STRING,
            STATEMENT_BASIS_NAME STRING,
            ACCOUNT_BASIS_NAME STRING,
            APR_ACCEPTABLE STRING,
            SOURCE_FILE_CREATE_DATE STRING,
            SRC_DE_UNIQ_ID_TEXT STRING,
            DP_VALUE STRING,
            REPORT_ID STRING,
            DELETE_FLAG STRING,
            ACTION STRING,
            WORK_TYPE STRING,
            KEYWORD_NAME STRING,
            RECEIVED_DATE STRING,
            TAGGED_DATE STRING,
            COLLECTION_DENOM STRING,
            processing_timestamp TIMESTAMP,
            source_file STRING,
            source_bucket STRING,
            process_date STRING,
            created_at TIMESTAMP,
            updated_at TIMESTAMP
        
)
USING DELTA
PARTITIONED BY (SECTOR_NAME, process_date)
LOCATION 's3://spr-idf-${env:aws_service_env}-platform-landing/catalog/uspf/t_dc_transaction_dp_load_v1'
TBLPROPERTIES (
  'delta.checkpoint.writeStatsAsJson' = 'false',
  'delta.checkpoint.writeStatsAsStruct' = 'true',
  'delta.columnMapping.mode' = 'name',
  'delta.feature.appendOnly' = 'supported',
  'delta.feature.invariants' = 'supported',
  'delta.minReaderVersion' = '1',
  'delta.minWriterVersion' = '2',
  'delta.feature.allowColumnDefaults' = 'supported'
);



# COMMAND ----------

%sql

CREATE TABLE IF NOT EXISTS idf_raw_${env:aws_env}.uspf.t_dc_transaction_comments (

            PHOENIX_ID STRING,
            PHOENIX_PLAN_ID STRING,
            SECTOR_NAME STRING,
            PER_TYPE_NAME STRING,
            MEASURE_DATE STRING,
            PERIOD_END_DATE STRING,
            PERIOD_MONTHS STRING,
            STATEMENT_BASIS_NAME STRING,
            ACCOUNT_BASIS_NAME STRING,
            APR_ACCEPTABLE STRING,
            SOURCE_FILE_CREATE_DATE STRING,
            SRC_DE_UNIQ_ID_TEXT STRING,
            REPORT_ID STRING,
            COMMENTS STRING,
            VALUE STRING,
            COMMENT_BY STRING,
            COMMENT_DATE_TIME STRING,
            processing_timestamp TIMESTAMP,
            source_file STRING,
            source_bucket STRING,
            process_date STRING,
            created_at TIMESTAMP,
            updated_at TIMESTAMP
        
)
USING DELTA
PARTITIONED BY (SECTOR_NAME, process_date)
LOCATION 's3://spr-idf-${env:aws_service_env}-platform-landing/catalog/uspf/t_dc_transaction_comments_v1'
TBLPROPERTIES (
  'delta.checkpoint.writeStatsAsJson' = 'false',
  'delta.checkpoint.writeStatsAsStruct' = 'true',
  'delta.columnMapping.mode' = 'name',
  'delta.feature.appendOnly' = 'supported',
  'delta.feature.invariants' = 'supported',
  'delta.minReaderVersion' = '1',
  'delta.minWriterVersion' = '2',
  'delta.feature.allowColumnDefaults' = 'supported'
);



# COMMAND ----------

%sql

CREATE TABLE IF NOT EXISTS idf_raw_${env:aws_env}.uspf.t_dc_transaction_schedules (

            PHOENIX_ID STRING,
            PHOENIX_PLAN_ID STRING,
            SECTOR_NAME STRING,
            PER_TYPE_NAME STRING,
            MEASURE_DATE STRING,
            PERIOD_END_DATE STRING,
            PERIOD_MONTHS STRING,
            STATEMENT_BASIS_NAME STRING,
            ACCOUNT_BASIS_NAME STRING,
            APR_ACCEPTABLE STRING,
            SOURCE_FILE_CREATE_DATE STRING,
            SRC_DE_UNIQ_ID_TEXT STRING,
            REPORT_ID STRING,
            SCHEDULE_NAME STRING,
            SCHEDULE_VALUE STRING,
            ACTION STRING,
            SCHEDULE_FRMLA_TEXT STRING,
            VALUE STRING,
            ORDER_ID STRING,
            REMARKS STRING,
            SCHEDULE_BY STRING,
            SCHEDULE_DATE_TIME STRING,
            processing_timestamp TIMESTAMP,
            source_file STRING,
            source_bucket STRING,
            process_date STRING,
            created_at TIMESTAMP,
            updated_at TIMESTAMP
        
)
USING DELTA
PARTITIONED BY (SECTOR_NAME, process_date)
LOCATION 's3://spr-idf-${env:aws_service_env}-platform-landing/catalog/uspf/t_dc_transaction_schedules_v1'
TBLPROPERTIES (
  'delta.checkpoint.writeStatsAsJson' = 'false',
  'delta.checkpoint.writeStatsAsStruct' = 'true',
  'delta.columnMapping.mode' = 'name',
  'delta.feature.appendOnly' = 'supported',
  'delta.feature.invariants' = 'supported',
  'delta.minReaderVersion' = '1',
  'delta.minWriterVersion' = '2',
  'delta.feature.allowColumnDefaults' = 'supported'
);


# COMMAND ----------

%sql

CREATE TABLE IF NOT EXISTS idf_raw_${env:aws_env}.uspf.t_dc_transaction_org (

            PHOENIX_ID STRING,
            SECTOR STRING,
            ORG_PRIMARY_NAME STRING,
            STATE STRING,
            SOURCE_FILE_CREATE_DATE STRING,
            COUNTRY_CODE STRING,
            CURRENCY_CODE STRING,
            DEAL_NAME_DESCRIPTOR STRING,
            FIN_REVENUE_TYPE STRING,
            FIN_REVENUE_SUBTYPE STRING,
            FYE STRING,
            processing_timestamp TIMESTAMP,
            source_file STRING,
            source_bucket STRING,
            process_date STRING,
            created_at TIMESTAMP,
            updated_at TIMESTAMP
        
)
USING DELTA
PARTITIONED BY (SECTOR, process_date)
LOCATION 's3://spr-idf-${env:aws_service_env}-platform-landing/catalog/uspf/t_dc_transaction_org_v1'
TBLPROPERTIES (
  'delta.checkpoint.writeStatsAsJson' = 'false',
  'delta.checkpoint.writeStatsAsStruct' = 'true',
  'delta.columnMapping.mode' = 'name',
  'delta.feature.appendOnly' = 'supported',
  'delta.feature.invariants' = 'supported',
  'delta.minReaderVersion' = '1',
  'delta.minWriterVersion' = '2',
  'delta.feature.allowColumnDefaults' = 'supported'
);



# COMMAND ----------

%sql

CREATE TABLE IF NOT EXISTS idf_raw_${env:aws_env}.uspf.dp_date_processing_log (

            process_date STRING,
            started_at TIMESTAMP,
            completed_at TIMESTAMP,
            status STRING,
            message_count INT,
            file_count INT,
            error_count INT,
            pipeline_type BOOLEAN
        
)
USING DELTA
LOCATION 's3://spr-idf-${env:aws_service_env}-platform-landing/catalog/uspf/dp_date_processing_log_v1'
TBLPROPERTIES (
  'delta.checkpoint.writeStatsAsJson' = 'false',
  'delta.checkpoint.writeStatsAsStruct' = 'true',
  'delta.columnMapping.mode' = 'name',
  'delta.feature.appendOnly' = 'supported',
  'delta.feature.invariants' = 'supported',
  'delta.minReaderVersion' = '1',
  'delta.minWriterVersion' = '2',
  'delta.feature.allowColumnDefaults' = 'supported'
);


# COMMAND ----------

%sql

CREATE TABLE IF NOT EXISTS idf_raw_${env:aws_env}.uspf.dp_file_processing_log (

            file_path STRING,
            file_name STRING,
            bucket_name STRING,
            target_table STRING,
            phoenix_id STRING,
            report_id STRING,
            message_key STRING,
            processed_at TIMESTAMP,
            process_date STRING,
            status STRING,
            pipeline_type BOOLEAN
        
)
USING DELTA
LOCATION 's3://spr-idf-${env:aws_service_env}-platform-landing/catalog/uspf/dp_file_processing_log_v1'
TBLPROPERTIES (
  'delta.checkpoint.writeStatsAsJson' = 'false',
  'delta.checkpoint.writeStatsAsStruct' = 'true',
  'delta.columnMapping.mode' = 'name',
  'delta.feature.appendOnly' = 'supported',
  'delta.feature.invariants' = 'supported',
  'delta.minReaderVersion' = '1',
  'delta.minWriterVersion' = '2',
  'delta.feature.allowColumnDefaults' = 'supported'
);


# COMMAND ----------

%sql

CREATE TABLE IF NOT EXISTS idf_raw_${env:aws_env}.uspf.t_asid_org_linking (

            ASID STRING,
            PHOENIX_ID STRING,
            SP_ORG_ID STRING,
            FINANCIAL_SECTOR STRING,
            FIN_REVENUE_TYPE STRING,
            FIN_REVENUE_SUBTYPE STRING,
            DEAL_NAME_DESCRIPTOR STRING,
            UPDATE_DATE TIMESTAMP,
            CSID STRING
        
)
USING DELTA
LOCATION 's3://spr-idf-${env:aws_service_env}-platform-landing/catalog/uspf/t_asid_org_linking_v1'
TBLPROPERTIES (
  'delta.checkpoint.writeStatsAsJson' = 'false',
  'delta.checkpoint.writeStatsAsStruct' = 'true',
  'delta.columnMapping.mode' = 'name',
  'delta.feature.appendOnly' = 'supported',
  'delta.feature.invariants' = 'supported',
  'delta.minReaderVersion' = '1',
  'delta.minWriterVersion' = '2',
  'delta.feature.allowColumnDefaults' = 'supported'
);


# COMMAND ----------

%sql

CREATE TABLE IF NOT EXISTS idf_raw_${env:aws_env}.uspf.t_asid_mapping_reference (

            ASID BIGINT,
            DISPLAY_NAME STRING,
            STATE STRING,
            CORE_OBLIGOR STRING,
            OBLIGOR_ORG_ID STRING,
            SP_ORG_NAME STRING,
            SP_ORG_ID BIGINT,
            ASID_ACTIVE_FLAG STRING,
            ASID_CREATE_DATE DATE,
            EXPECTED_FINANCIAL_SECTOR STRING,
            DEPENDENCY_TYP_NAME STRING,
            PORTFOLIO STRING,
            SECURITY STRING,
            SUBSECURITY STRING,
            DEPENDENCY_BUCKET STRING,
            MRS STRING
        
)
USING DELTA
LOCATION 's3://spr-idf-${env:aws_service_env}-platform-landing/catalog/uspf/t_asid_mapping_reference_v1'
TBLPROPERTIES (
  'delta.checkpoint.writeStatsAsJson' = 'false',
  'delta.checkpoint.writeStatsAsStruct' = 'true',
  'delta.columnMapping.mode' = 'name',
  'delta.feature.appendOnly' = 'supported',
  'delta.feature.invariants' = 'supported',
  'delta.minReaderVersion' = '1',
  'delta.minWriterVersion' = '2',
  'delta.feature.allowColumnDefaults' = 'supported'
);

# COMMAND ----------

%sql

CREATE TABLE IF NOT EXISTS idf_raw_${env:aws_env}.uspf.t_org_table_linking_stage (

            message_key STRING,
            org_primary_name STRING,
            sp_org_id STRING,
            phoenix_id STRING,
            status STRING,
            error_message STRING,
            process_time TIMESTAMP,
            etl_timestamp STRING,
            financial_sector STRING,
            display_name STRING,
            state STRING,
            portfolio STRING
        
)
USING DELTA
LOCATION 's3://spr-idf-${env:aws_service_env}-platform-landing/catalog/uspf/t_org_table_linking_stage_v1'
TBLPROPERTIES (
  'delta.checkpoint.writeStatsAsJson' = 'false',
  'delta.checkpoint.writeStatsAsStruct' = 'true',
  'delta.columnMapping.mode' = 'name',
  'delta.feature.appendOnly' = 'supported',
  'delta.feature.invariants' = 'supported',
  'delta.minReaderVersion' = '1',
  'delta.minWriterVersion' = '2',
  'delta.feature.allowColumnDefaults' = 'supported'
);


# COMMAND ----------

%sql

CREATE TABLE IF NOT EXISTS idf_raw_${env:aws_env}.uspf.t_dc_statement_basis_precedence (

            TEMPLT_SECTOR_NAME STRING,
            SCENARIO_CD STRING,
            SCENARIO_NAME STRING,
            PRIORITY_ORDR_NUM INT
        
)
USING DELTA
LOCATION 's3://spr-idf-${env:aws_service_env}-platform-landing/catalog/uspf/t_dc_statement_basis_precedence_v1'
TBLPROPERTIES (
  'delta.checkpoint.writeStatsAsJson' = 'false',
  'delta.checkpoint.writeStatsAsStruct' = 'true',
  'delta.columnMapping.mode' = 'name',
  'delta.feature.appendOnly' = 'supported',
  'delta.feature.invariants' = 'supported',
  'delta.minReaderVersion' = '1',
  'delta.minWriterVersion' = '2',
  'delta.feature.allowColumnDefaults' = 'supported'
);



# COMMAND ----------

%sql

CREATE TABLE IF NOT EXISTS idf_curated_${env:aws_env}.uspf.t_org_finorgid_phoenixid_map (

            finorg_id INT,
            phoenix_entity_id INT,
            START_DTTM DATE,
            END_DTTM DATE,
            CUR_IND STRING,
            ACTV_IND STRING,
            CREATE_USR_ID STRING,
            CREATE_DTTM DATE,
            LAST_UPD_USR_ID STRING,
            LAST_UPD_DTTM DATE
        
)
USING DELTA
LOCATION 's3://spr-idf-${env:aws_service_env}-platform-engineered/catalog/uspf/t_org_finorgid_phoenixid_map_v1'
TBLPROPERTIES (
  'delta.checkpoint.writeStatsAsJson' = 'false',
  'delta.checkpoint.writeStatsAsStruct' = 'true',
  'delta.columnMapping.mode' = 'name',
  'delta.enableChangeDataFeed' = 'true',
  'delta.feature.changeDataFeed' = 'supported',
  'delta.feature.invariants' = 'supported',
  'delta.feature.allowColumnDefaults' = 'supported'
);


# COMMAND ----------

%sql

CREATE TABLE IF NOT EXISTS idf_raw_${env:aws_env}.uspf.t_org_linking_responses (

            topic STRING,
            topic_partition INT,
            topic_offset BIGINT,
            topic_timestamp BIGINT,
            message_key STRING,
            message_value STRING,
            process_time TIMESTAMP        
        
)
USING DELTA
LOCATION 's3://spr-idf-${env:aws_service_env}-platform-landing/catalog/uspf/t_org_linking_responses_v1'
TBLPROPERTIES (
  'delta.checkpoint.writeStatsAsJson' = 'false',
  'delta.checkpoint.writeStatsAsStruct' = 'true',
  'delta.columnMapping.mode' = 'name',
  'delta.feature.appendOnly' = 'supported',
  'delta.feature.invariants' = 'supported',
  'delta.minReaderVersion' = '1',
  'delta.minWriterVersion' = '2',
  'delta.feature.allowColumnDefaults' = 'supported'
);


# COMMAND ----------

%sql


CREATE TABLE IF NOT EXISTS idf_curated_${env:aws_env}.uspf.t_dc_transaction_dp_load (

            PHOENIX_ID STRING,
            PHOENIX_PLAN_ID STRING,
            SECTOR_NAME STRING,
            PER_TYPE_NAME STRING,
            MEASURE_DATE STRING,
            PERIOD_END_DATE STRING,
            PERIOD_MONTHS STRING,
            STATEMENT_BASIS_NAME STRING,
            ACCOUNT_BASIS_NAME STRING,
            APR_ACCEPTABLE STRING,
            SOURCE_FILE_CREATE_DATE STRING,
            SRC_DE_UNIQ_ID_TEXT STRING,
            DP_VALUE STRING,
            REPORT_ID STRING,
            DELETE_FLAG STRING,
            ACTION STRING,
            WORK_TYPE string,
            KEYWORD_NAME string,
            RECEIVED_DATE STRING,
            TAGGED_DATE STRING,
            COLLECTION_DENOM STRING,
            actv_ind string,
            create_usr_id string,
            last_upd_usr_id string,
            create_dttm timestamp,
            last_upd_dttm timestamp,
            run_id bigint,
            record_hash STRING
        
)
USING delta
PARTITIONED BY (PERIOD_END_DATE, SECTOR_NAME)
LOCATION 's3://spr-idf-${env:aws_service_env}-platform-engineered/catalog/uspf/t_dc_transaction_dp_load_v1'
TBLPROPERTIES (
  'delta.checkpoint.writeStatsAsJson' = 'false',
  'delta.checkpoint.writeStatsAsStruct' = 'true',
  'delta.columnMapping.mode' = 'name',
  'delta.enableChangeDataFeed' = 'true',
  'delta.feature.changeDataFeed' = 'supported',
  'delta.feature.invariants' = 'supported',
  'delta.feature.allowColumnDefaults' = 'supported'
);


# COMMAND ----------

%sql

CREATE TABLE IF NOT EXISTS idf_curated_${env:aws_env}.uspf.t_dc_transaction_comments (

            PHOENIX_ID STRING,
            PHOENIX_PLAN_ID STRING,
            SECTOR_NAME STRING,
            PER_TYPE_NAME STRING,
            MEASURE_DATE STRING,
            PERIOD_END_DATE STRING,
            PERIOD_MONTHS STRING,
            STATEMENT_BASIS_NAME STRING,
            ACCOUNT_BASIS_NAME STRING,
            APR_ACCEPTABLE STRING,
            SOURCE_FILE_CREATE_DATE STRING,
            SRC_DE_UNIQ_ID_TEXT STRING,
            REPORT_ID STRING,
            COMMENTS STRING,
            VALUE STRING,
            COMMENT_BY STRING,
            COMMENT_DATE_TIME STRING,
            actv_ind STRING,
            create_usr_id STRING,
            last_upd_usr_id STRING,
            create_dttm TIMESTAMP,
            last_upd_dttm TIMESTAMP,
            run_id BIGINT,
            record_hash STRING
        
)
USING delta
PARTITIONED BY (PERIOD_END_DATE, SECTOR_NAME)
LOCATION 's3://spr-idf-${env:aws_service_env}-platform-engineered/catalog/uspf/t_dc_transaction_comments_v1'
TBLPROPERTIES (
  'delta.checkpoint.writeStatsAsJson' = 'false',
  'delta.checkpoint.writeStatsAsStruct' = 'true',
  'delta.columnMapping.mode' = 'name',
  'delta.enableChangeDataFeed' = 'true',
  'delta.feature.changeDataFeed' = 'supported',
  'delta.feature.invariants' = 'supported',
  'delta.feature.allowColumnDefaults' = 'supported'
);


# COMMAND ----------

%sql

CREATE TABLE IF NOT EXISTS idf_curated_${env:aws_env}.uspf.t_dc_transaction_schedules (

            PHOENIX_ID STRING,
            PHOENIX_PLAN_ID STRING,
            SECTOR_NAME STRING,
            PER_TYPE_NAME STRING,
            MEASURE_DATE STRING,
            PERIOD_END_DATE STRING,
            PERIOD_MONTHS STRING,
            STATEMENT_BASIS_NAME STRING,
            ACCOUNT_BASIS_NAME STRING,
            APR_ACCEPTABLE STRING,
            SOURCE_FILE_CREATE_DATE STRING,
            SRC_DE_UNIQ_ID_TEXT STRING,
            REPORT_ID STRING,
            SCHEDULE_NAME STRING,
            SCHEDULE_VALUE STRING,
            ACTION STRING,
            SCHEDULE_FRMLA_TEXT STRING,
            VALUE STRING,
            ORDER_ID STRING,
            REMARKS STRING,
            SCHEDULE_BY STRING,
            SCHEDULE_DATE_TIME STRING,
            actv_ind STRING,
            create_usr_id STRING,
            last_upd_usr_id STRING,
            create_dttm TIMESTAMP,
            last_upd_dttm TIMESTAMP,
            run_id BIGINT,
            record_hash STRING
        
)
USING delta
PARTITIONED BY (PERIOD_END_DATE, SECTOR_NAME)
LOCATION 's3://spr-idf-${env:aws_service_env}-platform-engineered/catalog/uspf/t_dc_transaction_schedules_v1'
TBLPROPERTIES (
  'delta.checkpoint.writeStatsAsJson' = 'false',
  'delta.checkpoint.writeStatsAsStruct' = 'true',
  'delta.columnMapping.mode' = 'name',
  'delta.enableChangeDataFeed' = 'true',
  'delta.feature.changeDataFeed' = 'supported',
  'delta.feature.invariants' = 'supported',
  'delta.feature.allowColumnDefaults' = 'supported'
);


# COMMAND ----------

%sql

CREATE TABLE IF NOT EXISTS idf_curated_${env:aws_env}.uspf.t_dc_transaction_org (

            PHOENIX_ID STRING,
            SECTOR STRING,
            ORG_PRIMARY_NAME STRING,
            STATE STRING,
            SOURCE_FILE_CREATE_DATE STRING,
            COUNTRY_CODE STRING,
            CURRENCY_CODE STRING,
            DEAL_NAME_DESCRIPTOR STRING,
            FIN_REVENUE_TYPE STRING,
            FIN_REVENUE_SUBTYPE STRING,
            FYE STRING,
            actv_ind STRING,
            create_usr_id STRING,
            last_upd_usr_id STRING,
            create_dttm TIMESTAMP,
            last_upd_dttm TIMESTAMP,
            run_id BIGINT,
            record_hash STRING
        
)
USING delta
PARTITIONED BY (SECTOR)
LOCATION 's3://spr-idf-${env:aws_service_env}-platform-engineered/catalog/uspf/t_dc_transaction_org_v1'
TBLPROPERTIES (
  'delta.checkpoint.writeStatsAsJson' = 'false',
  'delta.checkpoint.writeStatsAsStruct' = 'true',
  'delta.columnMapping.mode' = 'name',
  'delta.enableChangeDataFeed' = 'true',
  'delta.feature.changeDataFeed' = 'supported',
  'delta.feature.invariants' = 'supported',
  'delta.feature.allowColumnDefaults' = 'supported'
);


# COMMAND ----------

%sql

CREATE TABLE IF NOT EXISTS idf_curated_${env:aws_env}.uspf.run_log (

            run_id STRING,
            curated_table STRING,
            raw_table STRING,
            raw_processed_ts TIMESTAMP,
            status STRING,
            started_at TIMESTAMP,
            completed_at TIMESTAMP,
            raw_incr_count BIGINT,
            raw_incr_key_count BIGINT,
            raw_full_key_count BIGINT,
            curated_full_count BIGINT,
            updated_rows BIGINT DEFAULT 0 COMMENT 'Number of rows updated during merge operation',
            inserted_rows BIGINT DEFAULT 0 COMMENT 'Number of rows inserted during merge operation',
            affected_rows BIGINT DEFAULT 0 COMMENT 'Total number of rows affected during merge operation'
        
)
USING delta
LOCATION 's3://spr-idf-${env:aws_service_env}-platform-engineered/catalog/uspf/run_log_v1'
TBLPROPERTIES (
  'delta.checkpoint.writeStatsAsJson' = 'false',
  'delta.checkpoint.writeStatsAsStruct' = 'true',
  'delta.columnMapping.mode' = 'name',
  'delta.enableChangeDataFeed' = 'true',
  'delta.feature.changeDataFeed' = 'supported',
  'delta.feature.invariants' = 'supported',
  'delta.feature.allowColumnDefaults' = 'supported'
);


# COMMAND ----------

%sql


CREATE TABLE IF NOT EXISTS idf_raw_${env:aws_env}.uspf.t_dc_transaction_tif_pa (

            PHOENIX_ID STRING,
            PA_PHOENIXID STRING,
            LINKAGE STRING,
            ACTION STRING,
            SOURCE_FILE_CREATE_DATE STRING,
            processing_timestamp TIMESTAMP,
            source_file STRING,
            source_bucket STRING,
            process_date STRING,
            created_at TIMESTAMP,
            updated_at TIMESTAMP
        
)
USING DELTA
LOCATION 's3://spr-idf-${env:aws_service_env}-platform-landing/catalog/uspf/t_dc_transaction_tif_pa_v1'
TBLPROPERTIES (
  'delta.checkpoint.writeStatsAsJson' = 'false',
  'delta.checkpoint.writeStatsAsStruct' = 'true',
  'delta.columnMapping.mode' = 'name',
  'delta.feature.appendOnly' = 'supported',
  'delta.feature.invariants' = 'supported',
  'delta.minReaderVersion' = '1',
  'delta.minWriterVersion' = '2',
  'delta.feature.allowColumnDefaults' = 'supported'
);


# COMMAND ----------

%sql

CREATE TABLE IF NOT EXISTS idf_raw_${env:aws_env}.uspf.t_dc_transaction_plan_id (

            PHOENIX_PLAN_ID STRING,
            PHOENIX_ID STRING,
            ACTION STRING,
            REPORT_ID STRING,
            SOURCE_FILE_CREATE_DATE STRING,
            processing_timestamp TIMESTAMP,
            source_file STRING,
            source_bucket STRING,
            process_date STRING,
            created_at TIMESTAMP,
            updated_at TIMESTAMP
        
)
USING DELTA
LOCATION 's3://spr-idf-${env:aws_service_env}-platform-landing/catalog/uspf/t_dc_transaction_plan_id_v1'
TBLPROPERTIES (
  'delta.checkpoint.writeStatsAsJson' = 'false',
  'delta.checkpoint.writeStatsAsStruct' = 'true',
  'delta.columnMapping.mode' = 'name',
  'delta.feature.appendOnly' = 'supported',
  'delta.feature.invariants' = 'supported',
  'delta.minReaderVersion' = '1',
  'delta.minWriterVersion' = '2',
  'delta.feature.allowColumnDefaults' = 'supported'
);


# COMMAND ----------

%sql

CREATE TABLE IF NOT EXISTS idf_raw_${env:aws_env}.uspf.t_dc_transaction_plan_org (

            PHOENIX_ID STRING,
            PLAN_NAME STRING,
            PLAN_STATE STRING,
            PENSION_OPEB STRING,
            PLAN_TYPE STRING,
            SOURCE_FILE_CREATE_DATE STRING,
            processing_timestamp TIMESTAMP,
            source_file STRING,
            source_bucket STRING,
            process_date STRING,
            created_at TIMESTAMP,
            updated_at TIMESTAMP
        
)
USING DELTA
LOCATION 's3://spr-idf-${env:aws_service_env}-platform-landing/catalog/uspf/t_dc_transaction_plan_org_v1'
TBLPROPERTIES (
  'delta.checkpoint.writeStatsAsJson' = 'false',
  'delta.checkpoint.writeStatsAsStruct' = 'true',
  'delta.columnMapping.mode' = 'name',
  'delta.feature.appendOnly' = 'supported',
  'delta.feature.invariants' = 'supported',
  'delta.minReaderVersion' = '1',
  'delta.minWriterVersion' = '2',
  'delta.feature.allowColumnDefaults' = 'supported'
);



# COMMAND ----------

%sql


CREATE TABLE IF NOT EXISTS idf_curated_${env:aws_env}.uspf.t_dc_transaction_tif_pa (

            PHOENIX_ID STRING,
            PA_PHOENIXID STRING,
            LINKAGE STRING,
            ACTION STRING,
            SOURCE_FILE_CREATE_DATE STRING,
            actv_ind STRING,
            create_usr_id STRING,
            last_upd_usr_id STRING,
            create_dttm TIMESTAMP,
            last_upd_dttm TIMESTAMP,
            run_id BIGINT,
            record_hash STRING
        
)
USING delta
LOCATION 's3://spr-idf-${env:aws_service_env}-platform-engineered/catalog/uspf/t_dc_transaction_tif_pa_v1'
TBLPROPERTIES (
  'delta.checkpoint.writeStatsAsJson' = 'false',
  'delta.checkpoint.writeStatsAsStruct' = 'true',
  'delta.columnMapping.mode' = 'name',
  'delta.enableChangeDataFeed' = 'true',
  'delta.feature.changeDataFeed' = 'supported',
  'delta.feature.invariants' = 'supported',
  'delta.feature.allowColumnDefaults' = 'supported'
);


# COMMAND ----------

%sql

CREATE TABLE IF NOT EXISTS idf_curated_${env:aws_env}.uspf.t_dc_transaction_plan_id (

            PHOENIX_PLAN_ID STRING,
            PHOENIX_ID STRING,
            ACTION STRING,
            REPORT_ID STRING,
            SOURCE_FILE_CREATE_DATE STRING,
            actv_ind STRING,
            create_usr_id STRING,
            last_upd_usr_id STRING,
            create_dttm TIMESTAMP,
            last_upd_dttm TIMESTAMP,
            run_id BIGINT,
            record_hash STRING
        
)
USING delta
LOCATION 's3://spr-idf-${env:aws_service_env}-platform-engineered/catalog/uspf/t_dc_transaction_plan_id_v1'
TBLPROPERTIES (
  'delta.checkpoint.writeStatsAsJson' = 'false',
  'delta.checkpoint.writeStatsAsStruct' = 'true',
  'delta.columnMapping.mode' = 'name',
  'delta.enableChangeDataFeed' = 'true',
  'delta.feature.changeDataFeed' = 'supported',
  'delta.feature.invariants' = 'supported',
  'delta.feature.allowColumnDefaults' = 'supported'
);


# COMMAND ----------

%sql

CREATE TABLE IF NOT EXISTS idf_curated_${env:aws_env}.uspf.t_dc_transaction_plan_org (

            PHOENIX_ID STRING,
            PLAN_NAME STRING,
            PLAN_STATE STRING,
            PENSION_OPEB STRING,
            PLAN_TYPE STRING,
            SOURCE_FILE_CREATE_DATE STRING,
            actv_ind STRING,
            create_usr_id STRING,
            last_upd_usr_id STRING,
            create_dttm TIMESTAMP,
            last_upd_dttm TIMESTAMP,
            run_id BIGINT,
            record_hash STRING
        
)
USING delta
LOCATION 's3://spr-idf-${env:aws_service_env}-platform-engineered/catalog/uspf/t_dc_transaction_plan_org_v1'
TBLPROPERTIES (
  'delta.checkpoint.writeStatsAsJson' = 'false',
  'delta.checkpoint.writeStatsAsStruct' = 'true',
  'delta.columnMapping.mode' = 'name',
  'delta.enableChangeDataFeed' = 'true',
  'delta.feature.changeDataFeed' = 'supported',
  'delta.feature.invariants' = 'supported',
  'delta.feature.allowColumnDefaults' = 'supported'
);

