# Databricks notebook source
pip install msal

# COMMAND ----------
# MAGIC %run ./RSM_Utils

# COMMAND ----------
#get libraries

import os

aws_env = os.environ.get("aws_env")

# COMMAND ----------
# Determine platform
if aws_env in ["qa", "ssdqa"]:
    platform = "spr-idf-qa-platform"
elif aws_env in ["dev", "ssddev"]:
    platform = "spr-idf-dev-platform"
else:
    platform = f"spr-idf-{aws_env}-platform"

# COMMAND ----------
# Determine environments to generate
if aws_env == "dev":
    envs = ["dev", "ssddev"]
elif aws_env == "qa":
    envs = ["qa", "ssdqa"]
else:
    envs = [aws_env]

# COMMAND ----------
RAW_TABLES = [
    {
        "name": "t_dp_transaction_dp_load",
        "columns": """
            PHOENIX_ID STRING,
            PHOENIX_PLAN_ID STRING,
            SECTOR_NAME STRING,
            CORE_ORG_ID STRING,
            PER_TYPE_NAME STRING,
            MEASURE_DATE STRING,
            PERIOD_END_DATE STRING,
            PERIOD_MONTHS STRING,
            STATEMENT_BASIS_NAME STRING,
            ACCOUNT_BASIS_NAME STRING,
            APR_ACCEPTABLE STRING,
            SOURCE_FILE_CREATE_DATE STRING,
            SRC_DE_UNIQ_ID_TEXT STRING,
            DP_VALUE STRING,
            REPORT_ID STRING,
            DELETE_FLAG STRING,
            ACTION STRING,
            COLLECTION_DENOM STRING,
            processing_timestamp TIMESTAMP,
            source_file STRING,
            source_bucket STRING,
            process_date STRING,
            created_at TIMESTAMP,
            updated_at TIMESTAMP
        """,
        "partition": "SECTOR_NAME, process_date"
    },
    {
        "name": "t_dp_transaction_comments",
        "columns": """
            PHOENIX_ID STRING,
            PHOENIX_PLAN_ID STRING,
            SECTOR_NAME STRING,
            CORE_ORG_ID STRING,
            PER_TYPE_NAME STRING,
            MEASURE_DATE STRING,
            PERIOD_END_DATE STRING,
            PERIOD_MONTHS STRING,
            STATEMENT_BASIS_NAME STRING,
            ACCOUNT_BASIS_NAME STRING,
            APR_ACCEPTABLE STRING,
            SOURCE_FILE_CREATE_DATE STRING,
            SRC_DE_UNIQ_ID_TEXT STRING,
            REPORT_ID STRING,
            COMMENTS STRING,
            COMMENT_BY STRING,
            COMMENT_DATE_TIME STRING,
            processing_timestamp TIMESTAMP,
            source_file STRING,
            source_bucket STRING,
            process_date STRING,
            created_at TIMESTAMP,
            updated_at TIMESTAMP
        """,
        "partition": "SECTOR_NAME, process_date"
    },
    {
        "name": "t_dp_transaction_schedules",
        "columns": """
            PHOENIX_ID STRING,
            PHOENIX_PLAN_ID STRING,
            SECTOR_NAME STRING,
            CORE_ORG_ID STRING,
            PER_TYPE_NAME STRING,
            MEASURE_DATE STRING,
            PERIOD_END_DATE STRING,
            PERIOD_MONTHS STRING,
            STATEMENT_BASIS_NAME STRING,
            ACCOUNT_BASIS_NAME STRING,
            APR_ACCEPTABLE STRING,
            SOURCE_FILE_CREATE_DATE STRING,
            SRC_DE_UNIQ_ID_TEXT STRING,
            REPORT_ID STRING,
            SCHEDULE_NAME STRING,
            SCHEDULE_VALUE STRING,
            ACTION STRING,
            SCHEDULE_FRMLA_TEXT STRING,
            VALUE STRING,
            ORDER_ID STRING,
            processing_timestamp TIMESTAMP,
            source_file STRING,
            source_bucket STRING,
            process_date STRING,
            created_at TIMESTAMP,
            updated_at TIMESTAMP
        """,
        "partition": "SECTOR_NAME, process_date"
    },
    {
        "name": "t_dp_transaction_org",
        "columns": """
            PHOENIX_ID STRING,
            SECTOR STRING,
            CORE_ORG_ID STRING,
            ORG_PRIMARY_NAME STRING,
            STATE STRING,
            SOURCE_FILE_CREATE_DATE STRING,
            COUNTRY_CODE STRING,
            CURRENCY_CODE STRING,
            DEAL_NAME_DESCRIPTOR STRING,
            FIN_REVENUE_TYPE STRING,
            FIN_REVENUE_SUBTYPE STRING,
            FYE STRING,
            processing_timestamp TIMESTAMP,
            source_file STRING,
            source_bucket STRING,
            process_date STRING,
            created_at TIMESTAMP,
            updated_at TIMESTAMP
        """,
        "partition": "SECTOR, process_date"
    },
]

CURATED_TABLES = [
    {
        "name": "t_dp_transaction_dp_load",
        "columns": """
            PHOENIX_ID STRING,
            PHOENIX_PLAN_ID STRING,
            SECTOR_NAME STRING,
            CORE_ORG_ID STRING,
            PER_TYPE_NAME STRING,
            MEASURE_DATE STRING,
            PERIOD_END_DATE STRING,
            PERIOD_MONTHS STRING,
            STATEMENT_BASIS_NAME STRING,
            ACCOUNT_BASIS_NAME STRING,
            APR_ACCEPTABLE STRING,
            SOURCE_FILE_CREATE_DATE STRING,
            SRC_DE_UNIQ_ID_TEXT STRING,
            DP_VALUE STRING,
            REPORT_ID STRING,
            DELETE_FLAG STRING,
            ACTION STRING,
            COLLECTION_DENOM STRING,
            actv_ind STRING,
            create_usr_id STRING,
            last_upd_usr_id STRING,
            create_dttm TIMESTAMP,
            last_upd_dttm TIMESTAMP,
            run_id BIGINT,
            record_hash STRING
        """,
        "partition": None
    },
    {
        "name": "t_dp_transaction_comments",
        "columns": """
            PHOENIX_ID STRING,
            PHOENIX_PLAN_ID STRING,
            SECTOR_NAME STRING,
            CORE_ORG_ID STRING,
            PER_TYPE_NAME STRING,
            MEASURE_DATE STRING,
            PERIOD_END_DATE STRING,
            PERIOD_MONTHS STRING,
            STATEMENT_BASIS_NAME STRING,
            ACCOUNT_BASIS_NAME STRING,
            APR_ACCEPTABLE STRING,
            SOURCE_FILE_CREATE_DATE STRING,
            SRC_DE_UNIQ_ID_TEXT STRING,
            REPORT_ID STRING,
            COMMENTS STRING,
            COMMENT_BY STRING,
            COMMENT_DATE_TIME STRING,
            actv_ind STRING,
            create_usr_id STRING,
            last_upd_usr_id STRING,
            create_dttm TIMESTAMP,
            last_upd_dttm TIMESTAMP,
            run_id BIGINT,
            record_hash STRING
        """,
        "partition": None
    },
    {
        "name": "t_dp_transaction_schedules",
        "columns": """
            PHOENIX_ID STRING,
            PHOENIX_PLAN_ID STRING,
            SECTOR_NAME STRING,
            CORE_ORG_ID STRING,
            PER_TYPE_NAME STRING,
            MEASURE_DATE STRING,
            PERIOD_END_DATE STRING,
            PERIOD_MONTHS STRING,
            STATEMENT_BASIS_NAME STRING,
            ACCOUNT_BASIS_NAME STRING,
            APR_ACCEPTABLE STRING,
            SOURCE_FILE_CREATE_DATE STRING,
            SRC_DE_UNIQ_ID_TEXT STRING,
            REPORT_ID STRING,
            SCHEDULE_NAME STRING,
            SCHEDULE_VALUE STRING,
            ACTION STRING,
            SCHEDULE_FRMLA_TEXT STRING,
            VALUE STRING,
            ORDER_ID STRING,
            actv_ind STRING,
            create_usr_id STRING,
            last_upd_usr_id STRING,
            create_dttm TIMESTAMP,
            last_upd_dttm TIMESTAMP,
            run_id BIGINT,
            record_hash STRING
        """,
        "partition": None
    },
    {
        "name": "t_dp_transaction_org",
        "columns": """
            PHOENIX_ID STRING,
            SECTOR STRING,
            CORE_ORG_ID STRING,
            ORG_PRIMARY_NAME STRING,
            STATE STRING,
            SOURCE_FILE_CREATE_DATE STRING,
            COUNTRY_CODE STRING,
            CURRENCY_CODE STRING,
            DEAL_NAME_DESCRIPTOR STRING,
            FIN_REVENUE_TYPE STRING,
            FIN_REVENUE_SUBTYPE STRING,
            FYE STRING,
            actv_ind STRING,
            create_usr_id STRING,
            last_upd_usr_id STRING,
            create_dttm TIMESTAMP,
            last_upd_dttm TIMESTAMP,
            run_id BIGINT,
            record_hash STRING
        """,
        "partition": None
    }
    
]

# COMMAND ----------
def raw_table_sql(table, columns, partition=None, env=None):
    partition_str = f"PARTITIONED BY ({partition})\n" if partition else ""
    return f"""
CREATE TABLE IF NOT EXISTS idf_raw_{env}.uspf.{table} (
{columns}
)
USING DELTA
{partition_str}LOCATION 's3://{platform}-landing/{env}/catalog/raw/uspf/{table}_v2'
TBLPROPERTIES (
  'delta.checkpoint.writeStatsAsJson' = 'false',
  'delta.checkpoint.writeStatsAsStruct' = 'true',
  'delta.columnMapping.mode' = 'name',
  'delta.feature.appendOnly' = 'supported',
  'delta.feature.invariants' = 'supported',
  'delta.minReaderVersion' = '1',
  'delta.minWriterVersion' = '2'
);
"""

# COMMAND ----------
def curated_table_sql(table, columns, partition=None, env=None):
    partition_str = f"PARTITIONED BY ({partition})\n" if partition else ""
    return f"""
CREATE TABLE IF NOT EXISTS idf_curated_{env}.uspf.{table} (
{columns}
)
USING delta
{partition_str}LOCATION 's3://{platform}-engineered/{env}/catalog/curated/uspf/{table}_v2'
TBLPROPERTIES (
  'delta.checkpoint.writeStatsAsJson' = 'false',
  'delta.checkpoint.writeStatsAsStruct' = 'true',
  'delta.columnMapping.mode' = 'name',
  'delta.enableChangeDataFeed' = 'true',
  'delta.feature.changeDataFeed' = 'supported',
  'delta.feature.invariants' = 'supported'
);
"""

# COMMAND ----------
if __name__ == "__main__":
    for env in envs:
        print(f"-- RAW TABLES for {env} --")
        for tbl in RAW_TABLES:
            sql_statement = raw_table_sql(tbl["name"], tbl["columns"], tbl["partition"], env=env)
            print(sql_statement)
            spark.sql(sql_statement)
        print(f"-- CURATED TABLES for {env} --")
        for tbl in CURATED_TABLES:
            sql_statement = curated_table_sql(tbl["name"], tbl["columns"], tbl["partition"], env=env)
            print(sql_statement)
            spark.sql(sql_statement)
    # To execute in Databricks, use: spark.sql(sql_statement)
