# Databricks notebook source


# COMMAND ----------
# MAGIC %run ./RSM_Utils

# COMMAND ----------
#get libraries

import os

aws_env = os.environ.get("aws_env")

# COMMAND ----------
# Determine platform
if aws_env in ["qa", "ssdqa"]:
    platform = "spr-idf-qa-platform"
elif aws_env in ["dev", "ssddev"]:
    platform = "spr-idf-dev-platform"
else:
    platform = f"spr-idf-{aws_env}-platform"

# COMMAND ----------
# Determine environments to generate
if aws_env == "dev":
    envs = ["ssddev"]
elif aws_env == "qa":
    envs = ["qa", "ssdqa"]
else:
    envs = [aws_env]

# COMMAND ----------
RAW_TABLES = [
    
    {
        "name": "t_dc_transaction_tif_pa",
        "columns": """
            PHOENIX_ID STRING,
            PA_PHOENIXID STRING,
            LINKAGE STRING,
            ACTION STRING,
            SOURCE_FILE_CREATE_DATE STRING,
            processing_timestamp TIMESTAMP,
            source_file STRING,
            source_bucket STRING,
            process_date STRING,
            created_at TIMESTAMP,
            updated_at TIMESTAMP
        """,
        "partition": None
    },
    {
        "name": "t_dc_transaction_plan_id",
        "columns": """
            PHOENIX_PLAN_ID STRING,
            PHOENIX_ID STRING,
            ACTION STRING,
            REPORT_ID STRING,
            SOURCE_FILE_CREATE_DATE STRING,
            processing_timestamp TIMESTAMP,
            source_file STRING,
            source_bucket STRING,
            process_date STRING,
            created_at TIMESTAMP,
            updated_at TIMESTAMP
        """,
        "partition": None
    },
    {
        "name": "t_dc_transaction_plan_org",
        "columns": """
            PHOENIX_ID STRING,
            PLAN_NAME STRING,
            PLAN_STATE STRING,
            PENSION_OPEB STRING,
            PLAN_TYPE STRING,
            SOURCE_FILE_CREATE_DATE STRING,
            processing_timestamp TIMESTAMP,
            source_file STRING,
            source_bucket STRING,
            process_date STRING,
            created_at TIMESTAMP,
            updated_at TIMESTAMP
        """,
        "partition": None
    }
]

CURATED_TABLES = [
    {
        "name": "t_dc_transaction_tif_pa",
        "columns": """
            PHOENIX_ID STRING,
            PA_PHOENIXID STRING,
            LINKAGE STRING,
            ACTION STRING,
            SOURCE_FILE_CREATE_DATE STRING,
            actv_ind STRING,
            create_usr_id STRING,
            last_upd_usr_id STRING,
            create_dttm TIMESTAMP,
            last_upd_dttm TIMESTAMP,
            run_id BIGINT,
            record_hash STRING
        """,
        "partition": None
    },
    {
        "name": "t_dc_transaction_plan_id",
        "columns": """
            PHOENIX_PLAN_ID STRING,
            PHOENIX_ID STRING,
            ACTION STRING,
            REPORT_ID STRING,
            SOURCE_FILE_CREATE_DATE STRING,
            actv_ind STRING,
            create_usr_id STRING,
            last_upd_usr_id STRING,
            create_dttm TIMESTAMP,
            last_upd_dttm TIMESTAMP,
            run_id BIGINT,
            record_hash STRING
        """,
        "partition": None
    },
    {
        "name": "t_dc_transaction_plan_org",
        "columns": """
            PHOENIX_ID STRING,
            PLAN_NAME STRING,
            PLAN_STATE STRING,
            PENSION_OPEB STRING,
            PLAN_TYPE STRING,
            SOURCE_FILE_CREATE_DATE STRING,
            actv_ind STRING,
            create_usr_id STRING,
            last_upd_usr_id STRING,
            create_dttm TIMESTAMP,
            last_upd_dttm TIMESTAMP,
            run_id BIGINT,
            record_hash STRING
        """,
        "partition": None
    }
    
]

# COMMAND ----------
def raw_table_sql(table, columns, partition=None, env=None):
    partition_str = f"PARTITIONED BY ({partition})\n" if partition else ""
    return f"""
CREATE TABLE IF NOT EXISTS idf_raw_{env}.uspf.{table} (
{columns}
)
USING DELTA
{partition_str}LOCATION 's3://{platform}-landing/{env}/catalog/raw/uspf/{table}_v2'
TBLPROPERTIES (
  'delta.checkpoint.writeStatsAsJson' = 'false',
  'delta.checkpoint.writeStatsAsStruct' = 'true',
  'delta.columnMapping.mode' = 'name',
  'delta.feature.appendOnly' = 'supported',
  'delta.feature.invariants' = 'supported',
  'delta.minReaderVersion' = '1',
  'delta.minWriterVersion' = '2'
);
"""

# COMMAND ----------
def curated_table_sql(table, columns, partition=None, env=None):
    partition_str = f"PARTITIONED BY ({partition})\n" if partition else ""
    return f"""
CREATE TABLE IF NOT EXISTS idf_curated_{env}.uspf.{table} (
{columns}
)
USING delta
{partition_str}LOCATION 's3://{platform}-engineered/{env}/catalog/curated/uspf/{table}_v2'
TBLPROPERTIES (
  'delta.checkpoint.writeStatsAsJson' = 'false',
  'delta.checkpoint.writeStatsAsStruct' = 'true',
  'delta.columnMapping.mode' = 'name',
  'delta.enableChangeDataFeed' = 'true',
  'delta.feature.changeDataFeed' = 'supported',
  'delta.feature.invariants' = 'supported'
);
"""

# COMMAND ----------
if __name__ == "__main__":
    for env in envs:
        print(f"-- RAW TABLES for {env} --")
        for tbl in RAW_TABLES:
            sql_statement = raw_table_sql(tbl["name"], tbl["columns"], tbl["partition"], env=env)
            print(sql_statement)
            spark.sql(sql_statement)
        print(f"-- CURATED TABLES for {env} --")
        for tbl in CURATED_TABLES:
            sql_statement = curated_table_sql(tbl["name"], tbl["columns"], tbl["partition"], env=env)
            print(sql_statement)
            spark.sql(sql_statement)
    # To execute in Databricks, use: spark.sql(sql_statement)
