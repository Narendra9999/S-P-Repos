mydata-curation-service-databricks
---
This is a reference implementation for `Tomcat8-Java11` caas pattern and it uses following base  docker 
image to begin with:

```
docker.artifactory.pde.spratingsvpc.com/ratings/tomcat/8.5-java11
```
You must explicitly add dependencies on javax pacakges as they are dremoved from `Java9+`. 
You can find some useful tips for migration here: [Java8 to Java11 Migration](https://thehub.spglobal.com/community/sp_ratings/departments/information-technology/our-technology-journey/blog/2020/11/05/migrate-java8-applications-to-java11)

Let's assume you made the changes to your application so that it can run on Java11 runtime. You're now ready to  make changes to containerize your application.

Before you go any further, let's understand what each file/folder is.

```
????????? config                      [Define config/settings for each environment under this folder]
??????? ????????? dev-istio-rules.yaml    [Routing rules for each environment]
??????? ????????? dev.yaml                [Environment specific configs... same as FaaS] 
???
????????? src                         [this is where your source code lives]
???
????????? tomcat                      [Tomcat overrides]
???    ????????? context.xml            [All JNDI resources should be defined here. Use environment variables instead of actual values.]
???
????????? azure-pipeline.yml          [ci/cd pipeliens]
???
????????? Dockerfile                  [Define how to build your application image]
???
????????? pom.xml                     [Maven configuration file]
???
????????? service.yaml                [Kubernetes deployment descriptor]
???
????????? README.md 
```


### Resources managed by Tomcat (JNDI)
Create a top level `tomcat` folder at the project's root and create an empty file named `context.xml` inside that folder.
In true spirit of DevOps, App Dev teams will be responsible for defining the configuration for resource 
that the application may need. Define all JNDI resources in the context.xml file. [Check out the one in this repo which defines the JNDI Datasource](tomcat/context.xml).

### Config folder
Any environment specific application config should go under `config` directory (same as what we're doing for `FaaS`).
There will be a file with name matching environment name (e.g. dev/qa/si/uat/prod/dr/hotfix). You will also need to define an 
additional file for each environment where you will be defining how the traffic will be routed to your service. Check out [dev-istio-rules.yaml](config/dev-istio-rules.yaml) for example.

### Dockerfile
You will be defining how to build image or your applciation in this file. You must use following base image:
```
docker.artifactory.pde.spratingsvpc.com/ratings/tomcat/8.5-java11
```

Tomcat treats environment variable differently, so you have to make sure that all of your environment variables from `config/dev.yaml` are exported again in `setenv.sh`. 
Please refer to [Dockerfile](https://spglobal.visualstudio.com/ratingsproducts/_git/caas-tomcat-ref-impl?path=%2FDockerfile&version=GBmaster&line=22&lineEnd=28&lineStartColumn=1&lineEndColumn=1&lineStyle=plain&_a=contents) for reference.

You will now need to copy the `context.xml` file containing any JNDI resources for your application to `/local/apps/appusr/tomcat/conf/context.xml`.

At last you will need to copy your war file to tomcat's webapps directory. This example copies the war as ROOT.war so that the application 
is available at context path `/`, but you might need to change it to match it to your context path.

### service.yaml
This file should contain definitions for `Deployment`, `Service` and `ServiceMonitor` for your application. Please refer to [service.yaml](service.yaml) for more details.
You must define memory/cpu limits and resources based on the needs for your application. You must define the `liveness` and `readiness` probes in this file.
Base image comes with a default `/ready` endpoint which returns `200 (OK)` as long as tomcat can take traffic. You might want to change it to 
perform actual healthcheck based on your application.

How to run this on my local?
---
Assuming you have a fresh copy of tomcat-8.5, please make following changes in order to test the applciation on your local machine:

Following values needs to be set as environment variables in order to run this app on your local.

#### setenv.sh
Create a file called `setenv.sh` under `<CATALINA_HOME>/bin` directory and export all environment variables in that file.

Note: These are example values that you can use to test this repo, but your real values might be different.

```
export SPR_APP_SECRET_HC_VAULT_BASE_URL=https://sm-vault.dev.spratingsvpc.com
export SPR_APP_SECRET_HC_VAULT_TOKEN=<CHANGEME>
export SHELF_ID=<CHANGEME>/dev
export JDBC_URL="<CHANGEME>"
export JDBC_USER="<CHANGEME>"

```
you might have to use `SET` insetad of `EXPORT` if you're running on Windows based system. 

#### context.xml
Copy the context file from `tomcat` folder in this repo to `<CATALINA_HOME>/conf` 
folder overriding the default `context.xml` that comes packaged with tomcat by default. 

The reference Tomcat instance included in the CaaS base image provides the Oracle 19c JDBC driver jar under `<CATALINA_HOME>/lib/jdbc`

You will need to configure your tomcat to work with RSM. If you haven't already or not sure what it means, please check out RSM documentation on Hub.

[RSM Doc](https://thehub.spglobal.com/people/shri_hulisandra/blog/2019/05/23/do-you-have-plain-text-passwords-in-your-tomcat-config-files)

### Run Docker Image on your local (only if you have docker desktop installed)
Easiest way to try the application out on your local is to use docker.

## How to access Application Logs
- [Dev Logs](https://splunksearch.mge.spratingsvpc.com/en-US/app/search/search?q=search%20index%3Dcaas_dev%20container_name%3D%22mydata-curation-service-databricks%22)
- [QA Logs](https://splunksearch.mge.spratingsvpc.com/en-US/app/search/search?q=search%20index%3Dcaas_qa%20container_name%3D%22mydata-curation-service-databricks%22)


## Application Metrics
- [Prometheus Metrics](http://prometheus.pde.spratingsvpc.com/graph)
- [Grafana Dashboards](http://spmon-dash.pde.spratingsvpc.com/d/0b8g7trZk/ratings-apps-statistics?orgId=1)
- [DEV Jaeger Search UI](http://jaeger.caas.dev.spratingsvpc.com/search)

#### Docker build
```
mvn clean package

docker build -t mydata-curation-service-databricks .

docker run -it -e SPR_APP_SECRET_HC_VAULT_BASE_URL=https://sm-vault.dev.spratingsvpc.com -e SPR_APP_SECRET_HC_VAULT_TOKEN=<CHANGEME> -e JDBC_URL="<CHANGEME>" -e JDBC_USER=<CHANGEME> -e SHELF_ID="<CHANGEME>/dev"  -p 8080:8080  mydata-curation-service-databricks
```

Once the application is up and running following endpoints are available:
- `Home Page`: [https://localhost:8443](https://localhost:8443)

Health endpoint can be accessed through the `/ready` url:
- [http://localhost:8080/ready](http://localhost:8080/ready)

Your application is exposing prometheus metrics through actuator url:
- [https://localhost:8443/metrics/prometheus](https://localhost:8443/metrics/prometheus)


## Dockerize the Application

`CI/CD` pipeline will be building the docker image for your application based on the contents of `Dockerfile`.


## Environment Specific Configs using `ConfigMaps`

Environment specific configs defined in `dev.yaml` / `qa.yaml` / `prod.yaml` etc, will be provided to your application as environment variables/volume mounts.


![](https://matthewpalmer.net/kubernetes-app-developer/articles/configmap-diagram.gif)


