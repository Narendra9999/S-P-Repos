-- Create validation warnings table for DP to APD pipeline
CREATE TABLE IF NOT EXISTS idf_curated_${env}.uspf.t_pf_validation_warnings (
    PHOENIX_ID STRING,
    REPORT_ID STRING,
    SECTOR_NAME STRING,
    STATEMENT_BASIS_NAME STRING,
    warning_type STRING,
    warning_message STRING,
    invalid_value STRING,
    warning_timestamp TIMESTAMP,
    run_id BIGINT
)
USING DELTA
LOCATION 's3://spr-idf-${env:aws_service_env}-platform-engineered/${env}/catalog/curated/uspf/t_pf_validation_warnings'
TBLPROPERTIES (
    'delta.minReaderVersion' = '1',
    'delta.minWriterVersion' = '2',
    'delta.enableChangeDataFeed' = 'true'
);

