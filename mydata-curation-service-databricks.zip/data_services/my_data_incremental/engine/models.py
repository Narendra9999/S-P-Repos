from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Optional

from pyspark.sql import DataFrame

from data_services.my_data_incremental.prepared_financials.scd import SCDType2Config


@dataclass(frozen=True)
class DatasetTarget:
    """
    Describes the destination for a dataset execution.
    """

    catalog: str
    schema: str
    table: str
    options: Dict[str, str] = field(default_factory=dict)
    apply_transformations: bool = True
    transformation_catalog: Optional[str] = None
    transformation_schema: Optional[str] = None
    write_mode: str = "delta"
    transformation_table: Optional[str] = None
    skip_schema_validation: bool = False
    create_if_missing: bool = False
    config_key: Optional[str] = None
    schema_catalog: Optional[str] = None

    @property
    def catalog_for_schema(self) -> str:
        """Catalog to use for schema file lookup (may differ from target catalog for env-specific catalogs)"""
        return self.schema_catalog or self.catalog

    @property
    def catalog_for_transform(self) -> str:
        return self.transformation_catalog or self.catalog

    @property
    def schema_for_transform(self) -> str:
        return self.transformation_schema or self.schema

    @property
    def fully_qualified_name(self) -> str:
        if self.write_mode != "delta":
            return self.table or f"{self.catalog}.{self.schema}.{self.table}"
        return f"{self.catalog}.{self.schema}.{self.table}"

    @property
    def table_for_transform(self) -> str:
        return self.transformation_table or self.table

    @property
    def destination_type(self) -> str:
        return self.write_mode

    @property
    def has_physical_table(self) -> bool:
        return self.write_mode == "delta"


@dataclass
class DatasetExecution:
    """
    Captures the artefacts required to persist a prepared dataset.
    """

    name: str
    dataframe: DataFrame
    target: DatasetTarget
    run_id: Optional[int] = None
    scd_config: Optional[SCDType2Config] = None
    effective_timestamp_column: str = "processing_timestamp"
    context: Dict[str, str] = field(default_factory=dict)


@dataclass
class DatasetProcessingSummary:
    """
    Captures per-dataset execution metadata for downstream logging.
    """

    name: str
    write_mode: str
    target: str
    scd_applied: bool
    transformation_applied: bool
    run_id: Optional[str] = None
    row_count: Optional[int] = None
    kafka_result: Optional[Dict[str, Any]] = None
    postgres_result: Optional[Dict[str, Any]] = None
    additional_metadata: Dict[str, Any] = field(default_factory=dict)
