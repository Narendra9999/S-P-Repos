from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import datetime
from typing import Optional

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F

from data_services.my_data_incremental.config.config_loader import Config
from data_services.my_data_incremental.engine.models import DatasetExecution, DatasetProcessingSummary, DatasetTarget
from data_services.my_data_incremental.engine.transformation_manager import TransformationManager
from data_services.my_data_incremental.io.outputs.kafka_writer import KafkaDatasetWriter
from data_services.my_data_incremental.io.outputs.postgres_writer import PostgresDatasetWriter
from data_services.my_data_incremental.prepared_financials.scd import SCDType2MergeManager
from data_services.my_data_incremental.prepared_financials.sql_transforms import SQLTransformContext, SQLTransformExecutor

logger = logging.getLogger(__name__)


@dataclass
class SchemaCheckResult:
    catalog: str
    schema: str
    table: str
    has_schema: bool


class DatasetProcessingEngine:
    """
    Config-driven engine capable of applying optional SQL transformations,
    ensuring schema definitions exist, and writing data with or without SCD Type 2 semantics.
    """

    def __init__(
        self,
        spark: SparkSession,
        config_loader: Config,
        env: str,
    ) -> None:
        self.spark = spark
        self.config_loader = config_loader
        self.env = env
        self.transformation_manager = TransformationManager(env=env)
        self.sql_executor = SQLTransformExecutor(
            spark,
            default_context=SQLTransformContext(parameters={"env": env}),
            log_sql=False,
        )
        self.kafka_writer = KafkaDatasetWriter(env=env)
        self.postgres_writer = PostgresDatasetWriter(env=env)

    def _ensure_schema_exists(self, target: DatasetTarget) -> SchemaCheckResult:
        """
        Verify that a schema definition exists for the target table.
        """
        if target.write_mode != "delta" or target.skip_schema_validation:
            return SchemaCheckResult(
                catalog=target.catalog,
                schema=target.schema,
                table=target.table,
                has_schema=True,
            )

        schema = self.config_loader.load_schema(
            catalog=target.catalog_for_schema,
            schema=target.schema,
            table=target.table,
        )
        result = SchemaCheckResult(
            catalog=target.catalog,
            schema=target.schema,
            table=target.table,
            has_schema=schema is not None,
        )
        if not result.has_schema:
            raise ValueError(
                f"Schema definition missing for {target.fully_qualified_name}. "
                "Create config/schemas entry before writing."
            )
        return result

    def _apply_transformations(
        self,
        df: DataFrame,
        target: DatasetTarget,
        context: Optional[dict] = None,
    ) -> DataFrame:
        """
        Apply catalog/schema/table-specific SQL transformation if present.
        """
        if not target.apply_transformations:
            return df

        sql_template = self.transformation_manager.resolve_sql(
            catalog=target.catalog_for_transform,
            schema=target.schema_for_transform,
            table=target.table_for_transform,
        )

        if not sql_template:
            return df

        source_view = self.sql_executor.register_temporary_view(df, prefix=f"{target.table}_pre")
        try:
            ctx = context or {}
            transformed_df = self.sql_executor.execute(
                sql_template,
                params={
                    "source_view": source_view,
                    "source_table": ctx.get("source_table"),
                    "pipeline_run_id": ctx.get("pipeline_run_id"),
                    "dataset_run_id": ctx.get("dataset_run_id"),
                },
            )
            logger.info(
                "Transformation applied for %s.%s.%s using view %s",
                target.catalog_for_transform,
                target.schema_for_transform,
                target.table,
                source_view,
            )
            return transformed_df
        finally:
            self.spark.catalog.dropTempView(source_view)

    @staticmethod
    def _default_run_id() -> int:
        return int(datetime.utcnow().strftime("%Y%m%d%H%M%S"))

    def process_dataset(self, execution: DatasetExecution) -> DatasetProcessingSummary:
        """
        Execute the end-to-end dataset persistence flow.
        Returns a DatasetProcessingSummary capturing execution metadata for downstream logging.
        """
        logger.info("Processing dataset '%s'", execution.name)

        self._ensure_schema_exists(execution.target)

        working_df = self._apply_transformations(execution.dataframe, execution.target, execution.context)

        summary = DatasetProcessingSummary(
            name=execution.name,
            write_mode=execution.target.write_mode,
            target=execution.target.fully_qualified_name if execution.target.write_mode == "delta" else execution.target.table,
            scd_applied=bool(execution.scd_config),
            transformation_applied=execution.target.apply_transformations,
            run_id=execution.context.get("dataset_run_id"),
            additional_metadata={
                "source_table": execution.context.get("source_table"),
                "transformation": {
                    "catalog": execution.target.catalog_for_transform,
                    "schema": execution.target.schema_for_transform,
                    "table": execution.target.table_for_transform,
                }
                if execution.target.apply_transformations
                else None,
                "target_options": execution.target.options,
            },
        )

        table_fqn = execution.target.fully_qualified_name
        if execution.target.write_mode == "delta":
            if not self.spark.catalog.tableExists(table_fqn) and execution.target.create_if_missing:
                logger.info("Target table %s missing; creating with inferred schema", table_fqn)
                empty_df = working_df.limit(0)
                if execution.scd_config and execution.scd_config.version_col:
                    version_col = execution.scd_config.version_col
                    if version_col and version_col not in empty_df.columns:
                        empty_df = empty_df.withColumn(version_col, F.lit(None).cast("bigint"))
                (
                    empty_df.write.format("delta")
                    .mode("overwrite")
                    .options(**execution.target.options)
                    .saveAsTable(table_fqn)
                )

        if execution.scd_config:
            if execution.target.write_mode != "delta":
                raise ValueError("SCD processing is only supported for delta targets.")
            run_id = execution.run_id or self._default_run_id()
            manager = SCDType2MergeManager(self.spark, execution.scd_config)
            effective_col = execution.effective_timestamp_column
            if effective_col not in working_df.columns:
                if "processing_timestamp" in working_df.columns:
                    working_df = working_df.withColumn(effective_col, F.col("processing_timestamp"))
                else:
                    working_df = working_df.withColumn(effective_col, F.current_timestamp())
            version_col = execution.scd_config.version_col
            if version_col:
                existing_columns = {col.lower() for col in self.spark.table(table_fqn).columns}
                if version_col.lower() not in existing_columns:
                    logger.info(
                        "Adding missing SCD version column '%s' to target table %s",
                        version_col,
                        table_fqn,
                    )
                    self.spark.sql(f"ALTER TABLE {table_fqn} ADD COLUMN {version_col} BIGINT")
            scd_df = working_df.cache()
            try:
                summary.row_count = scd_df.count()
                manager.merge(
                    scd_df,
                    run_id=run_id,
                    effective_ts_col=effective_col,
                )
            finally:
                scd_df.unpersist()
            summary.additional_metadata["scd"] = {
                "business_keys": execution.scd_config.business_keys,
                "hash_column": execution.scd_config.hash_column,
                "run_id": run_id,
            }
            logger.info(
                "SCD Type 2 merge completed for dataset '%s' into %s",
                execution.name,
                execution.target.fully_qualified_name,
            )
        else:
            destination = execution.target.write_mode
            if destination == "temp_view":
                working_df.createOrReplaceTempView(execution.target.table)
                logger.info(
                    "Temporary view '%s' created for dataset '%s'",
                    execution.target.table,
                    execution.name,
                )
            elif destination == "delta":
                cached_df = working_df.cache()
                try:
                    summary.row_count = cached_df.count()
                    (
                        cached_df.write.format("delta")
                    .mode("append")
                    .options(**execution.target.options)
                    .saveAsTable(execution.target.fully_qualified_name)
                    )
                finally:
                    cached_df.unpersist()
                logger.info(
                    "DataFrame appended to %s for dataset '%s'",
                    execution.target.fully_qualified_name,
                    execution.name,
                )
            elif destination == "kafka":
                kafka_result = self.kafka_writer.write(
                    dataframe=working_df,
                    target=execution.target,
                    context=execution.context,
                )
                summary.kafka_result = kafka_result
                summary.row_count = kafka_result.get("records_sent")
                logger.info(
                    "Kafka payload produced for dataset '%s' using target config key '%s'",
                    execution.name,
                    execution.target.config_key or execution.target.table,
                )
            elif destination == "postgres":
                postgres_result = self.postgres_writer.write(
                    dataframe=working_df,
                    target=execution.target,
                    context=execution.context,
                )
                summary.postgres_result = postgres_result
                summary.row_count = postgres_result.get("rows_written")
                logger.info(
                    "Postgres write executed for dataset '%s' using target config key '%s'",
                    execution.name,
                    execution.target.config_key or execution.target.table,
                )
            else:
                raise ValueError(f"Unsupported target write mode '{destination}' for dataset '{execution.name}'.")
        return summary

