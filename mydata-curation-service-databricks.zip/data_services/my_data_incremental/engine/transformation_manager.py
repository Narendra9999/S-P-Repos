from __future__ import annotations

import logging
from importlib import resources
from pathlib import Path
from typing import Optional, Tuple

logger = logging.getLogger(__name__)

TRANSFORM_ROOT = "data_services.my_data_incremental.config.transformations"


class TransformationManager:
    """
    Resolves catalog/schema/table specific SQL transformations.
    """

    def __init__(self, env: str) -> None:
        self.env = env

    @staticmethod
    def _sanitize_segment(segment: str) -> str:
        """
        Normalise catalog/schema names into folder-friendly segments.
        """
        return segment.replace(".", "_")

    def _candidate_paths(self, catalog: str, schema: str, table: str) -> Tuple[Path, ...]:
        """
        Yield possible SQL file locations for a dataset transformation.
        """
        catalog_segment = self._sanitize_segment(catalog)
        schema_segment = self._sanitize_segment(schema)
        filenames = [
            f"{table}.sql",
            f"{table}_{self.env}.sql",
        ]

        candidates = []
        base = resources.files(TRANSFORM_ROOT)
        for filename in filenames:
            candidate = base / catalog_segment / schema_segment / filename
            candidates.append(candidate)

        env_suffix = f"_{self.env}" if self.env else ""
        if env_suffix and catalog_segment.endswith(env_suffix):
            base_catalog = catalog_segment[: -len(env_suffix)]
            for filename in filenames:
                candidates.append(base / base_catalog / schema_segment / filename)
        return tuple(candidates)

    def resolve_sql(self, catalog: str, schema: str, table: str) -> Optional[str]:
        """
        Return the contents of the first matching SQL transformation file, if present.
        """
        try:
            candidates = self._candidate_paths(catalog, schema, table)
        except ModuleNotFoundError:
            logger.debug(
                "Transformation root package %s not found; skipping lookups", TRANSFORM_ROOT
            )
            return None

        for candidate in candidates:
            if candidate.is_file():
                logger.info("Applying transformation from %s", candidate)
                return candidate.read_text(encoding="utf-8")
        logger.debug(
            "No transformation file found for %s.%s.%s under %s",
            catalog,
            schema,
            table,
            TRANSFORM_ROOT,
        )
        return None
