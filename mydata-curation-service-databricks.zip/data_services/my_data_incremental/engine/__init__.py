"""
Config-driven dataset processing engine.

Exposes:
    models: Dataclasses describing dataset targets and execution metadata.
    transformation_manager: Lookup utilities for optional SQL transformations.
    processing_engine: Orchestrates dataset execution with schema validation,
        transformation application, and optional SCD handling.
"""

from .models import DatasetExecution, DatasetProcessingSummary, DatasetTarget
from .processing_engine import DatasetProcessingEngine

__all__ = [
    "DatasetExecution",
    "DatasetProcessingSummary",
    "DatasetTarget",
    "DatasetProcessingEngine",
]
