import argparse
import logging
from datetime import datetime, timezone

import pandas as pd
import pyspark.dbutils
from pyspark.sql import SparkSession

from data_services.my_data_incremental.config.config_loader import Config
from data_services.my_data_incremental.curation.load_curated_table import load_curated

# Import only what is needed for raw data ingestion
from data_services.my_data_incremental.ingestion.raw_data_ingestion import process_raw_data
from data_services.my_data_incremental.utils.create_control_tables_ddls import create_control_tables
from data_services.my_data_incremental.utils.file_processing_utils import get_current_file_processing_log, determine_file_types_from_files
from data_services.my_data_incremental.utils.log_job_execution_status import (
    insert_job_metadata, insert_process_metadata, job_control_entry, job_end,
    job_start, process_control_entry, process_end, process_start)
from data_services.my_data_incremental.pipelines import process_from_config

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
handler = logging.StreamHandler()
formatter = logging.Formatter('[%(asctime)s] %(levelname)s: %(message)s')
handler.setFormatter(formatter)
logger.addHandler(handler)



# Main class for running only the raw data ingestion pipeline (DP variant)
class Main:
    def __init__(self, spark, dbutils, args):
        # Store environment and runtime arguments
        self.env = args["env"]
        self.spark = spark
        self.dbutils = dbutils
        self.args = args
        self.config_loader = None

    def run(self):
        # --- Step 1: Parse and normalize arguments ---
        def str2bool(val):
            return str(val).lower() in ("true", "1", "yes")
        self.args["dry_run"] = str2bool(self.args.get("dry_run", False))
        self.args["verbose"] = str2bool(self.args.get("verbose", False))
        self.args["show_all_messages"] = str2bool(self.args.get("show_all_messages", False))
        self.args["enable_prepared_financials"] = str2bool(self.args.get("enable_prepared_financials", False))

        # --- Step 2a: Configure logger level if provided ---
        log_level = self.args.get("log_level")
        if log_level:
            level_value = getattr(logging, str(log_level).upper(), None)
            if isinstance(level_value, int):
                logging.getLogger().setLevel(level_value)
                logger.setLevel(level_value)
                for h in logger.handlers:
                    h.setLevel(level_value)
            else:
                logger.warning("Unrecognised log level '%s'; defaulting to INFO.", log_level)
                logging.getLogger().setLevel(logging.INFO)
                logger.setLevel(logging.INFO)
                for h in logger.handlers:
                    h.setLevel(logging.INFO)

        # --- Step 2: Load DP-specific lineage config ---
        configLoader = Config(env=self.args["env"], variables=None)
        config = configLoader.loadConfig("lineage_config_dp.json")
        self.config_loader = configLoader
     

        # --- Step 3: Set processing date defaults if not provided ---
        today = datetime.now().strftime('%Y-%m-%d')
        self.args['date'] = self.args.get('date') or today
        self.args['process_date'] = self.args.get('process_date') or today

        # --- Step 4: Prepare parameters for raw data ingestion ---
        raw_data_params = {
            'process_mode': self.args['process_mode'],
            'force_reprocess': self.args['force_reprocess'],
            'date': self.args['date'],
            'process_last_n_days': self.args['process_last_n_days']
        }

        # --- Step 5: Ensure control tables exist ---
        create_control_tables(
            catalog=config['catalogs']['raw']['catalog'],
            schema=config['catalogs']['raw']['schema'],
            s3_base_path=config["storage"]["control_tables_base_path"]
        )

        # --- Step 6: Run raw data ingestion using the 'dp' mapping set ---
        # Check file processing log before raw data ingestion
        files_before_ingestion = get_current_file_processing_log(self.spark, config)
        logger.info(f"Files in dp_file_processing_log before ingestion: {len(files_before_ingestion)}")
        
    
        logger.info("STARTING RAW DATA INGESTION FOR DPTOAPD")
        process_raw_data(raw_data_params, {
            "TARGET_SCHEMA" : config['catalogs']['raw']['schema'],
            "SOURCE_S3_PREFIX" : config['storage']['stage_s3_prefix'],
            "SOURCE_S3_BUCKET": config['storage']['stage_s3_bucket'],
            "TARGET_CATALOG":  config['catalogs']['raw']['catalog'],
            "PIPELINE_TYPE": config.get("PIPELINE_TYPE", 0),
            "DATA_TYPE": "DP"
        })
        logger.info("RAW DATA INGESTION COMPLETED FOR DPTOAPD")

        # Check file processing log after raw data ingestion
        files_after_ingestion = get_current_file_processing_log(self.spark, config)
        logger.info(f"Files in dp_file_processing_log after ingestion: {len(files_after_ingestion)}")

        # Determine which files were processed in this run
        new_files = files_after_ingestion - files_before_ingestion
        
        # Determine file types from the new files processed
        processed_file_types = determine_file_types_from_files(new_files)
        
        logger.info(f"New files processed in this run: {new_files}")
        logger.info(f"File types processed: {processed_file_types}")
        
        # Check if only org files were processed (org-only mode)
        org_only_mode = processed_file_types - {"org"} and len(processed_file_types) > 0
        if org_only_mode:
            logger.info("MIXED FILE MODE - Processing all applicable file types")
        else:
            logger.info("ORG-ONLY MODE DETECTED - Skipping DP file generation and processing dp_load, comments, schedules")

        # Conditionally execute DP LOAD curation
        if "dp_load" in processed_file_types :
            logger.info("STARTING DP LOAD DP CURATION")
            load_curated(spark = self.spark, config_data = {
                "curated_table" : config['tables_curated']['t_dp_transaction_dp_load'],
                "raw_catalog" : config['catalogs']['raw']['catalog'],
                "raw_schema" : config['catalogs']['raw']['schema'],
                "raw_table" : config['tables_raw']['t_dp_transaction_dp_load'],
                "curated_catalog" : config['catalogs']['curated']['catalog'],
                "curated_schema" : config['catalogs']['curated']['schema'],
                "latest_on" : config['mappings']['curation_dp_load_dp']['latest_on'],
                "target_to_source_mapping" : config['mappings']['curation_dp_load_dp']['target_to_source_mapping'],
                "keys" : config['mappings']['curation_dp_load_dp']['keys'],
                "run_log" : config['tables_curated']['run_log'],
                # "aggregation_keys" : ["SRC_DE_UNIQ_ID_TEXT", "PHOENIX_ID", "REPORT_ID"]
            }, env=self.env)
            logger.info("CURATED DP LOAD DP COMPLETED")
        else:
            logger.info("SKIPPING DP LOAD DP CURATION - No DP_LOAD files processed")

        # Conditionally execute DP COMMENTS curation
        if "comments" in processed_file_types :
            logger.info("STARTING DP COMMENTS DP CURATION")
            load_curated(spark = self.spark, config_data = {
                "curated_table" : config['tables_curated']['t_dp_transaction_comments'],
                "raw_catalog" : config['catalogs']['raw']['catalog'],
                "raw_schema" : config['catalogs']['raw']['schema'],
                "raw_table" : config['tables_raw']['t_dp_transaction_comments'],
                "curated_catalog" : config['catalogs']['curated']['catalog'],
                "curated_schema" : config['catalogs']['curated']['schema'],
                "latest_on" : config['mappings']['curation_comments_dp']['latest_on'],
                "target_to_source_mapping" : config['mappings']['curation_comments_dp']['target_to_source_mapping'],
                "keys" : config['mappings']['curation_comments_dp']['keys'],
                "run_log" : config['tables_curated']['run_log'],
                # "aggregation_keys" : ["SRC_DE_UNIQ_ID_TEXT", "PHOENIX_ID", "REPORT_ID"]
            }, env=self.env)
            logger.info("CURATED DP COMMENTS DP COMPLETED")
        else:
            logger.info("SKIPPING DP COMMENTS DP CURATION - No COMMENTS files processed ")

        # Conditionally execute DP SCHEDULES curation
        if "schedules" in processed_file_types :
            logger.info("STARTING DP SCHEDULES DP CURATION")
            load_curated(spark = self.spark, config_data = {
                "curated_table" : config['tables_curated']['t_dp_transaction_schedules'],
                "raw_catalog" : config['catalogs']['raw']['catalog'],
                "raw_schema" : config['catalogs']['raw']['schema'],
                "raw_table" : config['tables_raw']['t_dp_transaction_schedules'],
                "curated_catalog" : config['catalogs']['curated']['catalog'],
                "curated_schema" : config['catalogs']['curated']['schema'],
                "latest_on" : config['mappings']['curation_schedules_dp']['latest_on'],
                "target_to_source_mapping" : config['mappings']['curation_schedules_dp']['target_to_source_mapping'],
                "keys" : config['mappings']['curation_schedules_dp']['keys'],
                "run_log" : config['tables_curated']['run_log'],
                # "aggregation_keys" : ["SRC_DE_UNIQ_ID_TEXT", "PHOENIX_ID", "REPORT_ID"]
            }, env=self.env)
            logger.info("CURATED DP SCHEDULES DP COMPLETED")
        else:
            logger.info("SKIPPING DP SCHEDULES DP CURATION - No SCHEDULES files processed")

        # Conditionally execute DP ORG curation
        if "org" in processed_file_types:
            logger.info("STARTING DP ORG DP CURATION")
            load_curated(spark = self.spark, config_data = {
                "curated_table" : config['tables_curated']['t_dp_transaction_org'],
                "raw_catalog" : config['catalogs']['raw']['catalog'],
                "raw_schema" : config['catalogs']['raw']['schema'],
                "raw_table" : config['tables_raw']['t_dp_transaction_org'],
                "curated_catalog" : config['catalogs']['curated']['catalog'],
                "curated_schema" : config['catalogs']['curated']['schema'],
                "latest_on" : config['mappings']['curation_dp_org_dp']['latest_on'],
                "target_to_source_mapping" : config['mappings']['curation_dp_org_dp']['target_to_source_mapping'],
                "keys" : config['mappings']['curation_dp_org_dp']['keys'],
                "run_log" : config['tables_curated']['run_log'],
                # "aggregation_keys" : ["PHOENIX_ID"]
            }, env=self.env)
            logger.info("CURATED DP ORG DP COMPLETED")
        else:
            logger.info("SKIPPING DP ORG DP CURATION - No ORG files processed")

        pipeline_config_name = self.args.get("pipeline_config")
        if pipeline_config_name:
            self._run_pipeline_from_config(pipeline_config_name)

    def _run_pipeline_from_config(self, config_name: str):
        logger.info("STARTING CONFIG-DRIVEN PIPELINE FROM %s", config_name)
        process_from_config(
            spark=self.spark,
            env=self.env,
            config_name=config_name,
            config_loader=self.config_loader,
        )
        logger.info("CONFIG-DRIVEN PIPELINE %s COMPLETED", config_name)


# Entrypoint for running the DP raw data ingestion pipeline
def main_entrypoint():
    parser = argparse.ArgumentParser(description="Run DP-only raw data ingestion pipeline")
    parser.add_argument("--env", help="Environment name (dev, qa, uat, prod, dr)")
    parser.add_argument("--process_mode", required=True, help="Processing mode (single_date, unprocessed_files, date_range, missing_dates)")
    parser.add_argument("--force_reprocess", help="Force reprocess flag")
    parser.add_argument("--date", help="Date for batch processing (YYYY-MM-DD), required for single_date and unprocessed_files modes")
    parser.add_argument("--process_date", help="Date for batch processing (YYYY-MM-DD), required for elt processing")
    parser.add_argument("--process_last_n_days", type=int, help="Number of days for date_range or missing_dates modes")
    parser.add_argument("--dry_run")
    parser.add_argument("--verbose")
    parser.add_argument("--show_all_messages")
    parser.add_argument("--s3_bucket", required=True, help="S3 bucket for output data")
    parser.add_argument("--output_dir", required=True, help="Output directory path")
    parser.add_argument("--pipeline_config", help="Execute datasets defined by the specified pipeline config file")
    parser.add_argument("--log_level", help="Python logging level (e.g., INFO, DEBUG, WARNING)")

    # Parse command-line arguments
    args = vars(parser.parse_args())

    # Initialize Spark and dbutils
    spark = SparkSession.builder.getOrCreate()
    dbutils = pyspark.dbutils.DBUtils(spark)

    # Run the main ingestion process
    main_obj = Main(spark=spark, dbutils=dbutils, args=args)
    main_obj.run()


if __name__ == "__main__":
    main_entrypoint()
