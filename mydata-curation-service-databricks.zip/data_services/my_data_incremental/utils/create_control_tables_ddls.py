from typing import Dict


def generate_table_ddls(catalog: str, schema: str, s3_base_path: str) -> Dict[str, str]:
    s3_path = f"{s3_base_path}/{schema}"

    job_control = f"""
    CREATE TABLE IF NOT EXISTS {catalog}.{schema}.t_job_control (
      job_id BIGINT,
      job_run_id BIGINT GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1),
      job_start_time TIMESTAMP,
      job_end_time TIMESTAMP,
      job_status VARCHAR(200),
      job_freq INT,
      audit_inserted_ts TIMESTAMP,
      audit_updated_ts TIMESTAMP,
      audit_insert_id VARCHAR(200),
      audit_updated_id VARCHAR(200))
    USING delta
    LOCATION '{s3_path}/job_control'
    TBLPROPERTIES (
      'delta.feature.identityColumns' = 'supported',
      'delta.minReaderVersion' = '3',
      'delta.minWriterVersion' = '7')
    """

    job_metadata = f"""
    CREATE TABLE IF NOT EXISTS {catalog}.{schema}.t_job_metadata (
      job_id BIGINT GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1),
      job_name VARCHAR(100),
      job_desc VARCHAR(200),
      job_dependencies VARCHAR(3000),
      job_source_schema VARCHAR(200),
      job_target_schema VARCHAR(300),
      job_freq INT,
      dq_enabled VARCHAR(10),
      dq_id VARCHAR(1000),
      audit_insert_id VARCHAR(200),
      audit_updated_id VARCHAR(200))
    USING delta
    LOCATION '{s3_path}/job_metadata'
    TBLPROPERTIES (
      'delta.enableChangeDataFeed' = 'true',
      'delta.minReaderVersion' = '1',
      'delta.minWriterVersion' = '6')
    """

    process_control = f"""
    CREATE TABLE IF NOT EXISTS {catalog}.{schema}.t_process_control (
      process_run_id BIGINT GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1),
      process_id BIGINT,
      job_run_id BIGINT,
      process_name VARCHAR(100),
      process_start_time TIMESTAMP,
      process_end_time TIMESTAMP,
      process_status VARCHAR(200),
      process_source_counts VARCHAR(4),
      process_target_counts VARCHAR(1000),
      process_dq_id INT,
      process_freq INT,
      audit_inserted_ts TIMESTAMP,
      audit_updated_ts TIMESTAMP,
      audit_insert_id VARCHAR(200),
      audit_updated_id VARCHAR(200),
      table_delta_version INT)
    USING delta
    LOCATION '{s3_path}/process_control'
    TBLPROPERTIES (
      'delta.enableChangeDataFeed' = 'true',
      'delta.minReaderVersion' = '1',
      'delta.minWriterVersion' = '6')
    """

    process_metadata = f"""
    CREATE TABLE IF NOT EXISTS {catalog}.{schema}.t_process_metadata (
      process_id BIGINT GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1),
      job_id BIGINT,
      process_name VARCHAR(100),
      process_source_schema VARCHAR(200),
      process_target_schema VARCHAR(200),
      process_dependencies VARCHAR(300),
      process_freq BIGINT,
      process_load_type VARCHAR(300),
      process_keys VARCHAR(300),
      audit_insert_id VARCHAR(200),
      audit_updated_id VARCHAR(200))
    USING delta
    LOCATION '{s3_path}/process_metadata'
    TBLPROPERTIES (
      'delta.enableChangeDataFeed' = 'true',
      'delta.minReaderVersion' = '1',
      'delta.minWriterVersion' = '6')
    """

    return {
        "job_control": job_control.strip(),
        "job_metadata": job_metadata.strip(),
        "process_control": process_control.strip(),
        "process_metadata": process_metadata.strip()
    }


def create_control_tables(catalog: str, schema: str, s3_base_path: str) -> None:
  ddl_scripts = generate_table_ddls(
      catalog=catalog,
      schema=schema,
      s3_base_path=s3_base_path
  )

  for _, ddl in ddl_scripts.items():
      spark.sql(ddl)
