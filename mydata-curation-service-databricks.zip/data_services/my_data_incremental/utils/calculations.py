from pyspark.sql import functions as F
from pyspark.sql import types as T

class calculations:
    def __init__(self, env: str = None):
        self.env = env or ""

    def smart_aggregate(
        self,
        df,
        keys,
        aggregate_cols=None,   # <- NEW: if provided, only these get aggregated; others -> first
        sep=", ",
        dedup=True,
        order_by=None,
        first_cols=None        # optional: force some columns to 'first' regardless
    ):
        """
        Group by `keys` and aggregate columns smartly:
          - Numeric columns (Byte/Short/Int/Long/Float/Double/Decimal): SUM
          - String columns: if all non-null values in a group are integers -> SUM (as string), else CONCAT_WS(sep)
          - Other types: CONCAT_WS(sep) of stringified values
          - If `aggregate_cols` is provided, only those columns get aggregated; all others use FIRST (optionally ordered).
        Notes:
          - String columns return STRING (safest, since some groups may concat).
          - If you want decimal-detection for strings (e.g. "1.5"), say the word and we’ll extend the regex.
        """
        if isinstance(keys, str):
            keys = [keys]
        key_set = set(keys)

        # normalize optional params
        if first_cols is None:
            first_cols = set()
        elif isinstance(first_cols, str):
            first_cols = {first_cols}
        else:
            first_cols = set(first_cols)

        if isinstance(order_by, str):
            order_keys = [order_by]
        else:
            order_keys = order_by  # None or list

        if aggregate_cols is None:
            aggregate_cols = [f.name for f in df.schema.fields if f.name not in key_set]
        elif isinstance(aggregate_cols, str):
            aggregate_cols = [aggregate_cols]

        agg_set = set(aggregate_cols)

        schema = df.schema

        # type buckets: everything Spark can SUM natively
        integral_types = (T.ByteType, T.ShortType, T.IntegerType, T.LongType)
        numeric_types  = integral_types + (T.FloatType, T.DoubleType, T.DecimalType)

        # helpers
        def concat_expr(colname: str):
            c = F.col(colname)
            base_val = F.when(c.isNotNull(), c.cast("string"))
            if order_keys:
                struct_fields = [F.col(k) for k in order_keys] + [base_val.alias("v")]
                arr = F.collect_list(F.struct(*struct_fields))
                arr = F.array_sort(arr)
                vals = F.transform(arr, lambda x: x["v"])
            else:
                vals = F.collect_list(base_val)
            if dedup:
                vals = F.array_distinct(vals)
            return F.concat_ws(sep, vals)

        def first_expr(colname: str):
            c = F.col(colname)
            base_val = F.when(c.isNotNull(), c)
            if order_keys:
                ord_struct = F.struct(*[F.col(k) for k in order_keys])
                return F.min_by(base_val, ord_struct)
            else:
                return F.first(base_val, ignorenulls=True)

        aggs = []
        select_exprs = [F.col(k) for k in keys]  # final projection
        finalize_specs = []  # (out_col, tmp_invalid, tmp_sum, tmp_concat)

        for field in schema.fields:
            c = field.name
            if c in key_set:
                continue

            # If aggregate_cols provided and this column is NOT in it -> take FIRST
            if c not in agg_set:
                agg = first_expr(c).alias(c)
                aggs.append(agg)
                select_exprs.append(F.col(c))
                continue

            # Explicit "first" override
            if c in first_cols:
                agg = first_expr(c).alias(c)
                aggs.append(agg)
                select_exprs.append(F.col(c))
                continue

            dt = field.dataType

            # Case 1: native-summable numeric types -> SUM (retain numeric type)
            if isinstance(dt, numeric_types):
                aggs.append(F.sum(F.col(c)).alias(c))
                select_exprs.append(F.col(c))
                continue

            # Case 2: strings -> sum-if-all-int-else-concat (always STRING output)
            if isinstance(dt, T.StringType):
                numeric_pattern = r'^[+-]?(?:\d+(?:\.\d+)?|\.\d+)$'
                is_numeric = F.coalesce(F.col(c).rlike(numeric_pattern), F.lit(False))

                tmp_invalid = f"__invalid_{c}"
                tmp_sum     = f"__sum_{c}"
                tmp_concat  = f"__concat_{c}"

                invalid_count = F.sum(
                    F.when(F.col(c).isNotNull() & (~is_numeric), F.lit(1)).otherwise(F.lit(0))
                )
                decimal_type = "decimal(38,12)"
                zero_decimal = F.lit(0).cast(decimal_type)
                numeric_value = F.when(is_numeric, F.col(c).cast(decimal_type)).otherwise(zero_decimal)
                sum_as_decimal = F.sum(numeric_value)

                aggs.extend([
                    invalid_count.alias(tmp_invalid),
                    sum_as_decimal.alias(tmp_sum),
                    concat_expr(c).alias(tmp_concat),
                ])
                finalize_specs.append((c, tmp_invalid, tmp_sum, tmp_concat))
                continue

            # Case 3: other types -> stringify + concat (STRING)
            tmp_concat = f"__concat_{c}"
            aggs.append(concat_expr(c).alias(tmp_concat))
            finalize_specs.append((c, None, None, tmp_concat))

        # run aggregation
        grouped = df.groupBy(*keys).agg(*aggs)

        # finalize string/dynamic columns
        for (out_col, tmp_invalid, tmp_sum, tmp_concat) in finalize_specs:
            if tmp_invalid is None:
                expr = F.col(tmp_concat)                             # only concat path
            else:
                sum_str = F.col(tmp_sum).cast("string")
                sum_trimmed = F.regexp_replace(sum_str, r'(\.[0-9]*[1-9])0+$', "$1")
                sum_trimmed = F.regexp_replace(sum_trimmed, r'\.0+$', '')
                normalized_sum = F.when(sum_trimmed.eqNullSafe(""), F.lit("0")).otherwise(sum_trimmed)
                expr = F.when(F.col(tmp_invalid) == 0,
                               normalized_sum) \
                         .otherwise(F.col(tmp_concat))              # sum-if-all-int else concat
            select_exprs.append(expr.alias(out_col))

        # select only desired outputs (avoids tmp columns automatically)
        return grouped.select(*select_exprs)
