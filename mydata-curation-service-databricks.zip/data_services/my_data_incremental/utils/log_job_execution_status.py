import datetime
import json
import logging
from datetime import timezone
from typing import Any, Dict, Optional, Tuple

import numpy as np
from pyspark.sql import SparkSession


logger = logging.getLogger(__name__)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[logging.StreamHandler()],
)


def insert_job_metadata(
    spark: SparkSession,
    job_name: str,
    job_frequency: int,
    schema: str,
    tables: Dict[str, str],
    status_values: Dict[str, str],
    source_schema: str,
    target_schema: str,
    audit_user: str,
) -> Tuple[Optional[int], Optional[int]]:
    """
    Inserts a new job metadata record into the job metadata table if it does not already exist,
    and creates a corresponding entry in the job control table.

    Parameters:
        spark (SparkSession): The active Spark session.
        job_name (str): The name of the job to check or insert.
        job_frequency (int): Frequency in minutes the job is expected to run.
        schema (str): Schema where the metadata table is located.
        tables (Dict[str, str]): Dictionary containing table names, e.g., "job_metadata" and "job_control".
        status_values (Dict[str, str]): Dictionary of job status labels and values.
        source_schema (str): Source schema used by the job.
        target_schema (str): Target schema used by the job.
        audit_user (str): User ID used for auditing the insert.

    Returns:
        Optional[Tuple[int, int]]: The (job_id, job_run_id) if inserted or found, else None.
    """
    job_id: int = None
    job_run_id: int = None

    current_time = str(datetime.datetime.now(timezone.utc))
    timestamp_expr = f"cast(date_format('{current_time}', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp)"

    sql_fetch_job_id = f"""
    SELECT job_id FROM {schema}.{tables['job_metadata']}
    WHERE job_name = '{job_name}'
    """
    existing = spark.sql(sql_fetch_job_id).first()

    if existing is not None:
        job_id = int(existing[0])
        logger.info(f"Job '{job_name}' already exists with job_id={job_id}. Skipping insert into job_metadata.")
    else:
        logger.info(f"Inserting job metadata for new job '{job_name}'...")
        sql_insert_metadata = f"""
            INSERT INTO {schema}.{tables['job_metadata']} (
                job_name,
                job_desc,
                job_dependencies,
                job_source_schema,
                job_target_schema,
                job_freq,
                dq_enabled,
                dq_id,
                audit_insert_id,
                audit_updated_id
            )
            VALUES (
                '{job_name}',
                '{job_name}',
                NULL,
                '{source_schema}',
                '{target_schema}',
                {job_frequency},
                FALSE,
                NULL,
                '{audit_user}',
                '{audit_user}'
            )
        """
        spark.sql(sql_insert_metadata)
        logger.info(f"Inserted job metadata with job_id={job_id}")

        result = spark.sql(sql_fetch_job_id).first()
        job_id = int(result[0])

    sql_fetch_job_run_id = f"""
        SELECT job_run_id
        FROM {schema}.{tables['job_control']}
        WHERE job_id = {job_id}
        AND job_status = '{status_values['NOT_STARTED']}'
        ORDER BY job_run_id DESC
        LIMIT 1
    """
    job_run_result = spark.sql(sql_fetch_job_run_id).first()

    if job_run_result is None:
        logger.warning(f"No entry with status 'NOT_STARTED' found for job_id={job_id}")
        sql_insert_control = f"""
            INSERT INTO {schema}.{tables['job_control']} (
                job_id,
                job_start_time,
                job_end_time,
                job_status,
                job_freq,
                audit_inserted_ts,
                audit_updated_ts,
                audit_insert_id,
                audit_updated_id
            )
            VALUES (
                {job_id},
                cast(date_format('1900-01-01 00:00:00', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp),
                {timestamp_expr},
                '{status_values['NOT_STARTED']}',
                {job_frequency},
                {timestamp_expr},
                {timestamp_expr},
                '{audit_user}',
                '{audit_user}'
            )
        """
        spark.sql(sql_insert_control)
        logger.info(f"Inserted job control entry for job_id={job_id}")

    result = spark.sql(sql_fetch_job_run_id).first()

    job_run_id = int(result[0])
    logger.info(f"Created job_run_id={job_run_id} for job_id={job_id}")

    return job_id, job_run_id


def insert_process_metadata(
    spark: SparkSession,
    job_id: int,
    job_run_id: int,
    process_name: str,
    process_frequency: int,
    load_type: str,
    key: str,
    schema: str,
    tables: Dict[str, str],
    status_values: Dict[str, str],
    source_schema: str,
    target_schema: str,
    audit_user: str,
) -> int:
    """
    Inserts a new process metadata record into the process metadata table,
    and creates a corresponding entry in the process control table.
    Skips insertion into process metadata if a process with the same job_id and process_name already exists,
    but always inserts a new process control entry for each job_run_id.
    """
    current_time = str(datetime.datetime.now(timezone.utc))
    timestamp_expr = f"cast(date_format('{current_time}', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp)"

    process_id: int = None

    sql_check = f"""
    SELECT process_id FROM {schema}.{tables['process_metadata']}
    WHERE job_id = {job_id}
      AND process_name = '{process_name}'
    """
    existing = spark.sql(sql_check).first()

    if existing:
        process_id = int(existing[0])
        logger.info(
            f"Process '{process_name}' already exists for job_id={job_id} with process_id={process_id}. Skipping insert into process_metadata."
        )
    else:
        sql_insert = f"""
            INSERT INTO {schema}.{tables['process_metadata']} (
                job_id,
                process_name,
                process_source_schema,
                process_target_schema,
                process_dependencies,
                process_freq,
                process_load_type,
                process_keys,
                audit_insert_id,
                audit_updated_id
            )
            VALUES (
                {job_id},
                '{process_name}',
                '{source_schema}',
                '{target_schema}',
                NULL,
                {process_frequency},
                '{load_type}',
                '{key}',
                '{audit_user}',
                '{audit_user}'
            )
        """
        spark.sql(sql_insert)

        sql_fetch_process_id = f"""
            SELECT process_id
            FROM {schema}.{tables['process_metadata']}
            WHERE job_id = {job_id}
            AND process_name = '{process_name}'
            ORDER BY process_id DESC
            LIMIT 1
        """
        result = spark.sql(sql_fetch_process_id).first()
        process_id = int(result[0])
        logger.info(f"Retrieved process_id={process_id}")

    sql_fetch_process_run_id = f"""
        SELECT process_run_id
        FROM {schema}.{tables['process_control']}
        WHERE job_run_id = {job_run_id}
        AND process_id = {process_id}
        AND process_status = '{status_values['NOT_STARTED']}'
        ORDER BY job_run_id DESC
        LIMIT 1
    """
    process_run_result = spark.sql(sql_fetch_process_run_id).first()

    if process_run_result is None:
        sql_control_insert = f"""
            INSERT INTO {schema}.{tables['process_control']} (
                process_id,
                job_run_id,
                process_name,
                process_start_time,
                process_end_time,
                process_status,
                process_source_counts,
                process_target_counts,
                process_dq_id,
                process_freq,
                table_delta_version,
                audit_inserted_ts,
                audit_updated_ts,
                audit_insert_id,
                audit_updated_id
            )
            VALUES (
                {process_id},
                {job_run_id},
                '{process_name}',
                cast(date_format('1900-01-01 00:00:00', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp),
                NULL,
                '{status_values['NOT_STARTED']}',
                NULL,
                NULL,
                NULL,
                {process_frequency},
                0,
                {timestamp_expr},
                {timestamp_expr},
                '{audit_user}',
                '{audit_user}'
            )
        """
        spark.sql(sql_control_insert)
        logger.info(f"Process control entry created for process_id={process_id}, job_run_id={job_run_id}")

    return process_id


def job_control_entry(
    spark: SparkSession,
    job_id: int,
    job_frequency: int,
    schema: str,
    job_start_time: str,
    tables: Dict[str, str],
    status_values: Dict[str, str],
    audit_user: str
) -> Optional[int]:
    """
    Creates a new job control entry if the last job completed successfully.

    Args:
        spark: SparkSession object.
        job_id: Job identifier.
        schema: Database schema.
        job_start_time: Proposed start time for the job.
        tables: Dictionary of table names.
        status_values: Dictionary of status values.
        audit_user: User performing the audit.

    Returns:
        job_run_id if created, else None.
    """
    sql_max_job_run_id = f"""
        SELECT max(job_run_id) FROM {schema}.{tables['job_control']} WHERE job_id = {job_id}
    """
    max_job_run_id_df = spark.sql(sql_max_job_run_id).toPandas()
    max_job_run_id_val = max_job_run_id_df.iloc[0, 0]

    if max_job_run_id_val is None or (isinstance(max_job_run_id_val, float) and np.isnan(max_job_run_id_val)):
        logger.info("No entry exists in the job control table")
        return None

    sql_status_check = f"""
        SELECT job_status
        FROM {schema}.{tables['job_control']}
        WHERE job_run_id = {max_job_run_id_val}
    """
    status_df = spark.sql(sql_status_check).toPandas()
    job_status = status_df.iloc[0]["job_status"]

    if job_status == status_values["COMPLETED"]:
        sql_insert = f"""
            INSERT INTO {schema}.{tables['job_control']}
            (job_id, job_start_time, job_end_time, job_status, job_freq, audit_insert_id, audit_updated_id)
            VALUES (
                {job_id},
                NULL,
                NULL,
                '{status_values['NOT_STARTED']}',
                {job_frequency},
                '{audit_user}',
                '{audit_user}'
            )
        """
        spark.sql(sql_insert)

        sql_fetch_new_run_id = f"""
            SELECT max(job_run_id)
            FROM {schema}.{tables['job_control']}
            WHERE job_status = '{status_values['NOT_STARTED']}' AND job_id = {job_id}
        """
        result_df = spark.sql(sql_fetch_new_run_id).toPandas()
        return result_df.iloc[0, 0]

    logger.info("Active or failed job already running")
    return None


def job_start(
    spark: SparkSession,
    job_id: int,
    schema: str,
    tables: Dict[str, str],
    status_values: Dict[str, str],
    audit_user: str
) -> Optional[int]:
    """
    Marks a job as RUNNING by updating its status and inserting a timestamp.

    Args:
        spark: SparkSession object.
        job_id: Job identifier.
        schema: Database schema.
        tables: Dictionary of table names.
        status_values: Dictionary of status values.
        audit_user: User performing the audit.

    Returns:
        job_run_id if updated, else None.
    """
    sql_fetch_not_started = f"""
        SELECT job_run_id
        FROM {schema}.{tables['job_control']}
        WHERE job_id = {job_id}
        AND job_status = '{status_values['NOT_STARTED']}'
        ORDER BY job_run_id DESC
        LIMIT 1
    """
    result = spark.sql(sql_fetch_not_started).toPandas()

    if result.empty or result.iloc[0, 0] is None:
        logger.info("No entry with status 'NOT_STARTED'")
        return None

    job_run_id_val = result.iloc[0, 0]

    current_time = str(datetime.datetime.now(timezone.utc))
    update_stmt = f"""
        UPDATE {schema}.{tables['job_control']}
        SET job_status = '{status_values['RUNNING']}',
            job_start_time = cast(date_format('{current_time}', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp),
            audit_inserted_ts = cast(date_format('{current_time}', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp),
            audit_insert_id = '{audit_user}'
        WHERE job_run_id = {job_run_id_val}
        AND job_id = {job_id}
    """
    spark.sql(update_stmt)

    return job_run_id_val


def job_end(
    spark: SparkSession,
    job_id: int,
    schema: str,
    tables: Dict[str, str],
    status_values: Dict[str, str],
    audit_user: str
) -> None:
    """
    Ends a running job and schedules the next occurrence.

    Args:
        spark: SparkSession object.
        job_id: Job identifier.
        schema: Database schema.
        tables: Dictionary of table names.
        status_values: Dictionary of status values.
        audit_user: User performing the audit.

    Returns:
        New job_run_id if inserted, else None.
    """
    current_time = str(datetime.datetime.now(timezone.utc))

    sql_get_max_run_id = f"""
        SELECT max(job_run_id) FROM {schema}.{tables['job_control']} WHERE job_id={job_id}
    """
    max_job_run_id_df = spark.sql(sql_get_max_run_id).toPandas()
    job_run_id_val = max_job_run_id_df.iloc[0, 0]

    if job_run_id_val is None or (isinstance(job_run_id_val, float) and np.isnan(job_run_id_val)):
        logger.info("No entry exists in the job control table")
        return

    sql_status_check = f"""
        SELECT job_status
        FROM {schema}.{tables['job_control']}
        WHERE job_run_id = {job_run_id_val}
    """
    result = spark.sql(sql_status_check).toPandas()
    status = result.iloc[0]["job_status"]

    if status != status_values['RUNNING']:
        return

    sql_update_end = f"""
        UPDATE {schema}.{tables['job_control']}
        SET job_end_time = cast(date_format('{current_time}', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp),
            job_status = '{status_values['COMPLETED']}',
            audit_updated_ts = cast(date_format('{current_time}', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp),
            audit_updated_id = '{audit_user}'
        WHERE job_run_id = {job_run_id_val}
    """
    spark.sql(sql_update_end)


def process_control_entry(
    spark: SparkSession,
    job_run_id: int,
    schema: str,
    process_id: int,
    tables: Dict[str, str],
    status_values: Dict[str, str],
    audit_user: str
) -> None:
    """
    Inserts a new entry into the process control table for a given process_id and job_run_id.

    Args:
        spark: SparkSession object.
        job_run_id: Job run identifier.
        schema: Database schema.
        process_id: Process identifier.
        process_start_time: ISO-format timestamp string.
        table_delta_version: Table delta version.
        status_values: Dictionary of status values.
        audit_user: Username used for audit columns.
    """
    sql_fetch = f"""
        SELECT process_name, process_freq
        FROM {schema}.{tables['process_metadata']}
        WHERE process_id = {process_id}
    """
    df = spark.sql(sql_fetch).toPandas()

    if df.empty:
        raise RuntimeError(f"No existing metadata entry found for process_id={process_id}")

    process_name, process_freq = df.iloc[0]
    current_time = str(datetime.datetime.now(timezone.utc))

    sql_insert = f"""
        INSERT INTO {schema}.{tables['process_control']} (
            process_id,
            job_run_id,
            process_name,
            process_start_time,
            process_end_time,
            process_status,
            process_source_counts,
            process_target_counts,
            process_dq_id,
            process_freq,
            table_delta_version,
            audit_inserted_ts,
            audit_updated_ts,
            audit_insert_id,
            audit_updated_id
        )
        VALUES (
            {process_id},
            {job_run_id},
            '{process_name}',
            NULL,
            NULL,
            '{status_values['NOT_STARTED']}',
            NULL,
            NULL,
            NULL,
            {process_freq},
            NULL,
            CAST('{current_time}' AS timestamp),
            CAST('{current_time}' AS timestamp),
            '{audit_user}',
            '{audit_user}'
        )
    """
    try:
        spark.sql(sql_insert)
        logger.info("Process control entry created for process_id=%s", process_id)
    except Exception as e:
        logger.error("Failed to insert process control entry: %s", e)
        raise


def process_start(
    spark: SparkSession,
    job_run_id: int,
    schema: str,
    process_id: int,
    tables: Dict[str, str],
    status_values: Dict[str, str],
    audit_user: str,
) -> Optional[int]:
    """
    Updates the process control entry to mark the process as RUNNING.

    Args:
        spark: SparkSession object.
        job_run_id: Job run identifier.
        schema: Database schema.
        process_id: Process identifier.
        tables: Dictionary of table names.
        status_values: Dictionary of status values.
        audit_user: User performing the update.

    Returns:
        process_run_id if found and updated, else None.
    """
    sql_fetch = f"""
        SELECT max(process_run_id)
        FROM {schema}.{tables['process_control']}
        WHERE process_id = {process_id}
        AND process_status = '{status_values['NOT_STARTED']}'
    """
    control_df = spark.sql(sql_fetch).toPandas()

    process_run_id = control_df.iloc[0, 0]
    if process_run_id is None or np.isnan(process_run_id):
        logger.warning("No pending process found to start.")
        return None

    current_time = str(datetime.datetime.now(timezone.utc))
    sql_update = f"""
        UPDATE {schema}.{tables['process_control']}
        SET process_status = '{status_values['RUNNING']}',
            process_start_time = cast(date_format('{current_time}', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp),
            audit_updated_ts = cast(date_format('{current_time}', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp),
            audit_updated_id = '{audit_user}',
            job_run_id = {job_run_id}
        WHERE process_run_id = {process_run_id}
        AND process_id = {process_id}
    """
    spark.sql(sql_update)

    # Confirm update
    sql_confirm = f"""
        SELECT max(process_run_id)
        FROM {schema}.{tables['process_control']}
        WHERE job_run_id = {job_run_id}
        AND process_status = '{status_values['RUNNING']}'
    """
    confirm_df = spark.sql(sql_confirm).toPandas()
    confirmed_run_id = confirm_df.iloc[0, 0]

    logger.info("Process started: process_run_id=%s", confirmed_run_id)
    return confirmed_run_id


def process_end(
    spark: SparkSession,
    job_run_id: int,
    schema: str,
    process_id: int,
    tables: Dict[str, str],
    status_values: Dict[str, str],
    audit_user: str
) -> None:
    """
    Marks the current process run as completed and schedules the next one.

    Args:
        spark: SparkSession object.
        job_run_id: Job run identifier.
        schema: Database schema.
        process_id: Process identifier.
        tables: Dictionary of table names.
        status_values: Dictionary of status values.
        audit_user: Username used for audit columns.
    """
    try:
        fetch_sql = f"""
            SELECT process_run_id
            FROM {schema}.{tables['process_control']}
            WHERE process_id = {int(process_id)}
            AND job_run_id = {int(job_run_id)}
            AND process_status = '{status_values['RUNNING']}'
        """
        df = spark.sql(fetch_sql).toPandas()

        if df.empty:
            raise RuntimeError("No running process found to end.")

        process_run_id = df.iloc[0]["process_run_id"]

        if process_run_id is None or np.isnan(process_run_id):
            raise RuntimeError("Trigger process control entry before ending the process!")

        current_time = str(datetime.datetime.now(timezone.utc))
        update_sql = f"""
            UPDATE {schema}.{tables['process_control']}
            SET process_end_time = CAST('{current_time}' AS timestamp),
                process_status = '{status_values['COMPLETED']}',
                audit_updated_ts = CAST('{current_time}' AS timestamp),
                audit_updated_id = '{audit_user}'
            WHERE job_run_id = {job_run_id}
            AND process_run_id = {int(process_run_id)}
        """
        spark.sql(update_sql)

        logger.info("Process ended successfully: process_run_id=%s", process_run_id)
    except Exception as e:
        logger.error("Failed to end process: %s", e)
        raise


def fetch_running_job_run_id(
    spark: SparkSession,
    job_id: int,
    schema: str,
    process_id: int,
    tables: Dict[str, str],
    status_values: Dict[str, str],
) -> Any:
    """
    Fetches the latest job_run_id for a given process_id where the job is RUNNING.

    Args:
        spark: SparkSession object.
        job_id: Job identifier.
        schema: Database schema.
        process_id: Process identifier.
        tables: Dictionary of table names.
        status_values: Dictionary of status values.

    Returns:
        job_run_id if found, else None.
    """
    query = (
        f"SELECT max(job_run_id) FROM {schema}.{tables['job_control']} "
        f"WHERE job_id IN (SELECT job_id FROM {schema}.{tables['process_metadata']} WHERE process_id={process_id}) "
        f"AND job_status='{status_values['RUNNING']}'"
    )
    job_run_id = spark.sql(query).toPandas().T.values
    job_run_id_val = job_run_id[0][0]

    if job_run_id_val is None or np.isnan(job_run_id_val):
        logger.info(f"No active job run for job_id-{job_id}")
        return None

    return job_run_id_val


def fetch_job_metadata(
    spark: SparkSession,
    job_id: int,
    schema: str,
    tables: Dict[str, str],
) -> Any:
    """
    Fetches job metadata details for the given job_id.

    Args:
        spark: SparkSession object.
        job_id: Job identifier.
        schema: Database schema.
        tables: Dictionary of table names.

    Returns:
        Tuple of job metadata fields.
    """
    df = spark.sql(f"SELECT * FROM {schema}.{tables['job_metadata']} WHERE job_id={job_id}")
    result = df.toPandas()
    if result.empty:
        logger.warning("No job metadata found for job_id=%s", job_id)
        return None
    return tuple(result.iloc[0])


def fetch_running_process_run_id(
    spark: SparkSession,
    job_run_id: int,
    schema: str,
    process_id: int,
    tables: Dict[str, str],
    status_values: Dict[str, str],
) -> Optional[int]:
    """
    Fetch the active process_run_id for the given process/job identifiers.

    Args:
        spark: SparkSession object.
        job_run_id: Job run identifier.
        schema: Database schema.
        process_id: Process identifier.
        status_values: Dictionary of status values.

    Returns:
        Tuple of status code and process_run_id (0 if success, 1 otherwise).
    """
    df = spark.sql(
        f"SELECT max(process_run_id) FROM {schema}.{tables['process_control']} "
        f"WHERE process_id={process_id} AND job_run_id={job_run_id} AND process_status='{status_values['RUNNING']}'"
    ).toPandas()

    process_run_id = df.iloc[0, 0]
    if process_run_id is None or np.isnan(process_run_id):
        logger.warning("No active process found for process_id=%s", process_id)
        return None

    return process_run_id
