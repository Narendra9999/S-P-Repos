import logging
from pyspark.sql import SparkSession

logger = logging.getLogger(__name__)


def get_current_file_processing_log(spark: SparkSession, config: dict) -> set:
    """
    Get the current files in dp_file_processing_log table
    Returns a set of file names that are currently in the log
    
    Args:
        spark: SparkSession instance
        config: Configuration dictionary containing catalog, schema, and table information
    
    Returns:
        set: Set of file names that are currently in the log
    """
    try:
        # Handle both config structures - main pipeline uses 'tables', DP pipeline uses 'tables_raw'
        tables_key = 'tables_raw' if 'tables_raw' in config else 'tables'
        dp_log_table = f"{config['catalogs']['raw']['catalog']}.{config['catalogs']['raw']['schema']}.{config[tables_key]['dp_file_processing_log']}"
        logger.info(f"Accessing dp_file_processing_log table: {dp_log_table}")
        
        # Check if the table exists
        if not spark.catalog.tableExists(dp_log_table):
            logger.warning(f"Table {dp_log_table} does not exist. Returning empty set.")
            return set()

        # Determine pipeline_type based on config structure: 0 if tables_raw, else 1
        pipeline_type = 0 if tables_key == 'tables_raw' else 1
        
        # Convert pipeline_type to string boolean for SQL query
        pipeline_bool_str = "'false'" if pipeline_type == 0 else "'true'"
        pipeline_filter = f"AND pipeline_type = {pipeline_bool_str}"
        
        logger.info(f"Using pipeline_type={pipeline_type} (SQL: {pipeline_bool_str}) based on config structure")
        
        files_df = spark.sql(f"""
            SELECT 
                CASE 
                    WHEN UPPER(file_name) LIKE '%_DP_LOAD_%' THEN 'dp_load'
                    WHEN UPPER(file_name) LIKE '%_COMMENTS_%' THEN 'comments'
                    WHEN UPPER(file_name) LIKE '%_SCHEDULES_%' THEN 'schedules'
                    WHEN UPPER(file_name) LIKE '%_TIF_PA_%' THEN 'tif_pa'
                    WHEN UPPER(file_name) LIKE '%_PLAN_ID_%' THEN 'plan_id'
                    WHEN UPPER(file_name) LIKE '%_PLAN_ORG_%' THEN 'plan_org'
                    WHEN UPPER(file_name) LIKE '%_ORG_%' THEN 'org'
                    ELSE 'other'
                END as file_type, 
                file_name,
                processed_at
            FROM {dp_log_table}
            WHERE to_date(processed_at) = (
                SELECT to_date(MAX(processed_at))
                FROM {dp_log_table} 
                WHERE to_date(processed_at) = to_date(current_date())
                
            )
            AND status = 'SUCCESS'
            AND file_name IS NOT NULL
            {pipeline_filter}
            ORDER BY processed_at DESC, file_type
        """)
        
        current_files = set([row['file_name'] for row in files_df.collect()])
        logger.info(f"Retrieved {len(current_files)} files from dp_file_processing_log")
        return current_files
    except Exception as e:
        logger.error(f"Error getting file processing log: {str(e)}")
        return set()


def determine_file_types_from_files(file_names: set) -> set:
    """
    Determine file types from a set of file names
    Returns a set of file types that were processed
    
    Args:
        file_names: Set of file names to classify
    
    Returns:
        set: Set of file types that were processed
    """
    processed_file_types = set()
    
    for file_name in file_names:
        file_name_upper = file_name.upper()
        if '_DP_LOAD_' in file_name_upper:
            processed_file_types.add('dp_load')
        elif '_COMMENTS_' in file_name_upper:
            processed_file_types.add('comments')
        elif '_SCHEDULES_' in file_name_upper:
            processed_file_types.add('schedules')
        elif '_TIF_PA_' in file_name_upper:
            processed_file_types.add('tif_pa')
        elif '_PLAN_ID_' in file_name_upper:
            processed_file_types.add('plan_id')
        elif '_PLAN_ORG_' in file_name_upper:
            processed_file_types.add('plan_org')
        elif '_ORG_' in file_name_upper:
            processed_file_types.add('org')
    
    return processed_file_types
