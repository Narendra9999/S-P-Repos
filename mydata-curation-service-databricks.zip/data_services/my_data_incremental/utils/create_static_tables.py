# Databricks notebook source

# COMMAND ----------
import pyspark.dbutils
from pyspark.sql import SparkSession
from pyspark.sql.functions import to_timestamp
import argparse

from data_services.my_data_incremental.config.config_loader import Config

class Creator:
    def __init__(self, spark, dbutils, args):
        self.env = args["env"]
        self.spark = spark
        self.dbutils = dbutils
        self.args = args
        self.configLoader = Config(env = self.env, variables=None)

    def createTable(self):
        df = None
        if self.args['type'].casefold() == "data":

            df = self.configLoader.load_data(
                spark = self.spark,
                catalog=self.args.get("catalog"), 
                schema=self.args.get("schema"), 
                table=self.args.get("table"), 
                fmt=self.args.get("fmt"), 
                enforce_schema=self.args.get("enforce_schema", True),
                options=self.args.get(self.args.get("options", {}))
            )

            # Apply specific transformations for phoenix ID mapping table
            if self.args.get("table") == "t_org_finorgid_phoenixid_map":
                from pyspark.sql.functions import to_date, lit, current_date
                df = df.withColumn("START_DTTM", to_date("START_DTTM", "M/d/yyyy h:mm:ss a")) \
                       .withColumn("END_DTTM", to_date("END_DTTM", "M/d/yyyy")) \
                       .withColumn("CREATE_DTTM", to_date("CREATE_DTTM", "M/d/yyyy h:mm:ss a")) \
                       .withColumn("LAST_UPD_USR_ID", lit("SYSTEM")) \
                       .withColumn("LAST_UPD_DTTM", current_date())

            df.write.mode(
                self.args.get('write_mode', "append")
                ).saveAsTable(
                    f"{self.args.get('catalog')}_{self.env}.{self.args.get('schema')}.{self.args.get('table')}"
                    )
        
        elif self.args['type'].casefold() == "sql":
        
            df = self.configLoader.load_sql_query(
                spark=self.spark,
                catalog=self.args.get("catalog"),
                schema=self.args.get("schema"),
                table=self.args.get("table"),
                execute_query=True
            )

            
            print(f"DEBUG: DataFrame schema for table {self.args.get('table')}:")
            df.printSchema()
    
            column_names = df.columns
            duplicate_cols = [col for col in set(column_names) if column_names.count(col) > 1]
            if duplicate_cols:
                print(f"WARNING: Duplicate columns detected: {duplicate_cols}")
                print(f"All columns: {column_names}")
            
           
            
            try:
                df.write.mode(
                    self.args.get('write_mode')
                    ).saveAsTable(
                        f"{self.args.get('catalog')}_{self.env}.{self.args.get('schema')}.{self.args.get('table')}"
                        )
                print(f"SUCCESS: Table {self.args.get('table')} created successfully")
                
            except Exception as e:
                print(f"ERROR: Failed to save table {self.args.get('table')}")
                print(f"Error message: {str(e)}")
                print(f"Target table: {self.args.get('catalog')}_{self.env}.{self.args.get('schema')}.{self.args.get('table')}")
                print(f"Write mode: {self.args.get('write_mode')}")
                raise
        
        elif self.args['type'].casefold() == "schema":
            schema = self.configLoader.load_schema(
                catalog=self.args.get("catalog"), 
                schema=self.args.get("schema"), 
                table=self.args.get("table")
            )
            df = self.spark.createDataFrame([], schema)

            if not self.spark.catalog.tableExists(f"{self.args.get('catalog')}_{self.env}.{self.args.get('schema')}.{self.args.get('table')}"):

                df.write.mode(
                    self.args.get('write_mode', "append")
                    ).saveAsTable(
                        f"{self.args.get('catalog')}_{self.env}.{self.args.get('schema')}.{self.args.get('table')}"
                        )
        
        print(f"Execution done for params: {self.args}")
                
def main():
    parser = argparse.ArgumentParser(description="Run tableCreation pipeline")
    parser.add_argument("env")
    parser.add_argument("--catalog")
    parser.add_argument("--schema")
    parser.add_argument("--table")
    parser.add_argument("--fmt")
    parser.add_argument("--write_mode")
    parser.add_argument("--enforce_schema")
    parser.add_argument("--type")
    parser.add_argument("--options")
    
    args = vars(parser.parse_args())

    spark = SparkSession.builder.getOrCreate()
    dbutils = pyspark.dbutils.DBUtils(spark)

    creator = Creator(spark, dbutils, args)

    creator.createTable()


if __name__ == "__main__":
    main()
