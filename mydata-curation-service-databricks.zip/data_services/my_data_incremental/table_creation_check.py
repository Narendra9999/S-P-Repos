import json
import os
import argparse
import logging
from typing import Any, Dict, Optional, Tuple, List
from pathlib import Path
import re

from pyspark.sql import SparkSession
from data_services.my_data_incremental.config.config_loader import Config
from pyspark.sql.types import (
    StructType, StructField, StringType, IntegerType, DoubleType, BooleanType
)

# Setup logging with better formatting
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
handler = logging.StreamHandler()
formatter = logging.Formatter('%(levelname)-8s | %(message)s')
handler.setFormatter(formatter)
logger.addHandler(handler)

class TableCreationCheck:
    def __init__(self, spark: SparkSession, environment: str):
        """
        Initialize the checker.

        :param spark: SparkSession instance
        :param environment: Environment name (e.g. 'dev', 'prod')
        """
        self.spark = spark
        self.environment = environment

        # Initialize config loader
        self.config_loader = Config(env=environment)
        
        # Load schema definitions from schemas folder
        schemas_path = Path(__file__).parent / "config" / "schemas"
        self.schema_definitions = self.load_schema_definitions(str(schemas_path))
        
        print(f"\n{'='*60}")
        print(f"🚀 INITIALIZED TABLE VALIDATION FOR: {environment.upper()}")
        print(f"{'='*60}")
        logger.info(f"Loaded {sum(len(schema_dict) for catalog_dict in self.schema_definitions.values() for schema_dict in catalog_dict.values())} table definitions")

    def flatten_table_properties(self, d):
        result = dict(d)  # start with a shallow copy
        props = result.pop('table properties', None)

        if props:
            # Remove [ and ] and split by commas
            props_clean = props.strip('[]')
            pairs = re.split(r',\s*', props_clean)
            for pair in pairs:
                if '=' in pair:
                    k, v = pair.split('=', 1)
                    result[k.strip()] = v.strip()
        return result

    def load_schema_definitions(self, schemas_base_path: str) -> Dict[str, Dict[str, Any]]:
        """
        Load all schema definitions from the schemas folder structure.

        :param schemas_base_path: Base path to the schemas folder
        :return: Dictionary with structure {catalog: {schema: {table_name: schema_definition}}}
        """
        schemas = {}

        try:
            schemas_path = Path(schemas_base_path)

            if not schemas_path.exists():
                logger.warning(f"❌ Schemas path does not exist: {schemas_base_path}")
                return schemas

            # Walk through the directory structure
            for root, dirs, files in os.walk(schemas_path):
                # Skip __pycache__ and other non-relevant directories
                dirs[:] = [d for d in dirs if not d.startswith('__')]

                for file in files:
                    if file.endswith('.json') and not file.startswith('__'):
                        file_path = Path(root) / file

                        # Extract catalog and schema from path structure
                        relative_path = file_path.relative_to(schemas_path)
                        path_parts = relative_path.parts

                        if len(path_parts) >= 3:  # catalog/schema/table.json
                            catalog = path_parts[0]
                            schema = path_parts[1]
                            table_name = file_path.stem  # filename without .json extension

                            try:
                                schema_definition = self.config_loader.load_schema(
                                    catalog=catalog,
                                    schema=schema,
                                    table=table_name,
                                    return_properties=True
                                )
                                
                                if schema_definition:
                                    # Initialize nested dictionaries if they don't exist
                                    if catalog not in schemas:
                                        schemas[catalog] = {}
                                    if schema not in schemas[catalog]:
                                        schemas[catalog][schema] = {}

                                    schemas[catalog][schema][table_name] = schema_definition
                                    logger.debug(f"  ✅ Loaded: {catalog}.{schema}.{table_name}")
                                else:
                                    logger.warning(f"  ⚠️ Config loader returned None for {catalog}.{schema}.{table_name}")

                            except Exception as e:
                                logger.error(f"  ❌ Failed to load {catalog}.{schema}.{table_name}: {str(e)}")
                        else:
                            logger.warning(f"  ⚠️ Unexpected file structure: {file_path}")

            return schemas

        except Exception as e:
            logger.error(f"❌ Error loading schema definitions: {str(e)}")
            return schemas

    def schema_to_dict(self, schema: StructType) -> dict:
        """
        Convert a PySpark StructType schema into a dictionary
        mapping column_name -> column_type (as string).
        """
        return {field.name.upper(): field.dataType.simpleString().upper() for field in schema.fields}

    def get_table_schema(self, database: str, table_name: str) -> Dict[str, str]:
        """
        Retrieve the schema of a table from Databricks.
        Returns a dict of {column_name: data_type}.
        """
        try:
            full_table_name = f"{database}.{table_name}"
            df = self.spark.sql(f"DESCRIBE {full_table_name}")
            schema = {}
            
            for row in df.collect():
                col_name = row["col_name"]
                data_type = row["data_type"]
                
                # Skip metadata rows and empty rows
                if col_name and not col_name.startswith("#") and col_name.strip():
                    schema[col_name.upper().strip()] = data_type.upper().strip()
            return schema
            
        except Exception as e:
            logger.error(f"❌ Failed to retrieve schema for {database}.{table_name}: {str(e)}")
            return {}

    def get_table_properties(self, database: str, table_name: str) -> Dict[str, str]:
        """
        Retrieve the properties of a table from Databricks.
        Returns a dict of {property_name: property_value}.
        """
        try:
            full_table_name = f"{database}.{table_name}"
            df = self.spark.sql(f"DESCRIBE EXTENDED {full_table_name}").where("col_name like '%Location%' or col_name like '%Table Properties%' ")
            properties = {}

            for row in df.collect():
                col_name = row["col_name"]
                data_type = row["data_type"]
                
                # Skip metadata rows and empty rows
                if col_name and not col_name.startswith("#") and col_name.strip():
                    properties[col_name.lower().strip()] = data_type.upper().strip()
            return self.flatten_table_properties(properties)

        except Exception as e:
            logger.error(f"❌ Failed to retrieve properties for {database}.{table_name}: {str(e)}")
            return {}
        
    def compare_properties(self, expected: Dict[str, str], actual: Dict[str, str], full_table_name: str) -> str:
        """
        Compare two dictionaries of properties and return a string describing the differences.
        """
        message = ""
        missing_properties = sorted(set(k.casefold() for k in expected.keys() if k not in ("path","location")) - set(k.casefold() for k in actual.keys() if k not in ("path","location")))
        extra_properties = sorted(set(k.casefold() for k in actual.keys() if k not in ("path","location")) - set(k.casefold() for k in expected.keys() if k not in ("path","location")))

        key_intersection = set(expected.keys()) & set(actual.keys())
        different_in_actual = {k.casefold(): actual[k].casefold() for k in key_intersection if expected[k] != actual[k]}
        different_in_expected = {k.casefold(): expected[k].casefold() for k in key_intersection if expected[k] != actual[k]}
        
        # Log warning if there are ANY differences
        if missing_properties or extra_properties:
            differences = []
            if missing_properties:
                differences.append(f"missing: {missing_properties}")
            if extra_properties:
                differences.append(f"extra: {extra_properties}")
            message = f"\n      📋 Property differences: {', '.join(differences)}"
        elif different_in_actual or different_in_expected:
            differences = []
            if different_in_expected:
                differences.append(f"expected: {different_in_expected}")
            if different_in_actual:
                differences.append(f"found: {different_in_actual}")
            message = f"\n      📋 Property value mismatches: {', '.join(differences)}"
        return message
    
    def validate_table_with_schema_definition(self, catalog: str, schema: str, table_name: str) -> Tuple[bool, str]:
        """
        Validate a table against its schema definition from JSON files.
        """
        try:
            full_table_name = f"{catalog}_{self.environment}.{schema}.{table_name}"
            
            print(f"\n🔍 Validating: {full_table_name}")
            
            # Check if table exists
            if not self.spark.catalog.tableExists(full_table_name):
                message = f"❌ Table does not exist"
                logger.error(f"   {message}")
                return False, message

            # Get schema definition
            if (catalog in self.schema_definitions and 
                schema in self.schema_definitions[catalog] and 
                table_name in self.schema_definitions[catalog][schema]):
                
                schema_def = self.schema_definitions[catalog][schema][table_name]["schema"]
                expected_properties = self.schema_definitions[catalog][schema][table_name]["properties"]
                expected_schema = self.schema_to_dict(schema_def)
                
                if not expected_schema:
                    message = f"⚠️ No column definitions found in schema file"
                    logger.warning(f"   {message}")
                    return True, message

                if not expected_properties:
                    message = f"⚠️ No properties found in schema file"
                    logger.warning(f"   {message}")
                    return True, message
                
                # Get actual table schema and properties
                db_schema = self.get_table_schema(f"{catalog}_{self.environment}", f"{schema}.{table_name}")
                properties = self.get_table_properties(f"{catalog}_{self.environment}", f"{schema}.{table_name}")
                
                if not db_schema:
                    message = f"❌ Could not retrieve actual schema"
                    logger.error(f"   {message}")
                    return False, message
                
                if not properties:
                    message = f"❌ Could not retrieve actual properties"
                    logger.error(f"   {message}")
                    return False, message
                
                validation_issues = []
                
                # Compare location
                expected_location = expected_properties.get("path", "").replace("{replace}", self.environment).lower().strip()
                db_location = properties.get("location", "").lower().strip()

                if expected_location and expected_location != db_location:
                    location_issue = f"📍 Location mismatch:\n      Expected: {expected_location}\n      Found:    {db_location}"
                    validation_issues.append(location_issue)
                    logger.warning(f"   {location_issue}")
                
                # Compare properties
                prop_comparison = self.compare_properties(expected_properties, properties, full_table_name)
                if prop_comparison.strip():
                    validation_issues.append(prop_comparison.strip())
                    logger.warning(f"   {prop_comparison.strip()}")

                # Compare schemas
                missing_cols = set(expected_schema.keys()) - set(db_schema.keys())
                extra_cols = set(db_schema.keys()) - set(expected_schema.keys())
                mismatched_types = {
                    col: (expected_schema[col], db_schema[col])
                    for col in expected_schema.keys() & db_schema.keys()
                    if expected_schema[col] != db_schema[col]
                }

                schema_issues = []
                
                if missing_cols:
                    missing_issue = f"➖ Missing columns: {', '.join(sorted(missing_cols))}"
                    schema_issues.append(missing_issue)
                    
                if extra_cols:
                    extra_issue = f"➕ Extra columns: {', '.join(sorted(extra_cols))}"
                    schema_issues.append(extra_issue)
                    
                if mismatched_types:
                    type_mismatches = []
                    for col, (exp, act) in sorted(mismatched_types.items()):
                        type_mismatches.append(f"      • {col}: expected {exp}, found {act}")
                    
                    type_issue = f"🔄 Type mismatches:\n" + "\n".join(type_mismatches)
                    schema_issues.append(type_issue)

                if schema_issues:
                    schema_summary = f"📊 Schema issues:\n   " + "\n   ".join(schema_issues)
                    validation_issues.append(schema_summary)
                    logger.warning(f"   {schema_summary}")

                # Final result
                if not validation_issues:
                    message = f"✅ Perfect match - schema and properties validated successfully"
                    logger.info(f"   {message}")
                    return True, message
                else:
                    message = f"⚠️ Validation issues found:\n   " + "\n   ".join(validation_issues)
                    return False, message
                    
            else:
                message = f"✅ Table exists - no schema definition available for validation"
                logger.info(f"   {message}")
                return True, message

        except Exception as e:
            message = f"❌ Validation error: {str(e)}"
            logger.error(f"   {message}")
            return False, message

    def validate_all_schema_definitions(self) -> Dict[str, Tuple[bool, str]]:
        """
        Validate all tables found in schema definition files.
        
        :return: Dictionary of {table_path: (is_valid, message)}
        """
        results = {}
        
        print(f"\n{'='*80}")
        print(f"🎯 STARTING VALIDATION FOR {self.environment.upper()} ENVIRONMENT")
        print(f"{'='*80}")
        
        table_count = 0
        for catalog, catalog_schemas in self.schema_definitions.items():
            print(f"\n📂 Processing catalog: {catalog.upper()}")
            for schema, tables in catalog_schemas.items():
                print(f"   📁 Schema: {schema}")
                for table_name in tables.keys():
                    table_count += 1
                    table_path = f"{catalog}.{schema}.{table_name}"
                    is_valid, message = self.validate_table_with_schema_definition(catalog, schema, table_name)
                    results[table_path] = (is_valid, message)
        
        # Summary
        valid_count = sum(1 for is_valid, _ in results.values() if is_valid)
        failed_count = len(results) - valid_count
        
        print(f"\n{'='*80}")
        print(f"📊 VALIDATION SUMMARY")
        print(f"{'='*80}")
        print(f"✅ Valid tables:   {valid_count:3d}")
        print(f"❌ Failed tables:  {failed_count:3d}")
        print(f"📋 Total tables:   {len(results):3d}")
        print(f"✔️  Success rate:   {(valid_count/len(results)*100):5.1f}%")
        print(f"{'='*80}")
        
        return results

    def generate_report(self) -> str:
        """Generate a detailed validation report for schema definitions only."""
        try:
            schema_def_results = self.validate_all_schema_definitions()
            
            from datetime import datetime
            
            report_lines = [
                f"\n{'='*100}",
                f"📋 SCHEMA VALIDATION REPORT",
                f"{'='*100}",
                f"Environment: {self.environment.upper()}",
                f"Timestamp:   {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
                f"{'='*100}",
                "",
                "🎯 VALIDATION RESULTS:",
                "-" * 50
            ]
            
            # Group results by status
            passed_tables = []
            failed_tables = []
            
            for table_path, (is_valid, message) in sorted(schema_def_results.items()):
                if is_valid:
                    passed_tables.append(f"✅ {table_path}")
                else:
                    failed_tables.append(f"❌ {table_path}")
                    # Add detailed message for failed tables
                    report_lines.append(f"❌ {table_path}")
                    for line in message.split('\n'):
                        if line.strip():
                            report_lines.append(f"   {line.strip()}")
                    report_lines.append("")
            
            # Add passed tables at the end
            if passed_tables:
                report_lines.extend(["", "✅ PASSED TABLES:", "-" * 20])
                report_lines.extend(passed_tables)
            
            # Calculate totals
            schema_def_valid = len(passed_tables)
            
            report_lines.extend([
                "",
                f"{'='*100}",
                f"📊 FINAL SUMMARY",
                f"{'='*100}",
                f"✅ Passed: {schema_def_valid}/{len(schema_def_results)} tables",
                f"❌ Failed: {len(failed_tables)}/{len(schema_def_results)} tables",
                f"✔️  Rate:   {(schema_def_valid/len(schema_def_results)*100):5.1f}%",
                f"{'='*100}"
            ])
            
            return "\n".join(report_lines)
            
        except Exception as e:
            logger.error(f"❌ Error generating report: {str(e)}")
            raise


def main():
    """Main entry point with proper argument parsing."""
    parser = argparse.ArgumentParser(description="Validate tables against schema definitions")
    parser.add_argument("env", help="Environment name (dev, qa, uat, prod, dr)")
    parser.add_argument("--report", action="store_true", 
                       help="Generate detailed report")
    parser.add_argument("--verbose", action="store_true", 
                       help="Enable verbose logging")
    
    args = parser.parse_args()
    
    if args.verbose:
        logger.setLevel(logging.DEBUG)
    
    try:
        spark = SparkSession.builder.getOrCreate()
        checker = TableCreationCheck(spark, args.env)
        
        if args.report:
            report = checker.generate_report()
            print(report)
        else:
            # Default: validate schema definitions
            checker.validate_all_schema_definitions()
            
    except Exception as e:
        logger.error(f"❌ Validation failed: {str(e)}")
        raise


if __name__ == "__main__":
    main()