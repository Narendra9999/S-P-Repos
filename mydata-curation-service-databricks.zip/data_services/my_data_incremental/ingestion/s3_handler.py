import datetime
import json
import logging

import boto3

logger = logging.getLogger(__name__)


class S3DataHandler:
    """Class to handle S3 data operations."""

    def __init__(self, base_path: str):
        """Initialize with S3 base path."""
        self.base_path = base_path.rstrip('/')

    def generate_file_path(self, entity_id: str, entity_name: str, timestamp: str = None) -> str:
        """
        Generate an S3 file path for the healthcare data using MM-DD-YYYY format.
        
        Args:
            entity_id: The ID of the entity.
            entity_name: The name of the entity.
            timestamp: Optional timestamp string, defaults to current time if None.
            
        Returns:
            A formatted S3 path string.
        """
        clean_name = self._clean_name_for_path(entity_name)
        timestamp = timestamp or datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
        today = datetime.datetime.now()
        date_path = f"{today.month:02d}-{today.day:02d}-{today.year}"
        file_name = f"{clean_name}_{entity_id}_{timestamp}.json"
        return f"{self.base_path}/{date_path}/{file_name}"

    @staticmethod
    def _clean_name_for_path(name: str) -> str:
        """
        Clean an entity name for use in file paths.
        
        Replaces non-alphanumeric characters with underscores,
        collapses multiple underscores, strips leading/trailing underscores,
        and truncates to 50 characters.
        """
        if not name:
            return "unknown"
        clean = ''.join(c if c.isalnum() else '_' for c in name)
        while '__' in clean:
            clean = clean.replace('__', '_')
        clean = clean.strip('_')
        return clean[:50]

    def write_json_to_s3(self, data: dict, file_path: str) -> bool:
        """
        Write data directly as a JSON file to an S3 location.
        
        Args:
            data: Dictionary data to write as JSON.
            file_path: Full S3 path starting with 's3://'.
            
        Returns:
            True if successful, False otherwise.
        """
        try:
            if not file_path.startswith("s3://"):
                raise ValueError("file_path must start with 's3://'")

            s3_path = file_path[len("s3://"):]
            bucket_name, *object_parts = s3_path.split("/")
            object_key = "/".join(object_parts)

            s3_client = boto3.client('s3')
            json_data = json.dumps(data, indent=2)

            s3_client.put_object(
                Bucket=bucket_name,
                Key=object_key,
                Body=json_data,
                ContentType='application/json'
            )

            logger.info(f"Successfully wrote JSON file to {file_path}")
            return True
        except Exception as e:
            logger.error(f"Error writing JSON file to {file_path}: {e}")
            return False

# This file has been moved to ingestion/s3_handler.py. Please update imports accordingly.
