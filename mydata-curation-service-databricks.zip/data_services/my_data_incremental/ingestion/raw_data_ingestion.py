'''
 Phoenix Data Processing Job
 This notebook processes messages stored in S3 and loads the data into Delta tables, tracking processed files to avoid duplicates.
 For daily processing: Use process_mode=single_date with empty date (uses current date)
 For catching up on missed dates: Use process_mode=missing_dates with process_last_n_days=7
 For full reprocessing: Use process_mode=date_range with force_reprocess=true

Phoenix Data Processing Job with Schema Handling
 This notebook processes messages stored in S3 and loads the data into Delta tables with proper schema handling.
 '''

import hashlib
import json
import os
import re
from datetime import datetime, timedelta
from pyspark.sql import SparkSession
from pyspark.sql.functions import coalesce, col, current_timestamp, lit
from pyspark.sql.types import TimestampType
import hashlib

# Update imports to reflect new structure
from data_services.my_data_incremental.ingestion.s3_handler import S3DataHandler
# from data_services.my_data_incremental.transformation.utils import log


# Remove dbutils.widgets usage for globals, expect them in params/config
# These will be set in process_raw_data from params/config
SOURCE_S3_BUCKET = None
SOURCE_S3_PREFIX = None
TARGET_CATALOG = None
TARGET_SCHEMA = None
process_mode = None
force_reprocess = None

# Initialize Spark session if not already present
import builtins
if not hasattr(builtins, 'spark'):
    spark = SparkSession.builder.getOrCreate()
    builtins.spark = spark
else:
    spark = builtins.spark

# COMMAND ----------


# Logger helper
def log(message):
    print(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {message}")

# COMMAND ----------


# Helper function to get fully qualified table name
def get_table_path(table_name):
    """Get fully qualified table path"""
    return f"{TARGET_CATALOG}.{TARGET_SCHEMA}.{table_name}"

# COMMAND ----------


# File pattern to table mapping

import pathlib
def get_lineage_config_path(data_type="DC"):
    config_dir = pathlib.Path(__file__).parent.parent / "config"
    if data_type.upper() == "DC":
        return config_dir / "lineage_config.json"
    else:
        return config_dir / "lineage_config_dp.json"

def load_file_table_mapping(data_type="DC"):
    _lineage_config_path = get_lineage_config_path(data_type)
    if _lineage_config_path.exists():
        with open(_lineage_config_path, "r") as f:
            lineage_config = json.load(f)
            mapping_dict = lineage_config.get("file_table_mapping", {})
            print(f"Loaded file_table_mapping from {_lineage_config_path}: {mapping_dict}")  # Debug print
            if mapping_dict:
                return mapping_dict
            else:
                log("No file_table_mapping found in config, using default mapping")
                return { r".*_COMMENTS_.*\.txt": "t_dc_transaction_comments",
                         r".*_SCHEDULES_.*\.txt": "t_dc_transaction_schedules",
                         r".*_DP_LOAD_.*\.txt": "t_dc_transaction_dp_load",
                         r".*_TIF_PA_.*\.txt": "t_dc_transaction_tif_pa",
                         r".*_PLAN_ID_.*\.txt": "t_dc_transaction_plan_id",
                         r".*_PLAN_ORG_.*\.txt": "t_dc_transaction_plan_org",
                         r".*_ORG_.*\.txt": "t_dc_transaction_org"}


# Helper to get file table mapping set from lineage_config.json
def get_file_table_mapping_from_config(config):
    # Use 'FILE_TABLE_MAPPING_SET' from config if provided, else use 'default'
    data_type = config.get('DATA_TYPE', 'DC')  # Default to DC if not specified
    return load_file_table_mapping(data_type)

# FILE_TABLE_MAPPING will be set in process_raw_data based on config
FILE_TABLE_MAPPING = None

# COMMAND ----------


def is_date_processed(process_date):
    """Check if a date has been fully processed"""
    result = spark.sql(
        f"""
    SELECT COUNT(*) as count 
    FROM {get_table_path('dp_date_processing_log')}
    WHERE process_date = '{process_date}' AND status = 'COMPLETED'
    """
    )

    count = result.collect()[0]["count"]
    return count > 0


# COMMAND ----------


def mark_date_processing_started(process_date, pipeline_type=1):
    """Mark a date as being processed"""
    spark.sql(
        f"""
    INSERT INTO {get_table_path('dp_date_processing_log')}
    VALUES (
        '{process_date}',
        current_timestamp(),
        NULL,
        'STARTED',
        0,
        0,
        0,
        {bool(pipeline_type)}
    )
    """
    )

    log(f"Marked date {process_date} as processing started")


# COMMAND ----------


def mark_date_processing_completed(
    process_date, message_count, file_count, error_count, pipeline_type=1):
    """Mark a date as completed"""
    spark.sql(
        f"""
    UPDATE {get_table_path('dp_date_processing_log')}
    SET 
        completed_at = current_timestamp(),
        status = 'COMPLETED',
        message_count = {message_count},
        file_count = {file_count},
        error_count = {error_count},
        pipeline_type = {bool(pipeline_type)}
    WHERE process_date = '{process_date}' AND status = 'STARTED'
    """
    )

    log(f"Marked date {process_date} as processing completed")


# COMMAND ----------


def mark_date_processing_failed(process_date, message_count, file_count, error_count, pipeline_type=1):
    """Mark a date as failed"""
    spark.sql(
        f"""
    UPDATE {get_table_path('dp_date_processing_log')}
    SET 
        completed_at = current_timestamp(),
        status = 'FAILED',
        message_count = {message_count},
        file_count = {file_count},
        error_count = {error_count},
        pipeline_type = {bool(pipeline_type)}
    WHERE process_date = '{process_date}' AND status = 'STARTED'
    """
    )

    log(f"Marked date {process_date} as processing failed")


# COMMAND ----------


def get_unprocessed_files(bucket_name, file_paths, batch_date):
    """
    Filter the list of files to only those that haven't been processed yet

    Args:
        bucket_name (str): S3 bucket name
        file_paths (list): List of file paths to check
        batch_date (str): Processing date

    Returns:
        list: List of unprocessed file paths
    """
    unprocessed_files = []

    for file_path in file_paths:
        # Get just the filename from the path
        filename = os.path.basename(file_path)

        # Check if this file has already been processed
        if not is_file_processed(file_path, bucket_name):
            unprocessed_files.append((filename, file_path))

    log(
        f"Found {len(unprocessed_files)} unprocessed files out of {len(file_paths)} total files"
    )
    return unprocessed_files


# COMMAND ----------


def determine_table_name(filename):
    """Determine which table the file should be loaded into based on filename pattern"""
    for pattern, table in FILE_TABLE_MAPPING.items():
        if re.match(pattern, filename):
            return table
    return None


# COMMAND ----------


def is_file_processed(file_path, bucket_name):
    """Check if the file has already been processed"""
    # Escape single quotes
    file_path_escaped = file_path.replace("'", "''")
    bucket_name_escaped = bucket_name.replace("'", "''")

    result = spark.sql(
        f"""
    SELECT COUNT(*) as count 
    FROM {get_table_path('dp_file_processing_log')}
    WHERE file_path = '{file_path_escaped}' 
      AND bucket_name = '{bucket_name_escaped}' 
      AND status = 'SUCCESS'
    """
    )

    count = result.collect()[0]["count"]
    return count > 0


# COMMAND ----------


def mark_file_as_processed(
    file_path,
    file_name,
    bucket_name,
    target_table,
    phoenix_id,
    report_id,
    message_key,
    process_date,
    status="SUCCESS",
    pipeline_type=1,
):
    try:
        # Create a list of data with explicit types for all values
        data = []
        data.append(
            (
                str(file_path),
                str(file_name),
                str(bucket_name),
                str(target_table),
                str(phoenix_id),
                str(report_id),
                str(message_key),
                datetime.now(),
                str(process_date),
                str(status),
                bool(pipeline_type)
            )
        )

        columns = [
            "file_path",
            "file_name",
            "bucket_name",
            "target_table",
            "phoenix_id",
            "report_id",
            "message_key",
            "processed_at",
            "process_date",
            "status",
            "pipeline_type"
        ]

        # Create DataFrame with explicit string typing for most columns
        tracking_df = spark.createDataFrame(data, columns)

        # Explicitly cast the timestamp column
        tracking_df = tracking_df.withColumn(
            "processed_at", tracking_df["processed_at"].cast(TimestampType())
        )

        # Write directly without mergeSchema option
        tracking_df.write.format("delta").mode("append").saveAsTable(
            get_table_path("dp_file_processing_log")
        )

        log(f"Marked file {file_path} as {status} in tracking table")
        return True
    except Exception as e:
        log(f"Error marking file as processed: {str(e)}")
        # Continue processing other files even if tracking fails
        return True


# COMMAND ----------


def read_and_process_file(
    file_path, target_table, phoenix_id, report_id, filename, bucket_name, batch_date
):
    """Read the pipe-delimited file and load it into the target table"""
    try:
        # Read the file with the correct delimiter
        file_df = (
            spark.read.option("header", "true")
            .option("delimiter", "|")
            .option("nullValue", "")
            .option("treatEmptyValuesAsNulls", "false")
            .csv(file_path)
        )

        target_table_path = get_table_path(target_table)
        try:
            existing_table_df = spark.table(target_table_path)
            target_columns = existing_table_df.columns
            log(f"Target table {target_table} has columns: {target_columns}")
        except Exception as schema_error:
            log(f"Could not get target table schema, using file columns: {str(schema_error)}")
            target_columns = file_df.columns

        file_columns = file_df.columns
        log(f"File {filename} has columns: {file_columns}")
        
        for column in file_columns:
            file_df = file_df.withColumn(
                column, coalesce(col(column).cast("string"), lit(""))
            )

        metadata_columns = ["processing_timestamp", "source_file", "source_bucket", "process_date", "created_at", "updated_at"]
        valid_data_columns = [col_name for col_name in file_columns 
                             if col_name in target_columns or col_name in metadata_columns]
        
        filtered_df = file_df.select(*[col_name for col_name in valid_data_columns if col_name in file_columns])
        
        for target_col in target_columns:
            if target_col not in file_columns and target_col not in metadata_columns:
                filtered_df = filtered_df.withColumn(target_col, lit(None).cast("string"))
                log(f"Added missing column '{target_col}' with null values")

        # Print schema and sample for debugging
        log(f"File schema for {filename} after column alignment:")
        filtered_df.printSchema()
        log("Sample data:")
        filtered_df.show(3, truncate=False)

        # Add metadata columns
        enriched_df = (
            filtered_df.withColumn("processing_timestamp", current_timestamp())
            .withColumn("source_file", lit(filename))
            .withColumn("source_bucket", lit(bucket_name))
            .withColumn("process_date", lit(batch_date))
            .withColumn("created_at", current_timestamp())
            .withColumn("updated_at", current_timestamp())
        )

        # Write to the target table with schema merging
        enriched_df.write.format("delta").mode("append").option(
            "mergeSchema", "false"
        ).saveAsTable(get_table_path(target_table))

        log(f"Successfully loaded data into {get_table_path(target_table)}")
        return True

    except Exception as e:
        log(f"Error processing file: {str(e)}")
        return False


# COMMAND ----------


def process_message_batch(batch_date, force_reprocess=False, pipeline_type=1):
    """Process a batch of messages from a specific date"""
    # Ensure tracking tables exist first
    ensure_date_tracking_table_exists()
    ensure_file_tracking_table_exists()

    # Mark date as processing started
    mark_date_processing_started(batch_date, pipeline_type=pipeline_type)

    # Initialize counters
    message_count = 0
    file_count = 0
    error_count = 0

    # Construct S3 path for the date
    s3_path = f"s3a://{SOURCE_S3_BUCKET}/{SOURCE_S3_PREFIX}{batch_date}/"

    log(f"Processing messages from: {s3_path}")

    # List files in the path
    try:
        message_files_df = spark.read.text(s3_path)
        message_count = message_files_df.count()

        if message_count == 0:
            log(f"No messages found in {s3_path}")
            mark_date_processing_completed(batch_date, 0, 0, 0)
            return

        log(f"Found {message_count} message files")

        # Process each message
        processed_files_count = 0
        for message_row in message_files_df.collect():
            message_content = message_row[0]

            # Generate a unique key for this message
            message_hash = hashlib.md5(message_content.encode()).hexdigest()
            message_key = f"{batch_date}_{message_hash}"

            # Parse the JSON message
            try:
                message = json.loads(message_content)

                # Extract necessary information

                outputFileUrl = message.get('outputFileUrl', '')
                bucket_name = message.get('bucket_name', '')
                list_of_files = message.get('list_of_files', [])
                phoenix_id = message.get('phoenix_id')
                report_id = message.get('report_id')

                if not bucket_name or not list_of_files:
                    log("Missing required fields in message, skipping...")
                    error_count += 1
                    continue

                # Prepare full file paths
                full_file_paths = []
                for filename in list_of_files:
                    file_path = ""
                    if outputFileUrl.endswith(".zip") and "_ORG_" in filename:
                        # Get the directory by removing the zip filename
                        output_dir = os.path.dirname(outputFileUrl)
                        file_path = f"{output_dir}/{filename}"
                    else:
                        # For non-ORG files or if outputFileURL doesn't end with .zip
                        file_path = f"{outputFileUrl}/{filename}"

                    full_file_paths.append(file_path)

                # Get only unprocessed files (unless force_reprocess is True)
                if force_reprocess:
                    files_to_process = [
                        (os.path.basename(path), path) for path in full_file_paths
                    ]
                    log(f"Force reprocessing all {len(files_to_process)} files")
                else:
                    files_to_process = get_unprocessed_files(
                        bucket_name, full_file_paths, batch_date
                    )
                    log(f"Processing {len(files_to_process)} unprocessed files")

                # Process each unprocessed file
                for filename, file_path in files_to_process:
                    try:
                        # Count all files attempted
                        file_count += 1

                        # Determine target table
                        target_table = determine_table_name(filename)

                        if not target_table:
                            log(
                                f"No table mapping found for file: {filename}, skipping..."
                            )
                            error_count += 1
                            continue

                        # Full S3 path to the file
                        full_file_path = f"s3a://{bucket_name}/{file_path}"

                        log(f"Processing file: {full_file_path}")

                        # Process the file
                        success = read_and_process_file(
                            file_path=full_file_path,
                            target_table=target_table,
                            phoenix_id=phoenix_id,
                            report_id=report_id,
                            filename=filename,
                            bucket_name=bucket_name,
                            batch_date=batch_date,
                        )

                        if success:
                            # Mark the file as processed
                            mark_file_as_processed(
                                file_path=file_path,
                                file_name=filename,
                                bucket_name=bucket_name,
                                target_table=target_table,
                                phoenix_id=phoenix_id,
                                report_id=report_id,
                                message_key=message_key,
                                process_date=batch_date,
                                status="SUCCESS",
                                pipeline_type=pipeline_type
                            )
                            processed_files_count += 1
                        else:
                            error_count += 1
                            # Mark as failed
                            mark_file_as_processed(
                                file_path=file_path,
                                file_name=filename,
                                bucket_name=bucket_name,
                                target_table=target_table,
                                phoenix_id=phoenix_id,
                                report_id=report_id,
                                message_key=message_key,
                                process_date=batch_date,
                                status="FAILED",
                                pipeline_type=pipeline_type
                            )
                    except Exception as tracking_error:
                        log(
                            f"Error tracking file status, but continuing: {str(tracking_error)}"
                        )
                        error_count += 1

            except json.JSONDecodeError:
                log("Invalid JSON message, skipping...")
                error_count += 1
                continue
            except Exception as e:
                log(f"Error processing message: {str(e)}")
                error_count += 1
                continue

        # Mark date as completed
        mark_date_processing_completed(
            batch_date, message_count, processed_files_count, error_count, pipeline_type=pipeline_type
        )
        log(
            f"Processed {processed_files_count} new files out of {file_count} files found for date {batch_date}"
        )

    except Exception as e:
        log(f"Error processing batch for date {batch_date}: {str(e)}")
        # Mark date as failed
        mark_date_processing_failed(batch_date, message_count, file_count, error_count, pipeline_type=pipeline_type)


# COMMAND ----------


# Create date tracking table
def ensure_date_tracking_table_exists():
    """Create the date tracking table if it doesn't exist"""
    spark.sql(f"""
    CREATE TABLE IF NOT EXISTS {get_table_path('dp_date_processing_log')} (
        process_date STRING,
        started_at TIMESTAMP,
        completed_at TIMESTAMP,
        status STRING,
        message_count INT,
        file_count INT,
        error_count INT,
        pipeline_type BOOLEAN
    )
    USING DELTA
    """)


# Create a tracking table to keep track of processed files
def ensure_file_tracking_table_exists():
    """Create the file tracking table if it doesn't exist"""
    spark.sql(f"""
    CREATE TABLE IF NOT EXISTS {get_table_path('dp_file_processing_log')} (
        file_path STRING,
        file_name STRING,
        bucket_name STRING,
        target_table STRING,
        phoenix_id STRING,
        report_id STRING,
        message_key STRING,
        processed_at TIMESTAMP,
        process_date STRING,
        status STRING,
        pipeline_type BOOLEAN
    )
    USING DELTA
    """)

# COMMAND ----------


def process_raw_data(params, config):
    global SOURCE_S3_BUCKET, SOURCE_S3_PREFIX, TARGET_CATALOG, TARGET_SCHEMA, FILE_TABLE_MAPPING
    SOURCE_S3_BUCKET = config.get('SOURCE_S3_BUCKET')
    SOURCE_S3_PREFIX = config.get('SOURCE_S3_PREFIX')
    TARGET_CATALOG = config.get('TARGET_CATALOG')
    TARGET_SCHEMA = config.get('TARGET_SCHEMA')
    FILE_TABLE_MAPPING = get_file_table_mapping_from_config(config)
    pipeline_type = config.get('PIPELINE_TYPE', 1)
    
    process_mode = params.get('process_mode')
    force_reprocess = params.get('force_reprocess', False)
    batch_date = params.get('date')
    process_last_n_days = params.get('process_last_n_days')

    if process_mode == "single_date":
        batch_date = batch_date or datetime.now().strftime('%Y-%m-%d')
        log(f"Processing single date: {batch_date} (force_reprocess: {force_reprocess})")
        process_message_batch(batch_date, force_reprocess)

    elif process_mode == "unprocessed_files":
        batch_date = batch_date or datetime.now().strftime('%Y-%m-%d')
        log(f"Processing unprocessed files for date: {batch_date}")
        process_message_batch(batch_date, force_reprocess=False, pipeline_type=pipeline_type)

    elif process_mode == "date_range":
        n_days = int(process_last_n_days)
        current_date = datetime.now()
        log(f"Processing last {n_days} days (force_reprocess: {force_reprocess})")
        for i in range(n_days):
            process_date = (current_date - timedelta(days=i)).strftime('%Y-%m-%d')
            log(f"Processing date {i+1}/{n_days}: {process_date}")
            process_message_batch(process_date, force_reprocess)

    elif process_mode == "missing_dates":
        n_days = int(process_last_n_days)
        current_date = datetime.now()
        log(f"Processing missing dates from last {n_days} days")
        for i in range(n_days):
            process_date = (current_date - timedelta(days=i)).strftime('%Y-%m-%d')
            s3_path = f"s3a://{SOURCE_S3_BUCKET}/{SOURCE_S3_PREFIX}{process_date}/"
            try:
                file_count = spark.read.text(s3_path).count()
                if file_count > 0:
                    if not is_date_processed(process_date):
                        log(f"Found unprocessed date: {process_date} with {file_count} files")
                        process_message_batch(process_date, force_reprocess=False)
                    else:
                        log(f"Date {process_date} already processed, skipping")
                else:
                    log(f"No files found for date {process_date}, skipping")
            except Exception as e:
                log(f"Error checking path for date {process_date}: {str(e)}")

    # Get summary of processed dates
    log("\nDate Processing Summary:")
    date_stats = spark.sql(f"""
    SELECT 
        status, 
        COUNT(*) as count,
        MIN(process_date) as earliest_date,
        MAX(process_date) as latest_date
    FROM {get_table_path('dp_date_processing_log')}
    GROUP BY status
    ORDER BY latest_date DESC
    """).collect()
    for row in date_stats:
        log(f"Status: {row['status']}, Count: {row['count']}, Latest: {row['latest_date']}, Earliest: {row['earliest_date']}")

    # Get list of recently processed dates
    log("\nRecently Processed Dates:")
    recent_dates = spark.sql(f"""
    SELECT 
        process_date,
        status,
        message_count,
        file_count,
        error_count,
        started_at,
        completed_at,
        pipeline_type
    FROM {get_table_path('dp_date_processing_log')}
    ORDER BY process_date DESC
    LIMIT 10
    """).collect()
    for row in recent_dates:
        log(f"Date: {row['process_date']}, Status: {row['status']}, Messages: {row['message_count']}, Files: {row['file_count']}, Errors: {row['error_count']}")

    log("Data processing complete!")

    # COMMAND ----------

