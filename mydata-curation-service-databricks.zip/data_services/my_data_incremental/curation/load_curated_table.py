# Databricks notebook source
from data_services.my_data_incremental.utils.calculations import calculations
from pyspark.sql.types import TimestampType
from datetime import datetime
from pyspark.sql.functions import lit, col, current_timestamp, row_number
from pyspark.sql.window import Window
from delta.tables import DeltaTable
from pyspark.sql import functions as F
from pyspark.sql import types as T
import traceback

def log_run_entry(spark, run_id, curated_table, raw_table, raw_processed_ts, status,
                  started_at, completed_at,
                  raw_incr_count, raw_incr_key_count, raw_full_key_count, curated_full_count, 
                  merge_stats=None, env=None):
    """
    Log run entry to the run_log table for audit and monitoring purposes.
    """
    try:
        # Safe extraction of merge stats
        updated_rows = 0
        inserted_rows = 0
        affected_rows = 0
        
        if merge_stats and isinstance(merge_stats, dict):
            updated_rows = merge_stats.get('num_updated_rows', 0)
            inserted_rows = merge_stats.get('num_inserted_rows', 0)
            affected_rows = merge_stats.get('num_affected_rows', 0)

        data = [(
            str(run_id),
            str(curated_table),
            str(raw_table),
            raw_processed_ts,
            str(status),
            started_at,
            completed_at,
            int(raw_incr_count),
            int(raw_incr_key_count),
            int(raw_full_key_count),
            int(curated_full_count),
            int(updated_rows),
            int(inserted_rows),
            int(affected_rows)
        )]

        # Explicit schema definition to avoid type inference issues
        from pyspark.sql.types import StructType, StructField, StringType, TimestampType, LongType
        
        schema = StructType([
            StructField("run_id", StringType(), True),
            StructField("curated_table", StringType(), True),
            StructField("raw_table", StringType(), True),
            StructField("raw_processed_ts", TimestampType(), True),
            StructField("status", StringType(), True),
            StructField("started_at", TimestampType(), True),
            StructField("completed_at", TimestampType(), True),
            StructField("raw_incr_count", LongType(), True),
            StructField("raw_incr_key_count", LongType(), True),
            StructField("raw_full_key_count", LongType(), True),
            StructField("curated_full_count", LongType(), True),
            StructField("updated_rows", LongType(), True),
            StructField("inserted_rows", LongType(), True),
            StructField("affected_rows", LongType(), True)
        ])

        # Create DataFrame with explicit schema
        run_log_df = spark.createDataFrame(data, schema)

        # Construct run log table name
        run_log_table = f"idf_curated_{env}.uspf.run_log"

        # Append to Delta table
        run_log_df.write.format("delta") \
            .mode("append") \
            .saveAsTable(run_log_table)

        print(f"Run ID {run_id} logged successfully to {run_log_table}")
        return True

    except Exception as e:
        print(f"Failed to log run entry: {str(e)}")
        traceback.print_exc()
        return False

def load_curated(spark, config_data, env=None):
    """
    Load curated table with incremental processing and proper error handling.
    """
    # Initialize variables for error handling - with safe defaults
    run_id_value = int(datetime.now().strftime("%Y%m%d%H%M%S"))
    start_time = datetime.now()
    
    # Initialize ALL variables that might be used in finally block
    batch_incr_df2 = None
    latest_df = None
    raw_processed_ts = None
    raw_incr_count = 0
    raw_incr_key_count = 0
    raw_full_key_count = 0
    curated_full_count = 0
    status = "STARTED"
    merge_stats = None
    
    # Initialize table names with defaults
    raw_table_name = "UNKNOWN"
    curated_table_name = "UNKNOWN"

    try:
        # Validate required configuration
        required_keys = ['raw_catalog', 'raw_schema', 'raw_table', 'curated_catalog', 
                        'curated_schema', 'curated_table', 'latest_on', 'target_to_source_mapping', 'keys']
        missing_keys = [key for key in required_keys if key not in config_data]
        if missing_keys:
            raise ValueError(f"Missing required configuration keys: {missing_keys}")

        # Extract config values
        raw_table_name = f"{config_data['raw_catalog']}.{config_data['raw_schema']}.{config_data['raw_table']}"
        curated_table_name = f"{config_data['curated_catalog']}.{config_data['curated_schema']}.{config_data['curated_table']}"
        latest_col = config_data["latest_on"]
        target_to_source_mapping = config_data["target_to_source_mapping"]
        merge_keys = [k.strip() for k in config_data["keys"].split(",")]

        print(f"Processing: {raw_table_name} -> {curated_table_name}")
        print(f"Merge keys: {merge_keys}")
        print(f"Latest column: {latest_col}")

        # Read raw data
        batch_df = spark.read.table(raw_table_name)
        print(f"Total raw records: {batch_df.count()}")

        # Get last processed timestamp
        try:
            run_log_table = f"{config_data['curated_catalog']}.{config_data['curated_schema']}.{config_data.get('run_log', 'run_log')}"
            run_log_df = spark.table(run_log_table)
            last_raw_ts_row = run_log_df.filter(F.col("curated_table") == curated_table_name) \
                                       .filter(F.col("status") == "SUCCESS") \
                                       .select(F.max("raw_processed_ts").alias("last_ts")).collect()
            last_raw_processed_ts = last_raw_ts_row[0]["last_ts"] if last_raw_ts_row and last_raw_ts_row[0]["last_ts"] else None
        except Exception as e:
            print(f"Could not read run log: {e}")
            last_raw_processed_ts = None

        print(f"Last processed timestamp: {last_raw_processed_ts}")

        # Filter for incremental load
        batch_incr_df2 = batch_df
        if last_raw_processed_ts:
            batch_incr_df2 = batch_incr_df2.filter(F.col(latest_col) > F.lit(last_raw_processed_ts))

        print(f"Incremental records count: {batch_incr_df2.count()}")
        
        if batch_incr_df2.count() > 0:
            print("Sample incremental data:")
            batch_incr_df2.select(*merge_keys, latest_col).show(10, truncate=False)

        # Handle no data scenario
        if batch_incr_df2.isEmpty():
            completed_at = datetime.now()
            raw_incr_count = 0
            raw_incr_key_count = 0
            raw_full_key_count = batch_df.select(*merge_keys).distinct().count()
            
            try:
                curated_full_count = spark.table(curated_table_name).count()
            except:
                curated_full_count = 0
        
            log_run_entry(
                spark=spark,
                run_id=run_id_value,
                curated_table=curated_table_name,
                raw_table=raw_table_name,
                raw_processed_ts=last_raw_processed_ts,
                status="NO_DATA",
                started_at=start_time,
                completed_at=completed_at,
                raw_incr_count=raw_incr_count,
                raw_incr_key_count=raw_incr_key_count,
                raw_full_key_count=raw_full_key_count,
                curated_full_count=curated_full_count,
                env=env
            )
            print("No new data to process.")
            return

        # Proper deduplication using window function
        # window_spec = Window.partitionBy(*merge_keys).orderBy(F.col(latest_col).desc())
        
        # latest_df = batch_incr_df2.withColumn("row_num", row_number().over(window_spec)) \
        #                           .filter(F.col("row_num") == 1) \
        #                           .drop("row_num")
        
        # print(f"Records after deduplication: {latest_df.count()}")
        
        latest_df = batch_incr_df2
        if latest_df.count() > 0:
            latest_df.select(*merge_keys, latest_col).show(10, truncate=False)

        # Validate that we have the mapping columns
        missing_source_cols = [source_col for target_col, source_col in target_to_source_mapping.items() 
                              if source_col not in latest_df.columns]
        if missing_source_cols:
            raise ValueError(f"Missing source columns in data: {missing_source_cols}")

        # Validate target table exists
        if not spark.catalog.tableExists(curated_table_name):
            raise Exception(f"Curated table {curated_table_name} does not exist")

        final_df = latest_df
        calculator = calculations(env = env)
        if "aggregation_keys" in config_data.keys():
            final_df = calculator.smart_aggregate(
                df = latest_df,
                keys = config_data["aggregation_keys"],
                aggregate_cols = config_data["aggregate_cols"],
                sep=", ", 
                dedup=True,
                order_by=None)

        # Check if insert-only mode (for tables like comments that don't support updates)
        insert_only_mode = config_data.get("insert_only", False)
        
        if insert_only_mode:
            print("Using INSERT-ONLY mode (no merge/update logic)")
            
            # Prepare data with audit columns for insert
            insert_df = final_df.select(
                *[col(source_col).alias(target_col) for target_col, source_col in target_to_source_mapping.items()]
            ).withColumn("actv_ind", lit("Y")) \
             .withColumn("create_usr_id", F.expr("current_user()")) \
             .withColumn("last_upd_usr_id", F.expr("current_user()")) \
             .withColumn("create_dttm", current_timestamp()) \
             .withColumn("last_upd_dttm", current_timestamp()) \
             .withColumn("run_id", lit(run_id_value))
            
            # Direct insert without merge
            insert_df.write.format("delta") \
                .mode("append") \
                .saveAsTable(curated_table_name)
            
            print(f"Inserted {insert_df.count()} records directly into {curated_table_name}")
            
            # Create merge stats for consistency
            merge_stats = {
                'num_inserted_rows': insert_df.count(),
                'num_updated_rows': 0,
                'num_affected_rows': insert_df.count()
            }
        else:
            # Perform merge operation (existing logic)
            curated_table = DeltaTable.forName(spark, curated_table_name)
            merge_condition = " AND ".join([f"target.{k} = source.{k}" for k in merge_keys])
            
            print(f"Merge condition: {merge_condition}")
            
            # Proper column mapping
            mapped_values = {}
            for target_col, source_col in target_to_source_mapping.items():
                mapped_values[target_col] = col(f"source.{source_col}")
            
            print(f"Column mapping count: {len(mapped_values)}")
            
            has_delete_flag = "DELETE_FLAG" in final_df.columns
            
            # Build complete merge operation
            if has_delete_flag:
                print("Processing with DELETE_FLAG logic")
                merge_result = curated_table.alias("target").merge(
                    final_df.alias("source"), 
                    merge_condition
                ).whenMatchedUpdate(
                    condition="source.DELETE_FLAG != 'Y'", 
                    set={
                        **mapped_values,
                        "actv_ind": lit("Y"),
                        "create_usr_id": col("target.create_usr_id"),
                        "last_upd_usr_id": F.expr("current_user()"),
                        "create_dttm": col("target.create_dttm"),
                        "last_upd_dttm": current_timestamp(),
                        "run_id": lit(run_id_value)
                    }
                ).whenMatchedUpdate(
                    condition="source.DELETE_FLAG = 'Y'", 
                    set={
                        "actv_ind": lit("N"),
                        "create_usr_id": col("target.create_usr_id"),
                        "last_upd_usr_id": F.expr("current_user()"),
                        "create_dttm": col("target.create_dttm"),
                        "last_upd_dttm": current_timestamp(),
                        "run_id": lit(run_id_value)
                    }
                ).whenNotMatchedInsert(
                    condition="source.DELETE_FLAG != 'Y'",
                    values={
                        **mapped_values,
                        "actv_ind": lit("Y"),
                        "create_usr_id": F.expr("current_user()"),
                        "last_upd_usr_id": F.expr("current_user()"),
                        "create_dttm": current_timestamp(),
                        "last_upd_dttm": current_timestamp(),
                        "run_id": lit(run_id_value)
                    }
                ).execute()
            else:
                print("Processing with standard update logic")
                merge_result = curated_table.alias("target").merge(
                    final_df.alias("source"), 
                    merge_condition
                ).whenMatchedUpdate(
                    set={
                        **mapped_values,
                        "actv_ind": lit("Y"),
                        "create_usr_id": col("target.create_usr_id"),
                        "last_upd_usr_id": F.expr("current_user()"),
                        "create_dttm": col("target.create_dttm"),
                        "last_upd_dttm": current_timestamp(),
                        "run_id": lit(run_id_value)
                    }
                ).whenNotMatchedInsert(
                    values={
                        **mapped_values,
                        "actv_ind": lit("Y"),
                        "create_usr_id": F.expr("current_user()"),
                        "last_upd_usr_id": F.expr("current_user()"),
                        "create_dttm": current_timestamp(),
                        "last_upd_dttm": current_timestamp(),
                        "run_id": lit(run_id_value)
                    }
                ).execute()
            
            print("Merge completed successfully")
            
            # Extract merge statistics
            merge_stats = merge_result if merge_result else {}
        
        # Calculate success metrics
        completed_at = datetime.now()
        raw_processed_ts = latest_df.agg(F.max(latest_col)).collect()[0][0]
        raw_incr_count = batch_incr_df2.count()
        raw_incr_key_count = latest_df.select(*merge_keys).distinct().count()
        raw_full_key_count = batch_df.select(*merge_keys).distinct().count()
        curated_full_count = spark.table(curated_table_name).count()
        status = "SUCCESS"

        print(f"Merge results:")
        print(f"  - Raw incremental records: {raw_incr_count}")
        print(f"  - Unique keys processed: {raw_incr_key_count}")
        print(f"  - Final curated count: {curated_full_count}")
        print(f"  - Max processed timestamp: {raw_processed_ts}")
        if merge_stats:
            print(f"  - Rows updated: {merge_stats.get('num_updated_rows', 0)}")
            print(f"  - Rows inserted: {merge_stats.get('num_inserted_rows', 0)}")

    except Exception as e:
        print(f"Load curated failed: {str(e)}")
        traceback.print_exc()
        
        completed_at = datetime.now()
        status = "FAILURE"
        
        # Safely calculate metrics for error case
        try:
            if final_df is not None and latest_col in final_df.columns:
                raw_processed_ts = final_df.agg(F.max(latest_col)).collect()[0][0]
            if batch_incr_df2 is not None:
                raw_incr_count = batch_incr_df2.count()
        except:
            pass  # Keep default values

    finally:
        # Always log the run
        log_run_entry(
            spark=spark,
            run_id=run_id_value,
            curated_table=curated_table_name,
            raw_table=raw_table_name,
            raw_processed_ts=raw_processed_ts,
            status=status,
            started_at=start_time,
            completed_at=completed_at,
            raw_incr_count=raw_incr_count,
            raw_incr_key_count=raw_incr_key_count,
            raw_full_key_count=raw_full_key_count,
            curated_full_count=curated_full_count,
            merge_stats=merge_stats,
            env=env
        )
        
        print(f"Run logged with status: {status}")
        
        if status == "FAILURE":
            raise Exception(f"Load curated process failed for {curated_table_name}")
