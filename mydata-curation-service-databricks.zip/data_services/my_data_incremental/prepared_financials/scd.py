from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Iterable, List, Mapping, Optional, Sequence

from delta.tables import DeltaTable
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class SCDType2Config:
    """
    Configuration for managing a Type 2 slowly changing dimension merge.
    """

    target_table: str
    business_keys: Sequence[str]
    natural_key_overrides: Mapping[str, str] = field(default_factory=dict)
    effective_start_col: str = "effective_start_dttm"
    effective_end_col: str = "effective_end_dttm"
    current_flag_col: str = "is_current"
    active_flag_col: str = "actv_ind"
    delete_indicator_col: Optional[str] = None
    hash_column: str = "record_hash"
    run_id_col: str = "run_id"
    created_col: str = "create_dttm"
    updated_col: str = "last_upd_dttm"
    created_user_col: str = "create_usr_id"
    updated_user_col: str = "last_upd_usr_id"
    payload_columns: Optional[Sequence[str]] = None
    user_expr: str = "current_user()"
    version_col: Optional[str] = "version_id"


class SCDType2MergeManager:
    """
    Provides reusable Type 2 merge semantics backed by Delta Lake MERGE operations.
    """

    def __init__(self, spark: SparkSession, config: SCDType2Config) -> None:
        self.spark = spark
        self.config = config

    def compute_record_hash(self, df: DataFrame, ordered_columns: Iterable[str]) -> DataFrame:
        """
        Compute a deterministic SHA-256 hash across the supplied columns.
        """
        null_literal = F.lit("~NULL~")
        concat_cols: List = []
        for column in ordered_columns:
            concat_cols.append(F.coalesce(df[column].cast("string"), null_literal))
            concat_cols.append(F.lit("||"))
        if concat_cols:
            concat_cols.pop()
        hash_expr = F.sha2(F.concat(*concat_cols), 256)
        return df.withColumn(self.config.hash_column, hash_expr)

    def _delta_table(self) -> DeltaTable:
        if not self.spark.catalog.tableExists(self.config.target_table):
            raise ValueError(f"Target table {self.config.target_table} does not exist")
        return DeltaTable.forName(self.spark, self.config.target_table)

    def merge(
        self,
        source_df: DataFrame,
        run_id: int,
        effective_ts_col: str,
        delete_flag_col: Optional[str] = None,
    ) -> None:
        """
        Apply Type 2 semantics using the provided source DataFrame.

        Assumes source_df already contains the payload columns, hash column,
        and an effective start timestamp column.
        """
        cfg = self.config
        delta_table = self._delta_table()

        natural_keys = []
        for key in cfg.business_keys:
            natural_keys.append(cfg.natural_key_overrides.get(key, key))
        merge_condition = " AND ".join(
            [f"target.{key} = source.{natural_key}" for key, natural_key in zip(cfg.business_keys, natural_keys)]
        )

        version_col = getattr(cfg, "version_col", None)
        if version_col:
            if version_col not in source_df.columns:
                existing_max = (
                    self.spark.table(cfg.target_table)
                    .groupBy(*cfg.business_keys)
                    .agg(F.max(version_col).alias("__max_version"))
                )
                original_cols = source_df.columns
                source_alias = source_df.alias("source")
                existing_alias = existing_max.alias("existing")
                join_cond = None
                for key, natural_key in zip(cfg.business_keys, natural_keys):
                    condition = F.col(f"source.{natural_key}") == F.col(f"existing.{key}")
                    join_cond = condition if join_cond is None else join_cond & condition
                joined = source_alias.join(existing_alias, join_cond, "left")
                source_df = joined.select(
                    *[F.col(f"source.{c}") for c in original_cols],
                    (F.coalesce(F.col("existing.__max_version"), F.lit(0)) + F.lit(1)).alias(version_col)
                )

        payload_cols = cfg.payload_columns or [
            c for c in source_df.columns if c not in set(natural_keys)
        ]

        delete_col = delete_flag_col or cfg.delete_indicator_col
        has_delete = delete_col is not None and delete_col in source_df.columns

        update_values = {
            col: F.col(f"source.{col}")
            for col in payload_cols
            if col not in {cfg.effective_start_col, cfg.effective_end_col, cfg.current_flag_col, cfg.active_flag_col}
            and (version_col is None or col != version_col)
        }
        update_values.update(
            {
                cfg.updated_user_col: F.expr(cfg.user_expr),
                cfg.updated_col: F.current_timestamp(),
                cfg.run_id_col: F.lit(run_id),
                cfg.current_flag_col: F.lit("Y"),
                cfg.active_flag_col: F.lit("Y"),
            }
        )

        insert_values = {col: F.col(f"source.{col}") for col in payload_cols}
        for key, natural_key in zip(cfg.business_keys, natural_keys):
            insert_values[key] = F.col(f"source.{natural_key}")
        insert_values.update(
            {
                cfg.created_user_col: F.expr(cfg.user_expr),
                cfg.updated_user_col: F.expr(cfg.user_expr),
                cfg.created_col: F.current_timestamp(),
                cfg.updated_col: F.current_timestamp(),
                cfg.run_id_col: F.lit(run_id),
                cfg.current_flag_col: F.lit("Y"),
                cfg.active_flag_col: F.lit("Y"),
                cfg.effective_end_col: F.lit(None).cast("timestamp"),
            }
        )

        merge_builder = delta_table.alias("target").merge(
            source_df.alias("source"), merge_condition
        )

        if has_delete:
            merge_builder = merge_builder.whenMatchedUpdate(
                condition=f"target.{cfg.current_flag_col} = 'Y' AND source.{delete_col} = 'Y'",
                set={
                    cfg.updated_user_col: F.expr(cfg.user_expr),
                    cfg.updated_col: F.current_timestamp(),
                    cfg.active_flag_col: F.lit("N"),
                    cfg.current_flag_col: F.lit("N"),
                    cfg.effective_end_col: F.col(f"source.{effective_ts_col}"),
                    cfg.run_id_col: F.lit(run_id),
                },
            )

        merge_builder = merge_builder.whenMatchedUpdate(
            condition=(
                f"target.{cfg.current_flag_col} = 'Y' AND "
                f"target.{cfg.hash_column} <> source.{cfg.hash_column}"
            ),
            set={
                cfg.updated_user_col: F.expr(cfg.user_expr),
                cfg.updated_col: F.current_timestamp(),
                cfg.current_flag_col: F.lit("N"),
                cfg.effective_end_col: (
                    F.col(f"source.{effective_ts_col}") - F.expr("INTERVAL 1 MICROSECOND")
                ),
                cfg.run_id_col: F.lit(run_id),
            },
        ).whenNotMatchedInsert(
            values=insert_values,
        )

        merge_result = merge_builder.execute()
        logger.info("SCD Type 2 merge applied: %s", merge_result)

        # Insert new versions for records that had hash changes (SCD Type 2 new versions)
        # After the merge has deactivated old records, we need to insert the new versions
        
        # Re-read the delta table to get the state AFTER the merge
        updated_target_df = self.spark.table(cfg.target_table)
        
        # Get all current records in the target (after merge, these are the ones still active)
        current_target_keys = (
            updated_target_df
            .filter(f"{cfg.current_flag_col} = 'Y'")
            .select(*cfg.business_keys, cfg.hash_column)
        )

        # Get source business keys and hashes
        source_keys = source_df.select(
            *[F.col(natural_key).alias(key) for key, natural_key in zip(cfg.business_keys, natural_keys)],
            F.col(cfg.hash_column).alias("source_hash")
        )

        # Find source records where business keys exist in target but are NOT active with the same hash
        # This means: business key exists in target, but either no active record or active record has different hash
        missing_versions = (
            source_keys.alias("src")
            .join(
                current_target_keys.alias("tgt"),
                [F.col(f"src.{key}") == F.col(f"tgt.{key}") for key in cfg.business_keys],
                "left_anti"  # Records in source that DON'T have matching business key + hash combination in active target
            )
            .join(
                updated_target_df.select(*cfg.business_keys).distinct().alias("exists"),
                [F.col(f"src.{key}") == F.col(f"exists.{key}") for key in cfg.business_keys],
                "inner"  # But the business key DOES exist in target (so it was deactivated, not brand new)
            )
            .select(*[F.col(f"src.{key}") for key in cfg.business_keys])
            .distinct()
        )

        # If there are changed records, insert them
        changed_count = missing_versions.count()
        if changed_count > 0:
            logger.info(f"Inserting {changed_count} new versions for changed records")
            
            # Get the full source records for the changed keys
            join_condition = None
            for key, natural_key in zip(cfg.business_keys, natural_keys):
                condition = F.col(f"source.{natural_key}") == F.col(f"keys.{key}")
                join_condition = condition if join_condition is None else join_condition & condition
            
            insert_df = (
                source_df.alias("source")
                .join(missing_versions.alias("keys"), join_condition, "inner")
                .select("source.*")
            )
            
            # Rename natural keys to business keys if needed
            for key, natural_key in zip(cfg.business_keys, natural_keys):
                if key != natural_key:
                    insert_df = insert_df.withColumnRenamed(natural_key, key)
            
            # Add SCD columns
            insert_df = (
                insert_df
                .withColumn(cfg.created_user_col, F.expr(cfg.user_expr))
                .withColumn(cfg.updated_user_col, F.expr(cfg.user_expr))
                .withColumn(cfg.created_col, F.current_timestamp())
                .withColumn(cfg.updated_col, F.current_timestamp())
                .withColumn(cfg.run_id_col, F.lit(run_id))
                .withColumn(cfg.current_flag_col, F.lit("Y"))
                .withColumn(cfg.active_flag_col, F.lit("Y"))
                .withColumn(cfg.effective_end_col, F.lit(None).cast("timestamp"))
            )
            
            insert_df.write.format("delta").mode("append").saveAsTable(cfg.target_table)

