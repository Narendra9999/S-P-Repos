from __future__ import annotations

import logging
import textwrap
import uuid
from dataclasses import dataclass, field
from string import Template
from typing import Any, Dict, Mapping, MutableMapping, Optional

from pyspark.sql import DataFrame, SparkSession

logger = logging.getLogger(__name__)


@dataclass
class SQLTransformContext:
    """
    Holds default parameters used when rendering SQL templates.
    """

    parameters: MutableMapping[str, Any] = field(default_factory=dict)

    def merged(self, overrides: Optional[Mapping[str, Any]] = None) -> Dict[str, Any]:
        result: Dict[str, Any] = dict(self.parameters)
        if overrides:
            result.update({k: v for k, v in overrides.items() if v is not None})
        return result


class SQLTransformExecutor:
    """
    Renders parameterised SQL templates and executes them with Spark.

    Designed to support complex transformations expressed in SQL for better traceability.
    """

    def __init__(
        self,
        spark: SparkSession,
        default_context: Optional[SQLTransformContext] = None,
        log_sql: bool = True,
    ) -> None:
        self.spark = spark
        self.default_context = default_context or SQLTransformContext()
        self.log_sql = log_sql

    def render(self, sql_template: str, params: Optional[Mapping[str, Any]] = None) -> str:
        """
        Render a SQL template using Template substitution.
        """
        merged_params = self.default_context.merged(params)
        template = Template(sql_template)
        rendered = template.safe_substitute(merged_params)
        return textwrap.dedent(rendered).strip()

    def execute(self, sql_template: str, params: Optional[Mapping[str, Any]] = None) -> DataFrame:
        """
        Render and execute a SQL template, returning a DataFrame.
        """
        rendered = self.render(sql_template, params)
        if self.log_sql:
            logger.debug("Executing SQL:\n%s", rendered)
        return self.spark.sql(rendered)

    def register_temporary_view(self, df: DataFrame, prefix: str = "tmp") -> str:
        """
        Register a DataFrame as a uniquely named temporary view and return the view name.
        """
        view_name = f"{prefix}_{uuid.uuid4().hex}"
        df.createOrReplaceTempView(view_name)
        return view_name

