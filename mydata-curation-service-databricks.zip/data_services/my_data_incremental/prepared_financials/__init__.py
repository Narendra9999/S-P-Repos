"""
Prepared Financials processing package.

Modules:
    scd: Provides reusable SCD Type 2 merge utilities and hashing helpers.
    sql_transforms: Executes parameterized Spark SQL transformations for custom logic injection.
"""

__all__ = [
    "scd",
    "sql_transforms",
]
