# Databricks notebook source

# COMMAND ----------

import json
import os
# from typing import Dict, List, Optional
from datetime import datetime, timedelta
import time
from kafka import KafkaConsumer
# from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.functions import col, current_timestamp
from pyspark.sql.types import TimestampType, IntegerType, LongType

# from data_services.my_data_incremental.io.meta.phoenix import pipelineLogger
# from data_services.my_data_incremental.io.kafka.writer import kafkaWriter
# from data_services.my_data_incremental.io.unityCatalog.reader import ucReader
from data_services.my_data_incremental.config.config_loader import Config
from data_services.my_data_incremental.io.kafka_config import get_kafka_config

from pyspark.sql import functions as F
import json


# COMMAND ----------
class LinkConsumer:
    def __init__(self, env, spark, dbutils):
        self.env = env
        self.spark = spark
        self.config = Config(env=self.env).loadConfig("lineage_config.json")
        self.dbutils = dbutils

    def get_kafka_consumer_config(self):

        config = self.config.get("linking")['kafka']
        kafka_creds = get_kafka_config(env=self.env)
        """Get Kafka consumer configuration"""
            # Convert to format expected by kafka-python
        return {
            'bootstrap_servers': config.get('bootstrap.servers'),
            'security_protocol': config.get('security.protocol'),
            'sasl_mechanism': config.get('sasl.mechanisms'),
            'ssl_cafile': config.get('ssl.ca.location'),
            'sasl_plain_username': kafka_creds['sasl.plain.username'],
            'sasl_plain_password': kafka_creds['_kafka_password'],  # Only injected at runtime
            'group_id': config.get('group.id'),
            'auto_offset_reset': config.get('auto.offset.reset', 'earliest'),
            'value_deserializer': lambda x: json.loads(x.decode('utf-8')) if x else None,
            'enable_auto_commit': True,
            'auto_commit_interval_ms': 5000,
            'session_timeout_ms': 30000,
            'request_timeout_ms': 40000
        }
    



    def ensure_delta_table_exists(self, catalog_name, schema_name, table_name, recreate=False):
        """Ensure Delta table exists, create if needed"""
        full_table_name = f"{catalog_name}.{schema_name}.{table_name}"
        
        # Create schema if needed
        self.spark.sql(f"CREATE SCHEMA IF NOT EXISTS {catalog_name}.{schema_name}")
        
        # Drop table if recreate is True
        if recreate:
            self.spark.sql(f"DROP TABLE IF EXISTS {full_table_name}")
            
        # Check if table exists
        tables = self.spark.sql(f"SHOW TABLES IN {catalog_name}.{schema_name}").filter(f"tableName = '{table_name}'").count()
        
        if tables == 0:
            # Create table with schema
            self.spark.sql(f"""
                CREATE TABLE {full_table_name} (
                    topic STRING,
                    topic_partition INT,
                    topic_offset BIGINT,
                    topic_timestamp BIGINT,
                    message_key STRING,
                    message_value STRING,
                    process_time TIMESTAMP
                )
                USING DELTA
                PARTITIONED BY (topic)
                COMMENT 'Kafka messages from organization linking response topic'
            """)
            print(f"Created table: {full_table_name}")
        else:
            print(f"Table {full_table_name} already exists")
            
        return full_table_name


    def consume_kafka_messages(self, topic, consumer_config, max_records=None, timeout=60):
        """Consume messages from Kafka topic"""
        messages = []
        count = 0
        start_time = datetime.now()
        end_time = start_time + timedelta(seconds=timeout)
    
        # Create consumer
        consumer = KafkaConsumer(topic, **consumer_config)
        print(f"Starting consumption from topic {topic}")
        
        # Poll for messages
        while datetime.now() < end_time and (max_records is None or count < max_records):
            remaining_time = max(1, (end_time - datetime.now()).total_seconds() * 1000)
            records = consumer.poll(timeout_ms=int(remaining_time), max_records=1000)
            
            if not records:
                time.sleep(1)  # Prevent tight polling
                continue
                
            # Process records
            for topic_partition, partition_messages in records.items():
                print(f"Received {len(partition_messages)} messages from partition {topic_partition.partition}")
                
                for message in partition_messages:
                    messages.append({
                        'topic': message.topic,
                        'topic_partition': message.partition,
                        'topic_offset': message.offset,
                        'topic_timestamp': message.timestamp,
                        'message_key': message.key.decode('utf-8') if message.key else None,
                        'message_value': message.value,
                        'process_time': datetime.now()
                    })
                    
                    count += 1
                    if count % 10 == 0:
                        print(f"Processed {count} messages")
                    
                    if max_records is not None and count >= max_records:
                        break
            
            # Commit offsets
            consumer.commit()
            
            if max_records is not None and count >= max_records:
                break

        if 'consumer' in locals():
            consumer.close()
            
        duration = (datetime.now() - start_time).total_seconds()
        print(f"Consumption completed: {count} messages in {duration:.2f} seconds")
        return messages



    def save_messages_to_delta(self, messages, catalog_name, schema_name, table_name):
        """Save messages to Delta table"""
        if not messages:
            print("No messages to save")
            return 0
            
        # Create rows for DataFrame
        from pyspark.sql import Row
        rows = []
        
        for msg in messages:
            # Convert value to string if needed
            if isinstance(msg['message_value'], (dict, list)):
                value_str = json.dumps(msg['message_value'])
            else:
                value_str = msg['message_value']
                
            rows.append(Row(
                topic=msg['topic'],
                topic_partition=int(msg['topic_partition']),
                topic_offset=int(msg['topic_offset']),
                topic_timestamp=int(msg['topic_timestamp']) if msg['topic_timestamp'] else None,
                message_key=msg['message_key'],
                message_value=value_str,
                process_time=msg['process_time']
            ))
            
        # Create DataFrame with proper types
        df = self.spark.createDataFrame(rows)
        df = df.withColumn("topic_partition", col("topic_partition").cast(IntegerType())) \
            .withColumn("topic_offset", col("topic_offset").cast(LongType())) \
            .withColumn("topic_timestamp", col("topic_timestamp").cast(LongType())) \
            .withColumn("process_time", col("process_time").cast(TimestampType()))
            
        # Get table name
        full_table_name = f"{catalog_name}.{schema_name}.{table_name}"
        
        # Match schema with existing table if needed
        existing_table = self.spark.table(full_table_name)
        for field in existing_table.schema.fields:
            if field.name in df.columns:
                df = df.withColumn(field.name, col(field.name).cast(field.dataType))

            
        # Write to Delta table
        df.write.format("delta").mode("append").saveAsTable(full_table_name)
        
        print(f"Saved {len(messages)} records to {full_table_name}")
        return len(messages)

        
    

    def run_consumer_pipeline(self):
        """Main function to run the consumer pipeline"""
        # Get parameters
        kafka_topic = self.config['linking']["kafka_topic"]
        config_json = self.config.get("kafka")
        max_records = int(self.config['linking'].get("max_records"))
        timeout = float(self.config['linking']['timeout'])
        catalog_name = self.config['linking']["catalog_name"]
        schema_name = self.config['linking']["schema_name"]
        table_name = self.config['linking']["table_name"]
        recreate_table = self.config['linking']["recreate_table"]
        
        # Print configuration
        print(f"Consuming from: {kafka_topic}")
        print(f"Max records: {max_records}, Timeout: {timeout}s")
        print(f"Target table: {catalog_name}.{schema_name}.{table_name}")
        
        # Get Kafka configuration
        consumer_config = self.get_kafka_consumer_config()
        
        # Ensure table exists
        self.ensure_delta_table_exists(catalog_name, schema_name, table_name, recreate_table)
        
        # Start pipeline
        start_time = datetime.now()
        
        # Consume messages
        messages = self.consume_kafka_messages(kafka_topic, consumer_config, max_records, timeout)
        
        # Save to Delta table
        records_saved = 0
        if messages:
            records_saved = self.save_messages_to_delta(messages, catalog_name, schema_name, table_name)
        
        # Calculate duration
        duration = (datetime.now() - start_time).total_seconds()

        print({
            "status": "success",
            "messages_consumed": len(messages),
            "records_saved": records_saved,
            "delta_table": f"{catalog_name}.{schema_name}.{table_name}",
            "execution_time_seconds": duration
        })
        
        # Return results
        return {
            "status": "success",
            "messages_consumed": len(messages),
            "records_saved": records_saved,
            "delta_table": f"{catalog_name}.{schema_name}.{table_name}",
            "execution_time_seconds": duration
        }

