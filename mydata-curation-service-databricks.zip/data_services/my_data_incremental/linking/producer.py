from data_services.my_data_incremental.io.meta.phoenix import pipelineLogger
from data_services.my_data_incremental.io.kafka.writer import kafkaWriter
from data_services.my_data_incremental.io.unityCatalog.reader import ucReader
from data_services.my_data_incremental.config.config_loader import Config
from data_services.my_data_incremental.io.kafka_config import fetch_kafka_credentials_from_vault


from pyspark.sql import functions as F
import json


class LinkProducer:
    def __init__(self, env, process_date, spark, dbutils):
        self.env = env
        self.spark = spark
        self.process_date = process_date
        self.config = dict()
        self.dbutils = dbutils

    def sort_configs(self):
        secrets = {
            "spark_kafka_value" : fetch_kafka_credentials_from_vault(key_name="kafka.orglinking.password")
            
        }
        configLoader = Config(env=self.env, variables=secrets)
        config = configLoader.loadConfig("lineage_config.json")

        self.config["kafka_properties"] = config["kafka_plain"]

        self.config["producer_config"] = {
                "metadata_catalog": config['catalogs']['raw']['catalog'],
                "metadata_schema": config['catalogs']['raw']['schema'],
                "messages_catalog": config['catalogs']['raw']['catalog'],
                "messages_schema": config['catalogs']['raw']['schema'],
                "messages_table": config['tables']['t_org_linking_responses'],
                "target_catalog": config['catalogs']['staging']['catalog'],
                "target_schema": config['catalogs']['staging']['schema'],
                "feed_name": config['incremental_feed']['feed_name'],
                "filteringKey" :  config['incremental_feed']['filteringKey'],
                "appName": config['incremental_feed']['appName'],
                "source": config['incremental_feed']['source'],
                "source_org_table": config['tables']['t_dc_transaction_org']
        }

        self.pipeline_logger = pipelineLogger(
            spark=self.spark, meta_options=self.config.get("producer_config")
        )

    def produce_linking(self, phoenix_ids_filter=None):
        self.sort_configs()

        options = {
            "catalog": self.config["producer_config"]["messages_catalog"],
            "schema": self.config["producer_config"]["messages_schema"],
            "table": self.config["producer_config"]["source_org_table"],
            "metadata": self.pipeline_logger.check_for_new_records(self.process_date),
            "filteringKey": self.config["producer_config"]["filteringKey"],
        }
        ur = ucReader(
            spark=self.spark,
            dbutils=self.dbutils,
            logger=self.pipeline_logger,
            options=options,
        )

        linking_configs = {
            "feed_name": self.config["producer_config"]["feed_name"],
            "batch_id": "1",
            "raw_table": f'{self.config["producer_config"]["messages_catalog"]}.{self.config["producer_config"]["messages_schema"]}.{self.config["producer_config"]["source_org_table"]}',
        }

        static_values = {
            "appName": self.config["producer_config"]["appName"],
            "source": self.config["producer_config"]["source"],
            "tableName": f"{options['catalog']}.{options['schema']}.{options['table']}",
        }
        options["config"] = linking_configs
        options["static_values"] = static_values
        options["kafka_config"] = self.config["kafka_properties"]

        df = ur.read_filtered()

        # Filter by specific phoenix_ids if provided
        if phoenix_ids_filter and len(phoenix_ids_filter) > 0:
            df = df.filter(F.col("PHOENIX_ID").isin(phoenix_ids_filter))
            
        # Add mandatory fields for org linking request
        df = df.withColumn(
            "countryByDomicileCountry",
            F.struct(
                F.coalesce(F.col("COUNTRY_CODE"), F.lit("US")).alias("countryIso2Code")
            )
        ).withColumn(
            "primaryName",
            F.coalesce(F.col("ORG_PRIMARY_NAME"), F.lit("Unknown Organization"))
        ).withColumn(
            "orgLinkings",
            F.array(
                F.struct(
                    F.struct(F.lit("PHOENIXID").alias("idType")).alias("identifierType"),
                    F.col("PHOENIX_ID").alias("idValue"),
                )
            ),
        )

        options["include_columns"] = ["countryByDomicileCountry", "primaryName", "source", "appName", "orgLinkings"]

        writer = kafkaWriter(
            spark=self.spark,
            options=options,
            logger=self.pipeline_logger,
            env=self.env
        )
       
        writer.write(df)