"""
Pipeline runners orchestrated through configuration.
"""

from .config_pipeline_runner import process_from_config

__all__ = ["process_from_config"]
