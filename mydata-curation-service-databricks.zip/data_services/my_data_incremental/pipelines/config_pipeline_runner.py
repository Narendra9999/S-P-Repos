from __future__ import annotations

import logging
from datetime import datetime
from typing import Any, Dict, Optional

from pyspark.sql import SparkSession
from pyspark.sql import functions as F

from data_services.my_data_incremental.config.config_loader import Config
from data_services.my_data_incremental.engine import DatasetExecution, DatasetProcessingEngine, DatasetProcessingSummary, DatasetTarget
from data_services.my_data_incremental.prepared_financials.scd import SCDType2Config
from data_services.my_data_incremental.pipelines.pipeline_run_logger import PipelineRunLogger

logger = logging.getLogger(__name__)


def _get_latest_data(df):
    if "run_id" not in df.columns:
        logger.warning("Requested latest read mode but dataframe has no run_id column; returning full dataset.")
        return df
    max_row = df.select(F.max("run_id").alias("max_run_id")).first()
    if not max_row or max_row["max_run_id"] is None:
        return df.limit(0)
    latest_run_id = max_row["max_run_id"]
    return df.filter(df.run_id == latest_run_id)


def _load_pipeline_config(config_loader: Config, config_name: str) -> Dict[str, Any]:
    pipeline_cfg = config_loader.loadConfig(config_name)
    datasets = pipeline_cfg.get("datasets")
    if not datasets:
        raise ValueError(f"Pipeline configuration '{config_name}' must define a non-empty 'datasets' list.")
    return pipeline_cfg


def _resolve_source_dataframe(spark: SparkSession, dataset_cfg: Dict[str, Any]) -> Dict[str, Any]:
    source_cfg = dataset_cfg.get("source")
    if not source_cfg:
        raise ValueError(f"Dataset '{dataset_cfg.get('name')}' is missing 'source' configuration.")

    source_type = source_cfg.get("type", "table").lower()
    read_mode = source_cfg.get("read_mode", "full").lower()
    if source_type == "table":
        catalog = source_cfg["catalog"]
        schema = source_cfg["schema"]
        table = source_cfg["table"]
        fqn = f"{catalog}.{schema}.{table}"
        logger.info("Reading source table %s for dataset '%s'", fqn, dataset_cfg.get("name"))
        dataframe = spark.table(fqn)
        if read_mode == "latest":
            dataframe = _get_latest_data(dataframe)
        source_identifier = fqn
    elif source_type in {"view", "temp_view"}:
        view_name = source_cfg["name"]
        logger.info("Reading source view %s for dataset '%s'", view_name, dataset_cfg.get("name"))
        dataframe = spark.table(view_name)
        source_identifier = view_name
    else:
        raise ValueError(f"Unsupported source type '{source_type}' for dataset '{dataset_cfg.get('name')}'.")

    return {
        "dataframe": dataframe,
        "source_table": source_identifier,
    }


def _build_target(dataset_cfg: Dict[str, Any]) -> DatasetTarget:
    target_cfg = dataset_cfg.get("target")
    if not target_cfg:
        raise ValueError(f"Dataset '{dataset_cfg.get('name')}' is missing 'target' configuration.")

    target_type = (target_cfg.get("type") or "delta").lower()
    transformation_cfg = dataset_cfg.get("transformation", {})

    table_name = target_cfg.get("table") or target_cfg.get("name") or dataset_cfg.get("name")

    write_mode_lookup = {
        "delta": "delta",
        "table": "delta",
        "temp_view": "temp_view",
        "view": "temp_view",
        "kafka": "kafka",
        "kafka_producer": "kafka",
        "postgres": "postgres",
        "postgresql": "postgres",
        "jdbc": "postgres",
    }

    if target_type not in write_mode_lookup:
        raise ValueError(
            f"Unsupported target type '{target_type}' for dataset '{dataset_cfg.get('name')}'. "
            "Supported types: delta, temp_view, kafka, postgres."
        )

    return DatasetTarget(
        catalog=target_cfg.get("catalog", ""),
        schema=target_cfg.get("schema", ""),
        table=table_name,
        options=target_cfg.get("options", {}),
        apply_transformations=dataset_cfg.get("apply_transformations", True),
        transformation_catalog=transformation_cfg.get("catalog"),
        transformation_schema=transformation_cfg.get("schema"),
        transformation_table=transformation_cfg.get("table"),
        write_mode=write_mode_lookup[target_type],
        skip_schema_validation=target_cfg.get("skip_schema_validation", False),
        create_if_missing=target_cfg.get("create_if_missing", False),
        config_key=target_cfg.get("config_key"),
        schema_catalog=target_cfg.get("schema_catalog"),
    )


def _build_scd_config(dataset_cfg: Dict[str, Any], target: DatasetTarget) -> Optional[SCDType2Config]:
    scd_cfg = dataset_cfg.get("scd")
    if not scd_cfg:
        return None

    scd_type = scd_cfg.get("type", "type2").lower()
    if scd_type != "type2":
        raise ValueError(f"Unsupported SCD type '{scd_type}' for dataset '{dataset_cfg.get('name')}'.")

    business_keys = scd_cfg.get("business_keys")
    if not business_keys:
        raise ValueError(f"SCD configuration for dataset '{dataset_cfg.get('name')}' must include 'business_keys'.")

    kwargs: Dict[str, Any] = {
        "target_table": scd_cfg.get("target_table") or target.fully_qualified_name,
        "business_keys": business_keys,
        "natural_key_overrides": scd_cfg.get("natural_key_overrides", {}),
        "hash_column": scd_cfg.get("hash_column", "record_hash"),
        "delete_indicator_col": scd_cfg.get("delete_indicator_col"),
    }

    optional_fields = [
        "effective_start_col",
        "effective_end_col",
        "current_flag_col",
        "active_flag_col",
        "run_id_col",
        "created_col",
        "updated_col",
        "created_user_col",
        "updated_user_col",
        "payload_columns",
    ]
    for field in optional_fields:
        if field in scd_cfg:
            kwargs[field] = scd_cfg[field]

    return SCDType2Config(**kwargs)


def process_from_config(
    spark: SparkSession,
    env: str,
    config_name: str,
    config_loader: Optional[Config] = None,
) -> None:
    """
    Execute datasets described in the supplied pipeline configuration file.
    """
    loader = config_loader or Config(env=env, variables=None)
    pipeline_cfg = _load_pipeline_config(loader, config_name)
    datasets = pipeline_cfg["datasets"]

    engine = DatasetProcessingEngine(
        spark=spark,
        config_loader=loader,
        env=env,
    )

    pipeline_identifier = config_name.replace(".json", "")
    if pipeline_identifier.startswith("pipeline_"):
        pipeline_identifier = pipeline_identifier[len("pipeline_") :]

    run_logger = PipelineRunLogger(
        spark=spark,
        env=env,
        pipeline_name=pipeline_identifier,
    )

    pipeline_run_id = int(datetime.utcnow().strftime("%Y%m%d%H%M%S"))
    dataset_summaries: list[DatasetProcessingSummary] = []
    status = "SUCCESS"
    error_message: Optional[str] = None

    try:
        for dataset_cfg in datasets:
            name = dataset_cfg.get("name")
            source_info = _resolve_source_dataframe(spark, dataset_cfg)
            target = _build_target(dataset_cfg)
            scd_config = _build_scd_config(dataset_cfg, target)
            effective_ts_col = dataset_cfg.get("effective_timestamp_column", "processing_timestamp")

            execution = DatasetExecution(
                name=name,
                dataframe=source_info["dataframe"],
                target=target,
                run_id=(dataset_cfg.get("run_id") or pipeline_run_id) if scd_config else None,
                context={
                    "source_table": source_info["source_table"],
                    "pipeline_run_id": str(pipeline_run_id),
                    "dataset_run_id": str(dataset_cfg.get("run_id") or pipeline_run_id),
                },
                scd_config=scd_config,
                effective_timestamp_column=effective_ts_col,
            )

            try:
                summary = engine.process_dataset(execution)
                dataset_summaries.append(summary)
                logger.info("Dataset '%s' processed successfully.", name)
            except Exception as dataset_exc:
                fallback_summary = DatasetProcessingSummary(
                    name=name,
                    write_mode=target.write_mode,
                    target=target.fully_qualified_name if target.write_mode == "delta" else target.table,
                    scd_applied=bool(scd_config),
                    transformation_applied=dataset_cfg.get("apply_transformations", True),
                    run_id=str(dataset_cfg.get("run_id") or pipeline_run_id),
                    additional_metadata={
                        "source_table": source_info["source_table"],
                        "error": str(dataset_exc),
                    },
                )
                dataset_summaries.append(fallback_summary)
                raise
    except Exception as exc:
        status = "FAILED"
        error_message = str(exc)
        raise
    finally:
        try:
            run_logger.log_run(
                pipeline_run_id=str(pipeline_run_id),
                dataset_summaries=dataset_summaries,
                pipeline_config=pipeline_cfg,
                status=status,
                error_message=error_message,
            )
        except Exception:  # pragma: no cover - logging failures should not mask pipeline errors
            logger.exception("Failed to persist pipeline run log for pipeline '%s'.", pipeline_identifier)
