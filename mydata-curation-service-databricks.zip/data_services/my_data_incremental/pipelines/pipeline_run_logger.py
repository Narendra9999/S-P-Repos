from __future__ import annotations

import json
import logging
from datetime import date, datetime
from decimal import Decimal
from typing import Any, Dict, Iterable, List, Optional

from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from pyspark.sql.types import (
    BooleanType,
    LongType,
    StringType,
    StructField,
    StructType,
    TimestampType,
)

from data_services.my_data_incremental.engine.models import DatasetProcessingSummary

logger = logging.getLogger(__name__)


LOG_TABLE_SCHEMA = StructType(
    [
        StructField("curated_run_id", LongType(), True),
        StructField("pipeline_run_id", StringType(), False),
        StructField("pipeline_name", StringType(), False),
        StructField("status", StringType(), False),
        StructField("dry_run", BooleanType(), False),
        StructField("transformation_payload", StringType(), True),
        StructField("configuration_payload", StringType(), True),
        StructField("kafka_payload", StringType(), True),
        StructField("postgres_payload", StringType(), True),
        StructField("metadata_payload", StringType(), True),
        StructField("created_at", TimestampType(), False),
        StructField("error_message", StringType(), True),
    ]
)


class PipelineRunLogger:
    """
    Persists end-to-end pipeline execution metadata in a configurable curated-layer Delta table.
    """

    def __init__(self, spark: SparkSession, env: str, pipeline_name: str) -> None:
        self.spark = spark
        self.env = env
        self.pipeline_name = pipeline_name

    def log_run(
        self,
        pipeline_run_id: str,
        dataset_summaries: Iterable[DatasetProcessingSummary],
        pipeline_config: Dict[str, Any],
        status: str,
        error_message: Optional[str],
    ) -> None:
        logging_cfg = (pipeline_config.get("logging") or {})
        log_cfg = logging_cfg.get("log_table") or pipeline_config.get("log_table")
        if not log_cfg:
            logger.info(
                "Pipeline config for '%s' is missing 'log_table'; skipping pipeline run logging.",
                self.pipeline_name,
            )
            return

        table_fqn = self._resolve_table_identifier(log_cfg)
        if not table_fqn:
            return

        try:
            self._ensure_log_table(table_fqn, log_cfg)
        except Exception:
            logger.exception("Unable to ensure log table '%s' exists for pipeline '%s'.", table_fqn, self.pipeline_name)
            return

        curated_cfg = logging_cfg.get("curated_run_log") or pipeline_config.get("curated_run_log")
        curated_run_id = self._lookup_curated_run_id(curated_cfg)
        curated_run_value: Optional[int] = None
        if curated_run_id is not None:
            try:
                curated_run_value = int(curated_run_id)
            except (TypeError, ValueError):
                logger.warning(
                    "Curated run identifier '%s' for pipeline '%s' is not numeric; storing as NULL.",
                    curated_run_id,
                    self.pipeline_name,
                )

        summaries = list(dataset_summaries)
        transformation_payload = self._build_transformation_payload(summaries)
        kafka_payload = self._build_kafka_payload(summaries)
        postgres_payload = self._build_postgres_payload(summaries)
        configuration_payload = pipeline_config
        metadata_payload = self._build_metadata_payload(summaries, status)
        dry_run = self._derive_dry_run_status(summaries)

        record = {
            "curated_run_id": curated_run_value,
            "pipeline_run_id": pipeline_run_id,
            "pipeline_name": self.pipeline_name,
            "status": status,
            "dry_run": dry_run,
            "transformation_payload": self._to_json(transformation_payload),
            "configuration_payload": self._to_json(configuration_payload),
            "kafka_payload": self._to_json(kafka_payload),
            "postgres_payload": self._to_json(postgres_payload),
            "metadata_payload": self._to_json(metadata_payload),
            "created_at": datetime.utcnow(),
            "error_message": (error_message or "")[:2000] if error_message else "",
        }

        df = self.spark.createDataFrame([record], schema=LOG_TABLE_SCHEMA)
        writer = df.write.format("delta").mode("append")
        if log_cfg.get("path"):
            writer = writer.option("path", log_cfg["path"])
        writer.saveAsTable(table_fqn)
        logger.info(
            "Pipeline run metadata for '%s' persisted to %s (status=%s, dry_run=%s).",
            self.pipeline_name,
            table_fqn,
            status,
            dry_run,
        )

    def _resolve_table_identifier(self, log_cfg: Dict[str, Any]) -> Optional[str]:
        catalog = log_cfg.get("catalog")
        schema = log_cfg.get("schema")
        table = log_cfg.get("table")
        if not (catalog and schema and table):
            logger.warning(
                "Log table configuration for pipeline '%s' must include catalog, schema, and table.",
                self.pipeline_name,
            )
            return None
        return f"{catalog}.{schema}.{table}"

    def _ensure_log_table(self, table_fqn: str, log_cfg: Dict[str, Any]) -> None:
        if self.spark.catalog.tableExists(table_fqn):
            return

        logger.info("Creating pipeline log table %s for pipeline '%s'.", table_fqn, self.pipeline_name)
        empty_df = self.spark.createDataFrame([], schema=LOG_TABLE_SCHEMA)
        writer = empty_df.write.format("delta").mode("overwrite")
        if log_cfg.get("path"):
            writer = writer.option("path", log_cfg["path"])
        partition_cols = log_cfg.get("partition_by") or []
        if partition_cols:
            writer = writer.partitionBy(*partition_cols)
        writer.saveAsTable(table_fqn)

    def _lookup_curated_run_id(self, run_cfg: Optional[Dict[str, Any]]) -> Optional[Any]:
        if not run_cfg:
            return None

        table_fqn = self._resolve_table_identifier(run_cfg)
        if not table_fqn:
            return None

        try:
            df = self.spark.table(table_fqn)
        except Exception:
            logger.exception(
                "Unable to read curated run log table '%s' for pipeline '%s'.",
                table_fqn,
                self.pipeline_name,
            )
            return None

        pipeline_id_column = run_cfg.get("pipeline_id_column")
        pipeline_id_value = run_cfg.get("pipeline_id_value")
        if pipeline_id_column and pipeline_id_value is not None and pipeline_id_column in df.columns:
            df = df.filter(F.col(pipeline_id_column) == pipeline_id_value)

        run_id_column = run_cfg.get("run_id_column", "run_id")
        if run_id_column not in df.columns:
            logger.warning(
                "Configured run_id_column '%s' not present in %s; unable to derive curated run id.",
                run_id_column,
                table_fqn,
            )
            return None

        latest = df.select(run_id_column).orderBy(F.col(run_id_column).desc()).limit(1).collect()
        if not latest:
            return None
        return latest[0][run_id_column]

    def _build_transformation_payload(self, summaries: List[DatasetProcessingSummary]) -> Dict[str, Any]:
        datasets = []
        for summary in summaries:
            datasets.append(
                self._clean_structure(
                    {
                        "name": summary.name,
                        "write_mode": summary.write_mode,
                        "target": summary.target,
                        "scd_applied": summary.scd_applied,
                        "transformation_applied": summary.transformation_applied,
                        "run_id": summary.run_id,
                        "row_count": summary.row_count,
                        "metadata": summary.additional_metadata,
                    }
                )
            )
        return {"datasets": datasets, "count": len(datasets)}

    def _build_kafka_payload(self, summaries: List[DatasetProcessingSummary]) -> Dict[str, Any]:
        payloads = []
        for summary in summaries:
            if not summary.kafka_result:
                continue
            payloads.append(
                self._clean_structure(
                    {
                        "dataset": summary.name,
                        **summary.kafka_result,
                    }
                )
            )
        return {"entries": payloads, "count": len(payloads)}

    def _build_postgres_payload(self, summaries: List[DatasetProcessingSummary]) -> Dict[str, Any]:
        payloads = []
        for summary in summaries:
            if not summary.postgres_result:
                continue
            payloads.append(
                self._clean_structure(
                    {
                        "dataset": summary.name,
                        **summary.postgres_result,
                    }
                )
            )
        return {"entries": payloads, "count": len(payloads)}

    def _build_metadata_payload(self, summaries: List[DatasetProcessingSummary], status: str) -> Dict[str, Any]:
        errors = [
            summary.additional_metadata.get("error")
            for summary in summaries
            if summary.additional_metadata.get("error")
        ]
        metadata = {
            "dataset_count": len(summaries),
            "status": status,
            "write_modes": sorted({summary.write_mode for summary in summaries}),
            "errors": errors,
        }
        application_id = self._resolve_application_id()
        if application_id:
            metadata["spark_application_id"] = application_id
        return self._clean_structure(metadata)

    def _derive_dry_run_status(self, summaries: List[DatasetProcessingSummary]) -> bool:
        writer_flags = []
        for summary in summaries:
            if summary.kafka_result:
                writer_flags.append(bool(summary.kafka_result.get("dry_run")))
            if summary.postgres_result:
                writer_flags.append(bool(summary.postgres_result.get("dry_run")))
        if not writer_flags:
            return False
        return all(writer_flags)

    def _to_json(self, data: Any) -> str:
        if data is None:
            return ""
        return json.dumps(self._clean_structure(data), default=self._json_default)

    def _clean_structure(self, value: Any) -> Any:
        if isinstance(value, dict):
            return {k: self._clean_structure(v) for k, v in value.items() if v is not None}
        if isinstance(value, list):
            return [self._clean_structure(v) for v in value if v is not None]
        return value

    @staticmethod
    def _json_default(value: Any) -> Any:
        if isinstance(value, (datetime,)):
            return value.isoformat()
        if isinstance(value, date):
            return value.isoformat()
        if isinstance(value, Decimal):
            return str(value)
        return str(value)

    def _resolve_application_id(self) -> Optional[str]:
        try:
            spark_context = self.spark.sparkContext  # type: ignore[attr-defined]
        except Exception:
            spark_context = None

        if spark_context is not None:
            try:
                return getattr(spark_context, "applicationId", None)
            except Exception:
                return None

        client = getattr(self.spark, "_client", None)
        if client is not None:
            try:
                return getattr(client, "application_id", None)
            except Exception:
                return None

        return None
