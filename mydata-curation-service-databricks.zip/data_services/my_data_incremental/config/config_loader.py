# import os
import json
from importlib.resources import files
from string import Template
import jsonref
import uuid
import os
import importlib.resources as pkg_resources

from pyspark.sql.types import (
    StructType, StructField, StringType, IntegerType, DoubleType, BooleanType
)

class Config:
    def __init__(self, env: str = None, variables: dict | None = None):
        self.env = env or ""
        self.variables = dict(variables or {})
        self.variables["env"] = self.env
        self.config_data = {}

    def get_ssd_exceptions(self):
        env_lower = self.env.casefold() if self.env else ""
        if "ssd" in env_lower:
            base = self.env.replace("ssd", "")
            return {
                "bucket_env": base,
                "ssd_opt_path_env": f"/{self.env}",
                "bootstrap_env": base,
                "p1" : "password"
            }
        else:
            # Special bootstrap environment mappings
            if env_lower == "uat":
                bootstrap_env = "qa"
            elif env_lower in ["prod", "dr"]:
                bootstrap_env = "pde"
            else:
                bootstrap_env = self.env
                
            return {
                "bucket_env": self.env,
                "ssd_opt_path_env": f"/{self.env}" if self.env else "",
                "bootstrap_env": bootstrap_env,
                "p1" : "password"
            }

    def loadConfig(self, configFile: str):
        ssd_exceptions = self.get_ssd_exceptions()
        self.variables.update(ssd_exceptions)

        resource_package = "data_services.my_data_incremental.config"
        resource_path = files(resource_package).joinpath(configFile)

        with resource_path.open("r", encoding="utf-8") as f:
            raw_config = f.read()

        substituted = Template(raw_config).safe_substitute(self.variables).replace("$$", "$")

        try:
            self.config_data = jsonref.loads(substituted, load_on_repr=True)
        except json.JSONDecodeError as e:
            lines = substituted.splitlines()
            start = max(0, e.lineno - 3)
            end = min(len(lines), e.lineno + 2)
            context = "\n".join(f"{i+1:4d}: {lines[i]}" for i in range(start, end))
            raise ValueError(
                f"JSON parse error at line {e.lineno}, col {e.colno}: {e.msg}\n"
                f"--- Context ---\n{context}\n"
            ) from e

        return self.config_data

    def load_schema(self, catalog=None, schema=None, table=None, return_properties: bool = False):
        typeMap = {
            "string": StringType(),
            "int": IntegerType(),
            "bool": BooleanType(),
            "double": DoubleType(),
        }

        if not (catalog and schema and table):
            print(f"One of the following is missing: Catalog({catalog}), Schema({schema}), Table({table})")
            return None

        resource_package = f"data_services.my_data_incremental.config.schemas.{catalog}.{schema}"
        path = files(resource_package).joinpath(f"{table}.json")

        with path.open("r", encoding="utf-8") as f:
            raw_schema = json.load(f)

        properties = {}
        if isinstance(raw_schema, dict):
            schema_def = raw_schema.get("schema")
            if schema_def is None:
                raise ValueError(f"Schema definition missing 'schema' key in {table}.json")
            properties = raw_schema.get("properties", {}) or {}
        else:
            schema_def = raw_schema

        structFields = []
        for field in schema_def:
            field_type_name = str(field.get("type", "string")).casefold()
            fieldType = typeMap.get(field_type_name, StringType())
            structFields.append(StructField(field["name"], fieldType, field.get("nullable", True)))

        schema_struct = StructType(structFields)
        if return_properties:
            return {"schema": schema_struct, "properties": properties}
        return schema_struct

    def load_data(
            self,
            spark,
            catalog:str,
            schema: str,
            table: str,
            fmt: str = "csv",
            enforce_schema: bool = True,
            options: dict|None = None
    ):
        self.spark = spark
        if not (catalog and schema and table):
            raise ValueError("Missing one of: catalog, schema, table")
        fmt = fmt.casefold()
        if fmt not in ("csv", "json"):
            raise ValueError(f"Unsupported format: {fmt}.")
        
        data_pkg = f"data_services.my_data_incremental.config.data.{catalog}.{schema}"
        ext = "csv" if fmt == "csv" else "json"
        data_path = files(data_pkg).joinpath(f"{table}.{ext}")
        if not data_path.is_file():
            return False
        
        uid = uuid.uuid4().hex
        local_dir = f"/dbfs/tmp/static_tables/{uid}/{catalog}/{schema}"
        os.makedirs(local_dir, exist_ok=True)
        local_path = os.path.join(local_dir, f"{table}.{ext}")
        with data_path.open("rb") as src, open(local_path, "wb") as dst:
            dst.write(src.read())

        staged_path = local_path.replace("/dbfs", "dbfs:")

        spark_schema = None
        if enforce_schema:
            spark_schema = self.load_schema(catalog=catalog, schema=schema, table=table)
            if spark_schema is None:
                enforce_schema = False
            
        reader_opts = {}
        if fmt == "csv":
            reader_opts = {
                "header": "true",
                "inferSchema": "false",
                "multiLine": "true",
                "quote" : '"',
                "escape": '"'
            }
        elif fmt == "json":
            reader_opts = {
                "multiLine": "true"
            }
        if options:
            reader_opts.update({k: str(v) for k,v in options.items()})

        reader = self.spark.read.options(**reader_opts)

        if enforce_schema and spark_schema is not None:
            reader = reader.schema(spark_schema)

        if fmt == "csv":
            df = reader.csv(str(staged_path))
        elif fmt == "json":
            df = reader.json(str(staged_path))
        
        return df

    def load_sql_query(
            self,
            spark,
            catalog: str,
            schema: str,
            table: str,
            fmt: str = "sql",
            execute_query: bool = True
    ):
        """
        Load and execute SQL query from file with environment templating.
        
        Args:
            spark: Spark session
            catalog: Target catalog name
            schema: Target schema name  
            table: Target table name
            execute_query: If True, execute the query and return DataFrame. If False, return query string.
            
        Returns:
            DataFrame if execute_query=True, otherwise SQL query string
        """
        self.spark = spark
        
        if not (catalog and schema and table):
            raise ValueError("Missing one of: catalog, schema, table")
        
        
        sql_pkg = "data_services.my_data_incremental.config.sql"
        sql_path = files(sql_pkg).joinpath(f"{table}.sql")
        
        if not sql_path.is_file():
            raise FileNotFoundError(f"SQL file not found: {table}.sql in {sql_pkg}")
        
        
        with sql_path.open("r", encoding="utf-8") as f:
            sql_query = f.read()
        
        
        sql_query = sql_query.replace("{env}", self.env)
        
        
        if self.variables:
            from string import Template
            template = Template(sql_query)
            sql_query = template.safe_substitute(self.variables)
        
        if execute_query:
            
            df = self.spark.sql(sql_query)
            return df
        else:
            
            return sql_query
