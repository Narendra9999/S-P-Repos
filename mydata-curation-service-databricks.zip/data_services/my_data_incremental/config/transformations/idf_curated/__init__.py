"""
idf_curated catalog transformation templates.
"""

__all__ = ["uspf"]
