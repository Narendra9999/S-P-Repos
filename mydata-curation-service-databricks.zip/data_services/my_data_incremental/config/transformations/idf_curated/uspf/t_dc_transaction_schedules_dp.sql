SELECT
    SRC_DE_UNIQ_ID_TEXT,
    PHOENIX_ID,
    REPORT_ID,
    SORT_ARRAY(
        COLLECT_LIST(
            NAMED_STRUCT(
                'order_id', CAST(ORDER_ID AS DOUBLE),
                'schedule_name', SCHEDULE_NAME,
                'schedule_value', SCHEDULE_VALUE,
                'formula_text', SCHEDULE_FRMLA_TEXT,
                'value', VALUE
            )
        )
    ) AS schedules
FROM ${source_table}
WHERE actv_ind = 'Y'
GROUP BY SRC_DE_UNIQ_ID_TEXT, PHOENIX_ID, REPORT_ID
