SELECT
    PHOENIX_ID,
    PHOENIX_PLAN_ID,
    SECTOR_NAME,
    CORE_ORG_ID,
    PER_TYPE_NAME,
    MEASURE_DATE AS measure_date_og,
    PERIOD_END_DATE AS period_end_date_og,
    COALESCE(
        TO_DATE(MEASURE_DATE),
        TO_DATE(MEASURE_DATE, 'MM-dd-yyyy'),
        TO_DATE(MEASURE_DATE, 'yyyyMMdd'),
        TO_DATE(MEASURE_DATE, 'MM/dd/yyyy')
    ) AS measure_date,
    COALESCE(
        TO_DATE(PERIOD_END_DATE),
        TO_DATE(PERIOD_END_DATE, 'MM-dd-yyyy'),
        TO_DATE(PERIOD_END_DATE, 'yyyyMMdd'),
        TO_DATE(PERIOD_END_DATE, 'MM/dd/yyyy')
    ) AS period_end_date,
    PERIOD_MONTHS,
    STATEMENT_BASIS_NAME,
    ACCOUNT_BASIS_NAME,
    APR_ACCEPTABLE,
    SOURCE_FILE_CREATE_DATE,
    SRC_DE_UNIQ_ID_TEXT,
    DP_VALUE,
    REPORT_ID,
    DELETE_FLAG,
    ACTION,
    COLLECTION_DENOM,
    actv_ind,
    create_usr_id,
    last_upd_usr_id,
    create_dttm,
    last_upd_dttm,
    run_id,
    record_hash,
    COALESCE(
        TO_TIMESTAMP(SOURCE_FILE_CREATE_DATE),
        TO_TIMESTAMP(SOURCE_FILE_CREATE_DATE, 'MM-dd-yyyy HH:mm:ss'),
        TO_TIMESTAMP(SOURCE_FILE_CREATE_DATE, 'MM/dd/yyyy')
    ) AS source_file_ts,
    COALESCE(last_upd_dttm, create_dttm) AS last_upd_ts
FROM ${source_table}
WHERE actv_ind = 'Y'
