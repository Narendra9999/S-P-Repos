SELECT
    SRC_DE_UNIQ_ID_TEXT,
    PHOENIX_ID,
    REPORT_ID,
    SORT_ARRAY(
        COLLECT_LIST(
            NAMED_STRUCT(
                'comment_timestamp', COMMENT_DATE_TIME,
                'comment_text', COMMENTS,
                'comment_by', COMMENT_BY
            )
        ),
        TRUE
    ) AS comments
FROM ${source_table}
WHERE actv_ind = 'Y'
GROUP BY SRC_DE_UNIQ_ID_TEXT, PHOENIX_ID, REPORT_ID
