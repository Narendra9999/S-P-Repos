SELECT
    PHOENIX_ID,
    SECTOR                AS org_sector,
    CORE_ORG_ID           AS org_core_org_id,
    ORG_PRIMARY_NAME,
    STATE                 AS org_state,
    COUNTRY_CODE          AS org_country_code,
    CURRENCY_CODE         AS org_currency_code,
    DEAL_NAME_DESCRIPTOR,
    FIN_REVENUE_TYPE,
    FIN_REVENUE_SUBTYPE,
    FYE,
    create_usr_id         AS org_create_usr_id,
    last_upd_usr_id       AS org_last_upd_usr_id,
    create_dttm           AS org_create_dttm,
    last_upd_dttm         AS org_last_upd_dttm,
    run_id                AS org_run_id,
    ROW_NUMBER() OVER (
        PARTITION BY PHOENIX_ID
        ORDER BY COALESCE(last_upd_dttm, create_dttm) DESC NULLS LAST
    ) AS rn
FROM ${source_table}
WHERE actv_ind = 'Y'
