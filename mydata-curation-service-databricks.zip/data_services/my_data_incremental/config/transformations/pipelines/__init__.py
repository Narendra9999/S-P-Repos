"""
Config-driven pipeline transformation templates.
"""

__all__ = ["dp_to_adp"]
