WITH latest_curated_run AS (
    SELECT MAX(run_id) AS max_run_id
    FROM ${source_table}
)
SELECT source.*
FROM ${source_table} AS source
INNER JOIN latest_curated_run
    ON source.run_id = latest_curated_run.max_run_id

