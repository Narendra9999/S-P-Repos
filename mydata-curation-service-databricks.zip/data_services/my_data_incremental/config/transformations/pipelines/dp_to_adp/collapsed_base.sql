WITH enriched AS (
    SELECT
        load.PHOENIX_ID,
        load.PHOENIX_PLAN_ID,
        load.SECTOR_NAME,
        load.CORE_ORG_ID,
        load.PER_TYPE_NAME,
        load.measure_date_og,
        load.PERIOD_END_DATE_og,
        load.measure_date,
        load.period_end_date,
        load.PERIOD_MONTHS,
        load.STATEMENT_BASIS_NAME,
        load.ACCOUNT_BASIS_NAME,
        load.APR_ACCEPTABLE,
        load.SOURCE_FILE_CREATE_DATE,
        load.REPORT_ID,
        load.DELETE_FLAG,
        load.ACTION,
        load.actv_ind,
        load.create_usr_id,
        load.last_upd_usr_id,
        load.create_dttm,
        load.last_upd_dttm,
        load.run_id,
        load.source_file_ts,
        load.last_upd_ts,
        load.SRC_DE_UNIQ_ID_TEXT,
        load.DP_VALUE,
        load.COLLECTION_DENOM,
        COALESCE(sched.schedules, ARRAY()) AS schedule_entry,
        COALESCE(comm.comments, ARRAY()) AS comment_entry,
        org.org_sector,
        org.org_core_org_id,
        org.ORG_PRIMARY_NAME,
        org.org_state,
        org.org_country_code,
        org.org_currency_code,
        org.DEAL_NAME_DESCRIPTOR,
        org.FIN_REVENUE_TYPE,
        org.FIN_REVENUE_SUBTYPE,
        org.FYE,
        map.ENT_MNEM_CD AS mapped_mnemonic,
        COALESCE(pre.priority_ordr_num, 9999) AS priority_ordr_num
    FROM ${source_table} AS load
    LEFT JOIN pf_schedules AS sched
        ON sched.PHOENIX_ID = load.PHOENIX_ID
       AND sched.REPORT_ID = load.REPORT_ID
       AND sched.SRC_DE_UNIQ_ID_TEXT = load.SRC_DE_UNIQ_ID_TEXT
    LEFT JOIN pf_comments AS comm
        ON comm.PHOENIX_ID = load.PHOENIX_ID
       AND comm.REPORT_ID = load.REPORT_ID
       AND comm.SRC_DE_UNIQ_ID_TEXT = load.SRC_DE_UNIQ_ID_TEXT
    LEFT JOIN idf_${env}.finmaster.t_dim_source_data_element map
        ON map.UNIQUE_MNEMONIC_TEXT = load.SRC_DE_UNIQ_ID_TEXT
    LEFT JOIN pf_org_latest_filtered AS org
        ON org.PHOENIX_ID = load.PHOENIX_ID
    LEFT JOIN idf_raw_${env}.uspf.t_dc_statement_basis_precedence pre
        ON load.SECTOR_NAME = pre.TEMPLT_SECTOR_NAME
       AND load.STATEMENT_BASIS_NAME = pre.SCENARIO_NAME
)
SELECT
    PHOENIX_ID,
    PHOENIX_PLAN_ID,
    SECTOR_NAME,
    CORE_ORG_ID,
    PER_TYPE_NAME,
    measure_date_og,
    PERIOD_END_DATE_og,
    measure_date,
    period_end_date,
    PERIOD_MONTHS,
    STATEMENT_BASIS_NAME,
    ACCOUNT_BASIS_NAME,
    APR_ACCEPTABLE,
    SOURCE_FILE_CREATE_DATE,
    REPORT_ID,
    DELETE_FLAG,
    ACTION,
    actv_ind,
    create_usr_id,
    last_upd_usr_id,
    MAX(create_dttm) AS create_dttm,
    MAX(last_upd_dttm) AS last_upd_dttm,
    MAX(run_id) AS run_id,
    MAX(source_file_ts) AS source_file_ts,
    MAX(last_upd_ts) AS last_upd_ts,
    org_sector,
    org_core_org_id,
    ORG_PRIMARY_NAME,
    org_state,
    org_country_code,
    org_currency_code,
    DEAL_NAME_DESCRIPTOR,
    FIN_REVENUE_TYPE,
    FIN_REVENUE_SUBTYPE,
    FYE,
    FIRST(priority_ordr_num, true) AS priority_ordr_num,
    MAP_FROM_ENTRIES(
        FILTER(
            COLLECT_LIST(
                STRUCT(
                    mapped_mnemonic AS key,
                    NAMED_STRUCT(
                        'dp_value', DP_VALUE,
                        'collection_denom', COLLECTION_DENOM,
                        'schedules', schedule_entry,
                        'comments', comment_entry
                    ) AS value
                )
            ),
            entry -> entry.key IS NOT NULL
        )
    ) AS src_de_dp_map
FROM enriched
GROUP BY
    PHOENIX_ID, PHOENIX_PLAN_ID, SECTOR_NAME, CORE_ORG_ID, PER_TYPE_NAME,
    measure_date_og, PERIOD_END_DATE_og, measure_date, period_end_date,
    PERIOD_MONTHS, STATEMENT_BASIS_NAME, ACCOUNT_BASIS_NAME, APR_ACCEPTABLE,
    SOURCE_FILE_CREATE_DATE, REPORT_ID, DELETE_FLAG, ACTION,
    actv_ind, create_usr_id, last_upd_usr_id,
    org_sector, org_core_org_id, ORG_PRIMARY_NAME, org_state,
    org_country_code, org_currency_code, DEAL_NAME_DESCRIPTOR,
    FIN_REVENUE_TYPE, FIN_REVENUE_SUBTYPE, FYE

