WITH current_run AS (
    SELECT
        base.*,
        ROW_NUMBER() OVER (
            PARTITION BY base.PHOENIX_ID,
                         base.period_end_date
            ORDER BY COALESCE(base.priority_ordr_num, 9999) ASC,
                     base.processing_timestamp DESC,
                     base.REPORT_ID ASC
        ) AS rn
    FROM ${source_table} AS base
    WHERE base.run_id = CAST(${pipeline_run_id} AS BIGINT)
      AND (
          COALESCE(base.delete_flag, 'N') = 'Y'
          OR base.is_current = 'Y'
      )
),
candidates AS (
    SELECT *
    FROM current_run
    WHERE rn = 1
),
history AS (
    SELECT
        hist.*,
        COALESCE(hist.priority_ordr_num, 9999) AS history_priority,
        ROW_NUMBER() OVER (
            PARTITION BY hist.PHOENIX_ID,
                         hist.period_end_date
            ORDER BY COALESCE(hist.priority_ordr_num, 9999) ASC,
                     hist.effective_start_dttm DESC,
                     hist.processing_timestamp DESC,
                     hist.REPORT_ID ASC
        ) AS rn
    FROM ${source_table} AS hist
    WHERE (hist.run_id IS NULL OR hist.run_id <> CAST(${pipeline_run_id} AS BIGINT))
      AND COALESCE(hist.actv_ind, 'Y') = 'Y'
      AND hist.effective_end_dttm IS NULL
),
history_best AS (
    SELECT *
    FROM history
    WHERE rn = 1
)
SELECT
    cand.*,
    CASE
        WHEN COALESCE(cand.delete_flag, 'N') = 'Y' THEN 'delete'
        WHEN hist.REPORT_ID IS NULL THEN 'create'
        WHEN hist.REPORT_ID <> cand.REPORT_ID THEN 'replace'
        ELSE 'update'
    END AS precedence_action,
    hist.REPORT_ID AS previous_vendor_report_id
FROM candidates cand
LEFT JOIN history_best hist
  ON hist.PHOENIX_ID = cand.PHOENIX_ID
 AND hist.period_end_date = cand.period_end_date
WHERE
    (
        COALESCE(cand.delete_flag, 'N') = 'Y'
        AND hist.REPORT_ID IS NOT NULL
    )
    OR
    (
        COALESCE(cand.delete_flag, 'N') <> 'Y'
        AND (
            hist.REPORT_ID IS NULL
            OR COALESCE(cand.priority_ordr_num, 9999) <= hist.history_priority
        )
    );
