SELECT
    *
FROM ${source_table}
WHERE rn = 1
