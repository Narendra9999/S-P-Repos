WITH candidate_raw AS (
    SELECT
        PHOENIX_ID,
        PHOENIX_PLAN_ID,
        SECTOR_NAME,
        CORE_ORG_ID,
        PER_TYPE_NAME,
        measure_date_og,
        PERIOD_END_DATE_og,
        measure_date,
        period_end_date,
        PERIOD_MONTHS,
        STATEMENT_BASIS_NAME,
        ACCOUNT_BASIS_NAME,
        APR_ACCEPTABLE,
        SOURCE_FILE_CREATE_DATE,
        REPORT_ID,
        DELETE_FLAG,
        ACTION,
        actv_ind,
        create_usr_id,
        last_upd_usr_id,
        create_dttm,
        last_upd_dttm,
        run_id,
        record_hash,
        source_file_ts,
        last_upd_ts,
        org_state,
        org_country_code,
        org_currency_code,
        ORG_PRIMARY_NAME,
        src_de_dp_map,
        processing_timestamp,
        precedence_action,
        previous_vendor_report_id
    FROM ${source_table}
),
candidate_ranked AS (
    SELECT
        *,
        ROW_NUMBER() OVER (
            PARTITION BY 
                PHOENIX_ID,
                period_end_date,
                STATEMENT_BASIS_NAME,
                REPORT_ID
            ORDER BY 
                processing_timestamp DESC,
                run_id DESC
        ) AS rn
    FROM candidate_raw
),
candidate AS (
    SELECT 
        PHOENIX_ID,
        PHOENIX_PLAN_ID,
        SECTOR_NAME,
        CORE_ORG_ID,
        PER_TYPE_NAME,
        measure_date_og,
        PERIOD_END_DATE_og,
        measure_date,
        period_end_date,
        PERIOD_MONTHS,
        STATEMENT_BASIS_NAME,
        ACCOUNT_BASIS_NAME,
        APR_ACCEPTABLE,
        SOURCE_FILE_CREATE_DATE,
        REPORT_ID,
        DELETE_FLAG,
        ACTION,
        actv_ind,
        create_usr_id,
        last_upd_usr_id,
        create_dttm,
        last_upd_dttm,
        run_id,
        record_hash,
        source_file_ts,
        last_upd_ts,
        org_state,
        org_country_code,
        org_currency_code,
        ORG_PRIMARY_NAME,
        src_de_dp_map,
        processing_timestamp,
        precedence_action,
        previous_vendor_report_id
    FROM candidate_ranked
    WHERE rn = 1
),
sp_org_mapping AS (
    SELECT
        PHOENIX_ID,
        FIRST(SP_ORG_ID) AS sp_org_id
    FROM idf_raw_${env}.uspf.t_asid_org_linking
    WHERE SP_ORG_ID IS NOT NULL
    GROUP BY PHOENIX_ID
),
history AS (
    SELECT
        base.PHOENIX_ID,
        base.period_end_date,
        base.STATEMENT_BASIS_NAME,
        base.REPORT_ID,
        base.effective_start_dttm,
        base.last_upd_dttm,
        base.last_upd_usr_id,
        base.create_usr_id,
        base.src_de_dp_map
    FROM idf_curated_${env}.uspf.t_pf_base base
    INNER JOIN candidate cand
        ON base.PHOENIX_ID = cand.PHOENIX_ID
       AND base.period_end_date = cand.period_end_date
       AND base.STATEMENT_BASIS_NAME = cand.STATEMENT_BASIS_NAME
       AND base.REPORT_ID = cand.REPORT_ID
    WHERE base.is_current = 'N'
),
exploded_history AS (
    SELECT
        he.PHOENIX_ID,
        he.period_end_date,
        he.STATEMENT_BASIS_NAME,
        he.REPORT_ID,
        he.mnemonic_id,
        he.hist_dp_value,
        he.hist_collection_denom,
        he.hist_schedules,
        he.hist_comments,
        he.effective_start_dttm,
        he.last_upd_dttm,
        he.last_upd_usr_id,
        he.create_usr_id
    FROM (
        SELECT
            h.PHOENIX_ID,
            h.period_end_date,
            h.STATEMENT_BASIS_NAME,
            h.REPORT_ID,
            h.effective_start_dttm,
            h.last_upd_dttm,
            h.last_upd_usr_id,
            h.create_usr_id,
            kv.key AS mnemonic_id,

            kv.value.dp_value AS hist_dp_value,
            kv.value.collection_denom AS hist_collection_denom,
            kv.value.schedules AS hist_schedules,
            kv.value.comments AS hist_comments
        FROM history h
        LATERAL VIEW explode(map_entries(h.src_de_dp_map)) AS kv
    ) he
    WHERE he.mnemonic_id IS NOT NULL
),
history_trail AS (
    SELECT
        PHOENIX_ID,
        REPORT_ID,
        period_end_date,
        STATEMENT_BASIS_NAME,
        mnemonic_id,
        array_sort(
            collect_list(
                named_struct(
                    'valueAsOf',
                        date_format(
                            coalesce(last_upd_dttm, effective_start_dttm),
                            "yyyy-MM-dd'T'HH:mm:ss"
                        ),
                    'valueUpdatedBy',
                        coalesce(last_upd_usr_id, create_usr_id, 'system'),
                    'value',
                        CAST(hist_dp_value AS STRING),
                    'schedule',
                        transform(
                            coalesce(hist_schedules, array()),
                            s -> named_struct(
                                'schedVal', CAST(s.schedule_value AS STRING),
                                'schedCode', s.schedule_name,
                                'scheduleFormula', coalesce(s.formula_text, '')
                            )
                        ),
                    'comment',
                        transform(
                            coalesce(hist_comments, array()),
                            c -> named_struct(
                                'commentText', c.comment_text,
                                'commentAsOf', date_format(c.comment_timestamp, "yyyy-MM-dd'T'HH:mm:ss"),
                                'commentUser', c.comment_by
                            )
                        )
                )
            ),
            (left, right) ->
                CASE
                    WHEN left.valueAsOf > right.valueAsOf THEN -1
                    WHEN left.valueAsOf < right.valueAsOf THEN 1
                    ELSE 0
                END
        ) AS value_trail
    FROM exploded_history
    GROUP BY
        PHOENIX_ID,
        REPORT_ID,
        period_end_date,
        STATEMENT_BASIS_NAME,
        mnemonic_id
),
current_exploded AS (
    SELECT
        ce.PHOENIX_ID,
        ce.PHOENIX_PLAN_ID,
        ce.SECTOR_NAME,
        ce.CORE_ORG_ID,
        ce.PER_TYPE_NAME,
        ce.measure_date_og,
        ce.PERIOD_END_DATE_og,
        ce.measure_date,
        ce.period_end_date,
        ce.PERIOD_MONTHS,
        ce.STATEMENT_BASIS_NAME,
        ce.ACCOUNT_BASIS_NAME,
        ce.APR_ACCEPTABLE,
        ce.SOURCE_FILE_CREATE_DATE,
        ce.REPORT_ID,
        ce.DELETE_FLAG,
        ce.ACTION,
        ce.actv_ind,
        ce.create_usr_id,
        ce.last_upd_usr_id,
        ce.create_dttm,
        ce.last_upd_dttm,
        ce.run_id,
        ce.record_hash,
        ce.source_file_ts,
        ce.last_upd_ts,
        ce.org_state,
        ce.org_country_code,
        ce.org_currency_code,
        ce.ORG_PRIMARY_NAME,
        ce.mnemonic_id,
        ce.current_dp_value,
        ce.current_collection_denom,
        ce.current_schedules,
        ce.current_comments
    FROM (
        SELECT
            cand.*,
            kv.key AS mnemonic_id,

            kv.value.dp_value AS current_dp_value,
            kv.value.collection_denom AS current_collection_denom,
            kv.value.schedules AS current_schedules,
            kv.value.comments AS current_comments
        FROM candidate cand
        LATERAL VIEW explode(map_entries(cand.src_de_dp_map)) AS kv
    ) ce
    WHERE ce.mnemonic_id IS NOT NULL
),
current_enriched AS (
    SELECT
        curr.*,
        hist.value_trail,
        element_at(curr.current_comments, -1) AS latest_comment_struct,
        transform(
            coalesce(curr.current_schedules, array()),
            s -> named_struct(
                'schedVal', CAST(s.schedule_value AS STRING),
                'schedCode', s.schedule_name,
                'scheduleFormula', coalesce(s.formula_text, '')
            )
        ) AS current_schedule_structs,
        transform(
            coalesce(curr.current_comments, array()),
            c -> named_struct(
                'commentText', c.comment_text,
                'commentAsOf', date_format(c.comment_timestamp, "yyyy-MM-dd'T'HH:mm:ss"),
                'commentUser', c.comment_by
            )
        ) AS current_comment_entries
    FROM current_exploded curr
    LEFT JOIN history_trail hist
        ON hist.PHOENIX_ID = curr.PHOENIX_ID
       AND hist.period_end_date = curr.period_end_date
       AND hist.STATEMENT_BASIS_NAME = curr.STATEMENT_BASIS_NAME
       AND hist.REPORT_ID = curr.REPORT_ID
       AND hist.mnemonic_id = curr.mnemonic_id
),
current_with_trail AS (
    SELECT
        *,
        transform(
            coalesce(current_comments, array()),
            c -> named_struct(
                'curInd',
                CASE
                    WHEN latest_comment_struct IS NOT NULL
                         AND c.comment_timestamp = latest_comment_struct.comment_timestamp
                    THEN 'Y'
                    ELSE 'N'
                END,
                'delInd', 'N',
                'actvInd', 'Y',
                'commentText', c.comment_text,
                'commentByUserId', c.comment_by,
                'commentDateTime', date_format(c.comment_timestamp, "yyyy-MM-dd'T'HH:mm:ss")
            )
        ) AS current_comment_trail
    FROM current_enriched
),
pre_agg AS (
    SELECT
        PHOENIX_ID,
        REPORT_ID,
        period_end_date,
        STATEMENT_BASIS_NAME,
        mnemonic_id,
        current_collection_denom,
        value_trail,
        current_dp_value,
        current_schedule_structs,
        current_comment_entries,
        current_comment_trail,
        latest_comment_struct,
        first(last_upd_dttm, true) AS agg_last_upd_dttm,
        first(create_dttm, true) AS agg_create_dttm,
        first(last_upd_usr_id, true) AS agg_last_upd_usr_id,
        first(create_usr_id, true) AS agg_create_usr_id
    FROM current_with_trail
    GROUP BY
        PHOENIX_ID,
        REPORT_ID,
        period_end_date,
        STATEMENT_BASIS_NAME,
        mnemonic_id,
        current_collection_denom,
        value_trail,
        current_dp_value,
        current_schedule_structs,
        current_comment_entries,
        current_comment_trail,
        latest_comment_struct
),
fin_data_points AS (
    SELECT
        PHOENIX_ID,
        REPORT_ID,
        period_end_date,
        STATEMENT_BASIS_NAME,
        array_sort(
            collect_list(
                named_struct(
                    'dataType', 'Number',
                    'mnemonic', mnemonic_id,


                    'unitType', 'Actual',
                    'magnitude', coalesce(current_collection_denom, 'ABS'),
                    'valueTrail',
                        CASE
                            WHEN value_trail IS NOT NULL AND size(value_trail) > 0 THEN value_trail
                            ELSE array(
                                named_struct(
                                    'valueAsOf',
                                        date_format(
                                            coalesce(agg_last_upd_dttm, agg_create_dttm, current_timestamp()),
                                            "yyyy-MM-dd'T'HH:mm:ss"
                                        ),
                                    'valueUpdatedBy',
                                        coalesce(agg_last_upd_usr_id, agg_create_usr_id, 'system'),
                                    'value',
                                        CAST(current_dp_value AS STRING),
                                    'schedule',
                                        current_schedule_structs,
                                    'comment',
                                        current_comment_entries
                                )
                            )
                        END,
                    'commentTrail', current_comment_trail,
                    'currentValue', CAST(current_dp_value AS STRING),

                    'currentComment',
                        CASE
                            WHEN latest_comment_struct IS NOT NULL
                                THEN latest_comment_struct.comment_text
                            ELSE NULL
                        END,
                    'currentSchedule',
                        current_schedule_structs,
                    'currentCommentAsOf',
                        CASE
                            WHEN latest_comment_struct IS NOT NULL
                                THEN date_format(latest_comment_struct.comment_timestamp, "yyyy-MM-dd'T'HH:mm:ss")
                            ELSE NULL
                        END,
                    'currentCommentUser',
                        CASE
                            WHEN latest_comment_struct IS NOT NULL
                                THEN latest_comment_struct.comment_by
                            ELSE NULL
                        END
                )
            ),
            (left, right) ->
                CASE
                    WHEN left.mnemonic < right.mnemonic THEN -1
                    WHEN left.mnemonic > right.mnemonic THEN 1
                    ELSE 0
                END
        ) AS fin_data_points
    FROM pre_agg
    GROUP BY
        PHOENIX_ID,
        REPORT_ID,
        period_end_date,
        STATEMENT_BASIS_NAME
),
linked_asids AS (
    SELECT
        PHOENIX_ID,
        collect_list(DISTINCT ASID) AS asid_list
    FROM idf_raw_${env}.uspf.t_asid_org_linking
    WHERE ASID IS NOT NULL
    GROUP BY PHOENIX_ID
),
dataset_enriched AS (
    SELECT
        cand.*,
        sp_map.sp_org_id AS sp_org_id,
        coalesce(
            fd.fin_data_points,
            CAST(
                array() AS array<
                    struct<
                        dataType:string,
                        mnemonic:string,
                        unitType:string,
                        magnitude:string,
                        valueTrail:array<
                            struct<
                                valueAsOf:string,
                                valueUpdatedBy:string,
                                value:string,
                                schedule:array<struct<schedVal:string,schedCode:string,scheduleFormula:string>>,
                                comment:array<struct<commentText:string,commentAsOf:string,commentUser:string>>
                            >
                        >,
                        commentTrail:array<struct<curInd:string,delInd:string,actvInd:string,commentText:string,commentByUserId:string,commentDateTime:string>>,
                        currentValue:string,
                        currentComment:string,
                        currentSchedule:array<struct<schedVal:string,schedCode:string,scheduleFormula:string>>,
                        currentCommentAsOf:string,
                        currentCommentUser:string
                    >
                >
            )
        ) AS fin_data_points_arr,
        named_struct(
            'city', CAST(NULL AS STRING),
            'state', cand.org_state,
            'CCY_CD', cand.org_currency_code,
            'county', CAST(NULL AS STRING),
            'finOrg', cand.PHOENIX_ID,
            'fipsCd', CAST(NULL AS STRING),
            'countryCd', CAST('USA' AS STRING),
            'finOrgName', cand.ORG_PRIMARY_NAME,
            'sectorName', cand.SECTOR_NAME,
            'vendorName', 'Mydata',
            'linkedAsids', COALESCE(asids.asid_list, ARRAY()),
            'finDatasetId', '',
            'aprAcceptable', cand.APR_ACCEPTABLE,
            'finDataPoints', fd.fin_data_points,
            'periodEndDate', date_format(cand.period_end_date, 'MM-dd-yyyy'),
            'vendorReportId', CAST(cand.REPORT_ID AS STRING),
            'financialPeriod', named_struct(
                'scenario', cand.STATEMENT_BASIS_NAME,
                'periodName', cand.PER_TYPE_NAME,
                'periodType', cand.PER_TYPE_NAME,
                'stmntBasis', cand.STATEMENT_BASIS_NAME,
                'irregularFlag', false,
                'periodEndDate', date_format(cand.period_end_date, 'MM-dd-yyyy'),
                'accountingBasis', cand.ACCOUNT_BASIS_NAME
            )
        ) AS dataset_struct
    FROM candidate cand
    LEFT JOIN fin_data_points fd
        ON fd.PHOENIX_ID = cand.PHOENIX_ID
       AND fd.REPORT_ID = cand.REPORT_ID
       AND fd.period_end_date = cand.period_end_date
       AND fd.STATEMENT_BASIS_NAME = cand.STATEMENT_BASIS_NAME
    LEFT JOIN linked_asids asids
        ON asids.PHOENIX_ID = cand.PHOENIX_ID
    LEFT JOIN sp_org_mapping sp_map
        ON sp_map.PHOENIX_ID = cand.PHOENIX_ID
),
final AS (
    SELECT
        dataset_enriched.*,
        to_json(dataset_struct) AS dataset_json
    FROM dataset_enriched
),
final_with_hash AS (
    SELECT
        PHOENIX_ID,
        PHOENIX_PLAN_ID,
        SECTOR_NAME,
        CORE_ORG_ID,
        PER_TYPE_NAME,
        measure_date_og,
        PERIOD_END_DATE_og,
        measure_date,
        period_end_date,
        PERIOD_MONTHS,
        STATEMENT_BASIS_NAME,
        ACCOUNT_BASIS_NAME,
        APR_ACCEPTABLE,
        SOURCE_FILE_CREATE_DATE,
        REPORT_ID,
        DELETE_FLAG,
        ACTION,
        actv_ind,
        create_usr_id,
        last_upd_usr_id,
        create_dttm,
        last_upd_dttm,
        run_id,
        record_hash,
        source_file_ts,
        last_upd_ts,
        org_state,
        org_country_code,
        org_currency_code,
        ORG_PRIMARY_NAME,
        src_de_dp_map,
        fin_data_points_arr,
        dataset_struct,
        dataset_json,
        sp_org_id,
        precedence_action,
        previous_vendor_report_id,
        processing_timestamp,
        sha2(dataset_json, 256) AS dataset_hash,
        ROW_NUMBER() OVER (
            PARTITION BY 
                PHOENIX_ID,
                period_end_date,
                STATEMENT_BASIS_NAME,
                REPORT_ID
            ORDER BY 
                processing_timestamp DESC,
                run_id DESC
        ) AS dedup_rn
    FROM final
)
SELECT
    PHOENIX_ID,
    PHOENIX_PLAN_ID,
    SECTOR_NAME,
    CORE_ORG_ID,
    PER_TYPE_NAME,
    measure_date_og,
    PERIOD_END_DATE_og,
    measure_date,
    period_end_date,
    PERIOD_MONTHS,
    STATEMENT_BASIS_NAME,
    ACCOUNT_BASIS_NAME,
    APR_ACCEPTABLE,
    SOURCE_FILE_CREATE_DATE,
    REPORT_ID,
    DELETE_FLAG,
    ACTION,
    actv_ind,
    create_usr_id,
    last_upd_usr_id,
    create_dttm,
    last_upd_dttm,
    run_id,
    record_hash,
    source_file_ts,
    last_upd_ts,
    org_state,
    org_country_code,
    org_currency_code,
    ORG_PRIMARY_NAME,
    src_de_dp_map,
    fin_data_points_arr,
    dataset_struct,
    dataset_json,
    dataset_hash,
    sp_org_id,
    precedence_action,
    previous_vendor_report_id
FROM final_with_hash
WHERE dedup_rn = 1;
