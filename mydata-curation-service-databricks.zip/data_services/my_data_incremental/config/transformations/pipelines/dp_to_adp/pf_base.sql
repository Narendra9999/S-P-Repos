WITH enriched AS (
    SELECT
        base.PHOENIX_ID,
        base.PHOENIX_PLAN_ID,
        base.SECTOR_NAME,
        base.CORE_ORG_ID,
        base.PER_TYPE_NAME,
        base.measure_date_og,
        base.PERIOD_END_DATE_og,
        base.measure_date,
        base.period_end_date,
        base.PERIOD_MONTHS,
        base.STATEMENT_BASIS_NAME,
        base.ACCOUNT_BASIS_NAME,
        base.APR_ACCEPTABLE,
        base.SOURCE_FILE_CREATE_DATE,
        base.REPORT_ID,
        base.priority_ordr_num,
        base.ACTION,
        base.source_file_ts,
        base.last_upd_ts,
        COALESCE(base.create_usr_id, CURRENT_USER()) AS create_usr_id,
        COALESCE(base.last_upd_usr_id, CURRENT_USER()) AS last_upd_usr_id,
        COALESCE(base.create_dttm, CURRENT_TIMESTAMP()) AS create_dttm,
        COALESCE(base.last_upd_dttm, CURRENT_TIMESTAMP()) AS last_upd_dttm,
        COALESCE(base.run_id, 0) AS run_id,
        base.src_de_dp_map,
        base.org_sector,
        base.org_core_org_id,
        base.ORG_PRIMARY_NAME,
        base.org_state,
        base.org_country_code,
        base.org_currency_code,
        base.DEAL_NAME_DESCRIPTOR,
        base.FIN_REVENUE_TYPE,
        base.FIN_REVENUE_SUBTYPE,
        base.FYE,
        COALESCE(base.DELETE_FLAG, 'N') AS delete_flag,
        COALESCE(base.actv_ind, 'Y') AS actv_ind,
        SHA2(TO_JSON(base.src_de_dp_map), 256) AS dp_map_hash,
        SHA2(
            TO_JSON(
                TRANSFORM(
                    MAP_VALUES(base.src_de_dp_map),
                    x -> x.schedules
                )
            ),
            256
        ) AS schedule_hash,
        SHA2(
            TO_JSON(
                TRANSFORM(
                    MAP_VALUES(base.src_de_dp_map),
                    x -> x.comments
                )
            ),
            256
        ) AS comment_hash,
        SHA2(
            TO_JSON(
                NAMED_STRUCT(
                    'org_sector', base.org_sector,
                    'org_core_org_id', base.org_core_org_id,
                    'org_primary_name', base.ORG_PRIMARY_NAME,
                    'org_state', base.org_state,
                    'org_country_code', base.org_country_code,
                    'org_currency_code', base.org_currency_code,
                    'deal_name_descriptor', base.DEAL_NAME_DESCRIPTOR,
                    'fin_revenue_type', base.FIN_REVENUE_TYPE,
                    'fin_revenue_subtype', base.FIN_REVENUE_SUBTYPE,
                    'fye', base.FYE
                )
            ),
            256
        ) AS org_hash
    FROM ${source_table} AS base
)
SELECT
    enriched.PHOENIX_ID,
    enriched.PHOENIX_PLAN_ID,
    enriched.SECTOR_NAME,
    enriched.CORE_ORG_ID,
    enriched.PER_TYPE_NAME,
    enriched.measure_date_og,
    enriched.PERIOD_END_DATE_og,
    enriched.measure_date,
    enriched.period_end_date,
    enriched.PERIOD_MONTHS,
    enriched.STATEMENT_BASIS_NAME,
    enriched.ACCOUNT_BASIS_NAME,
    enriched.APR_ACCEPTABLE,
    enriched.SOURCE_FILE_CREATE_DATE,
    enriched.REPORT_ID,
    enriched.priority_ordr_num,
    enriched.ACTION,
    enriched.source_file_ts,
    enriched.last_upd_ts,
    enriched.create_usr_id,
    enriched.last_upd_usr_id,
    enriched.create_dttm,
    enriched.last_upd_dttm,
    enriched.run_id,
    enriched.src_de_dp_map,
    enriched.org_sector,
    enriched.org_core_org_id,
    enriched.ORG_PRIMARY_NAME,
    enriched.org_state,
    enriched.org_country_code,
    enriched.org_currency_code,
    enriched.DEAL_NAME_DESCRIPTOR,
    enriched.FIN_REVENUE_TYPE,
    enriched.FIN_REVENUE_SUBTYPE,
    enriched.FYE,
    enriched.delete_flag,
    enriched.actv_ind,
    enriched.dp_map_hash,
    enriched.schedule_hash,
    enriched.comment_hash,
    enriched.org_hash,
    SHA2(
        TO_JSON(
            NAMED_STRUCT(
                'PHOENIX_ID', enriched.PHOENIX_ID,
                'PHOENIX_PLAN_ID', enriched.PHOENIX_PLAN_ID,
                'SECTOR_NAME', enriched.SECTOR_NAME,
                'CORE_ORG_ID', enriched.CORE_ORG_ID,
                'PER_TYPE_NAME', enriched.PER_TYPE_NAME,
                'measure_date_og', enriched.measure_date_og,
                'PERIOD_END_DATE_og', enriched.PERIOD_END_DATE_og,
                'measure_date', enriched.measure_date,
                'period_end_date', enriched.period_end_date,
                'PERIOD_MONTHS', enriched.PERIOD_MONTHS,
                'STATEMENT_BASIS_NAME', enriched.STATEMENT_BASIS_NAME,
                'ACCOUNT_BASIS_NAME', enriched.ACCOUNT_BASIS_NAME,
                'APR_ACCEPTABLE', enriched.APR_ACCEPTABLE,
                'SOURCE_FILE_CREATE_DATE', enriched.SOURCE_FILE_CREATE_DATE,
                'REPORT_ID', enriched.REPORT_ID,
                'priority_ordr_num', enriched.priority_ordr_num,
                'ACTION', enriched.ACTION,
                'source_file_ts', enriched.source_file_ts,
                'src_de_dp_map', enriched.src_de_dp_map,
                'org_sector', enriched.org_sector,
                'org_core_org_id', enriched.org_core_org_id,
                'ORG_PRIMARY_NAME', enriched.ORG_PRIMARY_NAME,
                'org_state', enriched.org_state,
                'org_country_code', enriched.org_country_code,
                'org_currency_code', enriched.org_currency_code,
                'DEAL_NAME_DESCRIPTOR', enriched.DEAL_NAME_DESCRIPTOR,
                'FIN_REVENUE_TYPE', enriched.FIN_REVENUE_TYPE,
                'FIN_REVENUE_SUBTYPE', enriched.FIN_REVENUE_SUBTYPE,
                'FYE', enriched.FYE,
                'delete_flag', enriched.delete_flag,
                'actv_ind', enriched.actv_ind,
                'dp_map_hash', enriched.dp_map_hash,
                'schedule_hash', enriched.schedule_hash,
                'comment_hash', enriched.comment_hash,
                'org_hash', enriched.org_hash
            )
        ),
        256
    ) AS record_hash,
    CURRENT_TIMESTAMP() AS processing_timestamp,
    CURRENT_TIMESTAMP() AS effective_start_dttm,
    CAST(NULL AS TIMESTAMP) AS effective_end_dttm,
    'Y' AS is_current
FROM enriched

