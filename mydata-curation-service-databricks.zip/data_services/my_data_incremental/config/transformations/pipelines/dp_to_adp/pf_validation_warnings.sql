-- Log validation warnings for date parsing failures and other data quality issues
WITH date_parse_failures AS (
    SELECT
        PHOENIX_ID,
        REPORT_ID,
        SECTOR_NAME,
        STATEMENT_BASIS_NAME,
        'INVALID_PERIOD_END_DATE' AS warning_type,
        CONCAT('Invalid date format: PERIOD_END_DATE=', PERIOD_END_DATE, ' - failed all parsing attempts') AS warning_message,
        PERIOD_END_DATE AS invalid_value,
        CURRENT_TIMESTAMP() AS warning_timestamp,
        run_id
    FROM idf_curated_${env}.uspf.t_dp_transaction_dp_load
    WHERE period_end_date IS NULL 
      AND PERIOD_END_DATE IS NOT NULL
      AND TRIM(PERIOD_END_DATE) != ''
      AND run_id = CAST(${pipeline_run_id} AS BIGINT)

    UNION ALL

    SELECT
        PHOENIX_ID,
        REPORT_ID,
        SECTOR_NAME,
        STATEMENT_BASIS_NAME,
        'INVALID_MEASURE_DATE' AS warning_type,
        CONCAT('Invalid date format: MEASURE_DATE=', MEASURE_DATE, ' - failed all parsing attempts') AS warning_message,
        MEASURE_DATE AS invalid_value,
        CURRENT_TIMESTAMP() AS warning_timestamp,
        run_id
    FROM idf_curated_${env}.uspf.t_dp_transaction_dp_load
    WHERE measure_date IS NULL 
      AND MEASURE_DATE IS NOT NULL
      AND TRIM(MEASURE_DATE) != ''
      AND run_id = CAST(${pipeline_run_id} AS BIGINT)
),
missing_mnemonics AS (
    SELECT
        load.PHOENIX_ID,
        load.REPORT_ID,
        load.SECTOR_NAME,
        load.STATEMENT_BASIS_NAME,
        'MISSING_MNEMONIC_MAPPING' AS warning_type,
        CONCAT('No mnemonic mapping found for SRC_DE_UNIQ_ID_TEXT=', load.SRC_DE_UNIQ_ID_TEXT) AS warning_message,
        load.SRC_DE_UNIQ_ID_TEXT AS invalid_value,
        CURRENT_TIMESTAMP() AS warning_timestamp,
        load.run_id
    FROM idf_curated_${env}.uspf.t_dp_transaction_dp_load load
    LEFT JOIN idf_${env}.finmaster.t_dim_source_data_element map
        ON map.UNIQUE_MNEMONIC_TEXT = load.SRC_DE_UNIQ_ID_TEXT
    WHERE load.run_id = CAST(${pipeline_run_id} AS BIGINT)
      AND load.actv_ind = 'Y'
      AND map.UNIQUE_MNEMONIC_TEXT IS NULL
)
SELECT
    PHOENIX_ID,
    REPORT_ID,
    SECTOR_NAME,
    STATEMENT_BASIS_NAME,
    warning_type,
    warning_message,
    invalid_value,
    warning_timestamp,
    run_id
FROM date_parse_failures

UNION ALL

SELECT
    PHOENIX_ID,
    REPORT_ID,
    SECTOR_NAME,
    STATEMENT_BASIS_NAME,
    warning_type,
    warning_message,
    invalid_value,
    warning_timestamp,
    run_id
FROM missing_mnemonics
