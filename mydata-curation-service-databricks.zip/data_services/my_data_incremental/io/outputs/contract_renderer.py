from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Dict, Iterable, Optional

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F
from pyspark.sql import types as T

from data_services.my_data_incremental.config.config_loader import Config
from data_services.my_data_incremental.transformation.utils import get_logger

logger = get_logger("io.outputs.contract_renderer")


@dataclass(frozen=True)
class ContractContext:
    pipeline_run_id: Optional[str]
    pipeline_timestamp: datetime

    @property
    def pipeline_timestamp_iso(self) -> str:
        return self.pipeline_timestamp.replace(tzinfo=timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")

    @property
    def pipeline_timestamp_str(self) -> str:
        return self.pipeline_timestamp.strftime("%Y-%m-%d %H:%M:%S")


class ContractRenderer:
    """
    Renders outbound payloads (Kafka/Postgres) from declarative contract specifications.
    """

    def __init__(self, env: str):
        self.env = env
        loader = Config(env=env)
        config = loader.loadConfig("output_contracts.json") or {}
        self.contracts: Dict[str, Dict[str, Any]] = config.get("contracts", {})
        if not self.contracts:
            logger.warning("No output contracts found in output_contracts.json")

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def render_kafka_payloads(
        self,
        dataframe: DataFrame,
        contract_id: str,
        output_config: Dict[str, Any],
        context: Dict[str, str],
    ) -> Iterable[str]:
        if dataframe is None or dataframe.isEmpty():
            return []

        contract = self._get_contract_section(contract_id, "kafka")
        ctx = self._build_context(context)

        groups = self._build_groups(dataframe, contract.get("group"), output_config, ctx)

        spark = dataframe.sparkSession
        base_df = spark.range(1).select(F.lit(1).alias("_anchor"))
        for group_df in groups.values():
            base_df = base_df.crossJoin(group_df)

        root_struct = self._build_struct(
            base_df,
            contract["root"],
            output_config,
            ctx,
            groups=groups,
        )

        payload_df = base_df.select(F.to_json(root_struct).alias("payload"))
        return (row.payload for row in payload_df.toLocalIterator())

    def render_postgres_frame(
        self,
        dataframe: DataFrame,
        contract_id: str,
        output_config: Dict[str, Any],
        context: Dict[str, str],
    ) -> DataFrame:
        if dataframe is None or dataframe.isEmpty():
            schema = self._infer_postgres_schema(contract_id)
            spark: SparkSession = dataframe.sparkSession if dataframe is not None else SparkSession.builder.getOrCreate()  # type: ignore[union-attr]
            return spark.createDataFrame([], schema)

        contract = self._get_contract_section(contract_id, "postgres")
        record_spec = contract["record"]
        ctx = self._build_context(context)

        columns = []
        for field_name, field_spec in record_spec.items():
            column = self._build_value(
                dataframe,
                field_spec,
                output_config,
                ctx,
                groups=None,
            ).alias(field_name)
            columns.append(column)

        return dataframe.select(*columns)

    # ------------------------------------------------------------------
    # Contract helpers
    # ------------------------------------------------------------------

    def _get_contract_section(self, contract_id: str, section: str) -> Dict[str, Any]:
        contract = self.contracts.get(contract_id)
        if contract is None:
            raise KeyError(f"Contract '{contract_id}' not defined in output_contracts.json")
        if section not in contract:
            raise KeyError(f"Contract '{contract_id}' is missing section '{section}'")
        return contract[section]

    def _build_context(self, runtime_ctx: Dict[str, str]) -> ContractContext:
        run_id = runtime_ctx.get("pipeline_run_id")
        if run_id:
            try:
                dt = datetime.strptime(run_id, "%Y%m%d%H%M%S")
                return ContractContext(pipeline_run_id=run_id, pipeline_timestamp=dt)
            except ValueError:
                logger.warning("Unable to parse pipeline_run_id '%s'; using current UTC time instead.", run_id)
        return ContractContext(pipeline_run_id=run_id, pipeline_timestamp=datetime.utcnow())

    # ------------------------------------------------------------------
    # Group construction
    # ------------------------------------------------------------------

    def _build_groups(
        self,
        dataframe: DataFrame,
        group_spec: Optional[Any],
        output_config: Dict[str, Any],
        ctx: ContractContext,
    ) -> Dict[str, DataFrame]:
        if not group_spec:
            return {}
        if isinstance(group_spec, list):
            specs = group_spec
        else:
            specs = [group_spec]

        groups: Dict[str, DataFrame] = {}
        for spec in specs:
            group_name = spec["name"]
            groups[group_name] = self._build_group_dataframe(dataframe, spec, output_config, ctx)
        return groups

    def _build_group_dataframe(
        self,
        dataframe: DataFrame,
        spec: Dict[str, Any],
        output_config: Dict[str, Any],
        ctx: ContractContext,
    ) -> DataFrame:
        group_by_map: Dict[str, Any] = spec.get("group_by", {})
        fields_map: Dict[str, Any] = spec.get("fields", {})

        working_df = dataframe
        for alias, expr_spec in group_by_map.items():
            working_df = working_df.withColumn(alias, self._build_value(working_df, expr_spec, output_config, ctx))

        group_columns = [F.col(alias) for alias in group_by_map.keys()]
        agg_expressions = []
        for alias, field_spec in fields_map.items():
            if isinstance(field_spec, dict) and "collect_list" in field_spec:
                struct_expr = self._build_struct(
                    working_df,
                    field_spec["collect_list"]["struct"],
                    output_config,
                    ctx,
                )
                agg_expressions.append(F.collect_list(struct_expr).alias(alias))
            else:
                value_column = self._build_value(working_df, field_spec, output_config, ctx)
                agg_expressions.append(F.first(value_column, ignorenulls=True).alias(alias))

        aggregated = working_df.groupBy(*group_columns).agg(*agg_expressions)

        struct_fields = [F.col(alias) for alias in group_by_map.keys()] + [
            F.col(alias) for alias in fields_map.keys()
        ]
        grouped_struct = aggregated.select(F.struct(*struct_fields).alias("group_struct"))
        group_name = spec["name"]
        return grouped_struct.agg(F.collect_list("group_struct").alias(group_name))

    # ------------------------------------------------------------------
    # Expression builders
    # ------------------------------------------------------------------

    def _build_struct(
        self,
        dataframe: DataFrame,
        spec: Dict[str, Any],
        output_config: Dict[str, Any],
        ctx: ContractContext,
        groups: Optional[Dict[str, DataFrame]] = None,
    ) -> F.Column:
        fields = []
        for field_name, field_spec in spec.items():
            column = self._build_value(
                dataframe,
                field_spec,
                output_config,
                ctx,
                groups=groups,
            ).alias(field_name)
            fields.append(column)
        return F.struct(*fields)

    def _build_value(
        self,
        dataframe: DataFrame,
        spec: Any,
        output_config: Dict[str, Any],
        ctx: ContractContext,
        groups: Optional[Dict[str, DataFrame]] = None,
    ) -> F.Column:
        if isinstance(spec, dict):
            if "literal" in spec:
                return self._lit_column(spec["literal"])
            if "config" in spec:
                value = output_config.get(spec["config"], spec.get("default"))
                if value is None:
                    return F.lit(None)
                if isinstance(value, list):
                    return F.array(*[self._lit_column(v) for v in value])
                return self._lit_column(value)
            if "context" in spec:
                context_value = self._resolve_context_value(spec["context"], ctx)
                if isinstance(context_value, datetime):
                    return F.lit(context_value.strftime("%Y-%m-%d %H:%M:%S")).cast("timestamp")
                return self._lit_column(context_value)
            if "literal_array" in spec:
                return F.array(*[self._lit_column(v) for v in spec["literal_array"]])
            if "array" in spec:
                array_items = [self._build_value(dataframe, item, output_config, ctx, groups) for item in spec["array"]]
                return F.array(*array_items)
            if "group_ref" in spec:
                ref = spec["group_ref"]
                if groups is None or ref not in groups:
                    raise KeyError(f"Group reference '{ref}' is not available in the current context.")
                return F.col(ref)
            if "json_struct" in spec:
                struct_expr = self._build_struct(dataframe, spec["json_struct"], output_config, ctx, groups)
                return F.to_json(struct_expr)
            if "expr" in spec:
                return F.expr(spec["expr"])
            # Fallback: treat dict as nested struct
            return self._build_struct(dataframe, spec, output_config, ctx, groups)

        if isinstance(spec, list):
            array_items = [self._build_value(dataframe, item, output_config, ctx, groups) for item in spec]
            return F.array(*array_items)

        if isinstance(spec, (int, float)):
            return F.lit(spec)

        if spec is None:
            return F.lit(None)

        # Default: treat string as SQL expression
        return F.expr(spec)

    def _lit_column(self, value: Any) -> F.Column:
        if value is None:
            return F.lit(None)
        if isinstance(value, datetime):
            return F.lit(value.strftime("%Y-%m-%d %H:%M:%S")).cast("timestamp")
        return F.lit(value)

    def _resolve_context_value(self, key: str, ctx: ContractContext) -> Any:
        if key == "pipeline_run_id":
            return ctx.pipeline_run_id
        if key == "pipeline_timestamp":
            return ctx.pipeline_timestamp
        if key == "pipeline_timestamp_iso":
            return ctx.pipeline_timestamp_iso
        if key == "pipeline_timestamp_str":
            return ctx.pipeline_timestamp_str
        raise KeyError(f"Unsupported context key '{key}' in contract specification.")

    def _infer_postgres_schema(self, contract_id: str) -> T.StructType:
        contract = self._get_contract_section(contract_id, "postgres")
        fields = []
        for field_name in contract["record"].keys():
            # Default to StringType; actual schema will be derived when data exists.
            fields.append(T.StructField(field_name, T.StringType(), True))
        return T.StructType(fields)
