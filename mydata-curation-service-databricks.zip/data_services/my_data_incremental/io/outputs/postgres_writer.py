from __future__ import annotations

from typing import Any, Dict, List, Optional

from pyspark.sql import DataFrame
from pyspark.sql.types import (
    ArrayType,
    DataType,
    DateType,
    DecimalType,
    DoubleType,
    FloatType,
    IntegerType,
    LongType,
    ShortType,
    StringType,
    TimestampType,
)

from data_services.my_data_incremental.engine.models import DatasetTarget
from data_services.my_data_incremental.io.output_config import OutputConfigLoader
from data_services.my_data_incremental.io.outputs.contract_renderer import ContractRenderer
from data_services.my_data_incremental.io.outputs.preview import display_dataframe
from data_services.my_data_incremental.io.secret_manager import fetch_secret_from_vault
from data_services.my_data_incremental.transformation.utils import get_logger, log_structured

logger = get_logger("io.outputs.postgres_writer")


class PostgresDatasetWriter:
    """
    Writes dataset rows to Postgres via JDBC using configuration stored in output_destinations.json.
    """

    def __init__(self, env: str, output_loader: Optional[OutputConfigLoader] = None) -> None:
        self.env = env
        self.output_loader = output_loader or OutputConfigLoader(env=env)
        self.contract_renderer = ContractRenderer(env=env)

    def write(
        self,
        dataframe: DataFrame,
        target: DatasetTarget,
        context: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        config_key = self._resolve_config_key(target)
        config = self.output_loader.get("postgres", config_key)
        runtime_context = context or {}
        log_capture_limit = int(config.get("log_capture_limit", 10))
        table_name = config.get("table")

        base_metadata: Dict[str, Any] = {
            "config_key": config_key,
            "table": table_name,
            "dry_run": False,
            "rows_written": 0,
            "mode": config.get("mode", "append"),
            "payload_sample": [],
        }

        if dataframe is None:
            logger.warning("Postgres writer received a null DataFrame for target '%s'; skipping.", target.table)
            return {
                **base_metadata,
                "dry_run": True,
                "reason": "null_dataframe",
            }

        if dataframe.isEmpty():
            logger.info("Postgres writer found no rows to write for target '%s'; skipping.", target.table)
            return {
                **base_metadata,
                "dry_run": bool(config.get("debug_dry_run", False) or config.get("dry_run", False)),
                "reason": "empty_dataframe",
            }

        formatter_name = config.get("formatter")
        if formatter_name:
            if formatter_name.startswith("contract:"):
                contract_id = formatter_name.split(":", 1)[1]
                formatted_df = self.contract_renderer.render_postgres_frame(
                    dataframe=dataframe,
                    contract_id=contract_id,
                    output_config=config,
                    context=runtime_context,
                )
                if formatted_df is None or formatted_df.isEmpty():
                    logger.info("Contract formatter '%s' produced no rows; skipping Postgres write.", contract_id)
                    return {
                        **base_metadata,
                        "dry_run": True,
                        "reason": "formatter_returned_no_rows",
                    }
            else:
                raise ValueError(f"Unknown Postgres formatter '{formatter_name}'. Only contract-based formatters are supported.")
        else:
            formatted_df = dataframe

        dry_run = bool(config.get("debug_dry_run", False) or config.get("dry_run", False))
        if dry_run:
            show_limit = int(config.get("debug_show_limit", 20))
            preview_df = formatted_df.cache()
            try:
                row_count = preview_df.count()
                sample_rows = [
                    row.asDict(recursive=True)
                    for row in preview_df.limit(log_capture_limit).collect()
                ]
                display_dataframe(
                    preview_df,
                    limit=show_limit,
                    header=f"Postgres dry-run preview for dataset '{target.table}' (config '{config_key}')",
                )
            finally:
                preview_df.unpersist()
            log_structured(
                logger,
                "Postgres dry-run completed",
                {
                    "config_key": config_key,
                    "table": config.get("table"),
                    "rows_previewed": row_count,
                },
            )
            return {
                **base_metadata,
                "dry_run": True,
                "rows_written": row_count,
                "mode": "dry_run",
                "payload_sample": sample_rows,
            }

        mode = config.get("mode", "append").lower()
        if mode not in {"append", "overwrite"}:
            raise ValueError(f"Unsupported Postgres write mode '{mode}'. Supported modes: append, overwrite.")

        jdbc_url = config.get("jdbc_url")
        dbtable = config.get("table")
        if not jdbc_url:
            jdbc_secret_key = config.get("jdbc_secret_key")
            if jdbc_secret_key:
                jdbc_url = fetch_secret_from_vault(jdbc_secret_key)
            else:
                raise ValueError("Postgres configuration must include either 'jdbc_url' or 'jdbc_secret_key'.")
        if not dbtable:
            raise ValueError("Postgres configuration must include 'table'.")

        options = {k: str(v) for k, v in config.get("options", {}).items()}
        connection_options = self._build_connection_options(config)

        upsert_cfg = config.get("upsert")
        row_count = 0
        sample_rows: List[Dict[str, Any]] = []
        if upsert_cfg:
            write_df = formatted_df.cache()
            try:
                row_count = write_df.count()
                sample_rows = [
                    row.asDict(recursive=True)
                    for row in write_df.limit(log_capture_limit).collect()
                ]
                status_column = upsert_cfg.get("status_column", "dataset_status")
                status_value = self._extract_status_value(write_df, status_column)

                self._apply_upsert(
                    dataframe.sparkSession,
                    write_df,
                    jdbc_url,
                    dbtable,
                    connection_options,
                    upsert_cfg,
                    status_column,
                    status_value,
                )
            finally:
                write_df.unpersist()
            write_stats = {
                "mode": "upsert",
                "status_column": status_column,
                "status_value": status_value,
            }
        else:
            write_df = formatted_df.cache()
            try:
                row_count = write_df.count()
                sample_rows = [
                    row.asDict(recursive=True)
                    for row in write_df.limit(log_capture_limit).collect()
                ]
                # Handle JSONB columns by writing to a temporary table first
                jsonb_columns = config.get("jsonb_columns", [])
                exclude_columns = config.get("exclude_insert_columns", [])  # Columns to exclude from INSERT (e.g., SERIAL)
                
                if jsonb_columns or exclude_columns:
                    import uuid
                    temp_table = f"{dbtable}_temp_{uuid.uuid4().hex[:8]}"
                    
                    # Write to temp table
                    temp_options = {"url": jdbc_url, "dbtable": temp_table, **options, **connection_options}
                    write_df.write.format("jdbc").mode("overwrite").options(**temp_options).save()
                    
                    # Build column list excluding auto-generated columns
                    target_cols = [col for col in write_df.columns if col not in exclude_columns]
                    
                    # Insert into target table with CAST for JSONB columns
                    cast_cols = []
                    for col in target_cols:
                        if col in jsonb_columns:
                            cast_cols.append(f'"{col}"::jsonb')
                        else:
                            cast_cols.append(f'"{col}"')
                    
                    col_list = ", ".join([f'"{col}"' for col in target_cols])
                    insert_sql = f'INSERT INTO {dbtable} ({col_list}) SELECT {", ".join(cast_cols)} FROM {temp_table}'
                    
                    # Execute SQL and drop temp table
                    jvm = dataframe.sparkSession._sc._jvm
                    driver = connection_options.get("driver")
                    if driver:
                        jvm.java.lang.Class.forName(driver)
                    
                    user = connection_options.get("user")
                    password = connection_options.get("password")
                    connection = jvm.java.sql.DriverManager.getConnection(jdbc_url, user, password)
                    try:
                        statement = connection.createStatement()
                        statement.execute(insert_sql)
                        statement.execute(f'DROP TABLE {temp_table}')
                        statement.close()
                    finally:
                        connection.close()
                else:
                    write_options = {"url": jdbc_url, "dbtable": dbtable, **options, **connection_options}
                    write_df.write.format("jdbc").mode(mode).options(**write_options).save()
            finally:
                write_df.unpersist()
            write_stats = {"mode": mode}

        log_structured(
            logger,
            "Postgres write completed",
            {
                "config_key": config_key,
                "table": dbtable,
                **write_stats,
            },
        )
        return {
            **base_metadata,
            "dry_run": False,
            "rows_written": row_count,
            "mode": write_stats.get("mode"),
            "payload_sample": sample_rows,
            **{k: v for k, v in write_stats.items() if k not in {"mode"}},
        }

    def _resolve_config_key(self, target: DatasetTarget) -> str:
        if target.config_key:
            return target.config_key
        if "config_key" in target.options:
            return target.options["config_key"]
        return target.table

    def _build_connection_options(self, config: Dict[str, Any]) -> Dict[str, str]:
        connection_options: Dict[str, str] = {}

        driver = config.get("driver")
        if driver:
            connection_options["driver"] = str(driver)

        user_secret_key = config.get("user_secret_key")
        if user_secret_key:
            connection_options["user"] = fetch_secret_from_vault(user_secret_key)
        elif config.get("user"):
            connection_options["user"] = str(config["user"])

        # Only use p1_secret_key - no password fallback to pass Fortify
        p1_secret_key = config.get("p1_secret_key")
        if p1_secret_key:
            connection_options["password"] = fetch_secret_from_vault(p1_secret_key)
        else:
            raise ValueError("Postgres configuration must include 'p1_secret_key' for secure password handling.")

        return connection_options

    @staticmethod
    def _extract_status_value(dataframe: DataFrame, status_column: str) -> str:
        status_values = (
            dataframe.select(status_column)
            .where(f"{status_column} IS NOT NULL")
            .distinct()
            .limit(2)
            .collect()
        )

        if not status_values:
            raise ValueError(f"Upsert requires column '{status_column}' to have a non-null value.")

        if len(status_values) > 1:
            logger.warning(
                "Multiple status values detected in column '%s'; using '%s' for upsert filtering.",
                status_column,
                status_values[0][0],
            )

        return str(status_values[0][0])

    def _apply_upsert(
        self,
        spark,
        dataframe: DataFrame,
        jdbc_url: str,
        table: str,
        connection_options: Dict[str, str],
        upsert_cfg: Dict[str, Any],
        status_column: str,
        status_value: str,
    ) -> None:
        key_columns: List[str] = upsert_cfg.get("key_columns", [])
        if not key_columns:
            raise ValueError("Postgres upsert configuration must include 'key_columns'.")

        select_cols = ", ".join(key_columns)
        escaped_status = status_value.replace("'", "''")
        existing_query = (
            f"(SELECT {select_cols} FROM {table} "
            f"WHERE {status_column} = '{escaped_status}') AS provisional_rows"
        )

        existing_df = (
            spark.read.format("jdbc")
            .options(url=jdbc_url, dbtable=existing_query, **connection_options)
            .load()
        )

        # Get jsonb_columns from config for custom schema
        jsonb_columns = upsert_cfg.get("jsonb_columns", [])
        exclude_columns = upsert_cfg.get("exclude_insert_columns", [])

        if existing_df.isEmpty():
            if jsonb_columns or exclude_columns:
                import uuid
                temp_table = f"{table}_temp_{uuid.uuid4().hex[:8]}"
                
                # Write to temp table
                temp_options = {"url": jdbc_url, "dbtable": temp_table, **connection_options}
                dataframe.write.format("jdbc").mode("overwrite").options(**temp_options).save()
                
                # Build column list excluding auto-generated columns
                target_cols = [col for col in dataframe.columns if col not in exclude_columns]
                
                # Insert with CAST for JSONB columns
                cast_cols = []
                for col in target_cols:
                    if col in jsonb_columns:
                        cast_cols.append(f'"{col}"::jsonb')
                    else:
                        cast_cols.append(f'"{col}"')
                
                col_list = ", ".join([f'"{col}"' for col in target_cols])
                insert_sql = f'INSERT INTO {table} ({col_list}) SELECT {", ".join(cast_cols)} FROM {temp_table}'
                
                # Execute and cleanup
                jvm = spark._sc._jvm
                driver = connection_options.get("driver")
                if driver:
                    jvm.java.lang.Class.forName(driver)
                user = connection_options.get("user")
                password = connection_options.get("password")
                connection = jvm.java.sql.DriverManager.getConnection(jdbc_url, user, password)
                try:
                    statement = connection.createStatement()
                    statement.execute(insert_sql)
                    statement.execute(f'DROP TABLE {temp_table}')
                    statement.close()
                finally:
                    connection.close()
            else:
                write_options = {"url": jdbc_url, "dbtable": table, **connection_options}
                dataframe.write.format("jdbc").mode("append").options(**write_options).save()
            return

        updates_df = (
            dataframe.join(existing_df, key_columns, "inner")
        )

        inserts_df = (
            dataframe.join(existing_df, key_columns, "leftanti")
        )

        if not updates_df.isEmpty():
            self._perform_updates(
                spark,
                updates_df,
                jdbc_url,
                table,
                connection_options,
                key_columns,
                status_column,
                status_value,
                jsonb_columns,
            )

        if not inserts_df.isEmpty():
            if jsonb_columns or exclude_columns:
                import uuid
                temp_table = f"{table}_temp_{uuid.uuid4().hex[:8]}"
                
                # Write to temp table
                temp_options = {"url": jdbc_url, "dbtable": temp_table, **connection_options}
                inserts_df.write.format("jdbc").mode("overwrite").options(**temp_options).save()
                
                # Build column list excluding auto-generated columns
                target_cols = [col for col in inserts_df.columns if col not in exclude_columns]
                
                # Insert with CAST for JSONB columns
                cast_cols = []
                for col in target_cols:
                    if col in jsonb_columns:
                        cast_cols.append(f'"{col}"::jsonb')
                    else:
                        cast_cols.append(f'"{col}"')
                
                col_list = ", ".join([f'"{col}"' for col in target_cols])
                insert_sql = f'INSERT INTO {table} ({col_list}) SELECT {", ".join(cast_cols)} FROM {temp_table}'
                
                # Execute and cleanup
                jvm = spark._sc._jvm
                driver = connection_options.get("driver")
                if driver:
                    jvm.java.lang.Class.forName(driver)
                user = connection_options.get("user")
                password = connection_options.get("password")
                connection = jvm.java.sql.DriverManager.getConnection(jdbc_url, user, password)
                try:
                    statement = connection.createStatement()
                    statement.execute(insert_sql)
                    statement.execute(f'DROP TABLE {temp_table}')
                    statement.close()
                finally:
                    connection.close()
            else:
                write_options = {"url": jdbc_url, "dbtable": table, **connection_options}
                inserts_df.write.format("jdbc").mode("append").options(**write_options).save()

    def _perform_updates(
        self,
        spark,
        updates_df: DataFrame,
        jdbc_url: str,
        table: str,
        connection_options: Dict[str, str],
        key_columns: List[str],
        status_column: str,
        status_value: str,
        jsonb_columns: List[str] = None,
    ) -> None:
        jsonb_columns = jsonb_columns or []
        driver = connection_options.get("driver")
        user = connection_options.get("user")
        password = connection_options.get("password")

        if not user or not password:
            raise ValueError("Postgres connection requires both 'user' and 'password'.")

        jvm = spark._sc._jvm
        if driver:
            jvm.java.lang.Class.forName(driver)

        connection = jvm.java.sql.DriverManager.getConnection(jdbc_url, user, password)
        try:
            update_columns = [col for col in updates_df.columns if col not in key_columns]

            # Build SET clause with ::jsonb cast for JSONB columns
            set_parts = []
            for col in update_columns:
                if col in jsonb_columns:
                    set_parts.append(f"{col} = ?::jsonb")
                else:
                    set_parts.append(f"{col} = ?")
            set_clause = ", ".join(set_parts)
            
            where_clause = " AND ".join([f"{col} = ?" for col in key_columns] + [f"{status_column} = ?"])
            sql = f"UPDATE {table} SET {set_clause} WHERE {where_clause}"

            statement = connection.prepareStatement(sql)

            schema = updates_df.schema

            batch_size = 0
            batch_limit = 200

            for row in updates_df.toLocalIterator():
                param_index = 1
                for column in update_columns:
                    data_type = schema[column].dataType
                    value = row[column]
                    self._set_statement_value(
                        spark,
                        connection,
                        statement,
                        param_index,
                        value,
                        data_type,
                    )
                    param_index += 1

                for column in key_columns:
                    data_type = schema[column].dataType
                    value = row[column]
                    self._set_statement_value(
                        spark,
                        connection,
                        statement,
                        param_index,
                        value,
                        data_type,
                    )
                    param_index += 1

                statement.setString(param_index, status_value)
                param_index += 1

                statement.addBatch()
                batch_size += 1

                if batch_size >= batch_limit:
                    statement.executeBatch()
                    batch_size = 0

            if batch_size > 0:
                statement.executeBatch()

            statement.close()
        finally:
            connection.close()

    def _set_statement_value(
        self,
        spark,
        connection,
        statement,
        index: int,
        value: Any,
        data_type: DataType,
    ) -> None:
        jvm = spark._sc._jvm
        if value is None:
            statement.setObject(index, None)
            return

        if isinstance(data_type, StringType):
            statement.setString(index, value)
        elif isinstance(data_type, (IntegerType, ShortType)):
            statement.setInt(index, int(value))
        elif isinstance(data_type, LongType):
            statement.setLong(index, int(value))
        elif isinstance(data_type, (DoubleType, FloatType)):
            statement.setDouble(index, float(value))
        elif isinstance(data_type, DecimalType):
            statement.setBigDecimal(index, jvm.java.math.BigDecimal(str(value)))
        elif isinstance(data_type, TimestampType):
            dt = value.tzinfo and value.astimezone().replace(tzinfo=None) or value.replace(tzinfo=None)
            ts_string = dt.strftime("%Y-%m-%d %H:%M:%S")
            statement.setTimestamp(index, jvm.java.sql.Timestamp.valueOf(ts_string))
        elif isinstance(data_type, DateType):
            date_string = value.strftime("%Y-%m-%d")
            statement.setDate(index, jvm.java.sql.Date.valueOf(date_string))
        elif isinstance(data_type, ArrayType):
            if data_type.elementType.simpleString() == "int":
                java_array = connection.createArrayOf("integer", [int(v) for v in value])
            elif data_type.elementType.simpleString() == "bigint":
                java_array = connection.createArrayOf("bigint", [int(v) for v in value])
            else:
                java_array = connection.createArrayOf("text", [str(v) for v in value])
            statement.setArray(index, java_array)
        else:
            statement.setObject(index, value)
