from __future__ import annotations

import json
from typing import Iterable, List, Optional

from pyspark.sql import DataFrame, SparkSession

from data_services.my_data_incremental.transformation.utils import get_logger

logger = get_logger("io.outputs.preview")


def _resolve_display():
    try:
        return display  # type: ignore[name-defined]
    except NameError:
        try:
            from IPython.display import display as ipy_display

            return ipy_display
        except Exception:
            return None


def display_dataframe(df: DataFrame, limit: Optional[int] = None, header: Optional[str] = None) -> None:
    subset = df.limit(limit) if limit else df
    display_fn = _resolve_display()

    if header:
        logger.info(header)

    if display_fn:
        try:
            display_fn(subset)
        except Exception as exc:  # noqa: BLE001
            logger.debug("Default display failed (%s); falling back to pandas.", exc)
            try:
                display_fn(subset.toPandas())
            except Exception as pandas_exc:  # noqa: BLE001
                logger.warning("Unable to display preview via IPython: %s", pandas_exc)
            else:
                _log_dataframe_rows(subset, limit)
                return
        else:
            _log_dataframe_rows(subset, limit)
            return

    _log_dataframe_rows(subset, limit)


def display_strings(
    spark: SparkSession,
    rows: Iterable[str],
    header: Optional[str] = None,
    limit: Optional[int] = None,
) -> None:
    data: List[str] = list(rows)
    display_fn = _resolve_display()

    if limit is not None:
        data = data[:limit]

    if header:
        logger.info(header)

    if display_fn and data:
        try:
            preview_df = spark.createDataFrame([(idx + 1, value) for idx, value in enumerate(data)], ["idx", "payload"])
            display_fn(preview_df)
        except Exception as exc:  # noqa: BLE001
            logger.warning("Unable to display preview DataFrame; falling back to stdout. Error: %s", exc)
        else:
            for value in data:
                logger.info("%s", _format_json_if_possible(value))
            return

    for value in data:
        logger.info("%s", _format_json_if_possible(value))


def _log_dataframe_rows(df: DataFrame, limit: Optional[int]) -> None:
    rows = df.limit(limit or 20).collect()
    for idx, row in enumerate(rows, start=1):
        payload = json.dumps(row.asDict(recursive=True), indent=2, default=str)
        logger.info("[%s]\n%s", idx, payload)
    if not rows:
        logger.info("No rows to preview.")


def _format_json_if_possible(value: str) -> str:
    try:
        parsed = json.loads(value)
    except Exception:
        return value
    return json.dumps(parsed, indent=2, sort_keys=True)
