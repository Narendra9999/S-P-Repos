from __future__ import annotations

import json
from typing import Any, Dict, Iterator, Optional

from pyspark.sql import DataFrame

from data_services.my_data_incremental.engine.models import DatasetTarget
from data_services.my_data_incremental.io.kafka_handler import KafkaHandler
from data_services.my_data_incremental.io.output_config import OutputConfigLoader
from data_services.my_data_incremental.io.outputs.contract_renderer import ContractRenderer
from data_services.my_data_incremental.io.outputs.preview import display_strings
from data_services.my_data_incremental.io.secret_manager import fetch_secret_from_vault
from data_services.my_data_incremental.transformation.utils import get_logger, log_structured

logger = get_logger("io.outputs.kafka_writer")


class KafkaDatasetWriter:
    """
    Sends dataset rows to Kafka topics using configuration stored in output_destinations.json.
    """

    def __init__(self, env: str, output_loader: Optional[OutputConfigLoader] = None) -> None:
        self.env = env
        self.output_loader = output_loader or OutputConfigLoader(env=env)
        self.contract_renderer = ContractRenderer(env=env)

    def write(
        self,
        dataframe: DataFrame,
        target: DatasetTarget,
        context: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        config_key = self._resolve_config_key(target)
        config = self.output_loader.get("kafka", config_key)
        log_capture_limit = int(config.get("log_capture_limit", 10))
        runtime_context = context or {}
        dry_run = bool(config.get("debug_dry_run", False) or config.get("dry_run", False))
        debug_print = bool(config.get("debug_print_messages", False))
        debug_limit = int(config.get("debug_print_limit", 10))
        topic_hint = config.get("topic") or config.get("producer_config", {}).get("topic")

        if dataframe is None:
            logger.warning("Kafka writer received a null DataFrame for target '%s'; skipping.", target.table)
            return {
                "config_key": config_key,
                "topic": topic_hint,
                "records_sent": 0,
                "dry_run": True,
                "payload_sample": [],
                "reason": "null_dataframe",
            }

        if dataframe.isEmpty():
            logger.info("Kafka writer found no rows to send for target '%s'; skipping.", target.table)
            return {
                "config_key": config_key,
                "topic": topic_hint,
                "records_sent": 0,
                "dry_run": dry_run,
                "payload_sample": [],
                "reason": "empty_dataframe",
            }

        serializer_name = config.get("serializer")
        if serializer_name:
            if serializer_name.startswith("contract:"):
                contract_id = serializer_name.split(":", 1)[1]
                payloads = self.contract_renderer.render_kafka_payloads(
                    dataframe=dataframe,
                    contract_id=contract_id,
                    output_config=config,
                    context=runtime_context,
                )
            else:
                payloads = self._apply_registered_serializer(serializer_name, dataframe, config, runtime_context)
        else:
            value_column = config.get("value_column")
            serializer = self._build_serializer(config, value_column)
            payloads = serializer(dataframe, value_column)

        dry_run = bool(config.get("debug_dry_run", False) or config.get("dry_run", False))
        sent = 0
        payload_samples: list[str] = []
        debug_payloads = []
        printed = 0

        def _prepare_preview(payload: Any) -> str:
            if isinstance(payload, str):
                return payload
            try:
                return json.dumps(payload)
            except TypeError:
                return str(payload)

        if dry_run:
            for payload in payloads:
                if len(payload_samples) < log_capture_limit:
                    payload_samples.append(_prepare_preview(payload))
                if debug_print and printed < debug_limit:
                    debug_payloads.append(payload)
                    printed += 1
                sent += 1
            if debug_print and debug_payloads:
                display_strings(
                    dataframe.sparkSession,
                    debug_payloads,
                    limit=debug_limit,
                    header=f"Kafka dry-run preview for dataset '{target.table}' (config '{config_key}')",
                )
            log_structured(
                logger,
                "Kafka dry-run completed",
                {
                    "config_key": config_key,
                    "topic": config.get("topic"),
                    "records_previewed": sent,
                    "dataset": target.table,
                },
            )
            return {
                "config_key": config_key,
                "topic": topic_hint,
                "records_sent": sent,
                "dry_run": True,
                "payload_sample": payload_samples[:log_capture_limit],
            }

        handler_config = self._build_handler_config(config)
        handler = KafkaHandler(handler_config)
        topic = handler_config.get("topic") or topic_hint

        try:
            for payload in payloads:
                if len(payload_samples) < log_capture_limit:
                    payload_samples.append(_prepare_preview(payload))
                if debug_print and printed < debug_limit:
                    print(f"[KafkaPreview] {payload}")
                    printed += 1
                handler.send(payload)
                sent += 1
        finally:
            handler.close()

        log_structured(
            logger,
            "Kafka write completed",
            {
                "config_key": config_key,
                "topic": handler_config.get("topic"),
                "records_sent": sent,
                "dataset": target.table,
            },
        )
        return {
            "config_key": config_key,
            "topic": topic,
            "records_sent": sent,
            "dry_run": False,
            "payload_sample": payload_samples[:log_capture_limit],
        }

    def _resolve_config_key(self, target: DatasetTarget) -> str:
        if target.config_key:
            return target.config_key
        if "config_key" in target.options:
            return target.options["config_key"]
        return target.table

    def _build_handler_config(self, config: Dict[str, Any]) -> Dict[str, Any]:
        producer_config = config.get("producer_config")
        if producer_config:
            handler_config = dict(producer_config)
        else:
            handler_config = {
                key: value
                for key, value in config.items()
                if key
                not in {
                    "producer_config",
                    "vault_secret_key",
                    "value_column",
                    "value_format",
                    "serializer",
                }
            }

        topic = config.get("topic") or handler_config.get("topic")
        if not topic:
            raise ValueError("Kafka output configuration must provide a 'topic'.")
        handler_config["topic"] = topic

        vault_secret_key = config.get("vault_secret_key")
        if vault_secret_key:
            handler_config["_kafka_password"] = fetch_secret_from_vault(vault_secret_key)
        elif "_kafka_password" not in handler_config:
            logger.warning("Kafka configuration missing '_kafka_password'; ensure credentials are provided.")

        return handler_config

    def _apply_registered_serializer(
        self,
        serializer_name: str,
        dataframe: DataFrame,
        config: Dict[str, Any],
        context: Dict[str, str],
    ) -> Iterator[str]:
        raise ValueError(f"Unknown Kafka serializer '{serializer_name}'. Only contract-based serializers are supported.")

    def _build_serializer(self, config: Dict[str, Any], value_column: Optional[str]):
        value_format = (config.get("value_format") or "json").lower()
        if value_column:
            def serialize_column(df: DataFrame, column_name: str) -> Iterator[str]:
                if column_name not in df.columns:
                    raise ValueError(f"Kafka value_column '{column_name}' not found in DataFrame columns.")
                for row in df.select(column_name).toLocalIterator():
                    value = row[column_name]
                    if value is None:
                        yield "null"
                    elif isinstance(value, str):
                        yield value
                    else:
                        yield json.dumps(value)
            return serialize_column

        if value_format == "json":
            return lambda df, _: df.toJSON().toLocalIterator()

        raise ValueError(f"Unsupported Kafka value_format '{value_format}'.")
