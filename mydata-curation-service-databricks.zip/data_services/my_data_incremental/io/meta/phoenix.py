import json
from datetime import datetime, timedelta


class pipelineLogger:
    def __init__(self, spark, meta_options):
        self.spark = spark
        self.meta_options = meta_options
        self.metadata_date_log = (
            f"{self.meta_options.get('metadata_catalog')}."
            f"{self.meta_options.get('metadata_schema')}.dp_date_processing_log"
        )
        self.metadata_file_log = (
            f"{self.meta_options.get('metadata_catalog')}."
            f"{self.meta_options.get('metadata_schema')}.dp_file_processing_log"
        )
        self.messages_full_table = (
            f"{self.meta_options.get('messages_catalog')}."
            f"{self.meta_options.get('messages_schema')}."
            f"{self.meta_options.get('messages_table')}"
        )
        self.target_full_table = (
            f"{self.meta_options.get('target_catalog')}."
            f"{self.meta_options.get('target_schema')}."
            f"{self.meta_options.get('metadata_schema')}.dp_date_processing_log"
        )

    def log_pipeline_event(self, event_name, status, details=None):
        """Log pipeline events with timestamp and details"""
        event = {
            "event": event_name,
            "status": status,
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "details": details or {},
        }
        print(f"[PIPELINE EVENT] {json.dumps(event)}")
        return event

    def check_for_new_records(self, process_date):
        """
        Check metadata tables for new records that need processing

        Args:
            process_date: Date to process in YYYY-MM-DD format

        Returns:
            Dictionary with status and count information
        """
        try:
            self.log_pipeline_event(
                "check_metadata", "started", {"process_date": process_date}
            )

            # Check the date processing log
            date_log_df = self.spark.sql(
                f"""
                SELECT 
                    process_date, 
                    MAX(completed_at) as latest_completion,
                    SUM(message_count) as total_messages,
                    SUM(file_count) as total_files,
                    SUM(error_count) as total_errors
                FROM {self.metadata_date_log}
                WHERE process_date = '{process_date}'
                AND status = 'COMPLETED'
                GROUP BY process_date
            """
            )

            # Check if we have data for the specified date
            if date_log_df.count() == 0:
                self.log_pipeline_event(
                    "check_metadata", "no_records", {"process_date": process_date}
                )
                return {
                    "status": "no_records",
                    "message": f"No completed records found for date {process_date}",
                    "process_date": process_date,
                }

            # Get the record counts
            date_record = date_log_df.first()
            total_messages = date_record["total_messages"]
            total_files = date_record["total_files"]
            latest_completion = date_record["latest_completion"]

            # Get distinct phoenix_ids from file processing log
            phoenix_ids_df = self.spark.sql(
                f"""
                SELECT DISTINCT phoenix_id
                FROM {self.metadata_file_log}
                WHERE process_date = '{process_date}'
                AND status = 'SUCCESS'
            """
            )

            phoenix_id_count = phoenix_ids_df.count()
            phoenix_ids = [row["phoenix_id"] for row in phoenix_ids_df.collect()]

            result = {
                "status": "success",
                "process_date": process_date,
                "latest_completion": str(latest_completion),
                "total_messages": total_messages,
                "total_files": total_files,
                "phoenix_id_count": phoenix_id_count,
                "phoenix_id": phoenix_ids,
            }

            self.log_pipeline_event("check_metadata", "completed", result)
            return result

        except Exception as e:
            error_details = {
                "process_date": process_date,
                "error": str(e),
            }
            self.log_pipeline_event("check_metadata", "error", error_details)
            raise
