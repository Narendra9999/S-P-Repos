import os
import requests

from data_services.my_data_incremental.transformation.utils import get_logger, log_structured

logger = get_logger("io.secret_manager")


class SecretManagerError(RuntimeError):
    """Raised when a secret cannot be retrieved from the configured vault."""


def _get_required_env_var(name: str) -> str:
    value = os.environ.get(name)
    if not value:
        raise SecretManagerError(f"Environment variable '{name}' is required to fetch secrets from vault.")
    return value


def fetch_secret_from_vault(key_name: str) -> str:
    """
    Fetch a secret from Vault using the configured environment variables.

    Args:
        key_name: The secret key to fetch from vault.

    Returns:
        The secret value as a string.
    """
    vault_token = _get_required_env_var("SPR_APP_SECRET_HC_PHOENIX_ELT_VAULT_TOKEN")
    vault_base_url = _get_required_env_var("SPR_APP_SECRET_HC_VAULT_BASE_URL")
    shelf_id = _get_required_env_var("IDF_PHOENIX_ELT_SHELF_ID")

    base_url = f"{vault_base_url}/{shelf_id}"
    log_structured(logger, "Fetching secret from vault", {"base_url": base_url, "key_name": key_name})

    params = {"secret-keys": key_name}
    headers = {"spr-sm-token": vault_token}

    try:
        response = requests.get(base_url, headers=headers, params=params, timeout=10)
        response.raise_for_status()
    except requests.RequestException as exc:
        raise SecretManagerError(f"Failed to retrieve secret '{key_name}' from vault") from exc

    payload = response.json()
    data = payload.get("data", {})
    if key_name not in data:
        raise SecretManagerError(f"Secret '{key_name}' not found in vault response.")

    return data[key_name]
