from delta.tables import DeltaTable


class ucWriter:
    def __init__(self, spark, dbutils, logger):
        self.spark = spark
        self.dbutils = dbutils
        self.logger = logger

    def table_exists(self, catalog, schema, table):
        full_table_name = f"{catalog}.{schema}.{table}"
        return self.spark.catalog.tableExists(full_table_name)

    def create_table_if_not_exists(self, catalog, schema, table, path, partitionBy, df_schema):
        try:
            self.logger.log_info(f"Checking if table {catalog}.{schema}.{table} exists.")
            """
            Creates a Delta table in Unity Catalog if it does not already exist,
            using the provided abfss path as the external location.
            """
            full_table_name = f"{catalog}.{schema}.{table}"
            schema_ddl = ", ".join(
                [
                    f"{'`' + field.name + '`'} {field.dataType.simpleString()}"
                    for field in df_schema.fields
                ]
            )

            location = "" if not path else f"LOCATION '{path}'"
            partitioning = "" if not partitionBy else f"PARTITIONED BY ({partitionBy})"

            if not self.spark.catalog.tableExists(full_table_name):
                self.spark.sql(
                    f"""
                    CREATE TABLE {full_table_name} 
                    (
                        {schema_ddl}
                    )
                    USING DELTA
                    {location}
                    {partitioning}
                """
                )
                print(f"Table {full_table_name} created with external location {path}.")
            else:
                print(f"Table {full_table_name} already exists.")
        except Exception as e:
            self.logger.log_error(f"Error checking table existence: {e}")
            print(f"Exception during table creation: {e}")

    def write_dataframe(self, dataframe, mode, catalog, schema, table, options):
        """
        Overridden method to write the given DataFrame to the specified table in Delta format.
        """
        self.spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", "true")
        full_table_name = f"{catalog}.{schema}.{table}"
        partitionBy = options.get("partitionBy") if options else None

        if mode == "merge":
            destination_df = DeltaTable.forName(self.spark, full_table_name)
            merge_condition = options.get("merge_keys") if options else None
            (
                destination_df.alias("destination")
                .merge(dataframe.alias("source"), merge_condition)
                .whenMatchedUpdateAll()
                .whenNotMatchedInsertAll()
                .execute()
            )
        elif mode == "partitionOverwriteMode":
            self.spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")
            mode = "overwrite"
            writer = (
                dataframe.write.format("delta")
                .mode(mode)
                .option("mergeSchema", "true")
                .option("schemaEvolution", "true")
                .option("overwriteSchema", "true")
            )
            if partitionBy:
                writer = writer.partitionBy(partitionBy)

            if options and isinstance(options, dict):
                writer = writer.options(**options)

            writer.saveAsTable(full_table_name)
        else:
            writer = (
                dataframe.write.format("delta")
                .mode(mode)
                .option("mergeSchema", "true")
                .option("schemaEvolution", "true")
                .option("overwriteSchema", "true")
            )
            if partitionBy:
                writer = writer.partitionBy(partitionBy)

            if options and isinstance(options, dict):
                writer = writer.options(**options)

            writer.saveAsTable(full_table_name)

    def write_table(
        self,
        dataframe,
        catalog,
        schema,
        table,
        path=None,
        mode="overwrite",
        type="external",
        options=None,
        partitionBy=None,
    ):
        """
        Overridden method to write the given DataFrame to the specified table in Delta format.
        """
        self.spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", "true")
        df_schema = dataframe.schema
        self.create_table_if_not_exists(catalog, schema, table, path, partitionBy, df_schema)
        self.write_dataframe(dataframe, mode, catalog, schema, table, options)
