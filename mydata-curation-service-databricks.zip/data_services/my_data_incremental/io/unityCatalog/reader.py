class ucReader:
    def __init__(self, spark, dbutils, logger, options):
        self.spark = spark
        self.dbutils = dbutils
        self.logger = logger
        self.options = options

    def read_data(self):
        # self.logger.info("Reading unprocessed data")
        df = self.spark.table(
            f"{self.options.get('catalog')}."
            f"{self.options.get('schema')}."
            f"{self.options.get('table')}"
        )
        return df

    def read_filtered(self):
        # self.logger.info("Reading unprocessed data")

        metadata = self.options.get("metadata", {})
        filteringKey = self.options.get("filteringKey")
        if metadata and filteringKey:
            print(metadata)
            filteringValues = metadata.get(filteringKey.casefold(), [])
            print(filteringValues)
        else:
            raise Exception("filteringKey and metadata is required")

        df = self.read_data()

        df = df.filter(df[filteringKey].isin(*filteringValues))

        recordCount = df.count()
        if recordCount == 0:
            # Return empty DataFrame with same schema
            return df.limit(0)
        else:
            return df
