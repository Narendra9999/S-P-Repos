import os
import logging
from copy import deepcopy

import requests

from data_services.my_data_incremental.config.config_loader import Config

logger = logging.getLogger(__name__)


def fetch_kafka_credentials_from_vault(key_name) -> str:
    """
    Fetch Kafka credentials from Vault using environment variables.
    Returns (username, password) or raises Exception if not found.
    """
    vault_token = os.environ.get("SPR_APP_SECRET_HC_PHOENIX_ELT_VAULT_TOKEN")
    vault_base_url = os.environ.get("SPR_APP_SECRET_HC_VAULT_BASE_URL")
    shelf_id = os.environ.get("IDF_PHOENIX_ELT_SHELF_ID")
    if not (vault_token and vault_base_url and shelf_id):
        raise RuntimeError("Vault environment variables are not set.")

    base_url = f"{vault_base_url}/{shelf_id}"
    print(f"Running query on vault: {base_url}")
    params = {'secret-keys': key_name}
    headers = {"spr-sm-token": vault_token}

    resp = requests.get(base_url, headers=headers, params=params, timeout=10)
    resp.raise_for_status()
    data = resp.json()

    # print(data)
    value = data["data"][key_name]

    return value


def get_kafka_config(env=None):
    """
    Retrieve Kafka configuration using lineage_config.json and inject credentials fetched at runtime.
    Returns: Dictionary with Kafka configuration. Password is never logged or returned in plain text.
    """
    resolved_env = env or os.environ.get("ENV") or os.environ.get("ENVIRONMENT")
    if not resolved_env:
        raise ValueError("Environment must be provided to load Kafka configuration.")

    config_loader = Config(env=resolved_env)
    config_data = config_loader.loadConfig("lineage_config.json")
    template_config = config_data.get("elt_notify_kafka")
    if template_config is None:
        raise KeyError("elt_notify_kafka configuration not found in lineage_config.json")

    kafka_config = deepcopy(template_config)

    password = fetch_kafka_credentials_from_vault('kafka.orglinking.password')
    kafka_config["_kafka_password"] = password  # Only for direct injection, not for logging or config propagation

    return kafka_config
