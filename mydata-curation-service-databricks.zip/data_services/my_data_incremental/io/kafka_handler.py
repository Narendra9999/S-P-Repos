# This file has been moved to io/kafka_handler.py. Please update imports accordingly.

from kafka import KafkaProducer

class KafkaHandler:
    def __init__(self, config):
        self.producer = KafkaProducer(
            bootstrap_servers=config["kafka.bootstrap.servers"],
            security_protocol=config["kafka.security.protocol"],
            sasl_mechanism=config["kafka.sasl.mechanism"],
            ssl_cafile=config["ssl.ca.location"],
            sasl_plain_username=config["sasl.plain.username"],
            sasl_plain_password=config["_kafka_password"],
            value_serializer=lambda x: x.encode('utf-8'),
            compression_type=config["kafka.compression.type"],
            retries=3
        )
        self.topic = config["topic"]

    def send(self, message: str):
        self.producer.send(self.topic, message).get(timeout=10)

    def close(self):
        self.producer.flush()
        self.producer.close()
