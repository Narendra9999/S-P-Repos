# Databricks notebook source
from elt_linking_service.src.kafka.consumer import KafkaConsumer
from data_services.my_data_incremental.io.kafka_config import get_kafka_config

# COMMAND ----------

class kafkaReader:
    def __init__(self, destinations, options, spark, env):
        self.env = env
        self.kafka_creds = get_kafka_config(env=self.env)
        self.kafka_config = {
            **self.kafka_creds,
            'sasl.plain.password': self.kafka_creds['_kafka_password']  # Only injected at runtime
        }
        self.options = options
        self.spark = spark
        self.destinations = destinations

    def consume(self):
        consumer = KafkaConsumer(kafka_config=self.kafka_config, destinations=self.options.get('destinations'), og_column=self.options.get('og_column'), og_response=self.options.get('og_response'), spark=self.spark)
        consumer.consume()

