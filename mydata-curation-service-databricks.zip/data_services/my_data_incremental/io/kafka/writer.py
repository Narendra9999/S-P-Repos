# Databricks notebook source
from elt_linking_service.src.elt_linking_service import EltLinkingService
from data_services.my_data_incremental.io.kafka_config import get_kafka_config

# COMMAND ----------

class kafkaWriter:
    def __init__(self, options, logger, spark, env):
        self.env=env
        # self.kafka_creds = get_kafka_config(env=self.env)
        self.options = options
        self.logger = logger
        self.spark = spark
        self.kafka_config = self.options["kafka_config"]


    def write(self, df):
        
        linking = EltLinkingService(self.spark, self.kafka_config)
        dm = linking.initiate_linking_process_for_dataframe(df=df, rdd_field_mappings=self.options.get('rdd_field_mappings'),
                                                   static_values=self.options.get('static_values'),
                                                   config = {**self.options.get('config')},
                                                   include_columns=self.options.get('include_columns'),
                                                   exclude_columns=self.options.get('exclude_columns')
                                                   )
        return dm
