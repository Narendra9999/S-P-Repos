from __future__ import annotations

from copy import deepcopy
from typing import Any, Dict

from data_services.my_data_incremental.config.config_loader import Config


class OutputConfigLoader:
    """
    Helper to load output destination configurations for Kafka, Postgres, etc.
    """

    def __init__(self, env: str):
        self.env = env
        self._cache: Dict[str, Any] | None = None

    def _load(self) -> Dict[str, Any]:
        if self._cache is None:
            config_loader = Config(env=self.env)
            self._cache = config_loader.loadConfig("output_destinations.json") or {}
        return self._cache

    def get(self, destination_type: str, config_key: str) -> Dict[str, Any]:
        data = self._load()
        type_section = data.get(destination_type)
        if type_section is None:
            raise KeyError(f"Destination type '{destination_type}' not defined in output_destinations.json")
        config = type_section.get(config_key)
        if config is None:
            raise KeyError(f"Config key '{config_key}' not found under destination type '{destination_type}'")
        return deepcopy(config)
