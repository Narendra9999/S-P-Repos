from typing import Dict, Any

class HealthcareMetadataGenerator:
    """Class to generate healthcare metadata records for Kafka (extended with due-date fields)."""

    # NOTE: Kept your existing schema + added new string fields.
    schema = {
        "type": "object",
        "properties": {
            "s3FileURL": {"type": "string"},
            "entityId": {"type": "integer"},
            "entityName": {"type": "string"},
            "keywordName": {"type": "string"},
            "fileName": {"type": "string"},
            "SourceFilePath": {"type": "string"},
            "createdBy": {"type": "string"},
            "workType": {"type": "string"},
            "taggedDate": {"type": "string"},
            "receivedDate": {"type": "string"},
            "spOrgId": {"type": "integer"},
            "periodObj": {
                "type": "object",
                "properties": {
                    "periodEndDate": {"type": "string"},
                    "statementBasis": {"type": "string"},
                    "periodType": {"type": "string"},
                    "periodMonths": {"type": "string"},
                    "accountingBasis": {"type": "string"},
                },
            },
            "state": {"type": "string"},
            "countryCode": {"type": "string"},
            "currencyCode": {"type": "string"},
            "mappedAsid": {
                "type": "array",
                "items": {"type": "integer"},
            },
            "sporgid": {"type": "integer"},
            "modelName": {"type": "string"},

            # NEW: due-date family (always strings in metadata)
            "dueDate": {"type": "string"},
            "fdmDueDate": {"type": "string"},
            "finalDueDate": {"type": "string"},
            "finalTime": {"type": "string"},
            "dcCompletionDate": {"type": "string"},
            "taggedFiles": {"type": "string"},
            "referenceFiles": {"type": "string"},
        }
    }

    @staticmethod
    def _to_int(value, default: int = 0) -> int:
        try:
            if value is None or (isinstance(value, str) and value.strip() == ""):
                return default
            return int(value)
        except Exception:
            return default

    @staticmethod
    def _to_str(value, default: str = "") -> str:
        if value is None:
            return default
        return str(value)

    def generate_metadata(self, row: Dict[str, Any], file_path: str) -> Dict[str, Any]:
        """
        Generate metadata for a healthcare record (Kafka payload).

        Args:
            row: The source row dict (parsed from your 'dataset' JSON).
            file_path: The S3 path for the data file.

        Returns:
            Dict with structured metadata, now including due-date fields.
        """
        # Period object (keep your defaults if missing)
        period = row.get("period", {})
        period_obj = {
            "periodEndDate": self._to_str(period.get("periodEndDate", "06/29/2024")),
            "statementBasis": self._to_str(period.get("statementBasis", "UnAudited")),
            "periodType": self._to_str(period.get("periodType", "Annual")),
            "periodMonths": self._to_str(period.get("periodMonths", "")),
            "accountingBasis": self._to_str(period.get("accountingBasis", "Accrual")),
        } if isinstance(period, dict) else {}

        # NEW: pull through due-date fields as strings (no assumptions about format)
        due_date_fields = {
            "dueDate": self._to_str(row.get("dueDate", "")),
            "fdmDueDate": self._to_str(row.get("fdmDueDate", "")),
            "finalDueDate": self._to_str(row.get("finalDueDate", "")),
            "finalTime": self._to_str(row.get("finalTime", "")),
            "dcCompletionDate": self._to_str(row.get("dcCompletionDate", "")),
        }

        metadata = {
            "s3FileURL": self._to_str(file_path),
            "entityId": self._to_int(row.get("entityId", 0), 0),
            "entityName": self._to_str(row.get("orgPrimaryName", "")),
            "keywordName": self._to_str(row.get("keywordName", "")),
            "fileName": self._to_str(row.get("fileName", file_path.split('/')[-1] if file_path else "")),
            "SourceFilePath": self._to_str(row.get("SourceFilePath", "")),
            "createdBy": self._to_str(row.get("createdBy", "System")),
            "workType": self._to_str(row.get("workType", "")),
            "taggedDate": self._to_str(row.get("taggedDate", "")),
            "receivedDate": self._to_str(row.get("receivedDate", "")),
            "spOrgId": self._to_int(row.get("spOrgId", 12345), 12345),
            "periodObj": period_obj,
            "state": self._to_str(row.get("state", "")),
            "countryCode": self._to_str(row.get("countryCode", "")),
            "currencyCode": self._to_str(row.get("currencyCode", "")),
            "mappedAsid": [self._to_int(i, 0) for i in row.get("mappedAsid", [])] if isinstance(row.get("mappedAsid", []), (list, tuple)) else [],
            # Back-compat: keep duplicate key you already had
            "sporgid": self._to_int(row.get("spOrgId", 0), 0),
            "modelName": self._to_str(row.get("modelName", "USPF")),
            "taggedFiles": self._to_str(row.get("taggedFiles", "")),
            "referenceFiles": self._to_str(row.get("referenceFiles", "")),
            # NEW:
            **due_date_fields,
        }
        return metadata
