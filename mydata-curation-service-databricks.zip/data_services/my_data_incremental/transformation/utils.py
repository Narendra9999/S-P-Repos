# This file has been moved to transformation/utils.py. Please update imports accordingly.

from typing import Any, Dict, List, Optional
from pyspark.sql import DataFrame, Window
from pyspark.sql import functions as F
import json
import logging
from datetime import datetime
from pprint import pformat


_LOGGER_ROOT = "mydata"
_LOG_FORMAT = "%(asctime)s | %(levelname)s | %(name)s | %(message)s"
_LOGGING_INITIALIZED = False


def _ensure_logging(level: int = logging.DEBUG) -> None:
    global _LOGGING_INITIALIZED
    if _LOGGING_INITIALIZED:
        return
    handler = logging.StreamHandler()
    handler.setFormatter(logging.Formatter(_LOG_FORMAT))
    logger = logging.getLogger(_LOGGER_ROOT)
    logger.setLevel(level)
    logger.addHandler(handler)
    logger.propagate = False
    _LOGGING_INITIALIZED = True


def get_logger(name: Optional[str] = None, level: int = logging.DEBUG) -> logging.Logger:
    _ensure_logging(level)
    full_name = f"{_LOGGER_ROOT}.{name}" if name else _LOGGER_ROOT
    logger = logging.getLogger(full_name)
    logger.setLevel(level)
    return logger


def _format_payload(payload: Any) -> str:
    if payload is None:
        return ""
    if isinstance(payload, str):
        return payload
    try:
        return json.dumps(payload, indent=2, sort_keys=True, default=str)
    except (TypeError, ValueError):
        return pformat(payload, indent=2, width=120, compact=False)


def log_structured(
    logger: logging.Logger,
    message: str,
    payload: Any = None,
    level: int = logging.INFO,
) -> None:
    formatted_payload = _format_payload(payload)
    if formatted_payload:
        logger.log(level, "%s\n%s", message, formatted_payload)
    else:
        logger.log(level, message)


def create_uppercase_name_dict(names: List[str]) -> Dict[str, str]:
    """
    Create a dictionary mapping uppercase names to original names.

    Args:
        names (List[str]): A list of names.

    Returns:
        Dict[str, str]: Dictionary with uppercase name as key, original name as value.
    """
    df = spark.createDataFrame([(name,) for name in names], ["name"])
    df = df.withColumn("uppercase_name", F.upper(F.col("name")))
    name_dict = {row["uppercase_name"]: row["name"] for row in df.collect()}
    return name_dict


def generic_join_fill(
    df1: DataFrame,
    df2: DataFrame,
    join_columns: List[str],
    fill_columns: List[str],
    join_type: str = "inner"
) -> DataFrame:
    """
    Perform a join and fill missing columns from df2 into df1.

    Args:
        df1 (DataFrame): Left DataFrame.
        df2 (DataFrame): Right DataFrame.
        join_columns (List[str]): Columns to join on.
        fill_columns (List[str]): Columns from df2 to add to df1.
        join_type (str): Type of join (default is "inner").

    Returns:
        DataFrame: Joined DataFrame with selected columns filled.
    """
    df1_alias = df1.alias("df1")
    df2_alias = df2.alias("df2")

    join_condition = [df1_alias[col] == df2_alias[col] for col in join_columns]
    joined_df = df1_alias.join(df2_alias, on=join_condition, how=join_type)

    columns_to_select = (
        [f"df1.{col}" for col in df1.columns if col not in fill_columns] +
        [f"df2.{col}" for col in fill_columns]
    )

    result_df = joined_df.selectExpr(*columns_to_select)

    return result_df


def get_last_n_periods(
    df: DataFrame,
    key_columns: List[str],
    value_column: str,
    last_n_periods: int = 12
) -> DataFrame:
    """
    Select the last N periods for each group defined by key columns.

    Args:
        df (DataFrame): Input DataFrame.
        key_columns (List[str]): Columns to group by.
        value_column (str): Column used to determine latest periods.
        last_n_periods (int): Number of periods to return per group.

    Returns:
        DataFrame: Filtered DataFrame containing only the last N periods.
    """
    window_spec = Window.partitionBy(*key_columns).orderBy(F.col(value_column).desc())

    df_with_rank = df.withColumn("rn", F.dense_rank().over(window_spec))
    result_df = (
        df_with_rank
        .filter(F.col("rn") <= last_n_periods)
        .drop("rn")
        .orderBy(*key_columns, F.col(value_column).desc())
    )

    return result_df




def is_running_in_databricks() -> bool:
    """
    Check if the code is running in a Databricks environment.
    """
    try:
        return "dbutils" in globals() or "spark" in globals()
    except Exception:
        return False


def generic_join_fill(
    df1: DataFrame,
    df2: DataFrame,
    join_columns: List[str],
    fill_columns: List[str],
    join_type: str = "inner"
) -> DataFrame:
    """
    Perform a join and fill missing columns from df2 into df1.

    Args:
        df1 (DataFrame): Left DataFrame.
        df2 (DataFrame): Right DataFrame.
        join_columns (List[str]): Columns to join on.
        fill_columns (List[str]): Columns from df2 to add to df1.
        join_type (str): Type of join (default is "inner").

    Returns:
        DataFrame: Joined DataFrame with selected columns filled.
    """
    df1_alias = df1.alias("df1")
    df2_alias = df2.alias("df2")

    join_condition = [df1_alias[col] == df2_alias[col] for col in join_columns]
    joined_df = df1_alias.join(df2_alias, on=join_condition, how=join_type)

    columns_to_select = (
        [f"df1.{col}" for col in df1.columns if col not in fill_columns] +
        [f"df2.{col}" for col in fill_columns]
    )

    result_df = joined_df.selectExpr(*columns_to_select)

    return result_df


def get_last_n_periods(
    df: DataFrame,
    key_columns: List[str],
    value_column: str,
    last_n_periods: int = 12
) -> DataFrame:
    """
    Select the last N periods for each group defined by key columns.

    Args:
        df (DataFrame): Input DataFrame.
        key_columns (List[str]): Columns to group by.
        value_column (str): Column used to determine latest periods.
        last_n_periods (int): Number of periods to return per group.

    Returns:
        DataFrame: Filtered DataFrame containing only the last N periods.
    """
    window_spec = Window.partitionBy(*key_columns).orderBy(F.col(value_column).desc())

    df_with_rank = df.withColumn("rn", F.dense_rank().over(window_spec))
    result_df = (
        df_with_rank
        .filter(F.col("rn") <= last_n_periods)
        .drop("rn")
        .orderBy(*key_columns, F.col(value_column).desc())
    )

    return result_df


def log_pipeline_event(event_name, status, details=None):
    """Log pipeline events with timestamp and details."""
    event = {
        "event": event_name,
        "status": status,
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "details": details or {}
    }
    logger = get_logger("pipeline")
    log_structured(logger, f"[PIPELINE EVENT] {event_name}", event)
    return event

