### ELT to DP

# Import required libraries
import datetime
import json
import time
import logging

try:
    from importlib.resources import files
except ImportError:
    from importlib_resources import files

from delta.tables import DeltaTable
from pyspark.sql.utils import AnalysisException
import pyspark.sql.functions as F
from pyspark.sql.functions import collect_list, col, current_timestamp, lit, sha2, concat_ws, max, desc, row_number
from pyspark.sql.window import Window
from data_services.my_data_incremental.transformation.metadata_generator import HealthcareMetadataGenerator
from data_services.my_data_incremental.io.kafka_handler import KafkaHandler
from data_services.my_data_incremental.ingestion.s3_handler import S3DataHandler
from data_services.my_data_incremental.transformation.utils import generic_join_fill, is_running_in_databricks
from data_services.my_data_incremental.io.kafka_config import get_kafka_config
from data_services.my_data_incremental.transformation.period_merge_dp_load import period_merge_logic_incremental
from typing import Dict
from pyspark.sql import SparkSession, DataFrame

try:
    spark
except NameError:
    from pyspark.sql import SparkSession
    spark = SparkSession.builder.getOrCreate()



logger = logging.getLogger(__name__)

# Timing removed

def write_scd2_delta(df: DataFrame, table_name: str, key_columns: list):
    """
    Upserts data into a Delta table using Type 2 SCD logic with hash-based change detection and CDF enabled.
    """
    logger.info(f"SCD2 write start table={table_name} rows={df.count()} keys={key_columns}")
    # Add metadata columns
    df = df.withColumn("is_current", lit(True)) \
           .withColumn("effective_date", current_timestamp()) \
           .withColumn("end_date", lit(None).cast("timestamp"))

    # Exclude SCD2 metadata columns from hash calculation
    compare_columns = [c for c in df.columns if c not in key_columns + ["is_current", "effective_date", "end_date"]]
    df = df.withColumn("hash", sha2(concat_ws("||", *[col(c).cast("string") for c in compare_columns]), 256))

    if not spark.catalog.tableExists(table_name):
        (df.write.format("delta")
            .option("delta.enableChangeDataFeed", "true")
            .option("mergeSchema", "true")
            .mode("append")
            .saveAsTable(table_name))
        print(f"Created new Delta table: {table_name}")
        return

    # Existing table: derive changed + new sets
    existing_current = spark.table(table_name).filter(col("is_current") == True) \
        .select(*key_columns, "hash")

    join_cond_expr = [df[k] == existing_current[k] for k in key_columns]
    # Changed rows: same keys, different hash
    changed_rows = (df.alias("s")
                      .join(existing_current.alias("t"), join_cond_expr, "inner")
                      .filter(col("s.hash") != col("t.hash"))
                      .select([col(f"s.{c}").alias(c) for c in df.columns]))
    # New rows: keys not present in current snapshot
    new_rows = (df.alias("s")
                   .join(existing_current.alias("t"), join_cond_expr, "left_anti")
                   .select([col(f"s.{c}").alias(c) for c in df.columns]))

    # Expire old versions for changed keys
    if changed_rows.count() > 0:
        delta_table = DeltaTable.forName(spark, table_name)
        expire_keys_df = changed_rows.select(*key_columns).distinct()
        merge_join = " AND ".join([f"target.{k} = source.{k}" for k in key_columns])
        (delta_table.alias("target")
            .merge(expire_keys_df.alias("source"), merge_join)
            .whenMatchedUpdate(set={
                "is_current": lit(False),
                "end_date": current_timestamp()
            })
            .execute())
        print(f"Expired {expire_keys_df.count()} key sets")
    else:
        print("No changed keys to expire")

    # Insert new versions (changed + brand new)
    to_insert = new_rows.unionByName(changed_rows, allowMissingColumns=True)
    if to_insert.count() > 0:
        (to_insert.write.format("delta")
            .mode("append")
            .saveAsTable(table_name))
        print(f"Inserted {to_insert.count()} new current rows")
    else:
        print("No new or changed rows to insert")

    print(f"Data successfully merged into Delta table: {table_name}")
    
def read_latest_delta_version(table_name: str):
    """
    Reads current active records from SCD2 Delta table.
    """
    try:
        # Simply read current active records - no need for version complexity
        latest_df = spark.table(table_name) \
            .filter("is_current = true") \
            .drop("is_current", "effective_date", "end_date", "hash")
        
        return latest_df

    except AnalysisException as ae:
        print(f"Table not found or inaccessible: {table_name}")
        raise ae
    except Exception as e:
        print(f"Unexpected error while reading Delta table '{table_name}': {str(e)}")
        raise e


def persist_scd2_batch(df: DataFrame, config) -> DataFrame:
    """
    Persists DataFrame to Delta table using SCD Type 2 logic and returns input with metadata.

    Args:
        df: Input DataFrame to persist
        config: Dict with 'scd2_keys', 'fin_group_linked_scd2', catalogs/schemas

    Returns:
        Original DataFrame with added columns: is_current, effective_date, end_date
        
    Raises:
        ValueError: Missing config keys or DataFrame columns
    """
    logger.info(f"persist_scd2_batch start rows={df.count()}")
    try:
        # Validate SCD2 configuration before processing
        validate_scd2_config(config)
        
        raw_catalog_schema = f"{config.get('raw_catalog')}.{config.get('raw_schema')}"
        curated_catalog_schema = f"{config.get('curated_catalog')}.{config.get('curated_schema')}"

        # Define Delta table parameters
        table_name = f"{curated_catalog_schema}.{config.get('fin_group_linked_scd2')}"
       
        # Validate required configuration
        if not table_name:
            raise ValueError("Missing required configuration: fin_group_linked_scd2")

        print(f"Processing Delta table: {table_name}")
        
        # Parse key columns from config
        scd2_keys = config.get('scd2_keys')
        if not scd2_keys:
            raise ValueError("Missing required configuration: scd2_keys")
            
        key_columns = [k.strip() for k in scd2_keys.split(",")]
        print(f"Using SCD2 key columns: {key_columns}")

        # Validate key columns exist in DataFrame
        missing_keys = [key for key in key_columns if key not in df.columns]
        if missing_keys:
            raise ValueError(f"Key columns not found in DataFrame: {missing_keys}")

        # Write incoming data using SCD Type 2 logic
        write_scd2_delta(df, table_name, key_columns)

        # Read latest active snapshot from Delta table
        latest_active_df = df.withColumn("is_current", lit(True)) \
           .withColumn("effective_date", current_timestamp()) \
           .withColumn("end_date", lit(None).cast("timestamp"))
        
        # Validate we got data back
        if latest_active_df.count() == 0:
            print(f"Warning: No active records found in Delta table: {table_name}")
        else:
            print(f"Retrieved {latest_active_df.count()} latest active records from Delta table: {table_name}")

        return latest_active_df
    except Exception as e:
        print(f"Failed to process Delta table: {str(e)}")
        raise


def apply_kafka_contract_formatting(df: DataFrame, contract_config: dict = None) -> DataFrame:
    """
    Applies Kafka contract formatting based on configuration.
    Ensures all fields are mandatory and handles null values according to contract rules.
    
    Parameters:
        df: DataFrame to format
        contract_config: Dictionary containing field types and null handling rules
    
    Returns:
        DataFrame with properly formatted fields according to Kafka contract
    """
    if contract_config is None:
        # Default contract configuration
        contract_config = {
            "string_fields": [
                "entityId", "orgPrimaryName", "subProductName", "spOrgId", "aprAcceptable",
                "state", "countryCode", "currencyCode", "reportId", "keywordName", "workType",
                "receivedDate", "taggedDate", "dueDate", "fdmDueDate", "finalDueDate", 
                "finalTime", "dcCompletionDate", "taggedFiles", "referenceFiles"
            ],
            "array_fields": [
                "mappedAsid", "datapoints"
            ],
            "object_fields": [
                "period"
            ],
            "datapoint_fields": {
                "required_string_fields": ["mnemonic", "value", "unitType"],
                "optional_array_fields": ["comments", "schedules"]
            },
            "null_replacements": {
                "string": "",
                "array": [],
                "object": {}
            }
        }
    
    try:
        # Apply null handling for top-level fields
        formatted_df = df
        
        # Handle string fields - replace null with empty string
        for field in contract_config.get("string_fields", []):
            if field in formatted_df.columns:
                formatted_df = formatted_df.withColumn(
                    field, 
                    F.when(F.col(field).isNull() | (F.col(field) == ""), "").otherwise(F.col(field).cast("string"))
                )
        
        # Handle array fields - replace null with empty array
        for field in contract_config.get("array_fields", []):
            if field in formatted_df.columns:
                formatted_df = formatted_df.withColumn(
                    field,
                    F.when(F.col(field).isNull(), F.array()).otherwise(F.col(field))
                )
        
        # Handle period object - ensure all nested fields exist
        if "period" in formatted_df.columns:
            formatted_df = formatted_df.withColumn(
                "period",
                F.when(F.col("period").isNull(), 
                       F.struct(
                           F.lit("").alias("periodEndDate"),
                           F.lit("").alias("statementBasis"), 
                           F.lit("").alias("periodType"),
                           F.lit("").alias("periodMonths"),
                           F.lit("").alias("accountingBasis")
                       )
                ).otherwise(
                    F.struct(
                        F.when(F.col("period.periodEndDate").isNull(), "").otherwise(F.col("period.periodEndDate").cast("string")).alias("periodEndDate"),
                        F.when(F.col("period.statementBasis").isNull(), "").otherwise(F.col("period.statementBasis").cast("string")).alias("statementBasis"),
                        F.when(F.col("period.periodType").isNull(), "").otherwise(F.col("period.periodType").cast("string")).alias("periodType"),
                        F.when(F.col("period.periodMonths").isNull(), "").otherwise(F.col("period.periodMonths").cast("string")).alias("periodMonths"),
                        F.when(F.col("period.accountingBasis").isNull(), "").otherwise(F.col("period.accountingBasis").cast("string")).alias("accountingBasis")
                    )
                )
            )
        
        # Handle datapoints array - ensure each datapoint has all required fields
        if "datapoints" in formatted_df.columns:
            formatted_df = formatted_df.withColumn(
                "datapoints",
                F.when(F.col("datapoints").isNull(), F.array()).otherwise(
                    F.transform(
                        F.col("datapoints"),
                        lambda dp: F.struct(
                            F.when(dp.getField("mnemonic").isNull(), "").otherwise(dp.getField("mnemonic").cast("string")).alias("mnemonic"),
                            F.when(dp.getField("value").isNull(), "").otherwise(dp.getField("value").cast("string")).alias("value"),
                            F.when(dp.getField("unitType").isNull(), "").otherwise(dp.getField("unitType").cast("string")).alias("unitType"),
                            F.when(dp.getField("comments").isNull(), F.array()).otherwise(dp.getField("comments")).alias("comments"),
                            F.when(dp.getField("schedules").isNull(), F.array()).otherwise(dp.getField("schedules")).alias("schedules")
                        )
                    )
                )
            )
        
        return formatted_df
        
    except Exception as e:
        print(f"Failed to apply Kafka contract formatting: {str(e)}")
        raise


def generate_kafka_json_message(df: DataFrame, contract_config: dict = None) -> DataFrame:
    """
    Generates a DataFrame containing a JSON-formatted DataFrame for Kafka messaging.
    Applies contract formatting to ensure all fields are mandatory and properly formatted.

    Parameters: 
        df: Latest active snapshot DataFrame
        contract_config: Optional configuration for field formatting rules
    """
    logger.info(f"generate_kafka_json_message start rows={df.count()}")
    try:
        # Apply contract formatting first
        formatted_df = apply_kafka_contract_formatting(df, contract_config)
        
        # Convert each row to JSON string
        df_json = formatted_df.withColumn(
            "dataset",
            F.to_json(F.struct([formatted_df[col] for col in formatted_df.columns]))
        ).select("dataset")

        return df_json
    except Exception as e:
        print(f"Failed to generate Kafka JSON message DataFrame: {str(e)}")
        raise




def refine_driving_data(driving_df: DataFrame, asid_linking_df: DataFrame, org_df: DataFrame, comments_df: DataFrame, schedule_df: DataFrame, plan_data_df: DataFrame) -> DataFrame:
    """
    Refines and enriches driving data by joining it with multiple related datasets
    (ASID linking, organization info, comments, schedules, and plan data), transforming it, and
    returning a JSON-ready Spark DataFrame

    Returns:
        pyspark.sql.DataFrame: A DataFrame with a single column 'dataset', 
        where each row contains a JSON string of the aggregated and enriched data record.
    """

    logger.info(f"refine_driving_data start driving_rows={driving_df.count()} comments_rows={comments_df.count()} schedule_rows={schedule_df.count()} org_rows={org_df.count()} linking_rows={asid_linking_df.count()} plan_rows={plan_data_df.count()}")
    rename_source_columns = {"PHOENIX_ID": "entityId",
                         "REPORT_ID":"reportId",
                         "SECTOR_NAME": "subProductName",
                         "PER_TYPE_NAME": "periodType",
                         "PERIOD_END_DATE": "periodEndDate",
                         "PERIOD_MONTHS": "periodMonths",
                         "STATEMENT_BASIS_NAME":"statementBasis",
                         "ACCOUNT_BASIS_NAME":"accountingBasis",
                         "APR_ACCEPTABLE":"aprAcceptable",
                         "SRC_DE_UNIQ_ID_TEXT":"mnemonic",
                         "DP_VALUE":"value",
                         "ORG_PRIMARY_NAME":"orgPrimaryName",
                         "STATE":"state",
                         "COUNTRY_CODE":"countryCode",
                         "CURRENCY_CODE":"currencyCode",
                         "ASID":"mappedAsid",
                         "SP_ORG_ID":"spOrgId",
                         "SOURCE_FILE_CREATE_DATE":"created_Date",
                         "COMMENTS":"comments",
                         "COMMENT_BY":"userName",
                         "SCHEDULE_NAME":"scheduleName",
                         "SCHEDULE_VALUE":"scheduleValue",
                         "SCHEDULE_FRMLA_TEXT":"scheduleValueResult",
                         "FINANCIAL_SECTOR":"subProductName",
                         "SECTOR":"subProductName",
                         "VALUE":"value",
                         "KEYWORD_NAME":"keywordName",
                         "WORK_TYPE":"workType",
                         "REMARKS":'remark',
                         "RECEIVED_DATE":"receivedDate",
                         "TAGGED_DATE":"taggedDate",
                         "ORDER_ID":"orderId",
                         "COLLECTION_DENOM":'unitType',
                         "DUE_DATE": "dueDate",
                         "FDM_DUE_DATE": "fdmDueDate",
                         "FINAL_DUE_DATE": "finalDueDate",
                         "FINAL_TIME": "finalTime",
                         "DC_COMPLETION_DATE": "dcCompletionDate",
                         "TAGGED_FILES": "taggedFiles",
                         "REFERENCE_FILES": "referenceFiles",
                         "PLAN_NAME": "orgPrimaryName",
                         "PLAN_STATE": "state"
                         }

    unknown_driving_columns = ["docObjectId"]
    periodColumnName = "period"

    periodCols = [
        "periodEndDate",
        "statementBasis",
        "periodType",
        "periodMonths",
        "accountingBasis",
    ]

    driving_cols = ['entityId', 'subProductName', 'periodType', 'periodEndDate', 'periodMonths',
                'statementBasis', 'accountingBasis', 'aprAcceptable', 'mnemonic', 'value','reportId','keywordName',
                'workType','receivedDate','taggedDate','unitType',
                'dueDate', 'fdmDueDate', 'finalDueDate', 'finalTime', 'dcCompletionDate',
                  'taggedFiles', 'referenceFiles'
                ]
    asid_linking_cols = ["mappedAsid", "entityId", "subProductName", "spOrgId"]

    org_cols = [
        "entityId", "subProductName", "orgPrimaryName", "state",
        "countryCode", "currencyCode"
    ]

    plan_cols = ["entityId", "orgPrimaryName", "state"]

    comments_cols = ["entityId", "subProductName", "mnemonic", "comments", "created_Date", "userName",'reportId']
    schedule_cols = ["entityId", "subProductName", "mnemonic", "scheduleName", "scheduleValueResult", "scheduleValue","remark",'reportId','orderId']

    asid_linking_key_columns = ["entityId", "subProductName"]
    asid_linking_fill_cols = [col for col in asid_linking_cols if col not in asid_linking_key_columns]

    org_key_columns = ["entityId", "subProductName"]
    org_fill_cols = [col for col in org_cols if col not in org_key_columns]

    plan_key_columns = ["entityId",]
    plan_fill_cols = [col for col in plan_cols if col not in plan_key_columns]

    comments_key_columns = ["entityId", "subProductName", "mnemonic",'reportId']
    comments_fill_cols = [col for col in comments_cols if col not in comments_key_columns]

    schedule_key_columns = ["entityId", "subProductName", "mnemonic",'reportId']
    schedule_fill_cols = [col for col in schedule_cols if col not in schedule_key_columns]

    dataPointsCols = ["mnemonic", "value", "schedules", "comments", "unitType"]
    dataPointsColName = "datapoints"
    scheduleColName = "schedules"
    commentsColName = "comments"

    final_columns = ['entityId', 'orgPrimaryName', 'subProductName', 'spOrgId', 'mappedAsid', 'period', 
                    'aprAcceptable', 'state', 'countryCode', 'currencyCode','reportId','keywordName','workType',
                    'receivedDate', 'taggedDate',
                    'dueDate', 'fdmDueDate', 'finalDueDate', 'finalTime', 'dcCompletionDate', 
                    'taggedFiles', 'referenceFiles'
                    ]

    # Rename columns for all source DataFrames
    # Removed wide-row distinct() to avoid unnecessary shuffle; duplicates handled later on key projections
    renamed_columns_driving_df = (
        driving_df.withColumnsRenamed(rename_source_columns)
        .select(*driving_cols)
    )

    # Removed wide-row distinct() for comments to reduce shuffle
    renamed_columns_comments_df = (
        comments_df.withColumnsRenamed(rename_source_columns)
        .select(*comments_cols)
    )

    # Removed wide-row distinct() for schedules to reduce shuffle
    renamed_columns_schedule_df = (
        schedule_df.withColumnsRenamed(rename_source_columns)
        .select(*schedule_cols)
    )

    # CREATE COMPREHENSIVE BASE: Union all unique entity-mnemonic combinations
    # Get base keys from driving data
    driving_base_keys = renamed_columns_driving_df.select("entityId", "subProductName", "mnemonic", "reportId").distinct()
    
    # Get base keys from comments (for mnemonics that might not be in driving)
    comments_base_keys = renamed_columns_comments_df.select("entityId", "subProductName", "mnemonic", "reportId").distinct()
    
    # Get base keys from schedules (for mnemonics that might not be in driving)
    schedule_base_keys = renamed_columns_schedule_df.select("entityId", "subProductName", "mnemonic", "reportId").distinct()
    
    # Union all base keys to get comprehensive mnemonic list
    comprehensive_base_keys = driving_base_keys.unionByName(comments_base_keys).unionByName(schedule_base_keys).distinct()
    
    # Left join comprehensive base with driving data to get values where available
    comprehensive_driving_df = comprehensive_base_keys.join(
        renamed_columns_driving_df,
        ["entityId", "subProductName", "mnemonic", "reportId"],
        "left"
    )

    # For records without driving data, inherit properties from other datapoints of the same entity/subProductName/reportId
    # Create a template record with non-mnemonic-specific data for each entity/subProductName/reportId combination
    # Use first() to ensure we get only one record per entity combination to avoid duplicate rows
    entity_template_df = renamed_columns_driving_df.select(
        "entityId", "subProductName", "reportId",
        *[col for col in driving_cols if col not in ["mnemonic", "value"]]
    ).groupBy("entityId", "subProductName", "reportId").agg(
        *[F.first(col_name).alias(col_name) for col_name in driving_cols if col_name not in ["mnemonic", "value", "entityId", "subProductName", "reportId"]]
    )
    
    # For missing driving data, fill with entity template (inherit period info, dates, etc.)
    # First identify records that don't have driving data (where periodEndDate is null)
    missing_driving_data = comprehensive_driving_df.filter(F.col("periodEndDate").isNull())
    has_driving_data = comprehensive_driving_df.filter(F.col("periodEndDate").isNotNull())
    
    # Join missing records with entity template to inherit non-mnemonic properties
    # This join should be 1:1 since entity_template_df has one record per entity/subProductName/reportId
    # Select only the mnemonic-specific columns from missing_driving_data to avoid column conflicts
    missing_data_keys = missing_driving_data.select("entityId", "subProductName", "mnemonic", "reportId", "value")
    
    filled_missing_data = missing_data_keys.join(
        entity_template_df,
        ["entityId", "subProductName", "reportId"],
        "left"
    )
    
    # Ensure filled_missing_data has the same column order as has_driving_data to avoid union issues
    # Get column order from has_driving_data and select in that order for both DataFrames
    column_order = has_driving_data.columns
    has_driving_data_ordered = has_driving_data.select(*column_order)
    
    # For filled_missing_data, only select columns that exist and avoid duplicates
    available_columns = [col for col in column_order if col in filled_missing_data.columns]
    filled_missing_data_ordered = filled_missing_data.select(*available_columns)
    
    # Add any missing columns to filled_missing_data with null values
    for col_name in column_order:
        if col_name not in filled_missing_data_ordered.columns:
            filled_missing_data_ordered = filled_missing_data_ordered.withColumn(col_name, F.lit(None))
    
    # Reorder columns to match has_driving_data exactly
    filled_missing_data_ordered = filled_missing_data_ordered.select(*column_order)
    
    # Union back together: records with driving data + records with inherited template data
    comprehensive_driving_df = has_driving_data_ordered.unionByName(filled_missing_data_ordered, allowMissingColumns=True)

    # Add missing columns with appropriate defaults only if still missing
    for col_name in driving_cols:
        if col_name not in comprehensive_driving_df.columns:
            if col_name == "unitType":
                comprehensive_driving_df = comprehensive_driving_df.withColumn(col_name, F.lit(""))
            else:
                comprehensive_driving_df = comprehensive_driving_df.withColumn(col_name, F.lit(None))

    # Add unknown driving columns
    for col_nm in unknown_driving_columns:
        if col_nm not in comprehensive_driving_df.columns:
            comprehensive_driving_df = comprehensive_driving_df.withColumn(col_nm, F.lit(None))

    # Create period structure (now inherited from entity template, so should not be null)
    refined_per_driving_df = comprehensive_driving_df.withColumn(
        periodColumnName,
        F.struct([comprehensive_driving_df[x] for x in periodCols]),
    )

    logger.info("Comprehensive Driving DataFrame Schema:")
    refined_per_driving_df.printSchema()

    # Removed wide-row distinct() for linking data; key-level distinct applied when aggregating
    renamed_columns_link_df = (
        asid_linking_df.withColumnsRenamed(rename_source_columns)
        .select(*asid_linking_cols)
    )

    # Removed wide-row distinct() for plan data
    renamed_columns_plan_df = (
        plan_data_df.withColumnsRenamed(rename_source_columns)
        .select(*plan_cols)
    )

    agg_link_exprs = [F.collect_list(col).alias(f"{col}") for col in asid_linking_fill_cols]

    refined_link_df = (
        renamed_columns_link_df.groupBy(asid_linking_key_columns)
        .agg(*agg_link_exprs)
        .withColumn("spOrgId", F.when(F.size(F.col("spOrgId")) == 1, F.col("spOrgId")[0].cast("string")).otherwise(F.col("spOrgId").cast("string")))
    )

    logger.info("Refined Linking DataFrame Schema:")
    refined_link_df.printSchema()
    # getting only the rows that are present in t_dc_transaction_plan_org table
    refined_df_with_plan_data = generic_join_fill(refined_per_driving_df, renamed_columns_plan_df, plan_key_columns, plan_fill_cols, "inner")
    
    # getting only the rows that are NOT present in t_dc_transaction_plan_org table and use them for the following joins
    refined_df_without_plan_data = generic_join_fill(refined_per_driving_df, renamed_columns_plan_df, plan_key_columns, [], "left_anti")

    fin_link_df = generic_join_fill(refined_df_without_plan_data, refined_link_df, asid_linking_key_columns, asid_linking_fill_cols, "left")

    logger.info("Final Linking DataFrame Schema:")
    fin_link_df.printSchema()

    # Removed wide-row distinct() for org data; rely on later grouping logic
    renamed_columns_org_df = (
        org_df.withColumnsRenamed(rename_source_columns)
        .select(*org_cols)
    )

    fin_org_df = generic_join_fill(fin_link_df, renamed_columns_org_df, org_key_columns, org_fill_cols, "left")

    # unioning the rows with plan data back to the final organization dataframe
    fin_org_df = fin_org_df.unionByName(refined_df_with_plan_data, allowMissingColumns=True)

    logger.info("Final Organization DataFrame Schema:")
    fin_org_df.printSchema()

    # Process comments - now using the already renamed DataFrame
    aggr_comm_df = (
        renamed_columns_comments_df.withColumn(commentsColName, F.struct([renamed_columns_comments_df[x] for x in comments_fill_cols]))
        .select(*(comments_key_columns + [commentsColName]))
        .groupBy(*comments_key_columns)
        .agg(F.collect_list(commentsColName).alias(commentsColName))
    )

    logger.info("Aggregated Comments DataFrame Schema:")
    aggr_comm_df.printSchema()

    fin_com_df = generic_join_fill(fin_org_df, aggr_comm_df, comments_key_columns, [commentsColName], "left")

    logger.info("Final Comments DataFrame Schema:")
    fin_com_df.printSchema()

    # Process schedules - now using the already renamed DataFrame
    aggr_schd_df = (
        renamed_columns_schedule_df.withColumn(scheduleColName, F.struct([renamed_columns_schedule_df[x] for x in schedule_fill_cols]))
        .select(*(schedule_key_columns + [scheduleColName]))
        .groupBy(*schedule_key_columns)
        .agg(F.collect_list(scheduleColName).alias(scheduleColName))
    )

    logger.info("Aggregated Schedule DataFrame Schema:")
    aggr_schd_df.printSchema()

    fin_sch_df = generic_join_fill(fin_com_df, aggr_schd_df, schedule_key_columns, [scheduleColName], "left")

    logger.info("Final Schedule DataFrame Schema:")
    fin_sch_df.printSchema()

    # Removed redundant distinct() before groupBy to avoid double shuffle
    gr_fin_dp_df = (
        fin_sch_df.withColumn(dataPointsColName, F.struct([fin_sch_df[x] for x in dataPointsCols]))
        .select(*(final_columns + [dataPointsColName]))
        .groupBy(*final_columns)
        .agg(F.collect_list(dataPointsColName).alias(dataPointsColName))
    )
    
    logger.info("Grouped Final DataPoints DataFrame Schema:")
    gr_fin_dp_df.printSchema()
    gr_fin_dp_df.show(truncate=False)

    return gr_fin_dp_df


def run_healthcare_data_pipeline(
    df: DataFrame,
    s3_base_path: str,
    dry_run: bool = False,
    verbose: bool = False,
    show_all_messages: bool = False,
    env=None
):
    """
    Main function to execute the healthcare data pipeline

    Args:
        df: Dataframe containing healthcare data
        s3_base_path: Base S3 path for writing data
        dry_run: If True, don't actually write to S3 or send to Kafka
        verbose: If True, show detailed status for each record
        show_all_messages: If True, show all Kafka messages sent

    Returns:
        Dictionary containing pipeline results
    """
    databricks_mode = is_running_in_databricks()
    try:
        # Create handlers
        s3_handler = S3DataHandler(s3_base_path)
        metadata_generator = HealthcareMetadataGenerator()
        

        # Check if the dataframe already has a dataset column with JSON data
        if "dataset" not in df.columns:
            json_df = df.withColumn(
                "dataset", F.to_json(F.struct([df[x] for x in df.columns]))
            )
        else:
            json_df = df

        # Process each record
        rows = json_df.select("dataset").collect()
        total_records = len(rows)
        logger.info(f"Processing {total_records} healthcare records")

        # Result tracking
        records_processed = 0
        s3_success = 0
        s3_failed = 0
        kafka_sent = 0
        kafka_failed = 0
        metadata_records = []
        record_status_details = []
        kafka_messages_sent = []

        # Create Kafka producer if not in dry run mode
        kafka_handler = None
        if not dry_run:
            kafka_config_dict = get_kafka_config(env=env)
            kafka_handler = KafkaHandler(kafka_config_dict)

        for i, row in enumerate(rows):
            record_status = {
                "record_index": i + 1,
                "s3_status": "N/A",
                "kafka_status": "N/A",
                "errors": [],
            }

            try:
                json_data = row["dataset"]
                row_dict = json.loads(json_data)

                entity_id = str(row_dict.get("entityId", "unknown"))
                entity_name = row_dict.get("orgPrimaryName", "unknown")
                record_status["entity_id"] = entity_id
                record_status["entity_name"] = entity_name

                period_end_raw = row_dict.get("period", {}).get("periodEndDate")
                if period_end_raw:
                    try:
                        period_end_token = datetime.datetime.strptime(period_end_raw, "%m/%d/%Y").strftime("%Y%m%d")
                    except ValueError:
                        period_end_token = period_end_raw.replace("/", "")
                else:
                    period_end_token = "unknownPeriod"


                runtime_stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
                file_token = f"{period_end_token}_{runtime_stamp}"


                file_path = s3_handler.generate_file_path(
                    entity_id, entity_name, file_token
                )
                record_status["file_path"] = file_path

                metadata = metadata_generator.generate_metadata(row_dict, file_path)
                metadata_json = json.dumps(metadata)
                metadata_records.append(metadata_json)

                if not dry_run:
                    try:
                        print(file_path)
                        s3_result = s3_handler.write_json_to_s3(row_dict, file_path)
                        if s3_result:
                            s3_success += 1
                            record_status["s3_status"] = "SUCCESS"
                        else:
                            s3_failed += 1
                            record_status["s3_status"] = "FAILED"
                            record_status["errors"].append("S3 write failed")
                    except Exception as e:
                        s3_failed += 1
                        error_msg = f"S3 error: {str(e)}"
                        record_status["s3_status"] = "ERROR"
                        record_status["errors"].append(error_msg)
                        logger.error(error_msg)
                else:
                    record_status["s3_status"] = "SKIPPED (dry-run)"

                records_processed += 1

            except Exception as e:
                error_msg = f"Record processing error: {str(e)}"
                traceback.print_exc()
                record_status["errors"].append(error_msg)
                logger.error(error_msg)

            record_status_details.append(record_status)

        if not dry_run and kafka_handler and metadata_records:
            print("\n===== Sample Kafka Message =====")
            print(json.dumps(json.loads(metadata_records[0]), indent=2))
            print("===============================\n")

            for i, message in enumerate(metadata_records):
                record_status = record_status_details[i]
                try:
                    kafka_handler.send(message)
                    kafka_sent += 1
                    record_status["kafka_status"] = "SUCCESS"
                    parsed_message = json.loads(message)
                    record_status["kafka_message"] = parsed_message
                    kafka_messages_sent.append(parsed_message)
                except Exception as e:
                    kafka_failed += 1
                    error_msg = f"Kafka error: {str(e)}"
                    record_status["kafka_status"] = "FAILED"
                    record_status["errors"].append(error_msg)
                    logger.error(error_msg)

            kafka_handler.close()
        else:
            for record_status in record_status_details:
                record_status["kafka_status"] = "SKIPPED (dry-run)"

        if show_all_messages and kafka_messages_sent:
            print("\n===== All Kafka Messages Sent =====")
            for i, message in enumerate(kafka_messages_sent):
                print(f"\nMessage #{i+1}:")
                print(json.dumps(message, indent=2))
            print("==================================\n")

        if verbose or show_all_messages:
            print("\n===== Detailed Record Status =====")
            for status in record_status_details:
                print(f"\nRecord #{status['record_index']}:")
                print(f"  Entity ID: {status.get('entity_id', 'N/A')}")
                print(f"  Entity Name: {status.get('entity_name', 'N/A')}")
                print(f"  S3 Status: {status['s3_status']}")
                print(f"  Kafka Status: {status['kafka_status']}")
                if status["errors"]:
                    print("  Errors:")
                    for error in status["errors"]:
                        print(f"    - {error}")
            print("==================================\n")

        result = {
            "status": "success",
            "records_processed": records_processed,
            "s3_writes_successful": s3_success,
            "s3_writes_failed": s3_failed,
            "kafka_messages_sent": kafka_sent,
            "kafka_messages_failed": kafka_failed,
            "record_status_details": record_status_details,
            "all_kafka_messages": kafka_messages_sent if show_all_messages else None,
        }

        print("\n===== Pipeline Summary =====")
        print(f"Total records processed: {records_processed}/{total_records}")
        print(f"S3 writes successful: {s3_success}")
        print(f"S3 writes failed: {s3_failed}")
        print(f"Kafka messages sent: {kafka_sent}")
        print(f"Kafka messages failed: {kafka_failed}")
        print(
            "\nUse the returned 'record_status_details' for individual record processing status"
        )
        print(
            "All Kafka messages and record status details are now included in the result object"
        )

        return result

    except Exception as e:
        logger.error(f"Pipeline failed: {str(e)}")
        import traceback

        traceback.print_exc()
        return {
            "status": "failed",
            "error": str(e),
        }

def get_all_successful_files(process_date: str, target_tables: list, file_log: str) -> dict:
    """
    Returns a dictionary mapping each table to a list of successfully processed file names
    for that table on the given processing date.
    """
    control_df = spark.table(file_log)

    filtered_df = control_df.filter(
        (col("process_date") == process_date) &
        (col("status") == "SUCCESS") &
        (col("target_table").isin(target_tables))
    )

    file_map = (
        filtered_df.groupBy("target_table")
        .agg(collect_list("file_name").alias("file_names"))
        .rdd.map(lambda row: (row["target_table"], row["file_names"]))
        .collectAsMap()
    )

    return file_map

def get_latest_data(df):
    """Original method - kept for backward compatibility"""
    # get the latest run_id
    latest_run_id = df.agg({"run_id": "max"}).collect()[0][0]

    # fetch data based on latest run_id
    latest_data = df.filter(df.run_id == latest_run_id)
    return latest_data

def get_latest_data_with_related_mnemonics(df, comments_df=None, schedule_df=None):
    """
    Get latest run_id data plus any additional records for mnemonics 
    that exist in comments/schedules but might not be in the latest run.
    """
    # Get the latest run_id data (existing logic)
    latest_run_id = df.agg({"run_id": "max"}).collect()[0][0]
    latest_data = df.filter(df.run_id == latest_run_id)
    
    # If no comments or schedules provided, return just latest data
    if comments_df is None and schedule_df is None:
        return latest_data
    
    # Get unique combinations from comments and schedules
    related_keys = None
    
    if comments_df is not None:
        comments_keys = comments_df.select("PHOENIX_ID", "SECTOR_NAME", "SRC_DE_UNIQ_ID_TEXT", "REPORT_ID").distinct()
        related_keys = comments_keys
    
    if schedule_df is not None:
        schedule_keys = schedule_df.select("PHOENIX_ID", "SECTOR_NAME", "SRC_DE_UNIQ_ID_TEXT", "REPORT_ID").distinct()
        if related_keys is not None:
            related_keys = related_keys.unionByName(schedule_keys).distinct()
        else:
            related_keys = schedule_keys
    
    # Ensure related_keys is distinct in case of overlapping mnemonics between comments and schedules
    if related_keys is not None:
        related_keys = related_keys.distinct()
    
    if related_keys is None:
        return latest_data
    
    # Get the key combinations that are already in latest data
    latest_keys = latest_data.select("PHOENIX_ID", "SECTOR_NAME", "SRC_DE_UNIQ_ID_TEXT", "REPORT_ID").distinct()
    
    # Find keys that are in comments/schedules but NOT in latest data
    missing_keys = related_keys.join(
        latest_keys,
        ["PHOENIX_ID", "SECTOR_NAME", "SRC_DE_UNIQ_ID_TEXT", "REPORT_ID"],
        "left_anti"
    )
    
    logger.info(f"Latest run_id records: {latest_data.count()}")
    logger.info(f"Missing key combinations from comments/schedules: {missing_keys.count()}")
    
    if missing_keys.count() == 0:
        return latest_data
    
    # For missing keys, get the most recent data from dp_load (regardless of run_id)
    # Add row_number to get the most recent record for each key combination
    window_spec = Window.partitionBy("PHOENIX_ID", "SECTOR_NAME", "SRC_DE_UNIQ_ID_TEXT", "REPORT_ID").orderBy(desc("run_id"))
    
    # Get most recent records for missing keys
    missing_data = df.join(
        missing_keys,
        ["PHOENIX_ID", "SECTOR_NAME", "SRC_DE_UNIQ_ID_TEXT", "REPORT_ID"],
        "inner"
    ).withColumn("rn", row_number().over(window_spec)).filter(col("rn") == 1).drop("rn")
    
    logger.info(f"Additional records found for missing keys: {missing_data.count()}")
    
    # Union latest data with missing data
    comprehensive_data = latest_data.unionByName(missing_data, allowMissingColumns=True).distinct()
    
    logger.info(f"Total comprehensive driving data: {comprehensive_data.count()}")
    
    return comprehensive_data


def run_elt_process(spark, params: dict, config, env=None):
    """Main ELT process with proper error handling and logging."""
    logger.info("run_elt_process start")
    try:
        # Configuration setup
        raw_catalog_schema = f"{config.get('raw_catalog')}.{config.get('raw_schema')}"
        curated_catalog_schema = f"{config.get('curated_catalog')}.{config.get('curated_schema')}"
        s3_bucket = params["s3_bucket"]
        output_dir = params["output_dir"]
        process_date = params.get('process_date')
        
        # Data loading
        tables = params["tables"]
        driving_table = f"{curated_catalog_schema}.{tables['driving']}"
        asid_linking_table = f"{raw_catalog_schema}.{tables['asid_linking']}"
        comments_table = f"{curated_catalog_schema}.{tables['comments']}"
        schedule_table = f"{curated_catalog_schema}.{tables['schedule']}"
        org_table = f"{curated_catalog_schema}.{tables['org']}"
        plan_data_table = f"{curated_catalog_schema}.{tables['plan_org']}"

        s3_path = f"s3://{s3_bucket}/{output_dir}"
        
        # Load data
        logger.info("Loading source data...")
        
        # Load comments and schedules first to get their latest data
        comments_df = get_latest_data(spark.table(comments_table))
        schedule_df = get_latest_data(spark.table(schedule_table))
        
        # Load driving data with comprehensive approach
        driving_df_full = spark.table(driving_table)
        driving_df = get_latest_data_with_related_mnemonics(
            driving_df_full, 
            comments_df=comments_df, 
            schedule_df=schedule_df
        )
        
        org_df = spark.table(org_table)
        asid_linking_df = spark.table(asid_linking_table)
        plan_data_df = spark.table(plan_data_table)

        # Data Refinement
        logger.info("Starting data refinement...")
        gr_fin_dp_df = refine_driving_data(
                driving_df=driving_df,
                asid_linking_df=asid_linking_df,
                org_df=org_df,
                comments_df=comments_df,
                schedule_df=schedule_df,
                plan_data_df=plan_data_df
            ).distinct()
        logger.info(f"Refined data: {gr_fin_dp_df.count()} records")
        
        # SCD2 Processing
        logger.info("Starting SCD2 processing...")
        latest_base_df = persist_scd2_batch(gr_fin_dp_df, config)
        logger.info(f"SCD2 processing complete: {latest_base_df.count()} active records")

        # Period Merge Logic    
        logger.info("Starting period merge logic...")
        period_merge_table_name = config.get("period_merge")
        staging_table_name = config.get("period_merge_staging")
        # Full table names with schema
        period_merge_table = f"{curated_catalog_schema}.{period_merge_table_name}"
        staging_table = f"{curated_catalog_schema}.{staging_table_name}"
        period_merge_logic_incremental(
                spark,
                latest_base_df,
                period_merge_table,  # Pass full table name
                staging_table,       # Pass full table name
                config
            )

        # Read from the correct final table
        period_merge_df = spark.table(period_merge_table)
        logger.info(f"Period merge complete: {period_merge_df.count()} records")
        # Verify schema before JSON generation
        logger.info("Period merge table schema:")
        period_merge_df.printSchema()
        # Generate JSON for Kafka
        logger.info("Generating Kafka messages...")
        
        # Get contract configuration from config file or config parameter
        kafka_contract_config = config.get("kafka_contract")
        if kafka_contract_config is None:
            kafka_contract_config = load_kafka_contract_config()
            
        df_json = generate_kafka_json_message(period_merge_df, kafka_contract_config)
        logger.info(f"Generated {df_json.count()} Kafka messages")

        # Execute pipeline
        return run_healthcare_data_pipeline(
            df_json,
            s3_path,
            dry_run=params.get("dry_run", False),
            verbose=params.get("verbose", False),
            show_all_messages=params.get("show_all_messages", False),
            env=env
        )
    except Exception as e:
        logger.error(f"ELT process failed: {str(e)}")
        raise

def validate_scd2_config(config):
    """Validate required SCD2 configuration parameters."""
    required_keys = ['raw_catalog', 'raw_schema', 'fin_group_linked_scd2', 'scd2_keys']
    missing_keys = [key for key in required_keys if not config.get(key)]
    if missing_keys:
        raise ValueError(f"Missing required configuration keys: {missing_keys}")

def load_kafka_contract_config(config_file: str = "kafka_contract_config.json") -> dict:
    """
    Loads Kafka contract configuration from JSON file using resource loading.
    
    Parameters:
        config_file: Name of the configuration JSON file
        
    Returns:
        Dictionary containing contract configuration
    """
    try:
        # Load config using the same resource loading pattern as other configs
        resource_package = "data_services.my_data_incremental.config"
        resource_path = files(resource_package).joinpath(config_file)

        with resource_path.open("r", encoding="utf-8") as f:
            raw_config = f.read()
            
        config = json.loads(raw_config)
        return config.get("kafka_contract", {})
        
    except FileNotFoundError:
        print(f"Kafka contract config file '{config_file}' not found, using defaults")
        return {}
    except Exception as e:
        print(f"Error loading Kafka contract config: {str(e)}, using defaults")
        return {}
