import json
import time
import traceback
from datetime import datetime
from importlib.resources import files
from pyspark.sql.functions import col, from_unixtime, udf, unix_timestamp
from pyspark.sql.types import StringType, StructField, StructType
from data_services.my_data_incremental.transformation.utils import log_pipeline_event
from data_services.my_data_incremental.curation.load_curated_table import load_curated
from data_services.my_data_incremental.linking.consumer import LinkConsumer
from data_services.my_data_incremental.linking.producer import LinkProducer


class AsidLinking:
    def __init__(self, env, spark, dbutils, process_date):
        self.env = env
        self.spark = spark
        self.dbutils = dbutils
        self.process_date = process_date

    # def load_table_configs(self, config_path: str):
    #     try:
    #         with open(config_path, "r") as config_file:
    #             return json.load(config_file)
    #     except Exception as e:
    #         log_pipeline_event("curation_config", "error_loading_config", {"error": str(e)})
    #         return []


    def safe_display_html(self, title: str, content: str | dict, show_html: bool = True, error: bool = False):
        """Display HTML if show_html is enabled (Databricks-only)."""
        if not show_html:
            return

        try:
            from IPython.display import HTML, display
            if isinstance(content, dict):
                content_html = f"<pre>{json.dumps(content, indent=2)}</pre>"
            else:
                content_html = f"<pre>{content}</pre>"

            if error:
                display(HTML(f"<h2 style='color: red;'>{title}</h2>{content_html}"))
            else:
                display(HTML(f"<h3>{title}</h3>{content_html}"))
        except ImportError:
            pass


    def check_for_new_records(self, metadata_catalog,metadata_schema,metadata_date_table,metadata_file_table):
        try:
            log_pipeline_event("check_metadata", "started", {"process_date": self.process_date})

            metadata_date_log = f'{metadata_catalog}.{metadata_schema}.{metadata_date_table}'
            metadata_file_log = f'{metadata_catalog}.{metadata_schema}.{metadata_file_table}'

            date_log_df = self.spark.sql(f"""
                SELECT 
                    process_date, 
                    MAX(completed_at) as latest_completion,
                    SUM(message_count) as total_messages,
                    SUM(file_count) as total_files,
                    SUM(error_count) as total_errors
                FROM {metadata_date_log}
                WHERE process_date = '{self.process_date}'
                AND status = 'COMPLETED'
                GROUP BY process_date
            """)

            if date_log_df.count() == 0:
                log_pipeline_event("check_metadata", "no_records", {"process_date": self.process_date})
                return {
                    "status": "no_records",
                    "message": f"No completed records found for date {self.process_date}",
                    "process_date": self.process_date
                }

            date_record = date_log_df.first()
            total_messages = date_record["total_messages"]
            total_files = date_record["total_files"]
            latest_completion = date_record["latest_completion"]

            phoenix_ids_df = self.spark.sql(f"""
                SELECT DISTINCT phoenix_id
                FROM {metadata_file_log}
                WHERE process_date = '{self.process_date}'
                AND status = 'SUCCESS'
            """)

            phoenix_id_count = phoenix_ids_df.count()
            phoenix_ids = [row["phoenix_id"] for row in phoenix_ids_df.collect()]

            result = {
                "status": "success",
                "process_date": self.process_date,
                "latest_completion": str(latest_completion),
                "total_messages": total_messages,
                "total_files": total_files,
                "phoenix_id_count": phoenix_id_count,
                "phoenix_ids": phoenix_ids
            }

            log_pipeline_event("check_metadata", "completed", result)
            return result

        except Exception as e:
            error_details = {"process_date": self.process_date, "error": str(e)}
            log_pipeline_event("check_metadata", "error", error_details)
            raise


    def check_existing_org_linking(self, config):
        """Check which phoenix_ids already have sp_org_id in org_linking_table"""
        try:
            log_pipeline_event("check_org_linking", "started")
            
            # Get phoenix_ids from metadata
            metadata_catalog = config.get("metadata_catalog")
            metadata_schema = config.get("metadata_schema") 
            metadata_file_table = config.get("metadata_file_table")
            org_linking_table = config.get("org_linking_table")
            
            metadata_file_log = f'{metadata_catalog}.{metadata_schema}.{metadata_file_table}'
            
            # Get all phoenix_ids that need processing
            phoenix_ids_df = self.spark.sql(f"""
                SELECT DISTINCT phoenix_id
                FROM {metadata_file_log}
                WHERE process_date = '{self.process_date}'
                AND status = 'SUCCESS'
                AND phoenix_id IS NOT NULL
            """)
            
            total_phoenix_ids = phoenix_ids_df.count()
            log_pipeline_event("check_org_linking", "total_phoenix_ids", {"count": total_phoenix_ids})
            
            if total_phoenix_ids == 0:
                return {
                    "status": "no_records",
                    "total_phoenix_ids": 0,
                    "existing_in_table": 0,
                    "need_kafka_lookup": 0,
                    "existing_phoenix_ids": [],
                    "kafka_phoenix_ids": []
                }
            
            # Check if org_linking_table exists and has records
            existing_records_df = None
            if org_linking_table and self.spark.catalog.tableExists(org_linking_table):
                existing_records_df = self.spark.sql(f"""
                    SELECT DISTINCT ol.id_value as phoenix_id, ol.sp_org_id
                    FROM {org_linking_table} ol
                    INNER JOIN (
                        SELECT DISTINCT phoenix_id 
                        FROM {metadata_file_log}
                        WHERE process_date = '{self.process_date}'
                        AND status = 'SUCCESS'
                    ) meta ON ol.id_value = meta.phoenix_id
                    WHERE ol.id_type = 'PHOENIXID' 
                    AND ol.sp_org_id IS NOT NULL
                    AND TRIM(ol.sp_org_id) != ''
                """)
                
                existing_count = existing_records_df.count()
                existing_phoenix_ids = [row["phoenix_id"] for row in existing_records_df.collect()]
            else:
                existing_count = 0
                existing_phoenix_ids = []
                log_pipeline_event("check_org_linking", "no_table", {"table": org_linking_table})
            
            # Phoenix IDs that need Kafka lookup (not found in org_linking_table)
            all_phoenix_ids = [row["phoenix_id"] for row in phoenix_ids_df.collect()]
            kafka_phoenix_ids = [pid for pid in all_phoenix_ids if pid not in existing_phoenix_ids]
            
            result = {
                "status": "success",
                "total_phoenix_ids": total_phoenix_ids,
                "existing_in_table": existing_count,
                "need_kafka_lookup": len(kafka_phoenix_ids),
                "existing_phoenix_ids": existing_phoenix_ids,
                "kafka_phoenix_ids": kafka_phoenix_ids
            }
            
            log_pipeline_event("check_org_linking", "completed", result)
            return result
            
        except Exception as e:
            error_details = {"error": str(e)}
            log_pipeline_event("check_org_linking", "error", error_details)
            raise

    def run_kafka_producer(self, kafka_phoenix_ids=None):
        try:
            log_pipeline_event("kafka_producer", "started")

            if kafka_phoenix_ids is not None and len(kafka_phoenix_ids) == 0:
                log_pipeline_event("kafka_producer", "no_records_to_send")
                return {
                    "status": "no_records",
                    "message": "No phoenix_ids need Kafka lookup"
                }

            try:
                producer = LinkProducer(env=self.env, process_date=self.process_date,spark=self.spark, dbutils=self.dbutils)
                # Pass the filtered phoenix_ids to producer
                producer.produce_linking(phoenix_ids_filter=kafka_phoenix_ids)
            except Exception as notebook_error:
                log_pipeline_event("kafka_producer", "notebook_error", {"error": str(notebook_error)})
                raise

            return {
                "status": "success",
            }

        except Exception as e:

            error_details = {"error": str(e)}
            log_pipeline_event("kafka_producer", "error", error_details)
            raise


    def run_kafka_consumer(self):
        try:
            log_pipeline_event("kafka_consumer", "started")


            wait_seconds = 10
            log_pipeline_event("kafka_consumer", "waiting", {"seconds": wait_seconds})
            time.sleep(wait_seconds)

            log_pipeline_event("kafka_consumer", "running", {"params": "consumer_params"})

            consumer = LinkConsumer(env=self.env, spark = self.spark, dbutils=self.dbutils)
            consumer_result = consumer.run_consumer_pipeline()

            log_pipeline_event("kafka_consumer", "completed", consumer_result)

            return {
                "status": "success",
                "consumer_result": consumer_result
            }

        except Exception as e:
            error_details = {"error": str(e)}
            log_pipeline_event("kafka_consumer", "error", error_details)
            raise


    def process_json_responses(self, config, existing_org_data=None):
        try:
            log_pipeline_event("transform_responses", "started")

            target_catalog = config.get("target_catalog")
            target_schema = config.get("target_schema")
            target_table = config.get("target_table")
            target_full_table = f"{target_catalog}.{target_schema}.{target_table}"
            recreate_target = config.get("recreate_target", False)
            messages_catalog = config.get("messages_catalog")
            messages_schema = config.get("messages_schema")
            messages_table = config.get("messages_table")

            messages_full_table = f"{messages_catalog}.{messages_schema}.{messages_table}"

            self.spark.sql(f"CREATE SCHEMA IF NOT EXISTS {target_catalog}.{target_schema}")

            table_exists = self.spark.sql(f"SHOW TABLES IN {target_catalog}.{target_schema}") \
                .filter(f"tableName = '{target_table}'").count() > 0

            if recreate_target:
                self.spark.sql(f"DROP TABLE IF EXISTS {target_full_table}")
                log_pipeline_event("transform_responses", "table_dropped", {"table": target_full_table})
                table_exists = False

            extract_schema = StructType([
                StructField("org_name", StringType(), True),
                StructField("sp_org_id", StringType(), True),
                StructField("phoenix_id", StringType(), True),
                StructField("status", StringType(), True),
                StructField("error_message", StringType(), True)
            ])

            def extract_phoenix_id(message_value):
                try:
                    message = json.loads(message_value) if isinstance(message_value, str) else message_value
                    phoenix_id = next((l.get("idValue") for l in message.get("orgLinkingRequest", {}).get("orgLinkings", []) if l.get("identifierType", {}).get("idType") == "PHOENIXID"), None)
                    return phoenix_id
                except Exception as e:
                    return None

            # Get org linking table from config
            org_linking_table = config.get("org_linking_table")
            def extract_org_data(phoenix_id, sp_org_id, message_value):
                try:
                    message = json.loads(message_value) if isinstance(message_value, str) else message_value
                    org_name = message.get("orgLinkingRequest", {}).get("primaryName")
                    
                    # Use sp_org_id from join if available (from org_linking_table)
                    if not sp_org_id:
                        sp_org_id = message.get("orgLinkingResponse", {}).get("id", {}).get("spOrgId")
                    
                    error_message = "; ".join(message.get("errorMessage", [])) if "errorMessage" in message else None
                    return {
                        "org_name": org_name,
                        "sp_org_id": str(sp_org_id) if sp_org_id else None,
                        "phoenix_id": phoenix_id,
                        "status": "ERROR" if error_message else "SUCCESS",
                        "error_message": error_message
                    }
                except Exception as e:
                    return {
                        "org_name": None,
                        "sp_org_id": None,
                        "phoenix_id": None,
                        "status": "PARSE_ERROR",
                        "error_message": str(e)
                    }

            extract_org_data_udf = udf(extract_org_data, extract_schema)
            extract_phoenix_id_udf = udf(extract_phoenix_id, StringType())

            # Process existing records from org_linking_table
            existing_df = None
            if existing_org_data and len(existing_org_data.get("existing_phoenix_ids", [])) > 0:
                log_pipeline_event("transform_responses", "processing_existing_records", {
                    "count": len(existing_org_data["existing_phoenix_ids"])
                })
                
                # Get existing records from org_linking_table with org names
                existing_query = f"""
                    SELECT 
                        '' as message_key,
                        NULL as org_name,
                        ol.sp_org_id,
                        ol.id_value as phoenix_id,
                        'SUCCESS' as status,
                        NULL as error_message,
                        current_timestamp() as process_time,
                        current_timestamp() as etl_timestamp
                    FROM {org_linking_table} ol
                    WHERE ol.id_type = 'PHOENIXID' 
                    AND ol.id_value IN ('{"', '".join(existing_org_data["existing_phoenix_ids"])}')
                    AND ol.sp_org_id IS NOT NULL
                    AND TRIM(ol.sp_org_id) != ''
                """
                existing_df = self.spark.sql(existing_query)

            # Process Kafka messages (only for phoenix_ids not found in org_linking_table)
            kafka_df = None
            if self.spark.catalog.tableExists(messages_full_table):
                messages_df = self.spark.table(messages_full_table)
                
                # Filter to only process phoenix_ids that need Kafka lookup
                if existing_org_data and len(existing_org_data.get("kafka_phoenix_ids", [])) > 0:
                    kafka_phoenix_filter = existing_org_data["kafka_phoenix_ids"]
                    messages_df = messages_df.filter(
                        extract_phoenix_id_udf(col("message_value")).isin(kafka_phoenix_filter)
                    )
                    log_pipeline_event("transform_responses", "filtering_kafka_messages", {
                        "phoenix_ids_to_process": len(kafka_phoenix_filter)
                    })

                org_linking_table_df = self.spark.table(org_linking_table) if org_linking_table and self.spark.catalog.tableExists(org_linking_table) else None
                org_linking_table_df = org_linking_table_df.where(col("id_type") == "PHOENIXID").select("id_value", "sp_org_id").distinct() if org_linking_table_df else None
                
                kafka_df = messages_df.withColumn("phoenix_id", extract_phoenix_id_udf(col("message_value")))
                if org_linking_table_df is not None:
                    kafka_df = kafka_df.join(org_linking_table_df, kafka_df["phoenix_id"] == org_linking_table_df["id_value"], "left")
                kafka_df = kafka_df.withColumn("extracted", extract_org_data_udf(col("phoenix_id"),col("sp_org_id"), col("message_value"))) \
                    .select(
                        col("message_key"),
                        col("extracted.org_name").alias("org_name"),
                        col("extracted.sp_org_id").alias("sp_org_id"),
                        col("extracted.phoenix_id").alias("phoenix_id"),
                        col("extracted.status").alias("status"),
                        col("extracted.error_message").alias("error_message"),
                        col("process_time"),
                        from_unixtime(unix_timestamp()).alias("etl_timestamp")
                    )

            # Combine existing and kafka results
            if existing_df is not None and kafka_df is not None:
                result_df = existing_df.union(kafka_df)
            elif existing_df is not None:
                result_df = existing_df
            elif kafka_df is not None:
                result_df = kafka_df
            else:
                # No data to process
                log_pipeline_event("transform_responses", "no_data", {"message": "No existing or kafka data to process"})
                return {"status": "success", "statistics": {"total_records_processed": 0}}

            total_count = result_df.count()
            success_count = result_df.filter(col("status") == "SUCCESS").count()
            error_count = result_df.filter(col("status") == "ERROR").count()
            parse_error_count = result_df.filter(col("status") == "PARSE_ERROR").count()

            if not table_exists:
                result_df.write.format("delta").mode("overwrite").option("mergeSchema", "true").saveAsTable(target_full_table)
                log_pipeline_event("transform_responses", "table_created", {"table": target_full_table})
                records_updated = 0
                records_inserted = total_count
            else:
                result_df.createOrReplaceTempView("all_extracted_responses")

                self.spark.sql("""
                    CREATE OR REPLACE TEMPORARY VIEW extracted_responses AS
                    WITH ranked_data AS (
                        SELECT *,
                            ROW_NUMBER() OVER (
                                PARTITION BY phoenix_id
                                ORDER BY CASE WHEN status = 'SUCCESS' THEN 0 ELSE 1 END, process_time DESC
                            ) AS row_num
                        FROM all_extracted_responses
                    )
                    SELECT * FROM ranked_data WHERE row_num = 1
                """)

                duplicate_check = self.spark.sql("""
                    SELECT phoenix_id, COUNT(*) as cnt
                    FROM extracted_responses
                    GROUP BY phoenix_id
                    HAVING COUNT(*) > 1
                """)

                if duplicate_check.count() > 0:
                    duplicates = duplicate_check.collect()
                    log_pipeline_event("transform_responses", "error", {
                        "message": f"Deduplication failed - {duplicate_check.count()} phoenix_ids still have duplicates",
                        "sample": str(duplicates[0])
                    })
                    raise Exception("Deduplication failed to eliminate all duplicates")

                before_count = self.spark.sql(f"SELECT COUNT(*) as count FROM {target_full_table}").first()["count"]

                self.spark.sql(f"""
                    MERGE INTO {target_full_table} AS target
                    USING extracted_responses AS source
                    ON target.phoenix_id = source.phoenix_id
                    WHEN MATCHED THEN
                        UPDATE SET
                            target.org_primary_name = source.org_name,
                            target.sp_org_id = source.sp_org_id,
                            target.status = source.status,
                            target.error_message = source.error_message,
                            target.process_time = source.process_time,
                            target.etl_timestamp = source.etl_timestamp
                    WHEN NOT MATCHED THEN
                        INSERT (
                            message_key, org_primary_name, sp_org_id, phoenix_id,
                            status, error_message, process_time, etl_timestamp
                        ) VALUES (
                            source.message_key, source.org_name, source.sp_org_id, source.phoenix_id,
                            source.status, source.error_message, source.process_time, source.etl_timestamp
                        )
                """)

                after_count = self.spark.sql(f"SELECT COUNT(*) as count FROM {target_full_table}").first()["count"]
                records_inserted = after_count - before_count
                records_updated = total_count - records_inserted

            stats = {
                "total_records_processed": total_count,
                "deduplicated_records": total_count - result_df.select("phoenix_id").distinct().count() if total_count > 0 else 0,
                "success_records": success_count,
                "error_records": error_count,
                "parse_error_records": parse_error_count,
                "records_updated": records_updated,
                "records_inserted": records_inserted,
                "target_table": target_full_table,
                "existing_records_processed": existing_df.count() if existing_df else 0,
                "kafka_records_processed": kafka_df.count() if kafka_df else 0
            }

            log_pipeline_event("transform_responses", "completed", stats)
            return {"status": "success", "statistics": stats}

        except Exception as e:
            log_pipeline_event("transform_responses", "error", {"error": str(e)})
            raise


    def prepare_org_table_structure(self, config):
        try:
            log_pipeline_event("prepare_org_table", "started")

            target_catalog = config.get("target_catalog")
            target_schema = config.get("target_schema")
            target_table = config.get("target_table")
            target_full_table = f"{target_catalog}.{target_schema}.{target_table}"

            
            table_exists = self.spark.catalog.tableExists(target_full_table)

            if not table_exists:
                log_pipeline_event("prepare_org_table", "error", {"message": f"Target table {target_full_table} does not exist"})
                return {"status": "error", "message": f"Target table {target_full_table} does not exist"}

            current_schema = self.spark.table(target_full_table).schema
            schema_columns = [field.name.lower() for field in current_schema.fields]

            required_columns = {
                "financial_sector": "STRING",
                "display_name": "STRING",
                "state": "STRING",
                "portfolio": "STRING"
            }

            if "asid" in schema_columns:
                log_pipeline_event("prepare_org_table", "removing_asid_column", {"table": target_full_table})
                temp_table_name = f"{target_catalog}.{target_schema}.{target_table}_temp"
                all_columns = [field.name for field in current_schema.fields if field.name.lower() != "asid"]
                columns_str = ", ".join(all_columns)

                self.spark.sql(f"CREATE OR REPLACE TABLE {temp_table_name} AS SELECT {columns_str} FROM {target_full_table}")
                self.spark.sql(f"DROP TABLE IF EXISTS {target_full_table}")
                self.spark.sql(f"ALTER TABLE {temp_table_name} RENAME TO {target_schema}.{target_table}")
                log_pipeline_event("prepare_org_table", "asid_column_removed", {"table": target_full_table})
                current_schema = self.spark.table(target_full_table).schema
                schema_columns = [field.name.lower() for field in current_schema.fields]

            columns_added = []
            for col_name, col_type in required_columns.items():
                if col_name.lower() not in schema_columns:
                    self.spark.sql(f"ALTER TABLE {target_full_table} ADD COLUMN {col_name} {col_type}")
                    columns_added.append(col_name)
                    log_pipeline_event("prepare_org_table", "column_added", {"column": col_name, "type": col_type})

            result = {
                "status": "success",
                "asid_removed": "asid" in schema_columns,
                "columns_added": columns_added,
                "table": target_full_table
            }

            log_pipeline_event("prepare_org_table", "completed", result)
            return result

        except Exception as e:
            log_pipeline_event("prepare_org_table", "error", {"error": str(e)})
            raise


    def create_and_update_asid_linking_table(self, config):
        try:
            log_pipeline_event("asid_linking_table", "started")

            target_catalog = config.get("target_catalog")
            target_schema = config.get("target_schema")
            target_table = config.get("target_table")
            asid_reference_table = config.get("asid_reference_table")
            transaction_table = config.get("t_dc_transaction_org")
            # Get mapping table for PhoenixID to CSID (direct parameter, not nested)
            phoenixid_map_table = config.get("phoenixid_map_table")
            phoenixid_map_table_full = f"{target_catalog}.{target_schema}.{phoenixid_map_table}"
            target_full_table = f"{target_catalog}.{target_schema}.{target_table}"
            reference_full_table =  f"{target_catalog}.{target_schema}.{asid_reference_table}"

            asid_org_linking_table = config.get("asid_org_linking_table")


            linking_table_name = f"{target_catalog}.{target_schema}.{asid_org_linking_table}"

            table_exists = self.spark.catalog.tableExists(f"{target_catalog}.{target_schema}.{asid_org_linking_table}")
            before_count = 0
            if table_exists:
                before_count = self.spark.sql(f"SELECT COUNT(*) as count FROM {target_catalog}.{target_schema}.{asid_org_linking_table}").first()["count"]

            self.spark.sql(f"""
                CREATE OR REPLACE TEMPORARY VIEW all_asid_mappings AS
                SELECT DISTINCT
                    m.SP_ORG_ID,
                    m.ASID,
                    m.EXPECTED_FINANCIAL_SECTOR AS FINANCIAL_SECTOR,
                    m.DISPLAY_NAME,
                    m.SECURITY,
                    m.SUBSECURITY
                FROM {reference_full_table} m
                WHERE m.ASID IS NOT NULL AND m.SP_ORG_ID IS NOT NULL
            """)

            from pyspark.sql.functions import col, trim, lower, udf
            from pyspark.sql.types import BooleanType
            # Load and normalize asid_mapping.csv
            data_pkg = f"data_services.my_data_incremental.config.data.dims.dims"
            ext = "json"
            data_path = files(data_pkg).joinpath(f"asid_mapping.{ext}")
            if not data_path.is_file():
                return False
            # Read the JSON file (support both single-line and multi-line JSON)
            with data_path.open("r", encoding="utf-8") as f:
                try:
                    # Try to load as a single JSON array or object
                    asid_mapping_data = json.load(f)
                except json.JSONDecodeError:
                    # If that fails, try to load as multi-line JSON (one object per line)
                    f.seek(0)
                    asid_mapping_data = [json.loads(line) for line in f if line.strip()]
            asid_mapping_df = self.spark.createDataFrame(asid_mapping_data)
            

            def normalize_bool(val):
                if val is None:
                    return False
                val = str(val).strip().lower()
                return val in ["true", "y", "yes", "1"]
            bool_udf = udf(normalize_bool, BooleanType())
            asid_mapping_df = asid_mapping_df.withColumn("Financial_Revenue_Type", bool_udf(col("Financial_Revenue_Type")))\
                                         .withColumn("Financial_Revenue_Sub_Type", bool_udf(col("Financial_Revenue_Sub_Type")))
            # Get sector lists
            type_sectors = [row["FINANCIAL_SECTOR_NAME"].strip().lower() for row in asid_mapping_df.filter(col("Financial_Revenue_Type") == True).collect()]
            subtype_sectors = [row["FINANCIAL_SECTOR_NAME"].strip().lower() for row in asid_mapping_df.filter(col("Financial_Revenue_Sub_Type") == True).collect()]
            deal_name_check_sectors = [row["FINANCIAL_SECTOR_NAME"].strip().lower() for row in asid_mapping_df.filter(col("Deal_Name_Check") == True).collect()]
            # Build join condition
            join_cond = ""
            if type_sectors:
                type_sectors_str = "', '".join(type_sectors)
                join_cond += f"(lower(trim(m.FINANCIAL_SECTOR)) IN ('{type_sectors_str}') AND t.FIN_REVENUE_TYPE = m.SECURITY)"
            if subtype_sectors:
                subtype_sectors_str = "', '".join(subtype_sectors)
                if join_cond:
                    join_cond += " OR "
                join_cond += f"(lower(trim(m.FINANCIAL_SECTOR)) IN ('{subtype_sectors_str}') AND t.FIN_REVENUE_SUBTYPE = m.SUBSECURITY)"
            if deal_name_check_sectors:
                deal_name_check_sectors_str = "', '".join(deal_name_check_sectors)
                if join_cond:
                    join_cond += " OR "
                join_cond += f"(lower(trim(m.FINANCIAL_SECTOR)) IN ('{deal_name_check_sectors_str}') AND t.DEAL_NAME_DESCRIPTOR = m.DISPLAY_NAME)"
            if join_cond:
                join_cond = f"({join_cond})"
            # Always join to the mapping table for CSID
            
            self.spark.sql(f"""
                CREATE OR REPLACE TEMPORARY VIEW org_with_asid_mapping AS
                SELECT DISTINCT
                    m.ASID,
                    t.PHOENIX_ID,
                    m.SP_ORG_ID,
                    pmap.finorg_id AS CSID,
                    m.FINANCIAL_SECTOR,
                    t.FIN_REVENUE_TYPE,
                    t.FIN_REVENUE_SUBTYPE,
                    t.DEAL_NAME_DESCRIPTOR
                FROM {transaction_table} t
                JOIN {target_full_table} stg ON t.PHOENIX_ID = stg.phoenix_id
                JOIN all_asid_mappings m ON {join_cond} AND m.SP_ORG_ID = stg.sp_org_id
                LEFT JOIN {phoenixid_map_table_full} pmap ON t.PHOENIX_ID = pmap.phoenix_entity_id
                WHERE m.SP_ORG_ID IS NOT NULL 
                AND t.PHOENIX_ID IS NOT NULL 
                AND stg.sp_org_id IS NOT NULL
                AND stg.status = 'SUCCESS'
            """)

            # Create view with records that don't have ASID mappings (insert with NULL ASID)
            self.spark.sql(f"""
                CREATE OR REPLACE TEMPORARY VIEW org_without_asid_mapping AS
                SELECT DISTINCT
                    NULL as ASID,
                    t.PHOENIX_ID,
                    stg.sp_org_id as SP_ORG_ID,
                    pmap.finorg_id AS CSID,
                    t.SECTOR as FINANCIAL_SECTOR,
                    t.FIN_REVENUE_TYPE,
                    t.FIN_REVENUE_SUBTYPE,
                    t.DEAL_NAME_DESCRIPTOR
                FROM {transaction_table} t
                JOIN {target_full_table} stg ON t.PHOENIX_ID = stg.phoenix_id
                LEFT JOIN all_asid_mappings m ON {join_cond} AND m.SP_ORG_ID = stg.sp_org_id
                LEFT JOIN {phoenixid_map_table_full} pmap ON t.PHOENIX_ID = pmap.phoenix_entity_id
                WHERE m.ASID IS NULL 
                AND t.PHOENIX_ID IS NOT NULL 
                AND stg.sp_org_id IS NOT NULL
                AND stg.status = 'SUCCESS'
            """)

            # Combine both views
            self.spark.sql(f"""
                CREATE OR REPLACE TEMPORARY VIEW all_org_mappings_tmp AS
                SELECT * FROM org_with_asid_mapping
                UNION ALL
                SELECT * FROM org_without_asid_mapping
            """)
            self.spark.sql(f"""
                CREATE OR REPLACE TEMPORARY VIEW all_org_mappings AS
                SELECT ASID,
                    PHOENIX_ID,
                    SP_ORG_ID,
                    FINANCIAL_SECTOR,
                    FIN_REVENUE_TYPE,
                    FIN_REVENUE_SUBTYPE,
                    DEAL_NAME_DESCRIPTOR,
                    CSID
                FROM (
                    SELECT *,
                        row_number() OVER (
                            PARTITION BY PHOENIX_ID, SP_ORG_ID, ASID
                            ORDER BY
                                CASE WHEN ASID IS NULL THEN 1 ELSE 0 END,
                                FINANCIAL_SECTOR,
                                FIN_REVENUE_TYPE,
                                FIN_REVENUE_SUBTYPE,
                                DEAL_NAME_DESCRIPTOR,
                                ASID,
                                CSID
                        ) as rn
                    FROM all_org_mappings_tmp
                )
                WHERE rn = 1
            """)
            # Use the combined view that includes both matched and unmatched records
            self.spark.sql(f"""
                MERGE INTO {linking_table_name} t
                USING all_org_mappings s
                ON t.PHOENIX_ID = s.PHOENIX_ID AND t.SP_ORG_ID = s.SP_ORG_ID AND t.ASID <=> s.ASID
                WHEN MATCHED THEN UPDATE SET
                    t.ASID = s.ASID,
                    t.FINANCIAL_SECTOR = s.FINANCIAL_SECTOR,
                    t.FIN_REVENUE_TYPE = s.FIN_REVENUE_TYPE,
                    t.FIN_REVENUE_SUBTYPE = s.FIN_REVENUE_SUBTYPE,
                    t.DEAL_NAME_DESCRIPTOR = s.DEAL_NAME_DESCRIPTOR,
                    t.CSID = s.CSID,
                    t.UPDATE_DATE = current_timestamp()
                WHEN NOT MATCHED THEN INSERT (
                    ASID, PHOENIX_ID, SP_ORG_ID, CSID, FINANCIAL_SECTOR, FIN_REVENUE_TYPE, FIN_REVENUE_SUBTYPE, DEAL_NAME_DESCRIPTOR, UPDATE_DATE
                ) VALUES (
                    s.ASID, s.PHOENIX_ID, s.SP_ORG_ID, s.CSID, s.FINANCIAL_SECTOR, s.FIN_REVENUE_TYPE, s.FIN_REVENUE_SUBTYPE, s.DEAL_NAME_DESCRIPTOR, current_timestamp()
                )
            """)

            duplicate_count = self.spark.sql(f"""
                WITH row_counts AS (
                    SELECT PHOENIX_ID, SP_ORG_ID, ASID, COUNT(*) as row_count
                    FROM {linking_table_name}
                    GROUP BY PHOENIX_ID, SP_ORG_ID, ASID
                    HAVING COUNT(*) > 1
                )
                SELECT SUM(row_count - 1) as duplicate_count FROM row_counts
            """).first()["duplicate_count"]

            if duplicate_count is not None and duplicate_count > 0:
                log_pipeline_event("asid_linking_table", "found_duplicates", {"count": duplicate_count})
                
                # Use DELETE to remove duplicates - rewritten to avoid multi-column IN predicate
                self.spark.sql(f"""
                    CREATE OR REPLACE TEMPORARY VIEW latest_records AS
                    SELECT PHOENIX_ID, SP_ORG_ID, ASID, MAX(UPDATE_DATE) as max_update_date
                    FROM {linking_table_name}
                    GROUP BY PHOENIX_ID, SP_ORG_ID, ASID
                """)
                
                self.spark.sql(f"""
                    DELETE FROM {linking_table_name}
                    WHERE NOT EXISTS (
                        SELECT 1 FROM latest_records lr
                        WHERE lr.PHOENIX_ID = {linking_table_name}.PHOENIX_ID
                        AND lr.SP_ORG_ID = {linking_table_name}.SP_ORG_ID
                        AND lr.ASID = {linking_table_name}.ASID
                        AND lr.max_update_date = {linking_table_name}.UPDATE_DATE
                    )
                """)
                log_pipeline_event("asid_linking_table", "removed_duplicates", {"count": duplicate_count})

            after_count = self.spark.sql(f"SELECT COUNT(*) as count FROM {linking_table_name}").first()["count"]
            records_updated = after_count - before_count if table_exists else after_count

            stats = self.spark.sql(f"""
                SELECT 
                    COUNT(*) AS total_records,
                    COUNT(DISTINCT PHOENIX_ID) AS unique_phoenix_ids,
                    COUNT(DISTINCT SP_ORG_ID) AS unique_sp_org_ids,
                    COUNT(DISTINCT ASID) AS unique_asids,
                    COUNT(DISTINCT FINANCIAL_SECTOR) AS unique_sectors
                FROM {linking_table_name}
            """).first().asDict()

            stats["records_updated_or_inserted"] = records_updated
            if duplicate_count and duplicate_count > 0:
                stats["duplicates_removed"] = duplicate_count

            log_pipeline_event("asid_linking_table", "completed", stats)

            sample_df = self.spark.sql(f"SELECT * FROM {linking_table_name} LIMIT 5")
            log_pipeline_event("asid_linking_table", "sample_data", {"sample_count": sample_df.count()})

            return {
                "status": "success",
                "table_name": linking_table_name,
                "records_updated_or_inserted": records_updated,
                "statistics": stats
            }

        except Exception as e:
            log_pipeline_event("asid_linking_table", "error", {"error": str(e)})
            raise


    def run_curation_for_multiple_tables(self, config):
        try:
            log_pipeline_event("curation_process", "started")

            table_configs = config["curation_jobs"]
            curation_results = {}

            for idx, config in enumerate(table_configs):
                table_name = config["processor_name"]
                log_pipeline_event("curation_process", "processing_table", {
                    "table_number": idx + 1,
                    "total_tables": len(table_configs),
                    "table_name": table_name
                })

                try:
                    curation_params = {
                        "s3_metadata_file": config["s3_metadata_file"],
                        "processor_name": config["processor_name"],
                        "catalog": config["catalog"],
                        "schema": config["schema"],
                        "del_indicator": "N"
                    }
                    log_pipeline_event("curation_process", "running_curation", {
                        "table": table_name,
                        "metadata_file": config["s3_metadata_file"],
                        "params": curation_params
                    })

                    # load_curated ar trebui să întoarcă un dict cu status și detalii
                    result = self.load_curated(config)
                    curation_results[table_name] = result

                except Exception as table_error:
                    error_details = {"table": table_name, "error": str(table_error)}
                    log_pipeline_event("curation_process", "table_error", error_details)
                    curation_results[table_name] = {
                        "status": "error",
                        "error": str(table_error)
                    }

            success_count = sum(1 for result in curation_results.values() if result.get("status") == "success")
            error_count = sum(1 for result in curation_results.values() if result.get("status") == "error")

            summary = {
                "total_tables": len(table_configs),
                "success_count": success_count,
                "error_count": error_count,
                "table_results": curation_results
            }

            log_pipeline_event("curation_process", "completed", summary)
            return summary

        except Exception as e:
            error_details = {"error": str(e)}
            log_pipeline_event("curation_process", "error", error_details)
            raise




    def main_asid_linking(self,config, recreate_target=False):
        start_time = datetime.now()
        metadata_result = {}
        target_catalog  = config["catalogs"]["raw"]["catalog"]
        message_catalog =  config["catalogs"]["raw"]["catalog"]
        message_schema =  config["catalogs"]["raw"]["schema"]
        message_table = config["tables"]["t_org_linking_responses"]
        target_schema =  config["catalogs"]["raw"]["schema"]
        target_table =  config["tables"]["t_org_table_linking_stage"]
        show_html =  config["etl_settings"]["show_html"]
        metadata_catalog =  config["catalogs"]["raw"]["catalog"]
        metadata_schema =  config["catalogs"]["raw"]["schema"]
        metadata_date_table =  config["tables"]["dp_date_processing_log"]
        metadata_file_table =  config["tables"]["dp_file_processing_log"]
        asid_org_linking_table = config["tables"]["t_asid_org_linking"]
        t_dc_transaction_org = config["tables"]["t_dc_transaction_org"]

        

        target_full_table = f"{target_catalog}.{target_schema}.{target_table}"
        asid_linking_table_name = f"{target_catalog}.{target_schema}.{asid_org_linking_table}"
        org_linking_table = f"{config['catalogs']['org']['catalog']}.{config['catalogs']['org']['schema']}.{config['tables']['t_org_linking']}"

        try:
            log_pipeline_event("pipeline", "started", {
                "process_date": self.process_date,
                "start_time": start_time.strftime("%Y-%m-%d %H:%M:%S")
            })

            metadata_result = self.check_for_new_records(metadata_catalog,metadata_schema,metadata_date_table,metadata_file_table)
            self.safe_display_html("Metadata Check Results", metadata_result, show_html=show_html)

            if metadata_result.get("status") == "no_records":
                summary = {
                    "process_date": self.process_date,
                    "pipeline_status": "completed",
                    "message": "No records to process",
                    "execution_time_seconds": (datetime.now() - start_time).total_seconds()
                }
                log_pipeline_event("pipeline", "completed", summary)
                return summary

            # NEW: Check existing records in org_linking_table FIRST
            org_check_result = self.check_existing_org_linking({
                "metadata_catalog": metadata_catalog,
                "metadata_schema": metadata_schema,
                "metadata_file_table": metadata_file_table,
                "org_linking_table": org_linking_table
            })

            print("Org Linking Table Check Results", org_check_result)
            # self.safe_display_html("Org Linking Table Check Results", org_check_result, show_html=show_html)

            # Only send to Kafka if there are phoenix_ids that need lookup
            producer_result = {"status": "no_records", "message": "All phoenix_ids found in org_linking_table"}
            consumer_result = {"status": "no_records", "consumer_result": {"messages_consumed": 0}}
            
            if org_check_result.get("need_kafka_lookup", 0) > 0:
                producer_result = self.run_kafka_producer(org_check_result.get("kafka_phoenix_ids"))
                print("Kafka Producer Results", producer_result)
                # self.safe_display_html("Kafka Producer Results", producer_result, show_html=show_html)

                if producer_result.get("status") != "no_records":
                    consumer_result = self.run_kafka_consumer()
                    print("Kafka Consumer Results", consumer_result)
                    # self.safe_display_html("Kafka Consumer Results", consumer_result, show_html=show_html)

                    messages_consumed = consumer_result.get("consumer_result", {}).get("messages_consumed", 0)
                    if messages_consumed == 0:
                        log_pipeline_event("pipeline", "warning", {"message": "No messages were consumed from Kafka"})
            else:
                log_pipeline_event("pipeline", "info", {"message": "No Kafka lookup needed - all phoenix_ids found in org_linking_table"})

            # Process responses (both existing and kafka)
            transform_result = self.process_json_responses({
                "target_catalog" : target_catalog,
                "target_schema" : target_schema,
                "target_table" : target_table,
                "recreate_target" : recreate_target,
                "messages_catalog" : message_catalog,
                "messages_schema" : message_schema,
                "messages_table" : message_table,
                "org_linking_table" : org_linking_table
            }, existing_org_data=org_check_result)
            print("JSON Transformation Results", transform_result)
            # self.safe_display_html("JSON Transformation Results", transform_result, show_html=show_html)

            prepare_result = self.prepare_org_table_structure({
                "target_catalog" : target_catalog,
                "target_schema" : target_schema,
                "target_table" : target_table,
            })
            print("Org Table Preparation Results", prepare_result)
            # self.safe_display_html("Org Table Preparation Results", prepare_result, show_html=show_html)

            linking_result = self.create_and_update_asid_linking_table({
                "target_catalog" : target_catalog,
                "target_schema" : target_schema,
                "target_table" : target_table,
                "asid_reference_table" :  config["tables"]["t_asid_mapping_reference"],
                "asid_org_linking_table" : config["tables"]["t_asid_org_linking"],
                "t_dc_transaction_org": f"{target_catalog}.{target_schema}.{t_dc_transaction_org}",
                "phoenixid_map_table": config["tables"]["t_org_finorgid_phoenixid_map"]
            })
            print("ASID Linking Table Results", linking_result)
            # self.safe_display_html("ASID Linking Table Results", linking_result, show_html=show_html)

            # curation_result = self.run_curation_for_multiple_tables(config)
            curation_result = {}
            # self.safe_display_html("Data Curation Results", curation_result, show_html=show_html)

            end_time = datetime.now()
            duration = (end_time - start_time).total_seconds()

            try:
                metadata_completion = datetime.strptime(metadata_result.get("latest_completion", ""), '%Y-%m-%d %H:%M:%S.%f')
                processing_time_seconds = (end_time - metadata_completion).total_seconds()
            except Exception:
                processing_time_seconds = duration

            summary = {
                "process_date": self.process_date,
                "pipeline_status": "success",
                "start_time": start_time.strftime("%Y-%m-%d %H:%M:%S"),
                "end_time": end_time.strftime("%Y-%m-%d %H:%M:%S"),
                "execution_time_seconds": duration,
                "processing_time_seconds": processing_time_seconds,
                "metadata_check": metadata_result,
                "org_linking_check": org_check_result,
                "kafka_producer": producer_result,
                "kafka_consumer": consumer_result,
                "transform_responses": transform_result,
                "org_table_preparation": prepare_result,
                "asid_linking_table": linking_result,
                "data_curation": curation_result,
                "final_table": target_full_table,
                "asid_linking_table_name": asid_linking_table_name
            }

            log_pipeline_event("pipeline", "completed", summary)
            # self.safe_display_html("Pipeline Execution Completed", summary, show_html=show_html)
            return summary

        except Exception as e:
            err_summary = {
                "process_date": self.process_date,
                "pipeline_status": "error",
                "error": str(e),
                "error_traceback": traceback.format_exc(),
                "execution_time_seconds": (datetime.now() - start_time).total_seconds()
            }

            log_pipeline_event("pipeline", "error", err_summary)
            self.safe_display_html("Pipeline Execution Failed", err_summary["error_traceback"], show_html=show_html, error=True)
            return err_summary