from pyspark.sql import functions as F
from pyspark.sql.types import *
from delta.tables import DeltaTable

def period_merge_logic_incremental(
    spark,
    driving_df,
    period_merge_table,
    staging_table,
    config
):
    raw_catalog_schema = f"{config.get('raw_catalog')}.{config.get('raw_schema')}"    
    precedence_table = f"{raw_catalog_schema}.{config.get('statement_basis_precedence')}"

    # Flatten the nested structure to create records for each datapoint
    flattened_df = driving_df.select(
        # Main entity fields
        F.col("entityId"),
        F.col("orgPrimaryName"),
        F.col("subProductName"),
        F.col("spOrgId"),
        F.col("mappedAsid"),
        
        # Period fields (extract from struct)
        F.col("period.periodEndDate"),
        F.col("period.statementBasis"),
        F.col("period.periodType"),
        F.col("period.periodMonths"),
        F.col("period.accountingBasis"),
        
        # Other fields
        F.col("aprAcceptable"),
        F.col("state"),
        F.col("countryCode"),
        F.col("currencyCode"),
        F.col("reportId"),
        F.col("keywordName"),
        F.col("workType"),
        F.col("receivedDate"),
        F.col("taggedDate"),
        F.col("dueDate"),
        F.col("fdmDueDate"),
        F.col("finalDueDate"),
        F.col("finalTime"),
        F.col("dcCompletionDate"),
        F.col("taggedFiles"),
        F.col("referenceFiles"),
        # Explode datapoints array to create one row per datapoint
        F.explode("datapoints").alias("datapoint")
    ).select(
        # Main fields
        "*",
        # Extract datapoint fields
        F.col("datapoint.mnemonic"),
        F.col("datapoint.value"),
        F.col("datapoint.unitType"),
        F.col("datapoint.schedules"),
        F.col("datapoint.comments")
    ).drop("datapoint")

    # Add temp_periodEndDate for merge conditions
    flattened_df = flattened_df.withColumn("temp_periodEndDate", F.col("periodEndDate"))

    # Get list of columns from flattened_df
    driving_columns = flattened_df.columns

    # Join with precedence table to get PRIORITY_ORDR_NUM
    raw_with_prec = (
        flattened_df.alias("raw")
        .join(
            spark.table(precedence_table).alias("prec"),
            (F.col("raw.subProductName") == F.col("prec.TEMPLT_SECTOR_NAME")) &
            (F.col("raw.statementBasis") == F.col("prec.SCENARIO_NAME")),
            "left"
        )
        .withColumn("PRIORITY_ORDR_NUM", F.coalesce(F.col("prec.PRIORITY_ORDR_NUM"), F.lit(999)))
        .select(*[F.col(f"raw.{col}") for col in driving_columns], F.col("PRIORITY_ORDR_NUM"))
    )

    # Get current timestamp to mark new records
    from pyspark.sql.functions import current_timestamp
    processing_timestamp = current_timestamp()
    from datetime import datetime
    pm_id_value = str(datetime.now().strftime("%Y%m%d%H%M%S"))
    
    # Add processing timestamp identify changes
    raw_with_tracking = raw_with_prec.withColumn("processing_ts", processing_timestamp) \
        .withColumn("pm_id", F.lit(pm_id_value))

    # Deduplicate source data before merge to avoid DELTA_MULTIPLE_SOURCE_ROW_MATCHING_TARGET_ROW error
    # The issue: same keys but different comments/schedules arrays create "duplicates"
    # Solution: Aggregate comments and schedules BEFORE deduplication to preserve all data
    from pyspark.sql.window import Window
    
    # First, aggregate comments and schedules for rows with same keys but different arrays
    # This preserves ALL comments and schedules, not just one
    dedupe_keys = ["entityId", "subProductName", "mnemonic", "temp_periodEndDate", "reportId"]
    
    # Group by all key columns plus value columns, then aggregate the array columns
    raw_with_tracking_deduped = raw_with_tracking.groupBy(
        *[col for col in driving_columns if col not in ["comments", "schedules"]], 
        "PRIORITY_ORDR_NUM", "processing_ts", "pm_id"
    ).agg(
        # Flatten and collect all comments from all matching rows
        F.flatten(F.collect_list("comments")).alias("comments"),
        # Flatten and collect all schedules from all matching rows  
        F.flatten(F.collect_list("schedules")).alias("schedules")
    )
    
    # Now deduplicate based on priority if there are still true duplicates (same value, same arrays)
    window_spec = Window.partitionBy("entityId", "subProductName", "mnemonic", "temp_periodEndDate") \
                        .orderBy(F.col("PRIORITY_ORDR_NUM").asc(), F.col("processing_ts").desc())
    
    raw_with_tracking_deduped = raw_with_tracking_deduped.withColumn("row_num", F.row_number().over(window_spec)) \
                                                         .filter(F.col("row_num") == 1) \
                                                         .drop("row_num")
    
    print(f"Deduplicated source data from {raw_with_tracking.count()} to {raw_with_tracking_deduped.count()} records (comments and schedules preserved)")

    # Create staging table if it doesn't exist
    if not spark.catalog.tableExists(staging_table):
        raw_with_tracking_deduped.write.format("delta").option("overwriteSchema", "true").mode("overwrite").saveAsTable(staging_table)
        print(f"Staging table {staging_table} created with {raw_with_tracking_deduped.count()} records.")

        # Create final period merge table - use all records since it's initial load
        create_final_table_from_new_records(spark, raw_with_tracking_deduped, period_merge_table)
        return f"Initial period merge table {period_merge_table} created with {raw_with_tracking_deduped.count()} records."

    # Track new/changed records during merge    
    # Load the Delta table
    delta_table = DeltaTable.forName(spark, staging_table)

    # Define merge condition based on key business fields
    merge_condition = (
        "stg.entityId = raw.entityId AND "
        "stg.subProductName = raw.subProductName AND "
        "stg.mnemonic = raw.mnemonic AND "
        "stg.temp_periodEndDate = raw.temp_periodEndDate"
    )

    # Define update condition based on priority logic
    update_condition = (
        "raw.reportId = stg.reportId OR "
        "(raw.reportId != stg.reportId AND raw.PRIORITY_ORDR_NUM <= stg.PRIORITY_ORDR_NUM)"
    )

    # Define columns to update/insert - include tracking columns
    update_columns = {
        col: f"raw.{col}" for col in driving_columns + ["PRIORITY_ORDR_NUM", "processing_ts", "pm_id"]
    }

    # PERFORM MERGE WITH TRACKING (using deduplicated data)
    merge_result = delta_table.alias("stg").merge(
        raw_with_tracking_deduped.alias("raw"),
        merge_condition
    ).whenMatchedUpdate(
        condition=update_condition,
        set=update_columns
    ).whenNotMatchedInsert(
        values=update_columns
    ).execute()
    
    print(f"Staging table {staging_table} merged and updated.")
    print(f"Merge statistics: {merge_result}")

    # GET ONLY NEW/CHANGED RECORDS FROM STAGING TABLE
    new_changed_records = spark.table(staging_table).filter(
        F.col("pm_id") == pm_id_value   # Current run's unique identifier
    ).drop("processing_ts", "temp_periodEndDate", "pm_id")

    new_changed_count = new_changed_records.count()
    print(f"Found {new_changed_count} new/changed records to process")
    
    if new_changed_count > 0:
        # CREATE/REPLACE PERIOD MERGE TABLE WITH ONLY NEW/CHANGED RECORDS
        create_final_table_from_new_records(spark, new_changed_records, period_merge_table)

        # Show preview of new/changed records
        print("Preview of new/changed records:")
        new_changed_records.show(truncate=False)
    else:
        print("No new/changed records found. Period merge table not updated.")

    print(f"Period merge completed. {new_changed_count} new/changed records processed in {period_merge_table}.")

def create_final_table_from_new_records(spark, new_records_df, period_merge_table):
    """
    Create/replace the final period merge table using only new/changed records
    """
    print(f"Creating/replacing {period_merge_table} with {new_records_df.count()} new/changed records")
    
    # Aggregate new/changed records back to nested structure
    aggregated_df = new_records_df.groupBy(
        "entityId", "orgPrimaryName", "subProductName", "spOrgId", "mappedAsid", "reportId"
    ).agg(
        # Reconstruct period struct (take first occurrence since it's same for all datapoints)
        F.first(F.struct(
            F.col("periodEndDate").alias("periodEndDate"),
            F.col("statementBasis").alias("statementBasis"),
            F.col("periodType").alias("periodType"),
            F.col("periodMonths").alias("periodMonths"),
            F.col("accountingBasis").alias("accountingBasis")
        )).alias("period"),
        
        # Take first occurrence of entity-level fields
        F.first("aprAcceptable").alias("aprAcceptable"),
        F.first("state").alias("state"),
        F.first("countryCode").alias("countryCode"),
        F.first("currencyCode").alias("currencyCode"),
        F.first("keywordName").alias("keywordName"),
        F.first("workType").alias("workType"),
        F.first("receivedDate").alias("receivedDate"),
        F.first("taggedDate").alias("taggedDate"),
        F.first("dueDate").alias("dueDate"),
        F.first("fdmDueDate").alias("fdmDueDate"),
        F.first("finalDueDate").alias("finalDueDate"),
        F.first("finalTime").alias("finalTime"),
        F.first("dcCompletionDate").alias("dcCompletionDate"),
        F.first("taggedFiles").alias("taggedFiles"),
        F.first("referenceFiles").alias("referenceFiles"),

        # Collect all datapoints back into array (use collect_list to preserve all, including duplicates)
        F.collect_list(F.struct(
            F.col("mnemonic").alias("mnemonic"),
            F.col("value").alias("value"),
            F.col("schedules").alias("schedules"),
            F.col("comments").alias("comments"),
            F.col("unitType").alias("unitType")
        )).alias("datapoints")
    )
    
    # Write to final table (overwrite mode to replace with only new/changed data)
    aggregated_df.write.format("delta") \
                 .mode("overwrite") \
                 .option("overwriteSchema", "true") \
                 .saveAsTable(period_merge_table)
    
    final_count = aggregated_df.count()
    print(f"Final period merge table {period_merge_table} created/replaced with {final_count} aggregated records.")

