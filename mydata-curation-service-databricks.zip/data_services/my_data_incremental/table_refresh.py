import argparse
from pyspark.sql import SparkSession
import logging

class Refresher:
  def __init__(self, env, table, spark, logger):
    self.env = env
    self.table = table
    self.spark = spark
    self.logger = logger
    self.query = f"""
    INSERT OVERWRITE TABLE idf_raw_{self.env}.USPF.{self.table}
    with obligor as (
        SELECT distinct d.DEPENDENT_OBJ_ID as ASID,
              O.OBLIGOR_OF_ANALYSIS_CORE_ID as OBLIGOR_ORG_ID,
              N.ORG_NAME AS OBLIGOR,
              RCAT.REVENUE_CATEGORY_DESC AS CATEGORY,
              RSEC.REVENUE_SECURITY_DESC AS SECURITY,
              RSUB.REVENUE_SUBSECURITY_DESC AS SUBSECURITY
        FROM idf_{self.env}.USPF_APR.v_DEPENDENCY d
        left join idf_{self.env}.USPF_APR.v_PLEDGE_REVENUE_SOURCE R on R.PLEDGE_ID = d.DEPENDENT_UPON_OBJ_ID and R.END_DATE > current_timestamp()
        left Join idf_{self.env}.USPF_APR.v_REVENUE_SOURCE_VERSION RV on RV.REVENUE_SRC_ID = R.REVENUE_SRC_ID AND RV.END_DATE > current_timestamp()
        left join idf_{self.env}.USPF_APR.v_REVENUE_OBLIGOR O on RV.REVENUE_OBLIGOR_ID = O.REVENUE_OBLIGOR_ID
        left join idf_{self.env}.CORE.v_ORG_NAMES N ON O.OBLIGOR_OF_ANALYSIS_CORE_ID = N.ORG_ID AND N.CURR_NAME_IND = 'Y'
        LEFT JOIN idf_{self.env}.USPF_APR.v_REVENUE_CATEGORY RCAT ON RV.REVENUE_CATEGORY_ID = RCAT.REVENUE_CATEGORY_ID
        LEFT JOIN idf_{self.env}.USPF_APR.v_REVENUE_SECURITY RSEC ON RV.REVENUE_SECURITY_ID = RSEC.REVENUE_SECURITY_ID
        LEFT JOIN idf_{self.env}.USPF_APR.v_REVENUE_SUBSECURITY RSUB ON RV.REVENUE_SUBSECURITY_ID = RSUB.REVENUE_SUBSECURITY_ID
        WHERE d.DEPENDENT_OBJ_TYP = 'ANALYTIC_SECURITY'
        and d.DEPENDENT_UPON_OBJ_TYP = 'PLEDGE'
        and d.end_date > current_timestamp() 
        ),
    final_table as(
      select
        asv.ANLYTC_SEC_ID as ASID,
        asv.ANLYTC_DISPLAY_NAME as DISPLAY_NAME,
        initcap(gu.GEO_UNIT_NAME) as STATE,
        ob.OBLIGOR AS CORE_OBLIGOR,
        ob.OBLIGOR_ORG_ID,
        eor.primary_name as SP_ORG_NAME,
        ol.SP_ORG_ID,
        asv.ACTIVE_FLAG as ASID_ACTIVE_FLAG,
        to_date(a.CREATE_DATE) as ASID_CREATE_DATE,
        CASE
            WHEN ASV.PRTFLIO_TYP_ID = '1637' THEN 'HUMAN SERVICE PROVIDER' --Federal_Prison_Contract_Revenue
            WHEN ASV.PRTFLIO_TYP_ID = '237' THEN 'HUMAN SERVICE PROVIDER' --Federal_Prison_Contract_Revenue_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '12' THEN 'HEALTH CARE Life Care' --HealthCare-CareRet_Center
            WHEN ASV.PRTFLIO_TYP_ID = '198' THEN 'HEALTH CARE Life Care' --HealthCare-CareRet_Center_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '15' THEN 'HUMAN SERVICE PROVIDER' --HealthCare-MHMRSSPROV
            WHEN ASV.PRTFLIO_TYP_ID = '231' THEN 'HUMAN SERVICE PROVIDER' --HealthCare-MHMRSSPROV_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '1638' THEN 'HEALTH CARE Acute' --HealthCare-Rev_Hospital Districts
            WHEN ASV.PRTFLIO_TYP_ID = '1639' THEN 'HEALTH CARE Acute' --HealthCare-Rev_Hospital Districts_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '14' THEN 'HEALTH CARE Acute' --HealthCare-Standalone
            WHEN ASV.PRTFLIO_TYP_ID = '200' THEN 'HEALTH CARE Acute' --HealthCare-Standalone_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '144' THEN 'HEALTH CARE Acute' --HealthCare-System
            WHEN ASV.PRTFLIO_TYP_ID = '223' THEN 'HEALTH CARE Acute' --HealthCare-System_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '122' THEN 'Off Balance Sheet Housing' --HigherEd-Auxiliary_Stand_Alone
            WHEN ASV.PRTFLIO_TYP_ID = '221' THEN 'Off Balance Sheet Housing' --HigherEd-Auxiliary_Stand_Alone_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '19' THEN 'SHORT TERM DEBT' --HigherEd-Cash_Flow_Notes
            WHEN ASV.PRTFLIO_TYP_ID = '232' THEN 'SHORT TERM DEBT' --HigherEd-Cash_Flow_Notes_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '23' THEN 'CHARTER SCHOOL' --HigherEd-CharterSchools
            WHEN ASV.PRTFLIO_TYP_ID = '206' THEN 'CHARTER SCHOOL' --HigherEd-CharterSchools_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '1685' THEN 'EDUCATION Enterprises' --HigherEd-Comnty_Coll_Dual
            WHEN ASV.PRTFLIO_TYP_ID = '1686' THEN 'EDUCATION Enterprises' --HigherEd-Comnty_Coll_Dual_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '45' THEN 'EDUCATION Enterprises' --HigherEd-Comnty_Coll_Rev
            WHEN ASV.PRTFLIO_TYP_ID = '218' THEN 'EDUCATION Enterprises' --HigherEd-Comnty_Coll_Rev_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '57' THEN 'EDUCATION Enterprises' --HigherEd-Comnty_Coll_Tax
            WHEN ASV.PRTFLIO_TYP_ID = '160' THEN 'EDUCATION Enterprises' --HigherEd-Comnty_Coll_Tax_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '18' THEN 'EDUCATION Enterprises' --HigherEd-Independent_Schools
            WHEN ASV.PRTFLIO_TYP_ID = '202' THEN 'EDUCATION Enterprises' --HigherEd-Independent_Schools_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '21' THEN 'EDUCATION Non-Profit' --HigherEd-Not_for_Profits
            WHEN ASV.PRTFLIO_TYP_ID = '204' THEN 'EDUCATION Non-Profit' --HigherEd-Not_for_Profits_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '16' THEN 'EDUCATION Enterprises' --HigherEd-PCUGO
            WHEN ASV.PRTFLIO_TYP_ID = '201' THEN 'EDUCATION Enterprises' --HigherEd-PCUGO_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '22' THEN 'EDUCATION Enterprises' --HigherEd-PCUUSF
            WHEN ASV.PRTFLIO_TYP_ID = '205' THEN 'EDUCATION Enterprises' --HigherEd-PCUUSF_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '34' THEN 'HOUSING Capital Fund' --Housing-Capital_Fund_Financing_Program
            WHEN ASV.PRTFLIO_TYP_ID = '209' THEN 'HOUSING Capital Fund' --Housing-Capital_Fund_Financing_Program_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '35' THEN 'SHORT TERM DEBT' --Housing-Cash_Flow_Notes
            WHEN ASV.PRTFLIO_TYP_ID = '210' THEN 'SHORT TERM DEBT' --Housing-Cash_Flow_Notes_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '37' THEN 'HOUSING Federally Enhanced Housing Security' --Housing-Fannie_Mae-Freddie_Mac_Collateral_Agreements
            WHEN ASV.PRTFLIO_TYP_ID = '211' THEN 'HOUSING Collateral Agreement' --Housing-Fannie_Mae-Freddie_Mac_Collateral_Agreements_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '169' THEN 'HOUSING Federally Enhanced Housing Security' --Housing-FEH_MF_Pass_Through
            WHEN ASV.PRTFLIO_TYP_ID = '225' THEN 'HOUSING Federally Enhanced Housing Security' --Housing-FEH_MF_Pass_Through_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '43' THEN 'HOUSING Federally Enhanced Housing Security' --Housing-FEH_MF_Stand-Alone
            WHEN ASV.PRTFLIO_TYP_ID = '217' THEN 'HOUSING Federally Enhanced Housing Security' --Housing-FEH_MF_Stand-Alone_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '1691' THEN 'HOUSING Federally Enhanced Housing Security' --Housing-FEH_MFFHLMC_Pool-Static
            WHEN ASV.PRTFLIO_TYP_ID = '1692' THEN 'HOUSING Federally Enhanced Housing Security' --Housing-FEH_MFFHLMC_Pool-Static_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '1675' THEN 'N/A' --Housing-FEH_SF_Parity_Resolution-Managed
            WHEN ASV.PRTFLIO_TYP_ID = '170' THEN 'N/A' --Housing-FEH_SF_Pass_Through
            WHEN ASV.PRTFLIO_TYP_ID = '226' THEN 'N/A' --Housing-FEH_SF_Pass_Through_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '1673' THEN 'HOUSING Federally Enhanced Housing Security' --Housing-FEH_SF_Stand-Alone
            WHEN ASV.PRTFLIO_TYP_ID = '1674' THEN 'HOUSING Federally Enhanced Housing Security' --Housing-FEH_SF_Stand-Alone_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '146' THEN 'HOUSING Federally Enhanced Housing Security' --Housing-FHA_Insured
            WHEN ASV.PRTFLIO_TYP_ID = '228' THEN 'HOUSING Federally Enhanced Housing Security' --Housing-FHA_Insured_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '1669' THEN 'HOUSING HFA/ SELO ICR' --Housing-HFASELO_CDFI_GO
            WHEN ASV.PRTFLIO_TYP_ID = '1670' THEN 'HOUSING HFA/ SELO ICR' --Housing-HFASELO_CDFI_GO_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '1665' THEN 'HOUSING HFA/ SELO ICR' --Housing-HFASELO_CDFI_ICR
            WHEN ASV.PRTFLIO_TYP_ID = '1666' THEN 'HOUSING HFA/ SELO ICR' --Housing-HFASELO_CDFI_ICR_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '1671' THEN 'HOUSING HFA/ SELO ICR' --Housing-HFASELO_HFA_GO
            WHEN ASV.PRTFLIO_TYP_ID = '1672' THEN 'HOUSING HFA/ SELO ICR' --Housing-HFASELO_HFA_GO_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '38' THEN 'HOUSING HFA/ SELO ICR' --Housing-HFASELO_HFA_ICR
            WHEN ASV.PRTFLIO_TYP_ID = '212' THEN 'HOUSING HFA/ SELO ICR' --Housing-HFASELO_HFA_ICR_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '1667' THEN 'HOUSING HFA/ SELO ICR' --Housing-HFASELO_SELO_ICR
            WHEN ASV.PRTFLIO_TYP_ID = '1668' THEN 'HOUSING HFA/ SELO ICR' --Housing-HFASELO_SELO_ICR_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '1659' THEN 'N/A' --Housing-Interest ONLY
            WHEN ASV.PRTFLIO_TYP_ID = '1660' THEN 'N/A' --Housing-Interest Only_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '1683' THEN 'HOUSING Whole Loan' --Housing-MRB_Programs
            WHEN ASV.PRTFLIO_TYP_ID = '1684' THEN 'HOUSING Whole Loan' --Housing-MRB_Programs_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '1661' THEN 'HOUSING Affordable Housing & Privatized Military' --Housing-RHB_Age_Restricted
            WHEN ASV.PRTFLIO_TYP_ID = '1662' THEN 'HOUSING Affordable Housing & Privatized Military' --Housing-RHB_Age_Restricted_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '39' THEN 'HOUSING Affordable Housing & Privatized Military' --Housing-RHB_Military
            WHEN ASV.PRTFLIO_TYP_ID = '213' THEN 'HOUSING Affordable Housing & Privatized Military' --Housing-RHB_Military_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '1663' THEN 'HOUSING Affordable Housing & Privatized Military' --Housing-RHB_Mobile_Home
            WHEN ASV.PRTFLIO_TYP_ID = '1664' THEN 'HOUSING Affordable Housing & Privatized Military' --Housing-RHB_Mobile_Home_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '1677' THEN 'HOUSING Whole Loan' --Housing-RHB_Multifamily_Whole_Loan_Pool-Managed
            WHEN ASV.PRTFLIO_TYP_ID = '1678' THEN 'HOUSING Whole Loan' --Housing-RHB_Multifamily_Whole_Loan_Pool-Managed_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '133' THEN 'HOUSING Multi-Family Pool' --Housing-RHB_Multifamily_Whole_Loan_Pool-Static
            WHEN ASV.PRTFLIO_TYP_ID = '220' THEN 'HOUSING Multi-Family Pool' --Housing-RHB_Multifamily_Whole_Loan_Pool-Static_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '42' THEN 'HOUSING Affordable Housing & Privatized Military' --Housing-RHB_Section_8
            WHEN ASV.PRTFLIO_TYP_ID = '216' THEN 'HOUSING Affordable Housing & Privatized Military' --Housing-RHB_Section_8_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '33' THEN 'HOUSING Affordable Housing & Privatized Military' --Housing-RHB_Unenhanced
            WHEN ASV.PRTFLIO_TYP_ID = '208' THEN 'HOUSING Affordable Housing & Privatized Military' --Housing-RHB_Unenhanced_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '41' THEN 'N/A' --Housing-Section_236
            WHEN ASV.PRTFLIO_TYP_ID = '44' THEN 'HOUSING Whole Loan' --Housing-Single_Family_Whole_Loan
            WHEN ASV.PRTFLIO_TYP_ID = '230' THEN 'HOUSING Whole Loan' --Housing-Single_Family_Whole_Loan_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '40' THEN 'HOUSING Public Housing Authority ICR' --Housing-Social_Housing_Provider_ICR
            WHEN ASV.PRTFLIO_TYP_ID = '214' THEN 'HOUSING Public Housing Authority ICR' --Housing-Social_Housing_Provider_ICR_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '143' THEN 'N/A' --National_Insured_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '56' THEN 'N/A' --Non_USPF_Dependent_Ratings
            WHEN ASV.PRTFLIO_TYP_ID = '172' THEN 'PRIORITY LIEN' --REVOTHER-Lottery_Rev
            WHEN ASV.PRTFLIO_TYP_ID = '233' THEN 'PRIORITY LIEN' --REVOTHER-Lottery_Rev_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '174' THEN 'PRIORITY LIEN' --REVOTHER-Lottery_Rev_STATES
            WHEN ASV.PRTFLIO_TYP_ID = '235' THEN 'PRIORITY LIEN' --REVOTHER-Lottery_Rev_STATES_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '1641' THEN 'PRIORITY LIEN' --State_Prison_Contract_Revenue
            WHEN ASV.PRTFLIO_TYP_ID = '1642' THEN 'PRIORITY LIEN' --State_Prison_Contract_Revenue_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '136' THEN 'SHORT TERM DEBT' --States-Cash_Flow_Notes
            WHEN ASV.PRTFLIO_TYP_ID = '196' THEN 'SHORT TERM DEBT' --States-Cash_Flow_Notes_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '175' THEN 'PRIORITY LIEN' --States-SACP
            WHEN ASV.PRTFLIO_TYP_ID = '236' THEN 'PRIORITY LIEN' --States-SACP_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '32' THEN 'G O State' --States-States
            WHEN ASV.PRTFLIO_TYP_ID = '207' THEN 'G O State' --States-States_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '46' THEN 'SHORT TERM DEBT' --TaxSec-Cash_Flow_Notes
            WHEN ASV.PRTFLIO_TYP_ID = '150' THEN 'SHORT TERM DEBT' --TaxSec-Cash_Flow_Notes_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '49' THEN 'G O School District' --TaxSec-Federal_Impact_Aid_Criteria_Borrowing
            WHEN ASV.PRTFLIO_TYP_ID = '153' THEN 'G O School District' --TaxSec-Federal_Impact_Aid_Criteria_Borrowing_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '137' THEN 'PRIORITY LIEN' --TaxSec-Federal_Impact_Aid_Criteria_Borrowing_States
            WHEN ASV.PRTFLIO_TYP_ID = '1' THEN 'G O Municipality & County' --TaxSec-GO_Counties
            WHEN ASV.PRTFLIO_TYP_ID = '149' THEN 'G O Municipality & County' --TaxSec-GO_Counties_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '60' THEN 'G O Municipality & County' --TaxSec-GO_Hospital Districts
            WHEN ASV.PRTFLIO_TYP_ID = '161' THEN 'G O Municipality & County' --TaxSec-GO_Hospital Districts_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '48' THEN 'G O Municipality & County' --TaxSec-GO_Municipalities
            WHEN ASV.PRTFLIO_TYP_ID = '152' THEN 'G O Municipality & County' --TaxSec-GO_Munis_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '55' THEN 'G O School District' --TaxSec-GO_Schools
            WHEN ASV.PRTFLIO_TYP_ID = '159' THEN 'G O School District' --TaxSec-GO_Schools_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '135' THEN 'G O Municipality & County' --TaxSec-GO_SpecialDistricts
            WHEN ASV.PRTFLIO_TYP_ID = '166' THEN 'G O Municipality & County' --TaxSec-GO_SpecialDistricts_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '1679' THEN 'G O Municipality & County' --TaxSec-GO_TransportDistricts
            WHEN ASV.PRTFLIO_TYP_ID = '1680' THEN 'G O Municipality & County' --TaxSec-GO_TransportDistricts_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '124' THEN 'WATER SEWER' --TaxSec-GO_WaterDistricts
            WHEN ASV.PRTFLIO_TYP_ID = '195' THEN 'WATER SEWER' --TaxSec-GO_WaterDistricts_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '50' THEN 'G O Municipality & County' --TaxSec-MUD
            WHEN ASV.PRTFLIO_TYP_ID = '154' THEN 'G O Municipality & County' --TaxSec-MUD_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '1649' THEN 'PRIORITY LIEN' --TaxSec-National_GO_Stadium_and_Convention_Center --moving FROM GOMC TO PL FOR GO Criteria PROJECT 9/7/24
            WHEN ASV.PRTFLIO_TYP_ID = '1650' THEN 'PRIORITY LIEN' --TaxSec-National_GO_Stadium_and_Convention_Center_ICE --moving FROM GOMC TO PL FOR GO Criteria PROJECT 9/7/24
            WHEN ASV.PRTFLIO_TYP_ID = '51' THEN 'PENSION FUND' --TaxSec-Pension_Funds
            WHEN ASV.PRTFLIO_TYP_ID = '155' THEN 'PENSION FUND' --TaxSec-Pension_Funds_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '118' THEN 'PRIORITY LIEN' --TaxSec-PLSACP
            WHEN ASV.PRTFLIO_TYP_ID = '163' THEN 'PRIORITY LIEN' --TaxSec-PLSACP_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '1643' THEN 'PRIORITY LIEN' --TaxSec-PLSACP_TIE
            WHEN ASV.PRTFLIO_TYP_ID = '1646' THEN 'PRIORITY LIEN' --TaxSec-PLSACP_TIE_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '1681' THEN 'PRIORITY LIEN' --TaxSec-PLSACP_TransportDistricts
            WHEN ASV.PRTFLIO_TYP_ID = '1682' THEN 'PRIORITY LIEN' --TaxSec-PLSACP_TransportDistricts_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '127' THEN 'N/A' --TaxSec_Rev_Change
            WHEN ASV.PRTFLIO_TYP_ID = '52' THEN 'SPECIAL ASSESSMENT' --TaxSec-Special_Assessments
            WHEN ASV.PRTFLIO_TYP_ID = '156' THEN 'SPECIAL ASSESSMENT' --TaxSec-Special_Assessments_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '1655' THEN 'State Withholding-Intercept Program' --TaxSec-Stenchprog_Munis_Intercept
            WHEN ASV.PRTFLIO_TYP_ID = '1656' THEN 'State Withholding-Intercept Program' --TaxSec-Stenchprog_Munis_Intercept_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '1657' THEN 'State Withholding-Intercept Program' --TaxSec-Stenchprog_Munis_Withholding
            WHEN ASV.PRTFLIO_TYP_ID = '1658' THEN 'State Withholding-Intercept Program' --TaxSec-Stenchprog_Munis_Withholding_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '53' THEN 'State Withholding-Intercept Program' --TaxSec-Stenchprog_Schools_Intercept
            WHEN ASV.PRTFLIO_TYP_ID = '157' THEN 'State Withholding-Intercept Program' --TaxSec-Stenchprog_Schools_Intercept_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '1653' THEN 'State Withholding-Intercept Program' --TaxSec-Stenchprog_Schools_Withholding
            WHEN ASV.PRTFLIO_TYP_ID = '1654' THEN 'State Withholding-Intercept Program' --TaxSec-Stenchprog_Schools_Withholding_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '1651' THEN 'State Withholding-Intercept Program' --TaxSec-Stenchprog_Universitites_Intercept
            WHEN ASV.PRTFLIO_TYP_ID = '1652' THEN 'State Withholding-Intercept Program' --TaxSec-Stenchprog_Universitites_Intercept_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '120' THEN 'N/A' --TaxSec-Stenchprog_Other
            WHEN ASV.PRTFLIO_TYP_ID = '54' THEN 'TAX INCREMENT' --TaxSec-Tax_Increment
            WHEN ASV.PRTFLIO_TYP_ID = '158' THEN 'TAX INCREMENT' --TaxSec-Tax_Increment_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '177' THEN 'G O Municipality & County' --TaxSec-Tribes_and_Nations
            WHEN ASV.PRTFLIO_TYP_ID = '180' THEN 'G O Municipality & County' --TaxSec-Tribes_and_Nations_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '5' THEN 'SHORT TERM DEBT' --Transport-Cash_Flow_Notes
            WHEN ASV.PRTFLIO_TYP_ID = '182' THEN 'SHORT TERM DEBT' --Transport-Cash_Flow_Notes_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '6' THEN 'TRANSP Grants' --Transport-Grants
            WHEN ASV.PRTFLIO_TYP_ID = '192' THEN 'TRANSP Grants' --Transport-Grants_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '4' THEN 'TRANSP Infrastructure Enterprise' --Transport-Infrastructure_Enterprise
            WHEN ASV.PRTFLIO_TYP_ID = '181' THEN 'TRANSP Infrastructure Enterprise' --Transport-Infrastructure_Enterprise_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '131' THEN 'N/A' --Utility_Wholesale_Simple
            WHEN ASV.PRTFLIO_TYP_ID = '24' THEN 'SHORT TERM DEBT' --Utility-Cash_Flow_Notes
            WHEN ASV.PRTFLIO_TYP_ID = '229' THEN 'SHORT TERM DEBT' --Utility-Cash_Flow_Notes_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '1687' THEN 'PUBLIC POWER' --Utility-Combined_Electric_Gas
            WHEN ASV.PRTFLIO_TYP_ID = '1688' THEN 'PUBLIC POWER' --Utility-Combined_Electric_Gas_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '1689' THEN 'WATER SEWER' --Utility-Combined_Water_Sewer
            WHEN ASV.PRTFLIO_TYP_ID = '1690' THEN 'WATER SEWER' --Utility-Combined_Water_Sewer_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '27' THEN 'PUBLIC POWER' --Utility-Retail_Electric_Gas
            WHEN ASV.PRTFLIO_TYP_ID = '168' THEN 'PUBLIC POWER' --Utility-Retail_Electric_Gas_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '28' THEN 'PUBLIC POWER Cooperative' --Utility-Rural_Elec_Coops
            WHEN ASV.PRTFLIO_TYP_ID = '190' THEN 'PUBLIC POWER Cooperative' --Utility-Rural_Elec_Coops_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '30' THEN 'WATER SEWER' --Utility-Solid_Waste
            WHEN ASV.PRTFLIO_TYP_ID = '227' THEN 'WATER SEWER' --Utility-Solid_Waste_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '2' THEN 'LONG-TERM MUNICIPAL POOL' --Utility-SRF_Pools
            WHEN ASV.PRTFLIO_TYP_ID = '197' THEN 'LONG-TERM MUNICIPAL POOL' --Utility-SRF_Pools_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '3' THEN 'WATER SEWER' --Utility-Water_Sewer
            WHEN ASV.PRTFLIO_TYP_ID = '179' THEN 'WATER SEWER' --Utility-Water_Sewer_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '171' THEN 'WATER SEWER' --Utility-Water_Sewer_Indpendent_Wholesale
            WHEN ASV.PRTFLIO_TYP_ID = '224' THEN 'WATER SEWER' --Utility-Water_Sewer_Indpendent_Wholesale_ICE
            WHEN ASV.PRTFLIO_TYP_ID = '31' THEN 'PUBLIC POWER' --Utility-Wholesale_Electric
            WHEN ASV.PRTFLIO_TYP_ID = '191' THEN 'PUBLIC POWER' --Utility-Wholesale_Electric_ICE
            ELSE 'To be defined'
        END AS EXPECTED_FINANCIAL_SECTOR,
        dt.DEPENDENCY_TYP_NAME,
        pt.PRTFLIO_TYP_NAME as PORTFOLIO,
        sec.SECURITY,
        SEC.SUBSECURITY,
        db.DEPENDENCY_BUCKET_DESC as DEPENDENCY_BUCKET,
        CASE WHEN upper(DB.DEPENDENCY_BUCKET_DESC) IN
                    ('WEAK LINK', 'STRONG LINK', 'STRONG-LINK-CREDEST', 'WEAK-LINK-CREDEST')
                    THEN 'Y'
                    ELSE 'N'
                END AS MRS
        from IDF_{self.env}.USPF_APR.V_ANALYTIC_SECURITY a
        join IDF_{self.env}.USPF_APR.V_ANALYTIC_SECURITY_VERSION asv on a.ANLYTC_SEC_ID = asv.ANLYTC_SEC_ID
        join IDF_{self.env}.USPF_APR.V_PORTFOLIO_TYPE pt on asv.PRTFLIO_TYP_ID = pt.PRTFLIO_TYP_ID
        join IDF_{self.env}.USPF_APR.V_ENTITY_RATING er on asv.ANLYTC_SEC_ID = er.ENTITY_ID
        left join IDF_{self.env}.USPF_APR.V_GEOGRAPHIC_UNIT gu on asv.GEO_UNIT_ID = gu.GEO_UNIT_ID
        left join IDF_{self.env}.USPF_APR.V_DEPENDENCY_BUCKET db on asv.DEPENDENCY_BUCKET_ID = db.DEPENDENCY_BUCKET_ID
        left join IDF_{self.env}.USPF_APR.V_DEPENDENCY_TYPE dt on asv.DEPENDENCY_TYP_ID = dt.DEPENDENCY_TYP_ID
        left join
        (select y.ASID,
                last(y.OBLIGOR) as OBLIGOR,
                last(y.OBLIGOR_ORG_ID) as OBLIGOR_ORG_ID
            FROM (    
            select x.asid,
                concat_ws('|', collect_list(x.obligor) over (partition by x.asid order by X.OBLIGOR)) as OBLIGOR,
                concat_ws('|', collect_list(X.OBLIGOR_ORG_ID) over (partition by X.ASID order by X.OBLIGOR)) as OBLIGOR_ORG_ID
            from (
                        SELECT distinct ob.ASID, --CAST(O.OBLIGOR_OF_ANALYSIS_CORE_ID as varchar(18))
                            OB.OBLIGOR_ORG_ID,
                            OB.OBLIGOR
                        FROM obligor ob
            ) x
            ) y
            GROUP BY y.ASID
        ) ob on ob.asid = asv.ANLYTC_SEC_ID
        -- subquery to link security and subsecurity
        LEFT JOIN (
              select z.asid,
                      last(z.security) as security,
                      last(z.subsecurity) as subsecurity
                from (
                select y.asid,
                    concat_ws('; ', collect_list(y.security) OVER (partition by y.asid order by y.security)) AS security,
                    concat_ws('; ', collect_list(y.subsecurity) OVER (partition by y.asid order by y.security)) AS subsecurity
                from (
                select x.asid, x.security,
                    concat_ws('; ', sort_array(collect_list(X.SUBSECURITY),true)) AS SUBSECURITY
                FROM (   
                select distinct asid, security, subsecurity
                from obligor ob
                ) X
                GROUP BY X.ASID, x.security
                ) Y
                ) Z
                group by z.asid
             ) sec on ASV.ANLYTC_SEC_ID = sec.asid
        left join idf_{self.env}.org.v_org_linking ol on OB.OBLIGOR_ORG_ID = ol.id_value and TRIM(ol.id_type) = 'CORE' and TRIM(ol.active_flag) = 'Y' and ol.end_date is null
        left join idf_{self.env}.org.v_enterprise_org_reference eor on ol.SP_ORG_ID = eor.sp_org_id

        where asv.END_DATE > current_timestamp()
        and asv.ACTIVE_FLAG = 'Y'
        and asv.PRTFLIO_TYP_ID is not null
        and asv.ANLYTC_SEC_ID <> '999999'
        and er.END_DATE > current_timestamp()
        and upper(er.RATING_CODE) not in ('NR', 'NA')
        )
        SELECT * FROM final_table
        """ 
  
  def refresh(self):
    self.logger.info(f"Running query for environment: {self.env}")
    self.spark.sql(self.query)

def refresh_entrypoint():
    spark = SparkSession.builder.getOrCreate()
    parser = argparse.ArgumentParser(description="Run mydataIncremental pipeline")
    parser.add_argument("--env", help="Environment name (dev, qa, uat, prod, dr)")
    parser.add_argument("--table", help="Table name")
    args = vars(parser.parse_args())
    env = args["env"]
    table = args["table"]
    logger = logging.getLogger(__name__)
    main_obj = Refresher(env=env, table=table, spark=spark, logger=logger)
    main_obj.refresh()


if __name__ == "__main__":
    refresh_entrypoint()
