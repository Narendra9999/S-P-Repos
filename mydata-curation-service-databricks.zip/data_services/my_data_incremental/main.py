import argparse
import logging
from datetime import datetime, timezone

import pandas as pd
import pyspark.dbutils
from pyspark.sql import SparkSession

from data_services.my_data_incremental.config.config_loader import Config
from data_services.my_data_incremental.curation.load_curated_table import load_curated
from data_services.my_data_incremental.ingestion.raw_data_ingestion import process_raw_data
from data_services.my_data_incremental.transformation.asid_linking import AsidLinking
from data_services.my_data_incremental.transformation.elt_to_dp import run_elt_process
from data_services.my_data_incremental.utils.create_control_tables_ddls import create_control_tables
from data_services.my_data_incremental.utils.file_processing_utils import get_current_file_processing_log, determine_file_types_from_files
from data_services.my_data_incremental.utils.log_job_execution_status import (
    insert_job_metadata, insert_process_metadata, job_control_entry, job_end,
    job_start, process_control_entry, process_end, process_start)

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
handler = logging.StreamHandler()
formatter = logging.Formatter('[%(asctime)s] %(levelname)s: %(message)s')
handler.setFormatter(formatter)
logger.addHandler(handler)


class Main:
    def __init__(self, spark, dbutils, args):
        self.env = args["env"]
        self.process_date = args['process_date']
        self.spark = spark
        self.dbutils = dbutils
        self.args = args
        # self.process_date = process_date

    def run(self):


        # Ensure boolean conversion for dry_run, verbose, show_all_messages
        def str2bool(val):
            return str(val).lower() in ("true", "1", "yes")
        self.args["dry_run"] = str2bool(self.args.get("dry_run", False))
        self.args["verbose"] = str2bool(self.args.get("verbose", False))
        self.args["show_all_messages"] = str2bool(self.args.get("show_all_messages", False))

        # Load config for the selected environment
        # config = configLoader.load_config("base.json")
        # config_asid_linking = configLoader.load_config("asid_linking.json")
        # config_raw_data = configLoader.load_config("raw_data_ingestion.json")
        # config_table_curation = configLoader.load_config('asid_linking_table_config.json')
        # config_elt = configLoader.load_config('elt.json')
        # config_curation_dp = configLoader.load_config('curation_dp_load.json')
        # config_schedules = configLoader.load_config('curation_schedules.json')
        # config_comments = configLoader.load_config('curation_comments.json')
        # config_org = configLoader.load_config('curation_org.json')

        configLoader = Config(env=self.args["env"], variables=None)

        config = configLoader.loadConfig("lineage_config.json")
        

        # Inject table names and s3/output_dir from config
        self.args["s3_bucket"] = config['storage'].get("filestore_s3_bucket")
        self.args["output_dir"] = config['storage'].get("filestore_output_dir")
        self.args["tables"] = {
            "driving": config['tables'].get("t_dc_transaction_dp_load"),
            "asid_linking": config['tables'].get("t_asid_org_linking"),
            "comments": config['tables'].get("t_dc_transaction_comments"),
            "schedule": config['tables'].get("t_dc_transaction_schedules"),
            "plan_org": config['tables'].get("t_dc_transaction_plan_org"),
            "org": config['tables'].get("t_dc_transaction_org"),
            "tif_pa": config['tables'].get("t_dc_transaction_tif_pa"),
            "plan_id": config['tables'].get("t_dc_transaction_plan_id")
            
        }

        # Optionally, keep curation_tables list for downstream use
        self.args["curation_tables"] = config['tables'].get("curation_tables", [])
        
        # Set date and process_date to current date if not provided
        today = datetime.now().strftime('%Y-%m-%d')
        self.args['date'] = self.args.get('date') or today
        self.args['process_date'] = self.args.get('process_date') or today

        raw_data_params = {
            'process_mode': self.args['process_mode'],
            'force_reprocess': self.args['force_reprocess'],
            'date': self.args['date'],
            'process_last_n_days': self.args['process_last_n_days']
        }

        ctrl_schema = f"{config['catalogs']['raw']['catalog']}.{config['catalogs']['raw']['schema']}"
        source_schema = f"{config['catalogs']['raw']['catalog']}.{config['catalogs']['raw']['schema']}"
        target_schema = f"{config['catalogs']['curated']['catalog']}.{config['catalogs']['curated']['schema']}"

        create_control_tables(
            catalog=config['catalogs']['raw']['catalog'],
            schema=config['catalogs']['raw']['schema'],
            s3_base_path=config["storage"]["control_tables_base_path"]
        )

        logger.info("STARTING JOB")
        job_id, job_run_id = insert_job_metadata(
            spark=self.spark,
            job_name=config["base"]["name"],
            job_frequency=config["base"]["frequency"],
            schema=ctrl_schema,
            tables=config["base"]["control_tables"],
            status_values=config["base"]["job_statuses"],
            source_schema=source_schema,
            target_schema=target_schema,
            audit_user=config["base"]["audit_user"],
        )

        job_run_id = job_start(
            spark=self.spark,
            job_id=job_id,
            schema=ctrl_schema,
            tables=config["base"]["control_tables"],
            status_values=config["base"]["job_statuses"],
            audit_user=config["base"]["audit_user"],
        )

        # Check file processing log before raw data ingestion
        files_before_ingestion = get_current_file_processing_log(self.spark, config)
        logger.info(f"Files in dp_file_processing_log before ingestion: {len(files_before_ingestion)}")

        logger.info("STARTING RAW DATA INGESTION")
        process_id_1 = insert_process_metadata(
            spark=self.spark,
            job_id=job_id,
            job_run_id=job_run_id,
            process_name="RAW_DATA_INGESTION",
            process_frequency=config["base"]["process_frequency"],
            load_type=None,
            key=None,
            schema=ctrl_schema,
            tables=config["base"]["control_tables"],
            status_values=config["base"]["job_statuses"],
            source_schema=source_schema,
            target_schema=target_schema,
            audit_user=config["base"]["audit_user"],
        )

        _ = process_start(
            spark=self.spark,
            job_run_id=job_run_id,
            schema=ctrl_schema,
            process_id=process_id_1,
            tables=config["base"]["control_tables"],
            status_values=config["base"]["job_statuses"],
            audit_user=config["base"]["audit_user"],
        )


        process_raw_data(raw_data_params, {
            "TARGET_SCHEMA" : config['catalogs']['raw']['schema'],
            "SOURCE_S3_PREFIX" : config['storage']['stage_s3_prefix'],
            "SOURCE_S3_BUCKET": config['storage']['stage_s3_bucket'],
            "TARGET_CATALOG":  config['catalogs']['raw']['catalog']
        })

        process_end(
            spark=self.spark,
            job_run_id=job_run_id,
            schema=ctrl_schema,
            process_id=process_id_1,
            tables=config["base"]["control_tables"],
            status_values=config["base"]["job_statuses"],
            audit_user=config["base"]["audit_user"],
        )
        logger.info("RAW DATA INGESTION COMPLETED")

        # Check file processing log after raw data ingestion
        files_after_ingestion = get_current_file_processing_log(self.spark, config)
        logger.info(f"Files in dp_file_processing_log after ingestion: {len(files_after_ingestion)}")

        # Determine which files were processed in this run
        new_files = files_after_ingestion - files_before_ingestion
        
        # Determine file types from the new files processed
        processed_file_types = determine_file_types_from_files(new_files)
        
        logger.info(f"New files processed in this run: {new_files}")
        logger.info(f"File types processed: {processed_file_types}")
        if "org" in processed_file_types:
            logger.info("STARTING ASID LINKING")
            process_id_2 = insert_process_metadata(
                spark=self.spark,
                job_id=job_id,
                job_run_id=job_run_id,
                process_name="ASID_LINKING",
                process_frequency=config["base"]["process_frequency"],
                load_type=None,
                key=None,
                schema=ctrl_schema,
                tables=config["base"]["control_tables"],
                status_values=config["base"]["job_statuses"],
                source_schema=source_schema,
                target_schema=target_schema,
                audit_user=config["base"]["audit_user"],
            )

            _ = process_start(
            spark=self.spark,
            job_run_id=job_run_id,
            schema=ctrl_schema,
            process_id=process_id_2,
            tables=config["base"]["control_tables"],
            status_values=config["base"]["job_statuses"],
            audit_user=config["base"]["audit_user"],
            )

            a_linking = AsidLinking(env=self.env, spark=self.spark, dbutils=self.dbutils, process_date=self.args["process_date"])
            a_linking.main_asid_linking(config = config)

            process_end(
            spark=self.spark,
            job_run_id=job_run_id,
            schema=ctrl_schema,
            process_id=process_id_2,
            tables=config["base"]["control_tables"],
            status_values=config["base"]["job_statuses"],
            audit_user=config["base"]["audit_user"],
            )
            logger.info("ASID LINKING COMPLETED")
        else:
            logger.info("SKIPPING ASID LINKING - No ORG files processed")
            process_id_2 = None

        # Conditionally execute DP LOAD curation
        if "dp_load" in processed_file_types:
            logger.info("STARTING CURATED DP LOAD")
            process_id_3 = insert_process_metadata(
                spark=self.spark,
                job_id=job_id,
                job_run_id=job_run_id,
                process_name="CURATED_DP_LOAD",
                process_frequency=config["base"]["process_frequency"],
                load_type=None,
                key=None,
                schema=ctrl_schema,
                tables=config["base"]["control_tables"],
                status_values=config["base"]["job_statuses"],
                source_schema=source_schema,
                target_schema=target_schema,
                audit_user=config["base"]["audit_user"],
            )

            _ = process_start(
                spark=self.spark,
                job_run_id=job_run_id,
                schema=ctrl_schema,
                process_id=process_id_3,
                tables=config["base"]["control_tables"],
                status_values=config["base"]["job_statuses"],
                audit_user=config["base"]["audit_user"],
            )

            #curation_dp_load
            load_curated(spark = self.spark, config_data = {
                "curated_table" : config['tables']['t_dc_transaction_dp_load'],
                "raw_catalog" : config['catalogs']['raw']['catalog'],
                "raw_schema" : config['catalogs']['raw']['schema'],
                "raw_table" : config['tables']['t_dc_transaction_dp_load'],
                "curated_catalog" : config['catalogs']['curated']['catalog'],
                "curated_schema" : config['catalogs']['curated']['schema'],
                "latest_on" : config['mappings']['curation_dp_load']['latest_on'],
                "target_to_source_mapping" : config['mappings']['curation_dp_load']['target_to_source_mapping'],
                "keys" : config['mappings']['curation_dp_load']['keys'],
                "run_log" : config['tables']['run_log'],
                "aggregation_keys" : ["SRC_DE_UNIQ_ID_TEXT", "PHOENIX_ID", "REPORT_ID", "SECTOR_NAME"],
                "aggregate_cols" : ["DP_VALUE"]
            }, env=self.env)

            process_end(
                spark=self.spark,
                job_run_id=job_run_id,
                schema=ctrl_schema,
                process_id=process_id_3,
                tables=config["base"]["control_tables"],
                status_values=config["base"]["job_statuses"],
                audit_user=config["base"]["audit_user"],
            )
            logger.info("CURATED DP LOAD COMPLETED")
        else:
            logger.info("SKIPPING CURATED DP LOAD - No DP_LOAD files processed")
            process_id_3 = None

        # Conditionally execute SCHEDULES curation
        if "schedules" in processed_file_types:
            logger.info("STARTING SCHEDULES")
            process_id_4 = insert_process_metadata(
                spark=self.spark,
                job_id=job_id,
                job_run_id=job_run_id,
                process_name="SCHEDULES",
                process_frequency=config["base"]["process_frequency"],
                load_type=None,
                key=None,
                schema=ctrl_schema,
                tables=config["base"]["control_tables"],
                status_values=config["base"]["job_statuses"],
                source_schema=source_schema,
                target_schema=target_schema,
                audit_user=config["base"]["audit_user"],
            )

            _ = process_start(
                spark=self.spark,
                job_run_id=job_run_id,
                schema=ctrl_schema,
                process_id=process_id_4,
                tables=config["base"]["control_tables"],
                status_values=config["base"]["job_statuses"],
                audit_user=config["base"]["audit_user"],
            )
            # config_schedules
            load_curated(spark = self.spark, config_data = {
                "curated_table" : config['tables']['t_dc_transaction_schedules'],
                "raw_catalog" : config['catalogs']['raw']['catalog'],
                "raw_schema" : config['catalogs']['raw']['schema'],
                "raw_table" : config['tables']['t_dc_transaction_schedules'],
                "curated_catalog" : config['catalogs']['curated']['catalog'],
                "curated_schema" : config['catalogs']['curated']['schema'],
                "latest_on" : config['mappings']['curation_schedules']['latest_on'],
                "target_to_source_mapping" : config['mappings']['curation_schedules']['target_to_source_mapping'],
                "keys" : config['mappings']['curation_schedules']['keys'],
                "run_log" : config['tables']['run_log'],
                "aggregation_keys" : ["SRC_DE_UNIQ_ID_TEXT", "PHOENIX_ID", "REPORT_ID", "SECTOR_NAME", "SCHEDULE_NAME"],
                "aggregate_cols" : ["SCHEDULE_VALUE"]
            }, env=self.env)

            process_end(
                spark=self.spark,
                job_run_id=job_run_id,
                schema=ctrl_schema,
                process_id=process_id_4,
                tables=config["base"]["control_tables"],
                status_values=config["base"]["job_statuses"],
                audit_user=config["base"]["audit_user"],
            )
            logger.info("SCHEDULES COMPLETED")
        else:
            logger.info("SKIPPING SCHEDULES - No SCHEDULES files processed")
            process_id_4 = None

        # Conditionally execute COMMENTS curation
        if "comments" in processed_file_types:
            logger.info("STARTING COMMENTS")
            process_id_5 = insert_process_metadata(
                spark=self.spark,
                job_id=job_id,
                job_run_id=job_run_id,
                process_name="COMMENTS",
                process_frequency=config["base"]["process_frequency"],
                load_type=None,
                key=None,
                schema=ctrl_schema,
                tables=config["base"]["control_tables"],
                status_values=config["base"]["job_statuses"],
                source_schema=source_schema,
                target_schema=target_schema,
                audit_user=config["base"]["audit_user"],
            )

            _ = process_start(
                spark=self.spark,
                job_run_id=job_run_id,
                schema=ctrl_schema,
                process_id=process_id_5,
                tables=config["base"]["control_tables"],
                status_values=config["base"]["job_statuses"],
                audit_user=config["base"]["audit_user"],
            )

            # config_comments
            load_curated(spark = self.spark, config_data = {
                "curated_table" : config['tables']['t_dc_transaction_comments'],
                "raw_catalog" : config['catalogs']['raw']['catalog'],
                "raw_schema" : config['catalogs']['raw']['schema'],
                "raw_table" : config['tables']['t_dc_transaction_comments'],
                "curated_catalog" : config['catalogs']['curated']['catalog'],
                "curated_schema" : config['catalogs']['curated']['schema'],
                "latest_on" : config['mappings']['curation_comments']['latest_on'],
                "target_to_source_mapping" : config['mappings']['curation_comments']['target_to_source_mapping'],
                "keys" : config['mappings']['curation_comments']['keys'],
                "run_log" : config['tables']['run_log'],
                "insert_only" : True  # Comments don't support updates, only inserts
            }, env=self.env)

            process_end(
                spark=self.spark,
                job_run_id=job_run_id,
                schema=ctrl_schema,
                process_id=process_id_5,
                tables=config["base"]["control_tables"],
                status_values=config["base"]["job_statuses"],
                audit_user=config["base"]["audit_user"],
            )
            logger.info("COMMENTS COMPLETED")
        else:
            logger.info("SKIPPING COMMENTS - No COMMENTS files processed")
            process_id_5 = None

        # Conditionally execute ORG curation
        if "org" in processed_file_types:
            logger.info("STARTING ORG")
            process_id_6 = insert_process_metadata(
                spark=self.spark,
                job_id=job_id,
                job_run_id=job_run_id,
                process_name="ORG",
                process_frequency=config["base"]["process_frequency"],
                load_type=None,
                key=None,
                schema=ctrl_schema,
                tables=config["base"]["control_tables"],
                status_values=config["base"]["job_statuses"],
                source_schema=source_schema,
                target_schema=target_schema,
                audit_user=config["base"]["audit_user"],
            )

            _ = process_start(
                spark=self.spark,
                job_run_id=job_run_id,
                schema=ctrl_schema,
                process_id=process_id_6,
                tables=config["base"]["control_tables"],
                status_values=config["base"]["job_statuses"],
                audit_user=config["base"]["audit_user"],
            )

            # config_org
            load_curated(spark = self.spark, config_data = {
                "curated_table" : config['tables']['t_dc_transaction_org'],
                "raw_catalog" : config['catalogs']['raw']['catalog'],
                "raw_schema" : config['catalogs']['raw']['schema'],
                "raw_table" : config['tables']['t_dc_transaction_org'],
                "curated_catalog" : config['catalogs']['curated']['catalog'],
                "curated_schema" : config['catalogs']['curated']['schema'],
                "latest_on" : config['mappings']['curation_org']['latest_on'],
                "target_to_source_mapping" : config['mappings']['curation_org']['target_to_source_mapping'],
                "keys" : config['mappings']['curation_org']['keys'],
                "run_log" : config['tables']['run_log']
                # ,
                # "aggregation_keys" : ["SRC_DE_UNIQ_ID_TEXT", "PHOENIX_ID", "REPORT_ID"]
            }, env=self.env)

            process_end(
                spark=self.spark,
                job_run_id=job_run_id,
                schema=ctrl_schema,
                process_id=process_id_6,
                tables=config["base"]["control_tables"],
                status_values=config["base"]["job_statuses"],
                audit_user=config["base"]["audit_user"],
            )
            logger.info("ORG COMPLETED")
        else:
            logger.info("SKIPPING ORG - No ORG files processed")
            process_id_6 = None

        # Conditionally execute TIF_PA curation
        if "tif_pa" in processed_file_types:
            logger.info("STARTING TIF_PA")
            process_id_7 = insert_process_metadata(
                spark=self.spark,
                job_id=job_id,
                job_run_id=job_run_id,
                process_name="TIF_PA",
                process_frequency=config["base"]["process_frequency"],
                load_type=None,
                key=None,
                schema=ctrl_schema,
                tables=config["base"]["control_tables"],
                status_values=config["base"]["job_statuses"],
                source_schema=source_schema,
                target_schema=target_schema,
                audit_user=config["base"]["audit_user"],
            )

            _ = process_start(
                spark=self.spark,
                job_run_id=job_run_id,
                schema=ctrl_schema,
                process_id=process_id_7,
                tables=config["base"]["control_tables"],
                status_values=config["base"]["job_statuses"],
                audit_user=config["base"]["audit_user"],
            )

            # config_tif_pa
            load_curated(spark = self.spark, config_data = {
                "curated_table" : config['tables']['t_dc_transaction_tif_pa'],
                "raw_catalog" : config['catalogs']['raw']['catalog'],
                "raw_schema" : config['catalogs']['raw']['schema'],
                "raw_table" : config['tables']['t_dc_transaction_tif_pa'],
                "curated_catalog" : config['catalogs']['curated']['catalog'],
                "curated_schema" : config['catalogs']['curated']['schema'],
                "latest_on" : config['mappings']['curation_tif_pa']['latest_on'],
                "target_to_source_mapping" : config['mappings']['curation_tif_pa']['target_to_source_mapping'],
                "keys" : config['mappings']['curation_tif_pa']['keys'],
                "run_log" : config['tables']['run_log'],
            }, env=self.env)

            process_end(
                spark=self.spark,
                job_run_id=job_run_id,
                schema=ctrl_schema,
                process_id=process_id_7,
                tables=config["base"]["control_tables"],
                status_values=config["base"]["job_statuses"],
                audit_user=config["base"]["audit_user"],
            )
            logger.info("TIF_PA COMPLETED")
        else:
            logger.info("SKIPPING TIF_PA - No TIF_PA files processed")
            process_id_7 = None

        # Conditionally execute PLAN_ID curation
        if "plan_id" in processed_file_types:
            logger.info("STARTING PLAN_ID")
            process_id_8 = insert_process_metadata(
                spark=self.spark,
                job_id=job_id,
                job_run_id=job_run_id,
                process_name="PLAN_ID",
                process_frequency=config["base"]["process_frequency"],
                load_type=None,
                key=None,
                schema=ctrl_schema,
                tables=config["base"]["control_tables"],
                status_values=config["base"]["job_statuses"],
                source_schema=source_schema,
                target_schema=target_schema,
                audit_user=config["base"]["audit_user"],
            )

            _ = process_start(
                spark=self.spark,
                job_run_id=job_run_id,
                schema=ctrl_schema,
                process_id=process_id_8,
                tables=config["base"]["control_tables"],
                status_values=config["base"]["job_statuses"],
                audit_user=config["base"]["audit_user"],
            )

            # config_plan_id
            load_curated(spark = self.spark, config_data = {
                "curated_table" : config['tables']['t_dc_transaction_plan_id'],
                "raw_catalog" : config['catalogs']['raw']['catalog'],
                "raw_schema" : config['catalogs']['raw']['schema'],
                "raw_table" : config['tables']['t_dc_transaction_plan_id'],
                "curated_catalog" : config['catalogs']['curated']['catalog'],
                "curated_schema" : config['catalogs']['curated']['schema'],
                "latest_on" : config['mappings']['curation_plan_id']['latest_on'],
                "target_to_source_mapping" : config['mappings']['curation_plan_id']['target_to_source_mapping'],
                "keys" : config['mappings']['curation_plan_id']['keys'],
                "run_log" : config['tables']['run_log'],
            }, env=self.env)

            process_end(
                spark=self.spark,
                job_run_id=job_run_id,
                schema=ctrl_schema,
                process_id=process_id_8,
                tables=config["base"]["control_tables"],
                status_values=config["base"]["job_statuses"],
                audit_user=config["base"]["audit_user"],
            )
            logger.info("PLAN_ID COMPLETED")
        else:
            logger.info("SKIPPING PLAN_ID - No PLAN_ID files processed")
            process_id_8 = None

        # Conditionally execute PLAN_ORG curation
        if "plan_org" in processed_file_types:
            logger.info("STARTING PLAN_ORG")
            process_id_9 = insert_process_metadata(
                spark=self.spark,
                job_id=job_id,
                job_run_id=job_run_id,
                process_name="PLAN_ORG",
                process_frequency=config["base"]["process_frequency"],
                load_type=None,
                key=None,
                schema=ctrl_schema,
                tables=config["base"]["control_tables"],
                status_values=config["base"]["job_statuses"],
                source_schema=source_schema,
                target_schema=target_schema,
                audit_user=config["base"]["audit_user"],
            )

            _ = process_start(
                spark=self.spark,
                job_run_id=job_run_id,
                schema=ctrl_schema,
                process_id=process_id_9,
                tables=config["base"]["control_tables"],
                status_values=config["base"]["job_statuses"],
                audit_user=config["base"]["audit_user"],
            )

            # config_plan_org
            load_curated(spark = self.spark, config_data = {
                "curated_table" : config['tables']['t_dc_transaction_plan_org'],
                "raw_catalog" : config['catalogs']['raw']['catalog'],
                "raw_schema" : config['catalogs']['raw']['schema'],
                "raw_table" : config['tables']['t_dc_transaction_plan_org'],
                "curated_catalog" : config['catalogs']['curated']['catalog'],
                "curated_schema" : config['catalogs']['curated']['schema'],
                "latest_on" : config['mappings']['curation_plan_org']['latest_on'],
                "target_to_source_mapping" : config['mappings']['curation_plan_org']['target_to_source_mapping'],
                "keys" : config['mappings']['curation_plan_org']['keys'],
                "run_log" : config['tables']['run_log'],
            }, env=self.env)

            process_end(
                spark=self.spark,
                job_run_id=job_run_id,
                schema=ctrl_schema,
                process_id=process_id_9,
                tables=config["base"]["control_tables"],
                status_values=config["base"]["job_statuses"],
                audit_user=config["base"]["audit_user"],
            )
            logger.info("PLAN_ORG COMPLETED")
        else:
            logger.info("SKIPPING PLAN_ORG - No PLAN_ORG files processed")
            process_id_9 = None

        

        # Conditionally execute ELT processing - skip if only org files were processed
        if processed_file_types - {"org"} and len(processed_file_types) > 0:
            logger.info("STARTING ELT PROCESSING")
            process_id_10 = insert_process_metadata(
                spark=self.spark,
                job_id=job_id,
                job_run_id=job_run_id,
                process_name="ELT_PROCESSING",
                process_frequency=config["base"]["process_frequency"],
                load_type=None,
                key=None,
                schema=ctrl_schema,
                tables=config["base"]["control_tables"],
                status_values=config["base"]["job_statuses"],
                source_schema=source_schema,
                target_schema=target_schema,
                audit_user=config["base"]["audit_user"],
            )

            _ = process_start(
                spark=self.spark,
                job_run_id=job_run_id,
                schema=ctrl_schema,
                process_id=process_id_10,
                tables=config["base"]["control_tables"],
                status_values=config["base"]["job_statuses"],
                audit_user=config["base"]["audit_user"],
            )

            run_elt_process(spark = self.spark, params=self.args, config={
                "raw_catalog" : config['catalogs']['raw']['catalog'],
                "raw_schema" : config['catalogs']['raw']['schema'],
                "curated_catalog" : config['catalogs']['curated']['catalog'],
                "curated_schema" : config['catalogs']['curated']['schema'],
                "fin_group_linked_scd2" : config['tables']['fin_group_linked_scd2'],
                "scd2_keys" : config['mappings']['scd2']['keys'],
                "period_merge" : config['tables']['period_merge'],
                "period_merge_staging" : config['tables']['period_merge_staging'],
                "statement_basis_precedence" : config['tables']['statement_basis_precedence']
            }, env=self.env)

            process_end(
                spark=self.spark,
                job_run_id=job_run_id,
                schema=ctrl_schema,
                process_id=process_id_10,
                tables=config["base"]["control_tables"],
                status_values=config["base"]["job_statuses"],
                audit_user=config["base"]["audit_user"],
            )
            logger.info("ELT PROCESSING COMPLETED")
        else:
            logger.info("SKIPPING ELT PROCESSING - Only ORG files processed, no ELT processing required")
            process_id_10 = None

        new_job_run_id = job_end(
            spark=self.spark,
            job_id=job_id,
            schema=ctrl_schema,
            tables=config["base"]["control_tables"],
            status_values=config["base"]["job_statuses"],
            audit_user=config["base"]["audit_user"],
        )
        logger.info("JOB COMPLETED SUCCESSFULLY")

        # Log next job run
        current_time = str(datetime.now(timezone.utc))
        next_start_time = pd.to_datetime(current_time) + pd.to_timedelta(int(config["base"]["frequency"]), unit="h")
        job_start_time_str = next_start_time.isoformat()

        new_job_run_id = job_control_entry(
            spark=self.spark,
            job_id=job_id,
            job_frequency=config["base"]["frequency"],
            schema=ctrl_schema,
            job_start_time=job_start_time_str,
            tables=config["base"]["control_tables"],
            status_values=config["base"]["job_statuses"],
            audit_user=config["base"]["audit_user"],
        )

        # Log next process run
        if process_id_1 is not None:
            process_control_entry(
                spark=self.spark,
                job_run_id=new_job_run_id,
                schema=ctrl_schema,
                process_id=process_id_1,
                tables=config["base"]["control_tables"],
                status_values=config["base"]["job_statuses"],
                audit_user=config["base"]["audit_user"]
            )

        if process_id_2 is not None:
            process_control_entry(
                spark=self.spark,
                job_run_id=new_job_run_id,
                schema=ctrl_schema,
                process_id=process_id_2,
                tables=config["base"]["control_tables"],
                status_values=config["base"]["job_statuses"],
                audit_user=config["base"]["audit_user"]
            )

        # Only log process control entries for processes that were actually executed
        if process_id_3 is not None:
            process_control_entry(
                spark=self.spark,
                job_run_id=new_job_run_id,
                schema=ctrl_schema,
                process_id=process_id_3,
                tables=config["base"]["control_tables"],
                status_values=config["base"]["job_statuses"],
                audit_user=config["base"]["audit_user"]
            )

        if process_id_4 is not None:
            process_control_entry(
                spark=self.spark,
                job_run_id=new_job_run_id,
                schema=ctrl_schema,
                process_id=process_id_4,
                tables=config["base"]["control_tables"],
                status_values=config["base"]["job_statuses"],
                audit_user=config["base"]["audit_user"]
            )

        if process_id_5 is not None:
            process_control_entry(
                spark=self.spark,
                job_run_id=new_job_run_id,
                schema=ctrl_schema,
                process_id=process_id_5,
                tables=config["base"]["control_tables"],
                status_values=config["base"]["job_statuses"],
                audit_user=config["base"]["audit_user"]
            )

        if process_id_6 is not None:
            process_control_entry(
                spark=self.spark,
                job_run_id=new_job_run_id,
                schema=ctrl_schema,
                process_id=process_id_6,
                tables=config["base"]["control_tables"],
                status_values=config["base"]["job_statuses"],
                audit_user=config["base"]["audit_user"]
            )

        if process_id_7 is not None:
            process_control_entry(
                spark=self.spark,
                job_run_id=new_job_run_id,
                schema=ctrl_schema,
                process_id=process_id_7,
                tables=config["base"]["control_tables"],
                status_values=config["base"]["job_statuses"],
                audit_user=config["base"]["audit_user"]
            )

        if process_id_8 is not None:
            process_control_entry(
                spark=self.spark,
                job_run_id=new_job_run_id,
                schema=ctrl_schema,
                process_id=process_id_8,
                tables=config["base"]["control_tables"],
                status_values=config["base"]["job_statuses"],
                audit_user=config["base"]["audit_user"]
            )

        if process_id_9 is not None:
            process_control_entry(
                spark=self.spark,
                job_run_id=new_job_run_id,
                schema=ctrl_schema,
                process_id=process_id_9,
                tables=config["base"]["control_tables"],
                status_values=config["base"]["job_statuses"],
                audit_user=config["base"]["audit_user"]
            )

        if process_id_10 is not None:
            process_control_entry(
                spark=self.spark,
                job_run_id=new_job_run_id,
                schema=ctrl_schema,
                process_id=process_id_10,
                tables=config["base"]["control_tables"],
                status_values=config["base"]["job_statuses"],
                audit_user=config["base"]["audit_user"]
            )

def main_entrypoint():
    parser = argparse.ArgumentParser(description="Run mydataIncremental pipeline")
    parser.add_argument("env", help="Environment name (dev, qa, uat, prod, dr)")
    parser.add_argument("--process_mode", required=True, help="Processing mode (single_date, unprocessed_files, date_range, missing_dates)")
    parser.add_argument("--force_reprocess", help="Force reprocess flag")
    parser.add_argument("--date", help="Date for batch processing (YYYY-MM-DD), required for single_date and unprocessed_files modes")
    parser.add_argument("--process_date", help="Date for batch processing (YYYY-MM-DD), required for elt processing")
    parser.add_argument("--process_last_n_days", type=int, help="Number of days for date_range or missing_dates modes")
    parser.add_argument("--dry_run")
    parser.add_argument("--verbose")
    parser.add_argument("--show_all_messages")
    parser.add_argument("--s3_bucket", required=True, help="S3 bucket for output data")
    parser.add_argument("--output_dir", required=True, help="Output directory path")
    
    args = vars(parser.parse_args())

    spark = SparkSession.builder.getOrCreate()
    dbutils = pyspark.dbutils.DBUtils(spark)
    main_obj = Main(spark=spark, dbutils=dbutils, args = args)
    main_obj.run()


if __name__ == "__main__":
    main_entrypoint()
