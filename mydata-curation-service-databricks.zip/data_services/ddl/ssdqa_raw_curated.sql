----ssdqa------
-- RAW ---
----------

-- Drop raw tables
drop table if exists idf_raw_ssdqa.uspf.t_dc_transaction_dp_load;
drop table if exists idf_raw_ssdqa.uspf.t_dc_transaction_comments;
drop table if exists idf_raw_ssdqa.uspf.t_dc_transaction_schedules;
drop table if exists idf_raw_ssdqa.uspf.t_dc_transaction_org;

-- Create raw tables
CREATE TABLE IF NOT EXISTS idf_raw_ssdqa.uspf.t_dc_transaction_dp_load (
                PHOENIX_ID STRING,
                PHOENIX_PLAN_ID STRING,
                SECTOR_NAME STRING,
                PER_TYPE_NAME STRING,
                MEASURE_DATE STRING,
                PERIOD_END_DATE STRING,
                PERIOD_MONTHS STRING,
                STATEMENT_BASIS_NAME STRING,
                ACCOUNT_BASIS_NAME STRING,
                APR_ACCEPTABLE STRING,
                SOURCE_FILE_CREATE_DATE STRING,
                SRC_DE_UNIQ_ID_TEXT STRING,
                DP_VALUE STRING,
                REPORT_ID STRING,
                DELETE_FLAG STRING,
                ACTION STRING,
                WORK_TYPE STRING,
                KEYWORD_NAME STRING,
                RECEIVED_DATE STRING,
                TAGGED_DATE STRING,
                processing_timestamp TIMESTAMP,
                source_file STRING,
                source_bucket STRING,
                process_date STRING,
                record_hash STRING,
                created_at TIMESTAMP,
                updated_at TIMESTAMP
            )
            USING DELTA
            PARTITIONED BY (SECTOR_NAME, process_date)
            LOCATION 
			's3://spr-idf-dev-platform-landing/ssdqa/catalog/raw/uspf/t_dc_transaction_dp_load'
            TBLPROPERTIES (
            'delta.minReaderVersion' = '1',
            'delta.minWriterVersion' = '2');
			
CREATE TABLE IF NOT EXISTS idf_raw_ssdqa.uspf.t_dc_transaction_comments (
                PHOENIX_ID STRING,
                PHOENIX_PLAN_ID STRING,
                SECTOR_NAME STRING,
                PER_TYPE_NAME STRING,
                MEASURE_DATE STRING,
                PERIOD_END_DATE STRING,
                PERIOD_MONTHS STRING,
                STATEMENT_BASIS_NAME STRING,
                ACCOUNT_BASIS_NAME STRING,
                APR_ACCEPTABLE STRING,
                SOURCE_FILE_CREATE_DATE STRING,
                SRC_DE_UNIQ_ID_TEXT STRING,
                REPORT_ID STRING,
                COMMENTS STRING,
                VALUE STRING,
                COMMENT_BY STRING,
                COMMENT_DATE_TIME STRING,
                processing_timestamp TIMESTAMP,
                source_file STRING,
                source_bucket STRING,
                process_date STRING,
                record_hash STRING,
                created_at TIMESTAMP,
                updated_at TIMESTAMP)
            USING DELTA
            PARTITIONED BY (SECTOR_NAME, process_date)
            LOCATION 
			's3://spr-idf-dev-platform-landing/ssdqa/catalog/raw/uspf/t_dc_transaction_comments'
            TBLPROPERTIES (
            'delta.minReaderVersion' = '1',
            'delta.minWriterVersion' = '2');
            
CREATE TABLE IF NOT EXISTS idf_raw_ssdqa.uspf.t_dc_transaction_schedules (
                PHOENIX_ID STRING,
                PHOENIX_PLAN_ID STRING,
                SECTOR_NAME STRING,
                PER_TYPE_NAME STRING,
                MEASURE_DATE STRING,
                PERIOD_END_DATE STRING,
                PERIOD_MONTHS STRING,
                STATEMENT_BASIS_NAME STRING,
                ACCOUNT_BASIS_NAME STRING,
                APR_ACCEPTABLE STRING,
                SOURCE_FILE_CREATE_DATE STRING,
                SRC_DE_UNIQ_ID_TEXT STRING,
                REPORT_ID STRING,
                SCHEDULE_NAME STRING,
                SCHEDULE_VALUE STRING,
                ACTION STRING,
                SCHEDULE_FRMLA_TEXT STRING,
                VALUE STRING,
                ORDER_ID STRING,
                REMARKS STRING,
                SCHEDULE_BY STRING,
                SCHEDULE_DATE_TIME STRING,
                processing_timestamp TIMESTAMP,
                source_file STRING,
                source_bucket STRING,
                process_date STRING,
                record_hash STRING,
                created_at TIMESTAMP,
                updated_at TIMESTAMP)
            USING DELTA
            PARTITIONED BY (SECTOR_NAME, process_date)
            LOCATION 
			's3://spr-idf-dev-platform-landing/ssdqa/catalog/raw/uspf/t_dc_transaction_schedules'
            TBLPROPERTIES (
            'delta.minReaderVersion' = '1',
            'delta.minWriterVersion' = '2');
			
CREATE TABLE IF NOT EXISTS idf_raw_ssdqa.uspf.t_dc_transaction_org (
		  PHOENIX_ID STRING,
		  SECTOR STRING,
		  ORG_PRIMARY_NAME STRING,
		  STATE STRING,
		  SOURCE_FILE_CREATE_DATE STRING,
		  COUNTRY_CODE STRING,
		  CURRENCY_CODE STRING,
		  DEAL_NAME_DESCRIPTOR STRING,
		  FIN_REVENUE_TYPE STRING,
		  FIN_REVENUE_SUBTYPE STRING,
		  FYE STRING,
		  processing_timestamp TIMESTAMP,
		  source_file STRING,
		  source_bucket STRING,
		  process_date STRING,
		  record_hash STRING,
		  created_at TIMESTAMP,
		  updated_at TIMESTAMP)
	USING delta
	PARTITIONED BY (SECTOR, process_date)
	LOCATION 's3://spr-idf-dev-platform-landing/ssdqa/catalog/raw/uspf/t_dc_transaction_org'
	TBLPROPERTIES (
            'delta.minReaderVersion' = '1',
            'delta.minWriterVersion' = '2');
			



-------------
-- CURATED --
-------------

-- Drop curated tables
drop table if exists idf_curated_ssdqa.uspf.t_dc_transaction_dp_load;
drop table if exists idf_curated_ssdqa.uspf.t_dc_transaction_comments;
drop table if exists idf_curated_ssdqa.uspf.t_dc_transaction_schedules;
drop table if exists idf_curated_ssdqa.uspf.t_dc_transaction_org;

-- Create curated tables 
CREATE TABLE IF NOT EXISTS idf_curated_ssdqa.uspf.t_dc_transaction_dp_load (
  PHOENIX_ID STRING,
  PHOENIX_PLAN_ID STRING,
  SECTOR_NAME STRING,
  PER_TYPE_NAME STRING,
  MEASURE_DATE STRING,
  PERIOD_END_DATE STRING,
  PERIOD_MONTHS STRING,
  STATEMENT_BASIS_NAME STRING,
  ACCOUNT_BASIS_NAME STRING,
  APR_ACCEPTABLE STRING,
  SOURCE_FILE_CREATE_DATE STRING,
  SRC_DE_UNIQ_ID_TEXT STRING,
  DP_VALUE STRING,
  REPORT_ID STRING,
  DELETE_FLAG STRING,
  ACTION STRING,
  WORK_TYPE	string,
  KEYWORD_NAME	string,
  RECEIVED_DATE STRING,
  TAGGED_DATE STRING,
  actv_ind	string,
  create_usr_id	string,
  last_upd_usr_id	string,
  create_dttm	timestamp,
  last_upd_dttm	timestamp,
  run_id bigint)
USING delta
PARTITIONED BY (PERIOD_END_DATE, SECTOR_NAME)
LOCATION 
's3://spr-idf-dev-platform-engineered/ssdqa/catalog/curated/uspf/t_dc_transaction_dp_load'
TBLPROPERTIES (
  'delta.checkpoint.writeStatsAsJson' = 'false',
  'delta.checkpoint.writeStatsAsStruct' = 'true',
  'delta.enableChangeDataFeed' = 'true',
  'delta.feature.appendOnly' = 'supported',
  'delta.feature.changeDataFeed' = 'supported',
  'delta.feature.invariants' = 'supported');
  
CREATE TABLE IF NOT EXISTS idf_curated_ssdqa.uspf.t_dc_transaction_comments (
  PHOENIX_ID STRING,
  PHOENIX_PLAN_ID STRING,
  SECTOR_NAME STRING,
  PER_TYPE_NAME STRING,
  MEASURE_DATE STRING,
  PERIOD_END_DATE STRING,
  PERIOD_MONTHS STRING,
  STATEMENT_BASIS_NAME STRING,
  ACCOUNT_BASIS_NAME STRING,
  APR_ACCEPTABLE STRING,
  SOURCE_FILE_CREATE_DATE STRING,
  SRC_DE_UNIQ_ID_TEXT STRING,
  REPORT_ID STRING,
  COMMENTS STRING,
  VALUE STRING,
  COMMENT_BY STRING,
  COMMENT_DATE_TIME STRING,
  actv_ind STRING,
  create_usr_id STRING,
  last_upd_usr_id STRING,
  create_dttm TIMESTAMP,
  last_upd_dttm TIMESTAMP,
  run_id BIGINT)
USING delta
PARTITIONED BY (PERIOD_END_DATE, SECTOR_NAME)
LOCATION 's3://spr-idf-dev-platform-engineered/ssdqa/catalog/curated/uspf/t_dc_transaction_comments'
TBLPROPERTIES (
  'delta.checkpoint.writeStatsAsJson' = 'false',
  'delta.checkpoint.writeStatsAsStruct' = 'true',
  'delta.enableChangeDataFeed' = 'true',
  'delta.feature.appendOnly' = 'supported',
  'delta.feature.changeDataFeed' = 'supported',
  'delta.feature.invariants' = 'supported');
  

CREATE TABLE IF NOT EXISTS idf_curated_ssdqa.uspf.t_dc_transaction_schedules (
 PHOENIX_ID STRING,
  PHOENIX_PLAN_ID STRING,
  SECTOR_NAME STRING,
  PER_TYPE_NAME STRING,
  MEASURE_DATE STRING,
  PERIOD_END_DATE STRING,
  PERIOD_MONTHS STRING,
  STATEMENT_BASIS_NAME STRING,
  ACCOUNT_BASIS_NAME STRING,
  APR_ACCEPTABLE STRING,
  SOURCE_FILE_CREATE_DATE STRING,
  SRC_DE_UNIQ_ID_TEXT STRING,
  REPORT_ID STRING,
  SCHEDULE_NAME STRING,
  SCHEDULE_VALUE STRING,
  ACTION STRING,
  SCHEDULE_FRMLA_TEXT STRING,
  VALUE STRING,
  ORDER_ID STRING,
  REMARKS STRING,
  SCHEDULE_BY STRING,
  SCHEDULE_DATE_TIME STRING,
  actv_ind STRING,
  create_usr_id STRING,
  last_upd_usr_id STRING,
  create_dttm TIMESTAMP,
  last_upd_dttm TIMESTAMP,
  run_id BIGINT)
USING delta
PARTITIONED BY (PERIOD_END_DATE, SECTOR_NAME)
LOCATION 's3://spr-idf-dev-platform-engineered/ssdqa/catalog/curated/uspf/t_dc_transaction_schedules'
TBLPROPERTIES (
  'delta.checkpoint.writeStatsAsJson' = 'false',
  'delta.checkpoint.writeStatsAsStruct' = 'true',
  'delta.enableChangeDataFeed' = 'true',
  'delta.feature.appendOnly' = 'supported',
  'delta.feature.changeDataFeed' = 'supported',
  'delta.feature.invariants' = 'supported');
  
  
CREATE TABLE IF NOT EXISTS idf_curated_ssdqa.uspf.t_dc_transaction_org (
  PHOENIX_ID STRING,
  SECTOR STRING,
  ORG_PRIMARY_NAME STRING,
  STATE STRING,
  SOURCE_FILE_CREATE_DATE STRING,
  COUNTRY_CODE STRING,
  CURRENCY_CODE STRING,
  DEAL_NAME_DESCRIPTOR STRING,
  FIN_REVENUE_TYPE STRING,
  FIN_REVENUE_SUBTYPE STRING,
  FYE STRING,
  actv_ind STRING,
  create_usr_id STRING,
  last_upd_usr_id STRING,
  create_dttm TIMESTAMP,
  last_upd_dttm TIMESTAMP,
  run_id BIGINT)
USING delta
PARTITIONED BY (SECTOR)
LOCATION 's3://spr-idf-dev-platform-engineered/ssdqa/catalog/curated/uspf/t_dc_transaction_org'
TBLPROPERTIES (
  'delta.checkpoint.writeStatsAsJson' = 'false',
  'delta.checkpoint.writeStatsAsStruct' = 'true',
  'delta.enableChangeDataFeed' = 'true',
  'delta.feature.appendOnly' = 'supported',
  'delta.feature.changeDataFeed' = 'supported',
  'delta.feature.invariants' = 'supported'); 
  

  
-----ssdqa----
-- Log tables
CREATE TABLE IF NOT EXISTS idf_raw_ssdqa.uspf.dp_date_processing_log (
  process_date STRING,
  started_at TIMESTAMP,
  completed_at TIMESTAMP,
  status STRING,
  message_count INT,
  file_count INT,
  error_count INT
)
USING delta
LOCATION 's3://spr-idf-qa-platform-landing/ssdqa/catalog/raw/uspf/dp_date_processing_log'
TBLPROPERTIES (
  'delta.minReaderVersion' = '1',
  'delta.minWriterVersion' = '2');
 
CREATE TABLE IF NOT EXISTS idf_raw_ssdqa.uspf.dp_file_processing_log (
  file_path STRING,
  file_name STRING,
  bucket_name STRING,
  target_table STRING,
  phoenix_id STRING,
  report_id STRING,
  message_key STRING,
  processed_at TIMESTAMP,
  process_date STRING,
  status STRING
)
USING delta
LOCATION 's3://spr-idf-qa-platform-landing/ssdqa/catalog/raw/uspf/dp_file_processing_log'
TBLPROPERTIES (
  'delta.minReaderVersion' = '1',
  'delta.minWriterVersion' = '2');
      
  
  