# Python  Utilities to manage IDF Metadata
This is a implementation for Python based application to manage metadata for idf-data-pipelines .

This code base supports the following features:
- Fetching metadata from Oracle DB and Creating a metadata file and stores into Databricks Volumes
- Creating Catalog for given IDF Schema name and save into Databricks Volumes
- Upload metadata into IDFDB_METADATA Schema in Oracle DB from DataBricks Volumes

The code base is designed to be deployed as Databricks Job.

Below are key python requirements for this code base:
- oracledb for connecting the Oracle Database
- pandas for data manipulation
- xlrd[1.1.0] for reading the Excel files(.xlsx)
- request
- json
- argparse
- os
- sys
- logging


# Steps to Run in Build project
1. Clone the repo in local directory 
    ```
    git clone https://spglobal.visualstudio.com/ratingsproducts/_git/idf-metadadata-utils-rest
    ```
2. Change directory to idf-metadadata-utils-rest
    ```
   cd idf-metadadata-utils-rest
    ```
3. Verify the pyproject.toml file
    ```
   poetry build
    ```
   Verify the dist folder for the generated wheel file
   




# Commands to run the Job
1. For generating Metadata JSON 
 ```
 1. ["--action","generate_metadata","--volume_name","s3://spr-idf-<env>-platform-config/platform/metadata/","--config_file","s3://spr-idf-<env>-platform-config/platform/config/idf2_global_config.json","--level","SCHEMA","--level_value","GS_GC"]
 
 2. ["--action","generate_metadata","--volume_name","s3://spr-idf-<env>-platform-config/platform/metadata/","--config_file","s3://spr-idf-<env>-platform-config/platform/config/idf2_global_config.json","--level","BATCH","--level_value","unique_batch_name"]
 
 3. ["--action","generate_metadata","--volume_name","s3://spr-idf-<env>-platform-config/platform/metadata/","--config_file","s3://spr-idf-<env>-platform-config/platform/config/idf2_global_config.json","--level","TABLE_NAME","--level_value","COMMA SEPARATED TABLES" , "--customized_json_name" , "adhoc.json"]
 
 4. ["--action","generate_metadata","--volume_name","s3://spr-idf-<env>-platform-config/platform/metadata/","--config_file","s3://spr-idf-<env>-platform-config/platform/config/idf2_global_config.json","--level","TABLE_ID","--level_value","COMMA SEPARATED TABLE IDs", "--customized_json_name" , "adhoc.json"]
 
 5. ["--action","generate_metadata","--volume_name","s3://spr-idf-<env>-platform-config/platform/metadata/","--config_file","s3://spr-idf-<env>-platform-config/platform/config/idf2_global_config.json"]
 
 ```

2. For uploading the Metadata JSON to Oracle DB.
   There are two options to upload the metadata all the files in the Volume or Specific files in the Location.
   
   If we are not passing the metadata_file then it will process only the that file, else it will upload all the data form volume_name
```
  1. ["--action","load_metadata","--config_file","{rsm:<env>.config.idf2_global.file.secret}","--volume_name","s3://spr-idf-<env>-platform-config/platform/metadata_mapping/","--config_file_env","DEV"]
  2. ["--action","load_metadata","--config_file","{rsm:<env>.config.idf2_global.file.secret}","--volume_name","s3://spr-idf-<env>-platform-config/platform/metadata_mapping/","--config_file_env","DEV","--metadata_file","Metadata_core_ads.xlsx"]
  
```

3. For generating Catalog JSON
  ```
   1. ["--action","generate_catalog","--config_file","s3://spr-idf-<env>-platform-config/platform/config/idf2_global_config.json","--volume_name","s3://spr-idf-<env>-platform-config/platform/metadata/catalog_sql/","--processed_location","spr-idf-<env>-platform-processed","--level","TABLE_ID","--level_value","COMMA SEPERATED TABLE IDs"]
   
   2. ["--action","generate_catalog","--config_file","s3://spr-idf-<env>-platform-config/platform/config/idf2_global_config.json","--volume_name","s3://spr-idf-<env>-platform-config/platform/metadata/catalog_sql/","--processed_location","spr-idf-<env>-platform-processed","--level","TABLE_NAME","--level_value","COMMA SEPERATED TABLE Namess"]

   2. ["--action","generate_catalog","--config_file","s3://spr-idf-<env>-platform-config/platform/config/idf2_global_config.json","--volume_name","s3://spr-idf-<env>-platform-config/platform/metadata/catalog_sql/","--processed_location","spr-idf-<env>-platform-processed","--level","SCHEMA","--level_value","Schema Name"]
```
4. For Managing the Job