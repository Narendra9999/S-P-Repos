from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker
import pandas as pd

# Sample DataFrame
data_to_merge = pd.DataFrame({
    'name': ['Alice', 'Bob', 'Charlie'],
    'age': [30, 25, 35]
})

# Create an engine (replace with your actual database URI)
engine = create_engine('oracle+cx_oracle://username:password@host:port/service_name')

# Create a configured "Session" class
Session = sessionmaker(bind=engine)

# Start a session and transaction
session = Session()

try:
    # Step 1: Dynamically construct the `WITH` clause from the DataFrame
    cte_parts = []

    # Iterate over the DataFrame rows and build the SELECT statements
    for idx, row in data_to_merge.iterrows():
        cte_parts.append(f"SELECT :name{idx} AS name, :age{idx} AS age FROM dual")

    # Join all parts with UNION ALL to create the full CTE query
    cte_query = " UNION ALL ".join(cte_parts)

    # Step 2: Create the full SQL MERGE statement
    merge_sql = text(f"""
        WITH new_data (name, age) AS (
            {cte_query}
        )
        MERGE INTO users target
        USING new_data source
        ON (target.name = source.name)
        WHEN MATCHED THEN
            UPDATE SET target.age = source.age
        WHEN NOT MATCHED THEN
            INSERT (name, age)
            VALUES (source.name, source.age)
    """)

    # Step 3: Prepare the parameters for the SQL statement
    params = {}
    for idx, row in data_to_merge.iterrows():
        params[f'name{idx}'] = row['name']
        params[f'age{idx}'] = row['age']

    # Step 4: Execute the SQL with parameters
    session.execute(merge_sql, params)

    # Commit the transaction
    session.commit()
    print("Transaction committed successfully.")

except Exception as e:
    # If an error occurs, rollback the transaction
    session.rollback()
    print(f"Transaction failed: {e}")

finally:
    # Close the session
    session.close()
