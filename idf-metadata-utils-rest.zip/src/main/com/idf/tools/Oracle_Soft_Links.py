import boto3
import cx_Oracle
import getopt
import json
import os
import sys
from botocore.config import Config
from main.com.idf.tools.RSMUtil import getpassword

try:
    opts, args = getopt.getopt(sys.argv[1:], 'l:f:d:s:',
                               ['conf_file_location=', 'conf_file_name=', 'database=', 'schema='])
except getopt.GetoptError:
    usage()
    raise Exception('non-dashed options "%s" not recognized' % args)
    sys.exit(2)

for opt, arg in opts:
    if opt in ('-l', '--conf_file_location'):
        conf_file_location = arg
    elif opt in ('-f', '--conf_file_name'):
        conf_file_name = arg
    elif opt in ('-d', '--database'):
        database = arg
    elif opt in ('-s', '--schema'):
        schema = arg
    else:
        usage()
        sys.exit(2)

print('conf_file_location  :', conf_file_location)
print('conf_file_name      :', conf_file_name)
print('database            :', database)
print('schema              :', schema)


def GetAWS_Config():
    global db_usrname
    global db_pswd
    global db_schema
    # global softlink_usrname
    # global softlink_pswd
    global db_url
    global processed_location
    global aws_region
    aws_region = os.getenv("aws_region")

    boto3.client('ssm')
    session = boto3.Session(region_name=aws_region)
    ssm = session.client("ssm")
    location = ssm.get_parameter(Name=conf_file_location, WithDecryption=True)
    global_filename = ssm.get_parameter(Name=conf_file_name, WithDecryption=True)
    client = boto3.client('s3')
    bucket_value = location['Parameter']['Value']
    gfilename_value = global_filename['Parameter']['Value']
    BUCKET = bucket_value.split("/")[0]
    KEY = bucket_value.split("/")[1] + '/' + bucket_value.split("/")[2] + '/' + gfilename_value
    result = client.get_object(Bucket=BUCKET, Key=KEY)
    text = result["Body"].read().decode()
    read_json = json.loads(text)
    db_usrname = read_json["control_table_conf"]["control_table_db_username"]
    secrect_pwd = read_json["control_table_conf"]["control_table_db_pwd"]
    db_pswd = getpassword(secrect_pwd[6:-1])
    # softlink_usrname = read_json["db_conf"]["db_instance"]["idf_query"]["rdbms_user_name"]
    # softlink_pswd = read_json["db_conf"]["db_instance"]["idf_query"]["rdbms_user_password"]
    db_url = read_json["control_table_conf"]["control_table_db_url"].split("//")[1]
    processed_location = read_json["s3_conf"]["s3_processed_location"]
    db_schema = read_json["control_table_conf"]["control_table_schema_owner"]


def Data_Catalog():
    try:
        # connstr = 'IDF_METADATA_USER/IDF_METADATA_USER_2018@spdrac-scan.dev.spratingsvpc.com/metadev.world'
        # connstr = 'IDF_METADATA_USER/idf_metadata_user_2018@fgracebs1-scan.qa.spratingsvpc.com:1521/metaqa.world'
        connstr = db_usrname + "/" + db_pswd + '@' + db_url
        connection = cx_Oracle.connect(connstr)

    except cx_Oracle.DatabaseError as e:
        raise
    cursor = connection.cursor()

    tables_list = "SELECT DISTINCT t.table_name,t.table_size_classification,abt.database_name " \
                  "FROM " + db_schema + ".rltnl_database_param d " \
                                        "JOIN " + db_schema + ".rltnl_schema s " \
                                                              "ON     d.rltnl_database_id = s.rltnl_database_id " \
                                                              "AND s.schema_name = upper('" + schema + "') " \
                                                                                                       "JOIN " + db_schema + ".rltnl_table t " \
                                                                                                                             "ON s.rltnl_schema_id = t.rltnl_schema_id " \
                                                                                                                             "JOIN " + db_schema + ".rltnl_abstrctn_col_map c " \
                                                                                                                                                   "ON t.rltnl_table_id = c.rltnl_table_id " \
                                                                                                                                                   "JOIN " + db_schema + ".abstrctn_table abt " \
                                                                                                                                                                         "ON c.abstrctn_table_id = abt.abstrctn_table_id " \
                                                                                                                                                                         "WHERE d.db_instance_id = upper('" + database + "') order by t.table_size_classification"

    cursor.execute(tables_list)
    tables_check = cursor.fetchone()

    if tables_check is None:
        print(
            "There are no tables to process for the mentioned Database " + database + " and the schema " + schema + "!!!")
        sys.exit()
    else:
        dir = "/home/idf/difftool/Databases/" + database + "/" + schema + "/SoftLinkFiles/"
        if os.path.exists(dir + "Consolidated_Soft_Link.sql"):
            os.remove(dir + "Consolidated_Soft_Link.sql")
            print("Consolidated sql File Removed!")
        else:
            print('Consolidated sql File does not exists')

        cursor.execute(tables_list)
        tables_loop = cursor.fetchall()

    for ind in range(len(tables_loop)):
        abstraction_schema = str(tables_loop[ind][2])

    for ind in range(len(tables_loop)):
        ls_colist_query = "select a.TABLE_NAME,nvl(RTRIM(REPLACE(REPLACE(XMLAGG(XMLELEMENT(\"a\",a.COLUMN_DATA_TYPE||CHR(10)) " \
                          "order by a.COLUMN_ORDR_NBR NULLS LAST).getClobVal(),'<a>',''),'</a>',','),','),'No Columns') as col_list " \
                          "from (select T.TABLE_NAME,DC.COLUMN_ORDR_NBR," \
                          "case when C.COLUMN_DATATYPE ='NUMBER' and C.DATA_PRECISION is null and C.DATA_SCALE is null " \
                          "then " \
                          "'case when substr('||C.FINAL_COLUMN||', 1, 2)=\\''-.\\'' then replace('||C.FINAL_COLUMN||', \\''-.\\'', \\''-0.\\'' ) '||CHR(10)|| " \
                          "      'when substr('||C.FINAL_COLUMN||',1,1)=\\''.\\'' then replace ('||C.FINAL_COLUMN||', \\''.\\'', \\''0.\\'') '||CHR(10)|| " \
                          "     'else cast('||C.FINAL_COLUMN||' as varchar2(110))' ||CHR(10)|| " \
                          " 'end as ' ||C.FINAL_COLUMN " \
                          "else c.FINAL_COLUMN " \
                          "end as COLUMN_DATA_TYPE " \
                          "from " \
                          + db_schema + ".RLTNL_SCHEMA s, " + db_schema + ".RLTNL_TABLE t, (select col.*,case when col.COLUMN_NAME<>upper(col.COLUMN_NAME) then CHR(34)||col.COLUMN_NAME||CHR(34) else col.COLUMN_NAME end FINAL_COLUMN from " + db_schema + ".RLTNL_COLUMN col) c, " + db_schema + ".DATA_FILE_COLUMN dc, " \
                          + db_schema + ".RLTNL_DATA_FILE_COL_MAP rdf , " + db_schema + ".RLTNL_DATABASE_PARAM P " \
                                                                                        "where T.RLTNL_SCHEMA_ID = S.RLTNL_SCHEMA_ID " \
                                                                                        "and C.RLTNL_TABLE_ID = T.RLTNL_TABLE_ID " \
                                                                                        "and RDF.RLTNL_TABLE_ID = T.RLTNL_TABLE_ID " \
                                                                                        "and RDF.RLTNL_COLUMN_ID = C.RLTNL_COLUMN_ID " \
                                                                                        "and RDF.DATA_FILE_COLUMN_ID = Dc.DATA_FILE_COLUMN_ID " \
                                                                                        "and S.SCHEMA_NAME = UPPER('" + schema + "') " \
                                                                                                                                 "and T.TABLE_NAME='" + str(
            tables_loop[ind][0]) + "' " \
                                   "and P.DB_INSTANCE_ID =UPPER('" + database + "') " \
                                                                                "and P.RLTNL_DATABASE_ID =S.RLTNL_DATABASE_ID " \
                                                                                "order by DC.COLUMN_ORDR_NBR) a group by a.TABLE_NAME "

        cursor.execute(ls_colist_query)
        query_check = cursor.fetchone()

        if query_check is None:
            print("There are no Columns for the table to process!!!" + str(tables_loop[ind][0]))
        else:
            cursor.execute(ls_colist_query)
            collist_query_loop = cursor.fetchall()

            if 'No Columns' in collist_query_loop:
                print("Column List is NULL for the table :" + table_name)
            else:
                for row in collist_query_loop:
                    table_nm = row[0]
                    col_list_row = row[1].read().replace('&apos;', '\'')
                    col_list = col_list_row.replace('&quot;', '"')

                    if str(table_nm) is 'None' and str(col_list) is 'None':
                        print("Column List to generate the Soft Links are not avilable for the table :" + table_name)
                    else:
                        ls_query = "select unique s.schema_name,t.table_name,P.DB_HOST,P.DB_CONNECT_PORT_NUM,P.DB_SERVICE_NAME,T.TABLE_SIZE_CLASSIFICATION " \
                                   "from " + db_schema + ".RLTNL_SCHEMA s, " + db_schema + ".RLTNL_TABLE t, " + db_schema + ".RLTNL_COLUMN c, " + db_schema + ".DATA_FILE_COLUMN dc, " \
                                   + db_schema + ".RLTNL_DATA_FILE_COL_MAP rdf , " + db_schema + ".RLTNL_DATABASE_PARAM P " \
                                                                                                 "where T.RLTNL_SCHEMA_ID = S.RLTNL_SCHEMA_ID " \
                                                                                                 "and C.RLTNL_TABLE_ID = T.RLTNL_TABLE_ID " \
                                                                                                 "and RDF.RLTNL_TABLE_ID = T.RLTNL_TABLE_ID " \
                                                                                                 "and RDF.RLTNL_COLUMN_ID = C.RLTNL_COLUMN_ID " \
                                                                                                 "and RDF.DATA_FILE_COLUMN_ID = Dc.DATA_FILE_COLUMN_ID " \
                                                                                                 "and S.SCHEMA_NAME = UPPER('" + schema + "') " \
                                                                                                                                          "and T.TABLE_NAME='" + str(
                            tables_loop[ind][0]) + "' " \
                                                   "and P.DB_INSTANCE_ID =UPPER('" + database + "') " \
                                                                                                "and P.RLTNL_DATABASE_ID =S.RLTNL_DATABASE_ID "

                        cursor.execute(ls_query)
                        query_check = cursor.fetchone()

                        if query_check is None:
                            print("There are no Columns to process!!!" + str(tables_loop[ind][0]))
                        else:
                            cursor.execute(ls_query)
                            query_loop = cursor.fetchall()

                            for row in query_loop:
                                host = row[2]
                                port = row[3]
                                service_name = row[4]
                                table_size_class = row[5]

                                if table_size_class in ['XL', 'XXL', 'SPL']:
                                    srid_random_number = "rowidtochar(rowid) as srid,round(DBMS_RANDOM.value (1, 10000)) random_number"
                                else:
                                    srid_random_number = "rowidtochar(rowid) as srid"

                                soft_link = "CREATE TABLE IF NOT EXISTS ORA_" + abstraction_schema + "." + str(
                                    tables_loop[ind][0]) + "\n" \
                                                           "USING JDBC \n" \
                                                           "OPTIONS ( \n" \
                                                           "url 'jdbc:oracle:thin:IDF_SQOOP_USER/IDF_SQOOP_USER@//" + host + ":" + str(
                                    port) + "/" + service_name + "',\n" \
                                                                 "serialization.format '1', \n" \
                                                                 "driver 'oracle.jdbc.driver.OracleDriver', \n" \
                                                                 "fetchsize '10000', \n" \
                                                                 "dbtable '(select /*+ parallel (a 4) */ " + srid_random_number + "," + str(
                                    col_list) + "from " + schema + "." + str(tables_loop[ind][0]) + " a) tmp', \n" \
                                                                                                    "user 'IDF_SQOOP_USER', \n" \
                                                                                                    "password 'sqoopusr' \n" \
                                                                                                    ");"

                                if not os.path.exists(dir):
                                    os.makedirs(dir)

                                file_name = str(tables_loop[ind][0]) + ".sql"
                                Consolidated_file_name = "Consolidated_Soft_Link.sql"
                                Create_Database = "CREATE DATABASE IF NOT EXISTS ORA_" + abstraction_schema + "  COMMENT 'To store SoftLinks DB/Schema: " + database + "/" + schema + "' LOCATION '" + processed_location + "warehouse/ORA_" + abstraction_schema + ".db';\n"

                                f = open(dir + file_name, 'w')
                                f.write(str(soft_link))
                                f.close()

                                hs = open(dir + Consolidated_file_name, "a")
                                if (os.path.getsize(dir + Consolidated_file_name) > 0):
                                    hs.write("\n\n" + str(soft_link))
                                else:
                                    hs.write(Create_Database + str(soft_link))

                                hs.close()


GetAWS_Config()
Data_Catalog()
