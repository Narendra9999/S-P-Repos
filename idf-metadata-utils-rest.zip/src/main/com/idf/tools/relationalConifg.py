"""
Author: 	srinivas.dumpala@spglobal.com
Date: 	2024-09-19
This module holds the configuration for the relational databases
"""
from dataclasses import dataclass , field
@dataclass
class DatabaseConfig:
    db_schema:str
    db_usrname:str
    db_pswd:str
    db_url:str
    db_env:str
    aws_region:str