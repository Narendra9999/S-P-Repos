#!/usr/bin/bash
filename=/home/idf/difftool/Scripts/.diff_batch_process
Datetime=`date "+%Y%m%d"`

while read -r line; do
    name="$line"
    database="$(echo $name | cut -d'~' -f1)"
    schema="$(echo $name | cut -d'~' -f2)"
    table_name="$(echo $name | cut -d'~' -f3)"
    path="/home/idf/difftool/Databases/$database/$schema"
    echo "spark-sql -S --name diff_$table_name --driver-memory 7g --driver-cores 2 --executor-memory 7g --executor-cores 1 --queue default --conf spark.dynamicAllocation.minExecutors=2  --conf spark.dynamicAllocation.maxExecutors=10  --conf spark.dynamicAllocation.initialExecutors=2 -f $path/DiffToolFiles/$table_name.sql"
    spark-sql -S --name diff_$table_name --driver-memory 7g --driver-cores 2 --executor-memory 7g --executor-cores 1 --queue default --conf spark.dynamicAllocation.minExecutors=2  --conf spark.dynamicAllocation.maxExecutors=10  --conf spark.dynamicAllocation.initialExecutors=2 -f $path/DiffToolFiles/$table_name.sql>>/local/apps/idf/diff_logs/Diff_$Datetime.log
done < "$filename" >>/local/apps/idf/diff_logs/Diff_$Datetime.log
