import logging
import oracledb
import json
import os, sys
import argparse
import pandas as pd
from .RSMUtil import getpassword


from main.com.idf.utils.VolumeManagement import read_data_from_volume
from main.com.idf.tools.relationalConifg import DatabaseConfig
from main.com.idf.utils.DBUtil import get_metadata_db_connection
from main.com.idf.utils.catalog_constants import *
from main.com.idf.utils.AWSUtil import upload_json_to_s3
from main.com.idf.utils.AWSUtil import read_s3_file


abstraction_col_names = ["ABSTRACTION_COLUMN_NAME", "ABSTRACTION_COLUMN_DATATYPE", "ABSTRACTION_DATA_LENGTH",
                             "ABSTRACTION_DATA_PRECISION", "ABSTRACTION_DATA_SCALE"]

def get_control_table_conf(configuration_file):
    if configuration_file.startswith("/Volumes"):
        global_json = read_data_from_volume(configuration_file)
    elif configuration_file.startswith("s3://") or configuration_file.startswith("spr-idf"):
        global_json = read_s3_file(configuration_file)
    else:
        raise ValueError(f"Invalid Config File Path provided {configuration_file}")
    #global_json = read_data_from_volume(configuration_file)
    read_json = json.loads(global_json)
    db_usrname = read_json["control_table_conf"]["control_table_db_username"]
    secrect_pwd = read_json["control_table_conf"]["control_table_db_pwd"]
    db_pswd = getpassword(secrect_pwd[6:-1])
    db_url = read_json["control_table_conf"]["control_table_db_url"].split("//")[1]
    db_env = read_json["control_table_conf"]["control_table_db_url"].split("/")[3]
    db_schema = read_json["control_table_conf"]["control_table_schema_owner"]
    aws_region = os.getenv("aws_region")
    database_config = DatabaseConfig(db_schema, db_usrname, db_pswd, db_url, db_env, aws_region)
    return database_config




def get_partition_string(partition_level_dataframe:pd.DataFrame, abstraction_table_id:int) -> str:
    partition_level_dataframe = partition_level_dataframe[partition_level_dataframe["ABSTRCTN_TABLE_ID"] == abstraction_table_id]
    if partition_level_dataframe is not None:
        partition_level_dataframe = partition_level_dataframe.sort_values(by='PARTITION_ORDER')
        partition_string_columns = []
        for index, row in partition_level_dataframe.iterrows():
            partition_string_columns.append(row["PARTITION_NAME"])
        return "PARTITIONED BY (" + ",".join(partition_string_columns) + ")" if partition_string_columns else ""
    else:
        return ""

def build_columns(column_dataframe:pd.DataFrame) -> str:
    column_dataframe = column_dataframe[abstraction_col_names]
    column_string = []
    for index, row in column_dataframe.iterrows():
        if row["ABSTRACTION_COLUMN_DATATYPE"] == "DECIMAL":
            column_string.append(row["ABSTRACTION_COLUMN_NAME"] + " " + row["ABSTRACTION_COLUMN_DATATYPE"] + "(" + str(int(row["ABSTRACTION_DATA_PRECISION"])) + "," + str(int(row["ABSTRACTION_DATA_SCALE"])) + ")")
        else:
            column_string.append(row["ABSTRACTION_COLUMN_NAME"] + " " + row["ABSTRACTION_COLUMN_DATATYPE"])
    return " ,".join(column_string)

def build_table_sql(table_level_dataframe:pd.DataFrame,
                    partition_dataframe:pd.DataFrame,
                    abs_schema_name:str,schema_name:str, table_name:str,
                    location:str,schema_classification:str) -> (str,str):
    column_string:str = build_columns(table_level_dataframe)
    table_location = f"s3://{location}/replication/idf2/{schema_classification}/{schema_name}/{table_name}"
    partition_string = get_partition_string(partition_dataframe, table_level_dataframe["ABSTRCTN_TABLE_ID"].iloc[0])
    table_string = f"CREATE TABLE IF NOT EXISTS {abs_schema_name}.t_{table_name} ( {column_string} ) USING DELTA {partition_string} COMMENT 'This table is related to RDBMS table :{table_name}' LOCATION '{table_location}' TBLPROPERTIES ('delta.enableChangeDataFeed' = 'true');"
    view_filter = table_level_dataframe["VIEW_FILTER_SQL_TEXT"].iloc[0]
    view_sql = "CREATE VIEW IF NOT EXISTS {0}.v_{1} AS SELECT * FROM {0}.t_{1} {2};".format(abs_schema_name, table_name,view_filter)
    return table_string , view_sql

def convert_precision_scale_to_str(value) -> str:
    if pd.isna(value):
        return 'None'
    else:
        return str(int(value))

def enrich_metadata(metadata_dataframe:pd.DataFrame) -> pd.DataFrame:
    metadata_dataframe['CDC_FLAG'] = metadata_dataframe['CDC_FLAG'].fillna(
        'N').astype(str)
    metadata_dataframe['RDBMS_PACKAGE_FLAG'] = metadata_dataframe['RDBMS_PACKAGE_FLAG'].fillna(
        'N').astype(str)
    metadata_dataframe['SCHEMA_PACKAGE_NAME'] = metadata_dataframe['SCHEMA_PACKAGE_NAME'].fillna(
        'N').astype(str)
    metadata_dataframe['ABSTRACTION_DATA_PRECISION'] = metadata_dataframe['ABSTRACTION_DATA_PRECISION'].apply(convert_precision_scale_to_str)
    metadata_dataframe['ABSTRACTION_DATA_SCALE'] = metadata_dataframe['ABSTRACTION_DATA_SCALE'].apply(convert_precision_scale_to_str)
    metadata_dataframe['ABSTRACTION_BUCKET_COUNT'] = metadata_dataframe['ABSTRACTION_BUCKET_COUNT'].fillna(0).astype(
        int)
    metadata_dataframe['ABSTRACTION_BUCKET_SORT_ORDER'] = metadata_dataframe['ABSTRACTION_BUCKET_SORT_ORDER'].fillna('None').astype(str)
    rdbms_check_columns = ["STRING", "TIMESTAMP", "DATE"]
    metadata_dataframe.loc[
        metadata_dataframe['ABSTRACTION_COLUMN_DATATYPE'].isin(rdbms_check_columns), 'RDBMS_DATA_PRECISION'] = 'None'
    metadata_dataframe['RDBMS_DATA_PRECISION'] = metadata_dataframe['RDBMS_DATA_PRECISION'].astype(str)
    metadata_dataframe.loc[
        metadata_dataframe['ABSTRACTION_COLUMN_DATATYPE'].isin(rdbms_check_columns), 'RDBMS_DATA_SCALE'] = 'None'
    metadata_dataframe['RDBMS_DATA_PRECISION'] = metadata_dataframe['RDBMS_DATA_PRECISION'].astype(str)
    metadata_dataframe['RDBMS_SQL_TEXT'] = metadata_dataframe['RDBMS_SQL_TEXT'].fillna('').astype(str)
    metadata_dataframe['VIEW_FILTER_SQL_TEXT'] = metadata_dataframe['VIEW_FILTER_SQL_TEXT'].fillna('').astype(str)
    return metadata_dataframe


def generate_data_catalog_for_schema(schema_level_dataframe:pd.DataFrame,
                                     partition_dataframe:pd.DataFrame,
                                     abs_schema_name:str,
                                     location:str,
                                     target_path:str):
    """
    This function generates the data catalog for the schema level and write the file into volume

    :param schema_level_dataframe: The dataframe containing the schema level information
    :param partition_dataframe: The dataframe containing the partition information
    :param abs_schema_name: Abstraction Schema Name
    :param location: The location where the data is stored
    :param target_path: The target_path where .sql is stored

    :return: None
    """
    catalog_file_name = os.path.join(target_path , abs_schema_name.lower() + ".sql")
    unique_abstraction_tables = schema_level_dataframe["ABSTRACTION_TABLE_NAME"].unique()
    schema_classification = schema_level_dataframe.iloc[0]["RDBMS_SCHEMA_CLASSIFICATION"]
    schema_name = schema_level_dataframe.iloc[0]["RDBMS_SCHEMA_NAME"]
    sqls = []
    for table_name in unique_abstraction_tables:
        print(f"Processing table {table_name}")
        table_level_dataframe = schema_level_dataframe[schema_level_dataframe["ABSTRACTION_TABLE_NAME"] == table_name]
        table_sql = build_table_sql(table_level_dataframe,partition_dataframe,
                                    abs_schema_name,schema_name,table_name,
                                    location,schema_classification)
        sqls.append(table_sql[0])
        sqls.append(table_sql[1])
    table_sqls = "\n".join(sqls)
    upload_sqls_to_target(target_path, abs_schema_name.lower(), table_sqls)
    # with open(catalog_file_name, "a") as catalog_file:
    #     catalog_file.write(table_sqls)

def generate_data_catalog_for_table_level(table_level_dataframe:pd.DataFrame,partition_dataframe:pd.DataFrame,
                                          table_name:str,location:str,
                                          target_path:str) -> (str,str):
    """
    This function generates the data catalog for the table level and write the file into volume

    :param table_level_dataframe: The dataframe containing the table level information filtered by table name or table id
    :param partition_dataframe: The dataframe containing the partition information
    :param table_name: The name of the table
    :param location: The location where the data is stored
    :param target_path: The name of the location where .sql is file is stored

    :return: None
    """
    schema_classification = table_level_dataframe.iloc[0]["RDBMS_SCHEMA_CLASSIFICATION"]
    schema_name = table_level_dataframe["RDBMS_SCHEMA_NAME"].iloc[0]
    abs_schema_name = table_level_dataframe.iloc[0]["ABSTRACT_SCHEMA_NAME"]
    table_sql = build_table_sql(table_level_dataframe, partition_dataframe,
                                abs_schema_name, schema_name, table_name,
                                location, schema_classification)

    table_sqls = "\n".join([table_sql[0] , table_sql[1]])
    upload_sqls_to_target(target_path, table_name.lower(), table_sqls)

    # with open(catalog_file_name, "w") as catalog_file:
    #     catalog_file.write(table_sqls)

def catalog_creation(generate_catalog_args):
    logging.info(f"Generating catalog ${generate_catalog_args}")
    db_config_file = generate_catalog_args.config_file
    level = generate_catalog_args.level
    level_value = generate_catalog_args.level_value
    processed_location =  generate_catalog_args.processed_location
    sql_stored_location =   generate_catalog_args.volume_name
    control_table_config = get_control_table_conf(db_config_file)
    conn = get_metadata_db_connection(control_table_config.db_usrname , control_table_config.db_pswd, control_table_config.db_url)
    metadata_dataframe = pd.read_sql(metadata_sql_query, conn)
    enrich_metadata(metadata_dataframe)
    logging.info(f"Metadata dataframe is enriched Successfully ")
    partition_dataframe = pd.read_sql(partition_sql_query, conn)

    if level == "SCHEMA":
        """
        For schema level only one file will be generated with schema_name.sql
        1. from full metadata dataframe, filter the schema level dataframe
        2. Call generate_data_catalog_for_schema function
        """
        input_schemas = level_value.split(",")
        for schema in input_schemas:
            schema_level_dataframe = metadata_dataframe[metadata_dataframe["ABSTRACT_SCHEMA_NAME"] == schema]
            if schema_level_dataframe.empty:
                logging.warning(f"No schema found with name {schema}")
            else:
                logging.info(f"Processing schema {schema} with length length {len(schema_level_dataframe)}")
                generate_data_catalog_for_schema(schema_level_dataframe, partition_dataframe, schema, processed_location, sql_stored_location)
    elif level == "TABLE_ID":

        level_value = list(map(int , level_value.split(",")))
        logging.info(f"Generating catalog for provided list of  table ids {level_value}")
        table_level_dataframe = metadata_dataframe[metadata_dataframe["RDBMS_TABLE_ID"].isin(level_value)]
        if table_level_dataframe.empty:
            logging.warning(f"No tables found with table id {level_value}")
        else:
            for a_table in table_level_dataframe["ABSTRACTION_TABLE_NAME"].unique():
                logging.info("Processing table " + a_table)
                table_dataframe = table_level_dataframe[table_level_dataframe["ABSTRACTION_TABLE_NAME"] == a_table]
                if table_dataframe.empty:
                    logging.warning(f"No table found with table id {a_table}")
                else:
                    generate_data_catalog_for_table_level(table_dataframe, partition_dataframe, a_table,
                                                          processed_location, sql_stored_location)
    elif level == "TABLE_NAME":
        logging.info("Generating catalog for table name")
        table_names = level_value.split(",")
        table_level_dataframe = metadata_dataframe[metadata_dataframe["RDBMS_TABLE_NAME"].isin(table_names)]
        if table_level_dataframe.empty:
            logging.warning(f"No tables found with table name {level_value}")
        else:
            for a_table in table_names:
                table_dataframe = table_level_dataframe[table_level_dataframe["RDBMS_TABLE_NAME"] == a_table]
                generate_data_catalog_for_table_level(table_dataframe, partition_dataframe, a_table, processed_location, sql_stored_location)

    elif level is None:
        logging.warning("No level is provided, generating catalog for all the DBs and all the schemas")
        """
        1. Find out all the unique abstraction schema names
        2. For each schema name, call generate_data_catalog_for_schema function
        """
        unique_abstraction_schemas = metadata_dataframe["ABSTRACT_SCHEMA_NAME"].unique()
        for abs_schema in unique_abstraction_schemas:
            schema_level_dataframe = metadata_dataframe[metadata_dataframe["ABSTRACT_SCHEMA_NAME"] == abs_schema]
            generate_data_catalog_for_schema(schema_level_dataframe, partition_dataframe, abs_schema, processed_location, sql_stored_location)
    else:
        raise ValueError(f"Invalid level provided {level}")

def upload_sqls_to_target(target_path:str,sql_file_name:str,sql_string:str) -> None:
    if target_path.lower().startswith('s3://') or target_path.lower().startswith('spr-idf'):
        upload_json_to_s3(target_path, sql_file_name + ".sql", sql_string)
    else:
        with open(os.path.join(target_path, sql_file_name.lower() + ".sql"), 'w') as f:
            f.write(json.dumps(sql_string))



