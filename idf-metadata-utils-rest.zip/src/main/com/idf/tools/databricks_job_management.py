import requests
import os
import json
from dataclasses import dataclass
import time
import logging
import sys
import oracledb
from main.com.idf.tools.RSMUtil import getpassword
import main.com.idf.utils.MetadataUtilV2 as mu

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')


@dataclass
class JobMetadata:
    job_name    :str
    jar_name    :str
    main_class  :str
    task_properties :str

@dataclass
class MetadataClass:
    name: str
    libraries: str
    main_class_name: str
    parameters: str
    email_on_start: str
    email_on_success: str
    email_on_failure: str
    no_alert_for_skipped_runs: bool
    timeout_seconds: int
    max_retries: int
    min_retry_interval_millis: int
    retry_on_timeout: int
    max_concurrent_runs: int
    existing_cluster_name: str
    new_cluster_ind: str
    new_cluster_policy_name: str
    new_cluster_payload: str
    access_level: str





class IDF2_Manage_Jobs:
    def __int__(self,baseURL,Token):
        self.baseURL = ""
        self.Token = ""

    def get_host(self):
        aws_env = os.getenv("aws_env")
        host = ""

        if aws_env == "prod":
            host = "spg-ratings-idf-prod.cloud.databricks.com"
        elif aws_env == "dev":
            host = "spg-ratings-idf-dev.cloud.databricks.com"
        elif aws_env == "qa":
            host = "spg-ratings-idf-qa.cloud.databricks.com"
        elif aws_env == "uat":
            host = "spg-ratings-idf-uat.cloud.databricks.com"
        elif aws_env == "dr":
            host = "spg-ratings-idf-dr.cloud.databricks.com"
        databricks_url = f"https://{host}/api/2.0/jobs/"
        permission_url = f"https://{host}/api/2.0/preview/permissions/jobs/"
        return host,databricks_url ,permission_url

    def get_meta_connection(self,db_usrname,db_pswd,db_url):
        try:
            connection = oracledb.connect(user= db_usrname, password=db_pswd,dsn=db_url)
            return connection
        except oracledb.DatabaseError as exc:
            err, = exc.args
            print("Oracle-Error-Code:", err.code)
            print("Oracle-Error-Message:", err.message)

    def update_metadata(self,Flag,JobName,Job_id,metadata_config:mu.meta_data):
        schema = metadata_config.db_schema
        sql = ""
        if Flag == "U-C":
            sql = "update " + schema + ".IDF_JOBS_METADATA set JOB_ID = " + str(Job_id) + ",UPDATED_ON = Sysdate,Latest_action = 'Job Created' where lower(JOB_NAME) = '" + str(JobName).lower() + "'"
        elif Flag == "U-U":
            sql = "update " + schema + ".IDF_JOBS_METADATA set JOB_ID = " + str(Job_id) + ",UPDATED_ON = Sysdate,Latest_action = 'Job Updated' where lower(JOB_NAME) = '" + str(JobName).lower() + "'"
        elif Flag == "U-D":
            sql = "update " + schema + ".IDF_JOBS_METADATA set JOB_ID = null ,UPDATED_ON = Sysdate,Latest_action = 'Job Deleted' where lower(JOB_NAME) = '" + str(JobName).lower() + "'"

        conn = self.get_meta_connection(metadata_config.db_usrname,
                                        metadata_config.db_pswd,
                                        metadata_config.db_url)
        try:
            with conn.cursor() as cursor:
                cursor.execute(sql)
                conn.commit()
        except oracledb.Error as error:
            logging.error(error)
        finally:
            conn.close()

    def processListValues(self,param):
        if param == None:
            return None
        else:
            params = ""
            for val in str(param).split(","):
                params = params + '"' + str(val) + '",'
            return params[:-1]

    def processListIdorName(self,job_id_name_list):
        IdList = "0,"
        NameList = "'dummmy',"
        for job in job_id_name_list.split(","):
            if str(job).isnumeric():
                IdList += str(job) + ","
            else:
                NameList += "'" + str(job).lower() + "',"
        finalList = [IdList[:-1], NameList[:-1]]
        filter = """ and ((job_id in ({}) and ACTIVE_IND = 'Y') or (lower(JOB_NAME) in ({}) and ACTIVE_IND = 'Y'))""".format(finalList[0],finalList[1])
        return filter

    def getJobMetadata(self,conn,job_id_name_list,metadata_config:mu.meta_data):
        #idfcls = IDF2_Manage_Jobs()
        filter = ""
        if job_id_name_list.lower() != "all":
            filter = self.processListIdorName(job_id_name_list)
        sql = """Select job_name,Jar_Libraries_List,main_class,Job_Parameter_List,Start_Email_List,Success_Email_List,Failure_Email_List,Email_If_Rows_Skipped,timeout_seconds,
max_retries,min_retry_interval_millis,retry_on_timeout,max_concurrent_runs,Existing_Cluster_Name,New_Cluster_Ind,New_cluster_Policy_Name,New_Cluster_Payload,Access_Level
FROM {}.IDF_JOBS_METADATA WHERE ACTIVE_IND = 'Y' {} """.format(metadata_config.db_schema,filter)
        #print(sql)
        cursor = conn.cursor()
        try:
            MetadataList = []
            for row in cursor.execute(sql):
                MetaClassObj = MetadataClass(row[0], self.processListValues(row[1]), row[2], row[3],self.processListValues(row[4]),self.processListValues(row[5]), self.processListValues
(row[6]),self.processListValues(row[7]), row[8], row[9],row[10], row[11], row[12], row[13], row[14], row[15],row[16],row[17])
                MetadataList.append(MetaClassObj)

            return MetadataList
        except oracledb.DatabaseError as exc:
            err = exc.args
            logging.error("Oracle-Error-Code:", err.code)
            logging.error("Oracle-Error-Message:", err.message)
        finally:
            cursor.close()
            conn.close()

    def get_JobId(self,job_id_or_name):
        host, url ,permission_url = self.get_host()
        endpoint = url + "list"
        if str(job_id_or_name).isnumeric():
            return int(job_id_or_name)
        else:
            response = requests.get(endpoint, headers=token)
            JobsList = response.json()["jobs"]
            JobId = []
            JobOut = 0
            for job in JobsList:
                setting = job["settings"]
                if str(setting["name"]).lower() == str(job_id_or_name).lower():
                    JobId.append(int(job["job_id"]))
            if len(JobId) > 0:
                JobOut = max(JobId)
            return int(JobOut)

    def get_JobName(self,job_id):
        host, url, permission_url = self.get_host()
        endpoint = url + "list"
        response = requests.get(endpoint, headers=token)
        JobsList = response.json()["jobs"]
        JobName = ""
        for job in JobsList:
            if int(job["job_id"]) == int(job_id):
                JobName = str(job["settings"]["name"])
        return JobName


    def get_RunStatus(self,RunId):
        host, url, permission_url = self.get_host()
        endpoint = url + "runs/get?run_id={}".format(RunId)
        response = requests.get(endpoint, headers=token)
        response_json = response.json()
        life_cycle_state = str(response_json["state"]["life_cycle_state"])
        status = ""
        if life_cycle_state.upper() in {"TERMINATED", "TERMINATING", "INTERNAL_ERROR"}:
            status = response_json["state"]["result_state"]
        else:
            status = life_cycle_state.upper()
        print(status)
        # If Status is one of these ('SUCCESS','FAILED','TIMEDOUT','CANCELED','SKIPPED'), then it is over else
        return status

    def get_cluster_id(self, cluster_name):
        host, url ,permission_url = self.get_host()
        endpoint = "https://" + host + "/api/2.0/clusters/list"
        response = requests.get(endpoint, headers=token)
        response_json = response.json()
        cluster_list = response_json["clusters"]
        cluster_id = ""
        for cluster in cluster_list:
            if str(cluster["cluster_name"]).lower() == str(cluster_name).lower():
                cluster_id = cluster["cluster_id"]
        return cluster_id

    def get_policy_id(self, policy_name):
        host = self.get_host()[0]
        endpoint = "https://" + host + "/api/2.0/policies/clusters/list"
        response = requests.get(endpoint, headers=token)
        response_json = response.json()
        policy_list = response_json["policies"]
        policy_id = ""
        for policy in policy_list:
            if str(policy["name"]).lower() == str(policy_name).lower():
                policy_id = policy["policy_id"]
        return policy_id

    def findmissingjobs(self,MetaJsonList,job_id_name_str):
        #idfcls = IDF2_Manage_Jobs()
        list_job_id_name = str(job_id_name_str).split(",")
        jobidlist = []
        metajoblist = []
        #Create list with jobs
        for jobidname in list_job_id_name:
            if self.get_JobId(jobidname) > 0 :
                jobidlist.append(self.get_JobId(jobidname))
            else:
                jobidlist.append(jobidname)

        #Create list from MetaJsonList
        for jsondata in MetaJsonList:
            data = jsondata[0]
            server_job_id = self.get_JobId(data["name"])
            if server_job_id == 0:
                serverjobname = data["name"]
            else:
                serverjobname = server_job_id
            metajoblist.append(serverjobname)


        # Get the missing jobs in a list
        jobidlist_lower = [str(i).lower() for i in jobidlist]
        metajoblist_lower = [str(i).lower() for i in metajoblist]


        missinglist = set(jobidlist_lower).difference(set(metajoblist_lower))

        #display the message
        for missingjobid in missinglist:
            print("Metadata missing or not active for Job Id/Name : " + str(missingjobid) + ", so job not created.")

    def create_job(self,job_id_name_list,metadata_config:mu.meta_data):
        host, url, permission_url = self.get_host()
        conn = self.get_meta_connection(metadata_config.db_usrname, metadata_config.db_pswd, metadata_config.db_url)
        endpoint_create = url +  "create"
        endpoint_update = url + "update"
        MetaJsonList = self.process_create_metadata(conn,job_id_name_list,metadata_config)
        #Check if any  jobs missing in metadata and throw message
        #print(MetaJsonList)
        #print(job_id_name_list)
        if job_id_name_list.lower() != "all":
            self.findmissingjobs(MetaJsonList,job_id_name_list)
        for jsondata in MetaJsonList:
            data = jsondata[0]
            access_level = jsondata[1]
            # Decide if Create or Update
            job_id =0
            server_job_id = self.get_JobId(data["name"])
            if server_job_id > 0 :
                upd_data_json = self.process_update_metadata(server_job_id,json.dumps(data))
                response = requests.post(endpoint_update,json=upd_data_json,headers=token)
                # print("Job " + data["name"] + " (job id : " + str(server_job_id) + ") updated successfully")
                self.update_metadata("U-U",data["name"],server_job_id,metadata_config)
                if response.status_code == 200:
                    self.grant_permission(server_job_id,access_level)
                    print("Updated Successfully Job Id : " + str(server_job_id))
                else:
                    print("===================================== FAILURE ==========================" + response.json()["error_code"] + " : " + response.json()["message"])
            else:
                response = requests.post(endpoint_create,json=data,headers=token)
                if response.status_code == 200:
                    response_json = response.json()
                    job_id = response_json["job_id"]
                    #print("Job " + data["name"] + " (job id : " + str(job_id) + ") created successfully")
                    self.grant_permission(job_id, access_level)
                    self.update_metadata("U-C", data["name"], int(job_id),metadata_config)
                else:
                    print("===================================== FAILURE ==========================" + response.json()["error_code"] + " : " + response.json()["message"])

    def grant_permission(self,job_id,access_level):
        host, url, permission_url = self.get_host()
        endpoint_permission = permission_url + str(job_id)
        # json_str = """{{"access_control_list": [{{"group_name": "{}", "permission_level": "{}"}}]}}""".format(access_group,access_level)
        #print(access_level)
        response = requests.patch(endpoint_permission, json=json.loads(access_level), headers=token)
        if response.status_code == 200:
            # print("Access " + access_level + " successfully granted to " + access_group + " for job id : " + str(job_id))
            print("Access " + access_level + " successfully granted to  for job id : " + str(job_id))
        else:
            # print(" Granting " + access_level + " access to " + access_group + " for job id : " + str(job_id) + " FAILED")
            print(" Granting " + access_level + " access to for job id : " + str(job_id) + " FAILED")
            print("Failed due to : " + response.json()["error_code"] + " : " + response.json()["message"])

    def update_job(self,JobName,Payload):
        endpoint = self.baseURL +  "create"
        headers = str(self.Token)
        data = json.loads(Payload)
        response = requests.post(endpoint,json=data,headers=headers)
        print(response.json())

    def run_job_workflow(self,JobList):
        host, url, permission_url = self.get_host()
        endpoint = url +  "run-now"
        headers = token
        #idfcls = IDF2_Manage_Jobs()
        ListJob = JobList.split(",")
        for job_id_or_name in ListJob:
            job_id = self.get_JobId(job_id_or_name)
            datastr = """{{"job_id" : {}}}""".format(int(job_id))
            data = json.loads(datastr)
            response = requests.post(endpoint,json=data,headers=headers)
            runId = int(response.json()["run_id"])
            while True:
                status = str(self.get_RunStatus(runId))
                if status in {'SUCCESS', 'FAILED', 'TIMEDOUT', 'CANCELED', 'SKIPPED'}:
                    break
                else :
                    print("Job run " + str(runId) + " is in progress , current status is : " + status)
                time.sleep(15)
            if status.upper() != "SUCCESS":
                print("Job run " + str(runId) + " completed with status : " + status + " : Workflow terminated")
                break
            else:
                print("Job run " + str(runId) + " completed with status : " + status )


    def run_job(self,JobList):
        host, url, permission_url = self.get_host()
        endpoint = url +  "run-now"
        headers = token
        #idfcls = IDF2_Manage_Jobs()
        ListJob = JobList.split(",")
        for job_id_or_name in ListJob:
            job_id = self.get_JobId(job_id_or_name)
            datastr = """{{"job_id" : {}}}""".format(int(job_id))
            data = json.loads(datastr)
            response = requests.post(endpoint,json=data,headers=headers)
            print(response.json()["run_id"])

    def run_job_with_params(self, JobList,param):
        host, url, permission_url = self.get_host()
        endpoint = url + "run-now"
        headers = token
        idfcls = IDF2_Manage_Jobs()
        ListJob = JobList.split(",")
        params = idfcls.processListValues(param)
        for job_id_or_name in ListJob:
            job_id = idfcls.get_JobId(job_id_or_name)
            datastr = """{{"job_id" : {},"jar_params" :[{}]}}""".format(int(job_id),params)
            data = json.loads(datastr)
            response = requests.post(endpoint, json=data, headers=headers)
            print(response.json())

    def delete_job(self,job_id_name_list,metadata_config:mu.meta_data):
        host, url, permission_url = self.get_host()
        endpoint = url +  "delete"
        headers = token
        idfcls = IDF2_Manage_Jobs()
        for job in job_id_name_list.split(","):
            Payload = """{{"job_id": {}}}""".format(int(idfcls.get_JobId(job)))
            data = json.loads(Payload)
            JobId = int(idfcls.get_JobId(job))
            jobname = idfcls.get_JobName(JobId)
            response = requests.post(endpoint,json=data,headers=headers)
            if response.status_code == 200:
                print("Deleted JobId " + str(job))
            else:
                print("Delete Failed : " + response.json()["message"])
            self.update_metadata("U-D", jobname, JobId,metadata_config)

    def process_update_metadata(self,job_id,create_metajson_str):
        jsonstr = """{{"job_id": {},"new_settings":{}}}""".format(job_id,create_metajson_str)
        return json.loads(jsonstr)

    def process_create_metadata(self,conn,job_id_name_list,metadata_config:mu.meta_data):
        #idfcls = IDF2_Manage_Jobs()
        metaList = self.getJobMetadata(conn,job_id_name_list,metadata_config)
        #print('metaList: ' + str(metaList))
        MetaJsonList = []
        for meta in metaList:
            time_o_secs = ""
            maxi_retries = ""
            min_retry_interval=""
            retry_on_tout = ""
            parameter = ""
            concor_runs = 1
            max_retry = 0
            no_alert_for_skip = "false"
            meta_struct = """{{
                        "{}" : {},
                        "name": "{}",
                        "libraries": [{{"jar":{}}}],
                        "spark_jar_task" : {{"main_class_name" : "{}", "parameters" : {}}},
                        "email_notifications" : {{"on_start" : {},
						                        "on_success" : {},
						                        "on_failure" : {},
							                    "no_alert_for_skipped_runs" : {} }},{}
                        "max_retries" : {},{}{}
                        "max_concurrent_runs" : {}
                        }}"""

            start_email = "[]"
            sucess_email = "[]"
            failure_email = "[]"


            if meta.no_alert_for_skipped_runs != None:
                no_alert_for_skip = meta.no_alert_for_skipped_runs

            if meta.max_retries != None:
                max_retry = meta.max_retries

            if meta.max_concurrent_runs != None:
                concor_runs = meta.max_concurrent_runs

            if meta.parameters!= '"None"':
                # parameter = "[{}]".format(meta.parameters)
                parameter = meta.parameters
            if meta.timeout_seconds != None:
                time_o_secs = """"timeout_seconds" : {},""".format(meta.timeout_seconds)
            if meta.min_retry_interval_millis != None:
                min_retry_interval = """"min_retry_interval_millis" : {},""".format(meta.min_retry_interval_millis)
            if meta.retry_on_timeout != None:
                retry_on_tout = """"retry_on_timeout" : {},""".format(meta.retry_on_timeout)
            if meta.email_on_start != None:
                start_email = "[" + meta.email_on_start + "]"
            if meta.email_on_success != None:
                sucess_email = "[" + meta.email_on_success + "]"
            if meta.email_on_failure != None:
                failure_email = "[" + meta.email_on_failure + "]"

            if meta.new_cluster_ind == "N":
                clusterid_key = "existing_cluster_id"
                clusterId_or_payload = """"{}" """.format(self.get_cluster_id(meta.existing_cluster_name))
            else:
                clusterid_key = "new_cluster"
                payload = meta.new_cluster_payload
                clusterId_or_payload = payload.replace("$POLICYID",self.get_policy_id(meta.new_cluster_policy_name))

            meta_final_str = meta_struct.format(clusterid_key, clusterId_or_payload, meta.name, meta.libraries,
                                                meta.main_class_name, parameter, start_email,
                                                sucess_email, failure_email,
                                                no_alert_for_skip, time_o_secs, max_retry,
                                                min_retry_interval, retry_on_tout, concor_runs)
            #print(meta_final_str)
            metajson = json.loads(meta_final_str)
            bundlelist = [metajson,meta.access_level]
            MetaJsonList.append(bundlelist)
        return MetaJsonList

def create_update_databricks_jobs(input_args):
    logging.info(f"input_args ===> {input_args}")
    logging.info(f"length of input_args ===> {len(sys.argv)}")
    global token
    if len(sys.argv) < 2:
        logging.error("Invalid parameters, please provide Action and Values ")
        raise Exception("Invalid parameters, please provide Action and Values ")
    rsm_token = getpassword(input_args.svc_account)
    token_tmp = """{{"Authorization": "Bearer {}"}}""".format(str(rsm_token))
    token = json.loads(token_tmp)
    logging.info(f"Token generated Successfully and assigned to global token Variable")
    job_class = IDF2_Manage_Jobs()
    config_fl_loc = input_args.config_file
    config_file_name = "$" + config_fl_loc
    metadata_config = mu.GetAWSConfig(config_file_name)
    logging.info(f"Configuration File Name ===> {config_file_name}")
    db_url = metadata_config.db_url
    user_name = metadata_config.db_usrname
    password = metadata_config.db_pswd
    schema = metadata_config.db_schema
    logging.info(f"DB URL ===> {db_url}")
    logging.info(f"DB User Name ===> {user_name}")
    logging.info(f"DB Schema ===> {schema}")
    action = input_args.job_action
    logging.info(f"Action ===> {action}")
    job_id_name_list = input_args.job_id
    run_params = input_args.run_params

    if str(action).lower() in {"create", "update"}:
        job_class.create_job(job_id_name_list, metadata_config)
        logging.info(f"Job {action}ed Successfully {job_id_name_list}")
    elif str(action).lower() == "run":
        if len(sys.argv) == 4:
            job_class.run_job(job_id_name_list)
        elif len(sys.argv) == 5:
            job_class.run_job_with_params(job_id_name_list, str(sys.argv[4]))
    elif str(action).lower() == "run_workflow":
        job_class.run_job_workflow(job_id_name_list)
    elif str(action).lower() == "delete":
        job_class.delete_job(job_id_name_list, metadata_config)
    elif str(action).lower() == "status":
        job_class.get_RunStatus(job_id_name_list)



