import xlrd
import oracledb
import json
import sys
import boto3
from botocore.config import Config
import os
import requests
from main.com.idf.tools.RSMUtil import getpassword

def parse_s3_config_json(loc,file):
    print("........................Parsing the Config Json S3 started.........")
    global db_usrname
    global db_pswd
    global db_url
    global xls_file_name
    global policy_tab
    global policy_obj_tab
    global policy_user_tab
    global policy_cols
    global policy_row_starts
    global policy_obj_cols
    global policy_obj_row_starts
    global policy_user_cols
    global policy_user_row_starts
    global policy_merge_stmnt
    global policy_obj_merge_stmnt
    global policy_user_merge_stmnt
    global db_schema

    boto3.client('ssm')
    session = boto3.Session(region_name="us-east-1")
    ssm = session.client("ssm")
    location = ssm.get_parameter(Name=loc, WithDecryption=True)
    global_filename = ssm.get_parameter(Name=file, WithDecryption=True)
    client = boto3.client('s3')
    bucket_value = location['Parameter']['Value']
    gfilename_value = global_filename['Parameter']['Value']
    #print("gfilename_value.." + gfilename_value)
    BUCKET = bucket_value.split("/")[0]
    KEY = bucket_value.split("/")[1] + '/' + bucket_value.split("/")[2] + '/' + gfilename_value
    result = client.get_object(Bucket=BUCKET, Key=KEY)
    text = result["Body"].read().decode()
    print("........................Config file parsed and parameter assignment starts.....")
    data = json.loads(text)
    db_usrname = data["user_name"]
    json_password = data['password']
    temp_trx = json_password[6:-1]
    db_pswd = getpassword(temp_trx)  
    #db_pswd = data["password"]
    db_url = data["DB_URL"]
    db_schema = data["db_schema"]
    xls_file_name = data["xls_file_name"]
    policy_tab = data["policy_tab"]
    policy_obj_tab = data["policy_obj_tab"]
    policy_user_tab = data["policy_user_tab"]
    policy_cols = data["policy_cols"]
    policy_row_starts = data["policy_row_starts"]
    policy_obj_cols = data["policy_obj_cols"]
    policy_obj_row_starts = data["policy_obj_row_starts"]
    policy_user_cols = data["policy_user_cols"]
    policy_user_row_starts = data["policy_user_row_starts"]
    policy_merge_stmnt = data["policy_merge_stmnt"]
    policy_obj_merge_stmnt = data["policy_obj_merge_stmnt"]
    policy_user_merge_stmnt = data["policy_user_merge_stmnt"]
    #print("db_usrname...." + db_usrname)
    #print("db_usrname...." + db_pswd)
    #print("db_usrname...." + db_schema)
    #print("db_url...." + db_url)
    #print(policy_user_merge_stmnt)
    print("........................Config file parsing completed ")


def get_Excel_Tab_Object(xls_file_path,tab_name,no_of_cols,row_starts):
    print("........................Scanning Excel tab " + str(tab_name) + " starts......")
    wb = xlrd.open_workbook(xls_file_path)
    tabSheet = wb.sheet_by_name(tab_name)
    sheetList = []
    for rownum in range(tabSheet.nrows):
        if rownum >= row_starts:
            rowList = []
            for colindex in range(0,no_of_cols):
                rowList.append(tabSheet.cell(rownum,colindex).value)
            sheetList.append(rowList)
    print("........................Scanning Excel tab " + str(tab_name) + " ends.")
    return sheetList

def buildSQLStatement(table_name,dataList,merge_statement):
    sqlstatement= ""
    if table_name.upper() == 'ACL_ARP_POLICIES':
        sqlstatement = merge_statement.format("'" + str(dataList[0]) + "'", "'" + str(dataList[1]) + "'","'" + str(dataList[2]) + "'",db_schema)
    elif table_name.upper() == 'ACL_ARP_POLICY_OBJECT_MAP':
        sqlstatement = merge_statement.format("upper('" + str(dataList[0]) + "')", "upper('" + str(dataList[1]) + "')","upper('" + str(dataList[2]) + "')", "upper('" + str(dataList[3]) + "')",db_schema)
    elif table_name.upper() == 'ACL_ARP_POLICY_USER_MAP':
        sqlstatement = merge_statement.format("upper('" + str(dataList[0]) + "')", "lower('" + str(dataList[1]) + "')","upper('" + str(dataList[2]) + "')",db_schema)
    return sqlstatement

def getMergeStatementList(sheet,col_nums,table_name,merge_stmnt):
    print("........................Generating Merge Statements List for " + str(table_name) + " starts....")
    mergelist = []
    for row in sheet:
        dList = []
        for i in range(0,col_nums):
            dList.append(row[i])
        mergestmnt = buildSQLStatement(table_name, dList, merge_stmnt)
        mergelist.append(mergestmnt)
    print("........................Generating Merge Statements List for " + str(table_name) + " ends")
    return mergelist


def processRequestFile():
    try:
        #Create object for each tab in the excel
        policy_sheet = get_Excel_Tab_Object(xls_file_name, policy_tab,int(policy_cols), int(policy_row_starts))
        policy_obj_sheet = get_Excel_Tab_Object(xls_file_name, policy_obj_tab,int(policy_obj_cols),int(policy_obj_row_starts))
        policy_user_sheet = get_Excel_Tab_Object(xls_file_name, policy_user_tab,int(policy_user_cols),int(policy_user_row_starts))

        # Get all merge statement in a list for each table
        policy_merge_list = getMergeStatementList(policy_sheet, int(policy_cols), 'ACL_ARP_POLICIES',str(policy_merge_stmnt))
        policy_obj_merge_list = getMergeStatementList(policy_obj_sheet, int(policy_obj_cols), 'ACL_ARP_POLICY_OBJECT_MAP',str(policy_obj_merge_stmnt))
        policy_user_merge_list = getMergeStatementList(policy_user_sheet, int(policy_user_cols),'ACL_ARP_POLICY_USER_MAP',str(policy_user_merge_stmnt))

        # Create Oracle Connection
        print("........................Trying to connect to Metadatdata DB... ")
        connstr = db_usrname + "/" + db_pswd + '@' + db_url
        connection = oracledb.connect(connstr)
        cursor = connection.cursor()
        print("........................Metadatdata DB established successfully !")

        # Process ACL_ARP_POLICIES Table
        print("........................Loading table ACL_ARP_POLICES starts .....")
        for merge_sql in policy_merge_list:
            cursor.execute(merge_sql)
        cursor.execute('commit')
        print("........................Loading table ACL_ARP_POLICES ends ")

        # Process ACL_ARP_POLICY_OBJECT_MAP Table
        print("........................Loading table ACL_ARP_POLICY_OBJECT_MAP starts ....")
        for merge_sql in policy_obj_merge_list:
            cursor.execute(merge_sql)
        cursor.execute('commit')
        print("........................Loading table ACL_ARP_POLICY_OBJECT_MAP ends ")

        # Process ACL_ARP_POLICY_OBJECT_MAP Table
        print("........................Loading table ACL_ARP_POLICY_OBJECT_MAP starts ....")
        for merge_sql in policy_user_merge_list:
            cursor.execute(merge_sql)
        cursor.execute('commit')
        print("........................Loading table ACL_ARP_POLICY_OBJECT_MAP ends ")

    except oracledb.DatabaseError as exc:
        err = exc.args
        print("Oracle-Error-Code:", err.code)
        print("Oracle-Error-Message:", err.message)
        raise
    finally:
        cursor.close()
        connection.close()


if __name__ == '__main__':
    if len(sys.argv) < 3:
        print("Invalid parameters, please provide SSM parameter for config file location and name ")
        sys.exit()

    print("........................processing started.........")
    confilg_file_loc = sys.argv[1]
    confilg_file_name = sys.argv[2]

    parse_s3_config_json(confilg_file_loc, confilg_file_name)
    processRequestFile()
    print("........................processing Ends")
    