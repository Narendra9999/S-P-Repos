from pyspark.sql import SparkSession
import argparse
parser = argparse.ArgumentParser()
parser.add_argument("date")
args = parser.parse_args()

if not args.date:
    print("Please provide date parameter")
    exit()
date = args.date
spark = SparkSession.builder.master("yarn").enableHiveSupport().appName("testAppp").getOrCreate()

def keyFieldsDF_method():
    keyFieldsDF = spark.sql("SELECT distinct I.* from sec_stg.v_CYNC_CMPNY_IND_AVG_STG I,sec_stg.v_CYNC_CMPNY_DETAILS_STG C  where I.INDUSTRY=C.INDUSTRY and C.REVENUE_BAND=I.REVENUE_BAND and date_format(I.assessment_date,'YYYYMM')='"+date+"'")
    keyFieldsDF=keyFieldsDF.coalesce(1)
    keyFieldsDF.write.option("header","True").format("csv").mode("overwrite").save("s3://spr-idf-prod-r360-published/packages/CYNC_CMPNY_IND_AVG_STG/"+date+"/")
keyFieldsDF_method()
