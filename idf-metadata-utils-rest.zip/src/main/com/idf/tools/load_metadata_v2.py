from distutils.command.build_scripts import first_line_re

import oracledb
import os, sys
import argparse
import logging
import xlrd
import boto3
import io
from io import BytesIO
logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO, format='%(asctime)s -%(module)s - %(levelname)s - %(message)s')

import main.com.idf.utils.MetadataUtilV2 as mu

# Create the parser
my_parser = argparse.ArgumentParser(description='Pass the execution arguments')

# Add the arguments
my_parser.add_argument('--volume_name', metavar='volume_name', type=str, help='The Volume Name where the Metadata file located')
my_parser.add_argument('--confilg_file_name', metavar='confilg_file_name', type=str, help='the config file Name')
my_parser.add_argument('--config_file_env', metavar='config_file_env', type=str, help='config_file_env')
my_parser.add_argument('--metadata_file', metavar='filename', nargs='?', type=str, help='filename', default=None)

# Execute the parse_args() method
args = my_parser.parse_args()

if len(sys.argv) < 4:
    print('Please provide SSM parameter for Volume Name , config file, location, and excel file location for metadata store update')
    sys.exit()

logging.info('Arguments passed are: ' + str(args))
confilg_file_name = "$" + args.confilg_file_name
config_file_env = args.config_file_env
path = args.volume_name
file_name = args.metadata_file

def perform_validations(src):
    xlrd.xlsx.ensure_elementtree_imported(False, None)
    xlrd.xlsx.Element_has_iter = True
    #tabs = openpyxl.load_workbook(src).sheetnames
    # with BytesIO(src) as file_stream:
    #     workbook = xlrd.open_workbook(file_stream)
    workbook = xlrd.open_workbook(file_contents=src.read())
    #tabs = xlrd.open_workbook(src).sheet_names()
    tabs = workbook.sheet_names()
    if 'SCHEMA MAPPINGS' not in tabs or 'TABLE MAPPINGS' not in tabs or 'COLUMN MAPPINGS' not in tabs or 'PARTITION COLUMNS' not in tabs:
        print(
            'One or all of the excel tabs is (are) not as per the template, please check the excel sheet again and process')
        raise ValueError('One or all of the excel tabs is (are) not as per the template, please check the excel sheet again and process')
    else:
        logging.info(f'Required tabs are present in the excel sheet {tabs}')

def load_data(src,input_file):
    xlrd.xlsx.ensure_elementtree_imported(False, None)
    xlrd.xlsx.Element_has_iter = True
    # Get Mapping details Using openpyxl
    #ws_schema_mapping = openpyxl.load_workbook(src).get_sheet_by_name('SCHEMA MAPPINGS')
    #ws_table_mapping = openpyxl.load_workbook(src).get_sheet_by_name('TABLE MAPPINGS')
    #ws_column_mapping = openpyxl.load_workbook(src).get_sheet_by_name('COLUMN MAPPINGS')
    #ws_partition_columns = openpyxl.load_workbook(src).get_sheet_by_name('PARTITION COLUMNS')
    # Get Mapping details Using xlrd
    # with BytesIO(src) as file_stream:
    #     workbook = xlrd.open_workbook(file_stream)
    workbook = xlrd.open_workbook(file_contents=src.read())
    logging.info('Successfully read the Excel File into work book')
    # ws_schema_mapping = xlrd.open_workbook(src).sheet_by_name('SCHEMA MAPPINGS')
    # ws_table_mapping = xlrd.open_workbook(src).sheet_by_name('TABLE MAPPINGS')
    # ws_column_mapping = xlrd.open_workbook(src).sheet_by_name('COLUMN MAPPINGS')
    # ws_partition_columns = xlrd.open_workbook(src).sheet_by_name('PARTITION COLUMNS')
    ws_schema_mapping = workbook.sheet_by_name('SCHEMA MAPPINGS')
    ws_table_mapping = workbook.sheet_by_name('TABLE MAPPINGS')
    ws_column_mapping = workbook.sheet_by_name('COLUMN MAPPINGS')
    ws_partition_columns = workbook.sheet_by_name('PARTITION COLUMNS')
    # Connect to database

    try:
        connstr = mu.db_usrname + "/" + mu.db_pswd + '@' + mu.db_url
        # print(connstr)
        connection = oracledb.connect(connstr)
    except oracledb.DatabaseError as e:
        raise
    cursor = connection.cursor()

    # Get Schema  Mapping Details
    num_schema_mapping_rows = ws_schema_mapping.nrows
    num_schema_mapping_cols = ws_schema_mapping.ncols
    # Get Schema Mapping details
    for schema_col_idx in range(num_schema_mapping_cols):
        if str(ws_schema_mapping.cell_value(0, schema_col_idx)).strip() == config_file_env:
            ls_db_instance = str(ws_schema_mapping.cell_value(1, schema_col_idx)).strip()
            ls_db_service = str(ws_schema_mapping.cell_value(2, schema_col_idx)).strip()
            ls_db_host = str(ws_schema_mapping.cell_value(3, schema_col_idx)).strip()
            ls_db_port = ws_schema_mapping.cell_value(4, schema_col_idx)
            ls_db_schema = str(ws_schema_mapping.cell_value(5, schema_col_idx)).strip()
            ls_db_schema_class = str(ws_schema_mapping.cell_value(6, schema_col_idx)).strip()
            ls_abs_schema_name = str(ws_schema_mapping.cell_value(7, schema_col_idx)).strip()
            ls_schema_pkg_name = str(ws_schema_mapping.cell_value(8, schema_col_idx)).strip()
            # print(ls_db_instance, ls_db_service, ls_db_host, ls_db_port, ls_db_schema, ls_db_schema_class, ls_abs_schema_name,ls_schema_pkg_name)

            if len(ls_db_instance) == 0 or len(ls_db_service) == 0 or len(str(ls_db_host)) == 0 or len(
                    str(ls_db_port)) == 0:
                print("Schema Mappings: DB Instance or DB Service or Host or Port# cannot be blank")
                sys.exit()

            ls_sql = " SELECT to_data_type FROM " + mu.db_schema + ".DATATYPE_TRANSLATION " \
                                                                   " where from_db_type = 'ORACLE' and to_db_type = 'ABSTRACTION'  " \
                                                                   " and from_data_type = 'NUMBER' AND DATA_PRECISION IS NULL"
            # print(ls_sql)
            try:
                cursor.execute(ls_sql)
            except oracledb.DatabaseError as e:
                raise
            row = cursor.fetchone()
            if row is not None:
                df_datatype_data_precision_null = row[0]

            ls_sql = " SELECT max(DATA_PRECISION) FROM " + mu.db_schema + ".DATATYPE_TRANSLATION " \
                                                                          " where from_db_type = 'ORACLE' and to_db_type = 'ABSTRACTION'  " \
                                                                          " and from_data_type = 'NUMBER' AND DATA_PRECISION IS NOT NULL"

            # print(ls_sql)
            try:
                cursor.execute(ls_sql)
            except oracledb.DatabaseError as e:
                raise
            row = cursor.fetchone()
            if row is not None:
                data_precision = row[0]

            # DB Merge
            merge_db_param = "MERGE INTO " + mu.db_schema + ".RLTNL_DATABASE_PARAM d " \
                                                            "USING(select 1 from dual ) d1 " \
                                                            "ON(upper(d.DB_INSTANCE_ID) = trim(upper('" + ls_db_instance + "'))) " \
                                                                                                                           "WHEN MATCHED THEN UPDATE SET " \
                                                                                                                           "D.DB_SERVICE_NAME = '" + ls_db_service + "', DB_HOST = '" + str(
                ls_db_host) + "', " \
                              "DB_CONNECT_PORT_NUM = " + str(int(ls_db_port)) + " where " \
                                                                                "d.DB_INSTANCE_ID = '" + ls_db_instance + "' " \
                                                                                                                          "WHEN NOT MATCHED " \
                                                                                                                          "THEN INSERT(d.RLTNL_DATABASE_ID, d.DB_INSTANCE_ID, " \
                                                                                                                          "D.DB_SERVICE_NAME, DB_HOST, DB_CONNECT_PORT_NUM) " \
                                                                                                                          "VALUES( " + mu.db_schema + ".SEQ_RLTNL_DATABASE_PARAM.NEXTVAL, upper('" + ls_db_instance + "')," \
                                                                                                                                                                                                                      "'" + ls_db_service + "','" + str(
                ls_db_host) + "'," + str(int(ls_db_port)) + ")"
            # print(merge_db_param)
            try:
                cursor.execute(merge_db_param)
            except oracledb.DatabaseError as e:
                raise

            try:
                cursor.execute(
                    "SELECT RLTNL_DATABASE_ID FROM " + mu.db_schema + ".RLTNL_DATABASE_PARAM where upper(DB_INSTANCE_ID) = " "upper('" + ls_db_instance + "')")
            except oracledb.DatabaseError as e:
                raise
            row = cursor.fetchone()
            if row is not None:
                seq_relational_db_id = row[0]
            else:
                print("DB Instance Id not found, please check")
                sys.exit()

            # Schema Merge
            merge_rel_schema = "Merge into " + mu.db_schema + ".RLTNL_SCHEMA  s " \
                                                              "Using (select 1 from dual) " \
                                                              "ON (upper(SCHEMA_NAME) = trim(upper('" + (
                                   ls_db_schema) + "')) and RLTNL_DATABASE_ID = " + str(seq_relational_db_id) + ") " \
                                                                                                                "WHEN MATCHED THEN " \
                                                                                                                "UPDATE SET SCHEMA_CLASSIFICATION = '" + ls_db_schema_class + "' , PACKAGE_NAME = '" + ls_schema_pkg_name + "' " \
                                                                                                                                                                                                                            "WHEN NOT MATCHED THEN " \
                                                                                                                                                                                                                            "INSERT(RLTNL_SCHEMA_ID, RLTNL_DATABASE_ID, SCHEMA_NAME, SCHEMA_CLASSIFICATION, REPLICATION_TYPE,PACKAGE_NAME) " \
                                                                                                                                                                                                                            "VALUES(" + mu.db_schema + ".SEQ_RLTNL_SCHEMA.NEXTVAL, " + str(
                seq_relational_db_id) + ", " \
                                        "upper('" + ls_db_schema + "'),'" + ls_db_schema_class + "', 'NA','" + ls_schema_pkg_name + "')"

            # print(merge_rel_schema)
            try:
                cursor.execute(merge_rel_schema)
            except oracledb.DatabaseError as e:
                raise

            try:
                cursor.execute(
                    "SELECT RLTNL_SCHEMA_ID FROM " + mu.db_schema + ".RLTNL_SCHEMA where RLTNL_DATABASE_ID = " + str(
                        seq_relational_db_id) + " "
                                                "and upper(SCHEMA_NAME) = upper('" + ls_db_schema + "')")
            except oracledb.DatabaseError as e:
                raise
            row = cursor.fetchone()
            if row is not None:
                seq_rel_db_sch_id = row[0]
            else:
                print("Rel Schema Id not found, please check")
                sys.exit()

            # Get Table and Column Mapping Details

            num_table_mapping_rows = ws_table_mapping.nrows
            num_table_mapping_cols = ws_table_mapping.ncols

            num_column_mapping_rows = ws_column_mapping.nrows
            num_column_mapping_cols = ws_column_mapping.ncols

            num_partition_rows = ws_partition_columns.nrows
            num_partition_cols = ws_partition_columns.ncols

            table_mapping_list = []
            column_mapping_list = []
            partition_columns_list = []

            counter = 0
            logging.info("\rProcessing Metadata Template :")
            for tbl_fields in range(2, num_table_mapping_rows):
                #print("num_table_mapping_rows: " + str(num_table_mapping_rows))
                for tbl_field_vals in range(num_table_mapping_cols):
                    col = ws_table_mapping.cell_value(tbl_fields, tbl_field_vals)
                    if tbl_field_vals == 0 and col == '':  # Table Name
                        logging.info("Table Mappings: Cannot have Table name blank on row# " + str(tbl_fields + 1))
                        sys.exit()
                    elif tbl_field_vals == 1 and col == '':  # Abs Source Type to be defaulted to params
                        logging.info("Table Mappings: Cannot have RDBMS_TABLE_REPL_TYPE blank on row# " + str(tbl_fields + 1))
                        sys.exit()
                    elif tbl_field_vals == 5 and col == '':  # TABLE SIZE CLASSIFICATION
                        logging.info("Table Mappings: Please enter table size classification on row# " + str(tbl_fields + 1))
                        sys.exit()
                    elif tbl_field_vals == 6 and col == '':  # abstraction table name to be defaulted to relational table name
                        col = ws_table_mapping.cell_value(tbl_fields, 0)
                    elif tbl_field_vals == 7 and col == '':  # CDC_FLAG default to N
                        col = 'N'
                    elif tbl_field_vals == 8 and col == '':  # DBMS_PACKAGE_FLAG default to Y
                        col = 'Y'

                    # Bala if ws_table_mapping.cell_type(tbl_fields, tbl_field_vals) == 2:
                    # Bala     col = int(col)

                    table_mapping_list.extend([col])  # Load into elements into Table Mapping List

                    # Loop for each table in table mappings - end
                    # All the table mappings, populate into the database
                if len(table_mapping_list) > 0:
                    merge_rel_tbl = "Merge into " + mu.db_schema + ".RLTNL_TABLE  s " \
                                                                   "Using (select 1 from dual) " \
                                                                   "ON (trim(upper(TABLE_NAME)) = trim(upper('" + \
                                    table_mapping_list[0] + "')) " \
                                                            " and RLTNL_SCHEMA_ID = " + str(seq_rel_db_sch_id) + ") " \
                                                                                                                 "WHEN MATCHED THEN " \
                                                                                                                 "UPDATE SET REPLICATION_TYPE = '" + \
                                    table_mapping_list[1] + "', " \
                                                            "TABLE_SIZE_CLASSIFICATION = '" + table_mapping_list[
                                        5] + "', " \
                                             "SQL_TEXT = '" + table_mapping_list[2] + "', " \
                                                                                      "VIEW_FILTER_SQL_TEXT = '" + \
                                    table_mapping_list[3].replace("'", "''") + "', " \
                                                                               "PACKAGE_FILTER_SQL_TEXT = '" + \
                                    table_mapping_list[4].replace("'", "''") + "', " \
                                                                               "RDBMS_PACKAGE_FLAG = '" + \
                                    table_mapping_list[8] + "', " \
                                                            "CDC_FLAG = '" + table_mapping_list[7] + "', " \
                                                                                                     "REPLICATION_SCHD_TYPE = '" + \
                                    table_mapping_list[9] + "' " \
                                                            "WHEN NOT MATCHED THEN " \
                                                            "INSERT(RLTNL_TABLE_ID, RLTNL_SCHEMA_ID, TABLE_NAME, " \
                                                            "REPLICATION_TYPE, TABLE_SIZE_CLASSIFICATION, " \
                                                            "SQL_TEXT, VIEW_FILTER_SQL_TEXT, PACKAGE_FILTER_SQL_TEXT,RDBMS_PACKAGE_FLAG, CDC_FLAG, REPLICATION_SCHD_TYPE)" \
                                                            "VALUES(" + mu.db_schema + ".SEQ_RLTNL_TABLE.NEXTVAL," + str(
                        seq_rel_db_sch_id) + ",'" + table_mapping_list[0].strip() + \
                                    "','" + table_mapping_list[1] + "','" + table_mapping_list[5] + "','" + \
                                    table_mapping_list[2].replace("'", "''") + "','" + table_mapping_list[3].replace(
                        "'", "''") + "','" + \
                                    table_mapping_list[4].replace("'", "''") + "','" + \
                                    table_mapping_list[8] + "','" + table_mapping_list[7] + "','" + table_mapping_list[
                                        9] + "')"
                    # print(merge_rel_tbl)
                    try:
                        cursor.execute(merge_rel_tbl)
                    except oracledb.DatabaseError as e:
                        raise

                    try:
                        cursor.execute(
                            "SELECT RLTNL_TABLE_ID, TABLE_SIZE_CLASSIFICATION FROM " + mu.db_schema + ".RLTNL_TABLE where "
                                                                                                      "RLTNL_SCHEMA_ID = " + str(
                                seq_rel_db_sch_id) + " and upper(TABLE_NAME) = upper('" + table_mapping_list[0] + "')")
                    except oracledb.DatabaseError as e:
                        raise
                    row = cursor.fetchone()
                    if row is not None:
                        seq_rel_table_id = row[0]
                        seq_rel_table_size = row[1]
                    else:
                        print("Rel Table Id not found, please check")
                        sys.exit()

                    merge_abs_tbl = "Merge into  " + mu.db_schema + ".ABSTRCTN_TABLE a " \
                                                                    "Using (select 1 from dual) " \
                                                                    "ON (trim(upper(DATABASE_NAME)) = trim(upper('" + ls_abs_schema_name.strip() + "')) " \
                                                                                                                                                   "and upper(TABLE_NAME) = upper('" + \
                                    table_mapping_list[6].strip() + "'))" \
                                                                    "WHEN NOT MATCHED THEN  " \
                                                                    "INSERT (ABSTRCTN_TABLE_ID, DATABASE_NAME, TABLE_NAME, ABSTRCTN_TABLE_TYPE, ABSTRCTN_FILE_TYPE) " \
                                                                    "Values (" + mu.db_schema + ".SEQ_ABSTRCTN_TABLE.NEXTVAL, " + "trim(upper('" + ls_abs_schema_name.strip() + \
                                    "')), upper('" + table_mapping_list[6].strip() + "'), 'DELTA', 'PARQUET')"
                    # print(merge_abs_tbl)
                    try:
                        cursor.execute(merge_abs_tbl)
                    except oracledb.DatabaseError as e:
                        cursor.close()
                        connection.close()
                        raise

                    try:
                        cursor.execute(
                            "SELECT ABSTRCTN_TABLE_ID FROM " + mu.db_schema + ".ABSTRCTN_TABLE where upper(DATABASE_NAME) = upper('" + \
                            ls_abs_schema_name.strip() + "') "
                                                         "and upper(TABLE_NAME) = upper('" + table_mapping_list[
                                6].strip() + "')")
                    except oracledb.DatabaseError as e:
                        raise
                    row = cursor.fetchone()
                    if row is not None:
                        seq_abs_table_id = row[0]
                    else:
                        # print(merge_abs_tbl)
                        # print(ls_abs_schema_name.strip())
                        #print(table_mapping_list[9])
                        print("Abstraction Table Id not found, please check")
                        sys.exit()

                    # Scheduling
                    # print(seq_abs_table_id)
                    try:
                        cursor.execute(
                            "Delete from " + mu.db_schema + ".ABSTRCTN_PARTITION_COLUMN where ABSTRCTN_TABLE_ID = " + str(
                                seq_abs_table_id) + "")
                    except oracledb.DatabaseError as e:
                        raise
                    try:
                        cursor.execute(
                            "Delete from " + mu.db_schema + ".BATCH_REPLCTN_ENTITY_MAP where REPLCTN_SOURCE_ENTITY_ID = " + str(
                                seq_rel_table_id) + "")
                    except oracledb.DatabaseError as e:
                        raise

                    if table_mapping_list[9].upper() == 'FIXED SCHEDULE' or table_mapping_list[9].upper() == 'JOB CLUSTER' or table_mapping_list[9].upper() == 'ON DEMAND':
                        if table_mapping_list[11].find(',') >= 1:
                            schedule_value = table_mapping_list[11].split(',')
                        else:
                            schedule_value = table_mapping_list[11].split()

                        #print(schedule_value)
                        if len(schedule_value) == 0:
                            vschedule_value = "06:00"
                            schedule_value = vschedule_value.split(',')

                        #print('table_mapping_list[11] : ' + str(table_mapping_list[11]) + '  ' + str(schedule_value))
                        for schedule_records in schedule_value:
                            schedule_rec = schedule_records.split(':')
                            # schedule_hour = format(int(schedule_rec[0]), '02') + ':' + format(int(schedule_rec[1]),'02')
                            schedule_hour = format(int(schedule_rec[0]), '02') + format(int(schedule_rec[1]), '02')
                            fs_batch_name = 'batch_' + schedule_hour + '_' + table_mapping_list[12].lower()
                            # print('schedule_hour--> ' + schedule_hour + ' fs_batch_name=' + fs_batch_name)

                            #print ('table_mapping_list[5].upper(): ' + table_mapping_list[5].upper() + ' table_mapping_list[10] : ' + table_mapping_list[10].lower())
                            if table_mapping_list[5].upper() == 'L' and table_mapping_list[9].upper() == 'JOB CLUSTER':
                                batch_size = 'l_'
                            elif table_mapping_list[5].upper() == 'XL' and table_mapping_list[9].upper() == 'JOB CLUSTER':
                                batch_size = 'xl_'
                            elif table_mapping_list[5].upper() == 'XXL' and table_mapping_list[9].upper() == 'JOB CLUSTER':
                                batch_size = 'xxl_'
                            elif table_mapping_list[5].upper() == 'SPL' and table_mapping_list[9].upper() == 'JOB CLUSTER':
                                batch_size = 'xxl_'
                            else:
                                batch_size = ''

                            if mu.db_env == 'metaprod.world' and table_mapping_list[9].upper() == 'FIXED SCHEDULE':
                                batch_name = 'p_ds_idfdb_fs_' + fs_batch_name
                            elif mu.db_env == 'metaqa.world' and table_mapping_list[9].upper() == 'FIXED SCHEDULE':
                                batch_name = 'q_ds_idfdb_fs_' + fs_batch_name
                            elif mu.db_env == 'metauat.world' and table_mapping_list[9].upper() == 'FIXED SCHEDULE':
                                batch_name = 'u_ds_idfdb_fs_' + fs_batch_name
                            elif mu.db_env == 'metadev.world' and table_mapping_list[9].upper() == 'FIXED SCHEDULE':
                                batch_name = 'd_ds_idfdb_fs_' + fs_batch_name
                            elif mu.db_env == 'metae2e2.world' and table_mapping_list[9].upper() == 'FIXED SCHEDULE':
                                batch_name = 's_ds_idfdb_fs_' + fs_batch_name
                            elif mu.db_env == 'metaprod.world' and table_mapping_list[9].upper() == 'JOB CLUSTER':
                                batch_name = 'p_ds_idfdb_jc_' + batch_size + table_mapping_list[10].lower()
                            elif mu.db_env == 'metaqa.world' and table_mapping_list[9].upper() == 'JOB CLUSTER':
                                batch_name = 'q_ds_idfdb_jc_' + batch_size + table_mapping_list[10].lower()
                            elif mu.db_env == 'metauat.world' and table_mapping_list[9].upper() == 'JOB CLUSTER':
                                batch_name = 'u_ds_idfdb_jc_' + batch_size + table_mapping_list[10].lower()
                            elif mu.db_env == 'metadev.world' and table_mapping_list[9].upper() == 'JOB CLUSTER':
                                batch_name = 'd_ds_idfdb_jc_' + batch_size + table_mapping_list[10].lower()
                            elif mu.db_env == 'metae2e2.world' and table_mapping_list[9].upper() == 'JOB CLUSTER':
                                batch_name = 's_ds_idfdb_jc_' + batch_size + table_mapping_list[10].lower()
                            elif mu.db_env == 'metaprod.world' and table_mapping_list[9].upper() == 'ON DEMAND':
                                batch_name = 'p_ds_idfdb_od_' + batch_size + table_mapping_list[10].lower()
                            elif mu.db_env == 'metaqa.world' and table_mapping_list[9].upper() == 'ON DEMAND':
                                batch_name = 'q_ds_idfdb_od_' + table_mapping_list[10].lower()
                            elif mu.db_env == 'metauat.world' and table_mapping_list[9].upper() == 'ON DEMAND':
                                batch_name = 'u_ds_idfdb_od_' + table_mapping_list[10].lower()
                            elif mu.db_env == 'metadev.world' and table_mapping_list[9].upper() == 'ON DEMAND':
                                batch_name = 'd_ds_idfdb_od_' + table_mapping_list[10].lower()
                            elif mu.db_env == 'metae2e2.world' and table_mapping_list[9].upper() == 'ON DEMAND':
                                batch_name = 's_ds_idfdb_od_' + table_mapping_list[10].lower()
                            batch_name = batch_name[0:64]
                            #print('batch_name...: ' + batch_name + ' batch_size: ' + batch_size)

                            merge_batch = "Merge into  " + mu.db_schema + ".BATCH " \
                                        "Using (select 1 from dual) ON ( BATCH_NAME = '" + batch_name + "' AND BATCH_TYPE = 'Replication')" \
                                        "WHEN NOT MATCHED THEN " \
                                        "INSERT (BATCH_NAME, SCHEDULE_HOUR, BATCH_TYPE, DEP_UPON_BATCH_NAME) " \
                                        "VALUES ( '" + batch_name + "','" + schedule_records + "', 'Replication', NULL)"
                            # print(merge_batch)
                            try:
                                cursor.execute(merge_batch)
                            except oracledb.DatabaseError as e:
                                raise

                            merge_batch_repl_map = "INSERT INTO " + mu.db_schema + ".BATCH_REPLCTN_ENTITY_MAP " \
                                                                                   "(BATCH_NAME, REPLCTN_SOURCE_ENTITY_ID, REPLCTN_SOURCE_ENTITY_TYPE) VALUES ('" + \
                                                   batch_name.strip() + "'," + str(seq_rel_table_id) + ",'RELATIONAL')"

                            #print(merge_batch_repl_map)
                            try:
                                cursor.execute(merge_batch_repl_map)
                            except oracledb.DatabaseError as e:
                                raise
                    elif table_mapping_list[9].upper() == 'REALTIME':
                        if mu.db_env == 'metaprod.world' and table_mapping_list[9].upper() == 'REALTIME':
                            batch_name = 'p_ds_idfdb_rt_' + ls_db_instance.lower().strip() + '_' + ls_abs_schema_name.lower().strip()
                            source_job = ''
                        elif mu.db_env == 'metaqa.world' and table_mapping_list[9].upper() == 'REALTIME':
                            batch_name = 'q_ds_idfdb_rt_' + ls_db_instance.lower().strip() + '_' + ls_abs_schema_name.lower().strip()
                            source_job = ''
                        elif mu.db_env == 'metauat.world' and table_mapping_list[9].upper() == 'REALTIME':
                            batch_name = 'u_ds_idfdb_rt_' + ls_db_instance.lower().strip() + '_' + ls_abs_schema_name.lower().strip()
                            source_job = ''
                        elif mu.db_env == 'metadev.world' and table_mapping_list[9].upper() == 'REALTIME':
                            batch_name = 'd_ds_idfdb_rt_' + ls_db_instance.lower().strip() + '_' + ls_abs_schema_name.lower().strip()
                            source_job = ''
                        elif mu.db_env == 'metae2e2.world' and table_mapping_list[9].upper() == 'REALTIME':
                            batch_name = 's_ds_idfdb_rt_' + ls_db_instance.lower().strip() + '_' + ls_abs_schema_name.lower().strip()
                            source_job = ''
                        merge_batch = "Merge into  " + mu.db_schema + ".BATCH " \
                                "Using (select 1 from dual) ON ( BATCH_NAME = '" + batch_name + "' AND BATCH_TYPE = 'Replication')" \
                                "WHEN NOT MATCHED THEN " \
                                "INSERT (BATCH_NAME, SCHEDULE_HOUR, BATCH_TYPE, DEP_UPON_BATCH_NAME) " \
                                "Values ( '" + batch_name + "',NULL, 'Replication', '" + source_job.strip() + "')"
                        # print(merge_batch)
                        try:
                            cursor.execute(merge_batch)
                        except oracledb.DatabaseError as e:
                            raise

                        merge_batch_repl_map = "INSERT INTO " + mu.db_schema + ".BATCH_REPLCTN_ENTITY_MAP " \
                                        "(BATCH_NAME,REPLCTN_SOURCE_ENTITY_ID,REPLCTN_SOURCE_ENTITY_TYPE) Values ('" + batch_name.strip() + "'," \
                                               + str(seq_rel_table_id) + ",'RELATIONAL')"

                        # print(merge_batch_repl_map)
                        try:
                            cursor.execute(merge_batch_repl_map)
                        except oracledb.DatabaseError as e:
                            raise
                    elif table_mapping_list[9].upper() == 'AUTOSYS DEPENDENT':
                        for source_job_name in table_mapping_list[10].lower().split(","):
                            t_source_job_name = source_job_name[source_job_name.find(source_job_name.split("_")[3]):]
                            store_source_job_name = source_job_name[
                                                    source_job_name.find(source_job_name.split("_")[1]):]

                            if mu.db_env == 'metaprod.world' and table_mapping_list[9].upper() == 'AUTOSYS DEPENDENT':
                                batch_name = 'p_ds_idfdb_dp_' + t_source_job_name.lower().strip()
                                source_job = 'p_' + store_source_job_name
                            elif mu.db_env == 'metaqa.world' and table_mapping_list[9].upper() == 'AUTOSYS DEPENDENT':
                                batch_name = 'q_ds_idfdb_dp_' + t_source_job_name.lower().strip()
                                source_job = 'q_' + store_source_job_name
                            elif mu.db_env == 'metauat.world' and table_mapping_list[9].upper() == 'AUTOSYS DEPENDENT':
                                batch_name = 'u_ds_idfdb_dp_' + t_source_job_name.lower().strip()
                                source_job = 'u_' + store_source_job_name
                            elif mu.db_env == 'metadev.world' and table_mapping_list[9].upper() == 'AUTOSYS DEPENDENT':
                                batch_name = 'd_ds_idfdb_dp_' + t_source_job_name.lower().strip()
                                source_job = 'd_' + store_source_job_name
                            elif mu.db_env == 'metae2e2.world' and table_mapping_list[9].upper() == 'AUTOSYS DEPENDENT':
                                batch_name = 's_ds_idfdb_dp_' + t_source_job_name.lower().strip()
                                source_job = 's_' + store_source_job_name
                            merge_batch = "Merge into  " + mu.db_schema + ".BATCH " \
                                                                          "Using (select 1 from dual) ON ( BATCH_NAME = '" + batch_name + "' AND BATCH_TYPE = 'Replication')" \
                                                                                                                                          "WHEN NOT MATCHED THEN " \
                                                                                                                                          "INSERT (BATCH_NAME, SCHEDULE_HOUR, BATCH_TYPE, DEP_UPON_BATCH_NAME) " \
                                                                                                                                          "Values ( '" + batch_name + "',NULL, 'Replication', '" + source_job.strip() + "')"
                            # print(merge_batch)
                            try:
                                cursor.execute(merge_batch)
                            except oracledb.DatabaseError as e:
                                raise

                            merge_batch_repl_map = "INSERT INTO " + mu.db_schema + ".BATCH_REPLCTN_ENTITY_MAP " \
                                                                                   "(BATCH_NAME,REPLCTN_SOURCE_ENTITY_ID,REPLCTN_SOURCE_ENTITY_TYPE) Values ('" + batch_name.strip() + "'," \
                                                   + str(seq_rel_table_id) + ",'RELATIONAL')"

                            # print(merge_batch_repl_map)
                            try:
                                cursor.execute(merge_batch_repl_map)
                            except oracledb.DatabaseError as e:
                                raise
                    # Loop for each column for that table in column mappings - start

                # column_mapping_list.extend([table_mapping_list[0]])
                for col_fields in range(2, num_column_mapping_rows):
                    for col_field_vals in range(1, num_column_mapping_cols):
                        if len(ws_column_mapping.cell_value(col_fields, 0)) == 0:  #
                            print("Column Mappings: Cannot have Table name blank on row# " + str(col_fields + 1))
                            sys.exit()

                        if table_mapping_list[0] == ws_column_mapping.cell_value(col_fields,
                                                                                 0):  # Loop only for that table
                            col1 = ws_column_mapping.cell_value(col_fields, col_field_vals)

                            if col_field_vals == 1 and col1 == '':
                                print("Column Mappings: Cannot have Column name blank on row# " + str(col_fields + 1))
                                sys.exit()
                            elif col_field_vals == 2 and col1 == '':
                                print("Column Mappings: Cannot have Column data type blank on row# " + str(
                                    col_fields + 1))
                                sys.exit()
                            elif col_field_vals == 3:
                                col1 = int(col1)
                            elif col_field_vals == 6 and col1 == '':  # IS_INCR_LOAD_IDENTIFIER to be defaulted to N
                                col1 = 'N'
                            elif col_field_vals == 7 and col1 == '':  # ABSTRACT_COLUMN_NAME defaulted to Relational column
                                col1 = ws_column_mapping.cell_value(col_fields, 1)
                            elif col_field_vals == 8 and col1 == '':
                                print("Column Mappings: Cannot have abtraction column sequence as NULL # " + str(
                                    col_fields + 1))
                                sys.exit()
                            elif col_field_vals == 9 and col1 == '':  # abstraction data type to be translated
                                ls_rdbms_datatype = ws_column_mapping.cell_value(col_fields, 2)
                                l_rdbms_dataprecision = ws_column_mapping.cell_value(col_fields, 4)
                                l_rdbms_datascale = ws_column_mapping.cell_value(col_fields, 5)

                                if l_rdbms_datascale == '': l_rdbms_datascale = 0
                                if l_rdbms_dataprecision == '': l_rdbms_dataprecision = 0
                                # Added for Int to Bigint changes
                                if ls_rdbms_datatype in ('NUMBER'):
                                    if l_rdbms_dataprecision == 0:
                                        col1 = df_datatype_data_precision_null
                                    elif l_rdbms_dataprecision > 0 and l_rdbms_datascale == 0:
                                        ls_sql = "SELECT TO_DATA_TYPE FROM " + mu.db_schema + ".DATATYPE_TRANSLATION  " \
                                                                                              "where from_db_type = 'ORACLE' " \
                                                                                              "and from_data_type = 'NUMBER' " \
                                                                                              "and DATA_PRECISION is not null " \
                                                                                              "and to_db_type = 'ABSTRACTION' "
                                        if l_rdbms_dataprecision < data_precision:
                                            ls_sql1 = "SELECT max(DATA_PRECISION) FROM " + mu.db_schema + ".DATATYPE_TRANSLATION " \
                                                                                                          "where from_db_type = 'ORACLE' and to_db_type = 'ABSTRACTION' " \
                                                                                                          "and from_data_type = 'NUMBER' AND DATA_PRECISION IS NOT NULL " \
                                                                                                          "AND DATA_PRECISION <>  " + str(
                                                data_precision)
                                            try:
                                                cursor.execute(ls_sql1)
                                            except oracledb.DatabaseError as e:
                                                raise
                                            row = cursor.fetchone()
                                            if row is not None:
                                                ls_sql_second_max = row[0]

                                            if l_rdbms_dataprecision < ls_sql_second_max:
                                                ls_sql = ls_sql + " and nvl(data_precision,0) < " + str(
                                                    ls_sql_second_max)
                                            else:
                                                ls_sql = ls_sql + " and (nvl(data_precision,0) >= " + str(
                                                    ls_sql_second_max) + " " \
                                                                         " and nvl(data_precision,0) < " + str(
                                                    data_precision) + ")"
                                        else:
                                            ls_sql = ls_sql + "and nvl(data_precision,0) >= " + str(data_precision)

                                        # print(ls_sql)
                                        try:
                                            cursor.execute(ls_sql)
                                        except oracledb.DatabaseError as e:
                                            raise

                                        data_file_data_type = cursor.fetchone()
                                        if data_file_data_type is None:
                                            col1 = ls_rdbms_datatype
                                        else:
                                            col1 = data_file_data_type[0]
                                    elif l_rdbms_datascale > 0 and l_rdbms_dataprecision > 0:
                                        ls_rdbms_datatype = "NUMBER(P,S)"

                                        ls_sql = "SELECT TO_DATA_TYPE FROM " + mu.db_schema + ".DATATYPE_TRANSLATION " \
                                                                                              "where from_db_type = 'ORACLE' " \
                                                                                              "and to_db_type = 'ABSTRACTION' " \
                                                                                              "and from_data_type = " + "'" + str(
                                            ls_rdbms_datatype) + "'"
                                        try:
                                            cursor.execute(ls_sql)
                                        except oracledb.DatabaseError as e:
                                            raise

                                        data_file_data_type = cursor.fetchone()
                                        if data_file_data_type is None:
                                            col1 = ls_rdbms_datatype
                                        else:
                                            col1 = data_file_data_type[0]
                                else:
                                    ls_sql = "SELECT TO_DATA_TYPE FROM " + mu.db_schema + ".DATATYPE_TRANSLATION where from_db_type = 'ORACLE' " \
                                                                                          "and to_db_type = 'ABSTRACTION' " \
                                                                                          "and from_data_type = " + "'" + str(
                                        ls_rdbms_datatype) + "'"
                                    try:
                                        cursor.execute(ls_sql)
                                    except oracledb.DatabaseError as e:
                                        raise

                                    data_file_data_type = cursor.fetchone()
                                    if data_file_data_type is None:
                                        col1 = ls_rdbms_datatype
                                    else:
                                        col1 = data_file_data_type[0]
                            elif col_field_vals == 10 and col1 == '':  # abstraction data length to be defaulted to rdbms columns
                                col1 = ws_column_mapping.cell_value(col_fields, 3)
                            elif col_field_vals == 11 and col1 == '':  # abstraction data precision column to be defaulted to rdbms columns
                                ls_rdbms_datatype = ws_column_mapping.cell_value(col_fields, 2)
                                l_rdbms_dataprecision = ws_column_mapping.cell_value(col_fields, 4)
                                l_rdbms_datascale = ws_column_mapping.cell_value(col_fields, 5)
                                if l_rdbms_datascale == '': l_rdbms_datascale = 0
                                if l_rdbms_dataprecision == '': l_rdbms_dataprecision = 0

                                if ls_rdbms_datatype in ('NUMBER', 'NUMBER(P,S)'):
                                    if l_rdbms_dataprecision == 0:
                                        ls_sql = "SELECT NVL(TO_DATA_PRECISION,0) FROM " + mu.db_schema + ".DATATYPE_TRANSLATION " \
                                                                                                          "where from_db_type = 'ORACLE'  and from_data_type = 'NUMBER' and DATA_PRECISION is null "
                                        try:
                                            cursor.execute(ls_sql)
                                        except oracledb.DatabaseError as e:
                                            raise

                                        data_file_data_precision = cursor.fetchone()
                                        if data_file_data_precision is None:
                                            col1 = ws_column_mapping.cell_value(col_fields, 4)
                                        else:
                                            col1 = data_file_data_precision[0]
                                    elif l_rdbms_dataprecision >= data_precision and l_rdbms_datascale == 0:
                                        ls_sql = "SELECT NVL(TO_DATA_PRECISION,0) FROM " + mu.db_schema + ".DATATYPE_TRANSLATION " \
                                                                                                          "where from_db_type = 'ORACLE' and from_data_type = 'NUMBER' and nvl(data_precision,0) >= " + str(
                                            data_precision)

                                        try:
                                            cursor.execute(ls_sql)
                                        except oracledb.DatabaseError as e:
                                            raise
                                        data_file_data_precision = cursor.fetchone()
                                        if data_file_data_precision is None:
                                            col1 = ws_column_mapping.cell_value(col_fields, 4)
                                        else:
                                            col1 = data_file_data_precision[0]
                                    elif l_rdbms_datascale > 0 and l_rdbms_dataprecision > 0:
                                        col1 = ws_column_mapping.cell_value(col_fields, 4)
                            elif col_field_vals == 12 and col1 == '':  # abstraction data scale column to be defaulted to rdbms columns
                                ls_rdbms_datatype = ws_column_mapping.cell_value(col_fields, 2)
                                l_rdbms_dataprecision = ws_column_mapping.cell_value(col_fields, 4)
                                l_rdbms_datascale = ws_column_mapping.cell_value(col_fields, 5)

                                if l_rdbms_datascale == '': l_rdbms_datascale = 0
                                if l_rdbms_dataprecision == '': l_rdbms_dataprecision = 0

                                if ls_rdbms_datatype in ('NUMBER', 'NUMBER(P,S)'):
                                    if l_rdbms_dataprecision == 0:
                                        ls_sql = "SELECT NVL(TO_DATA_SCALE,0) FROM " + mu.db_schema + ".DATATYPE_TRANSLATION " \
                                                                                                      "where from_db_type = 'ORACLE' and from_data_type = 'NUMBER' and DATA_PRECISION is null "

                                        try:
                                            cursor.execute(ls_sql)
                                        except oracledb.DatabaseError as e:
                                            raise

                                        data_file_data_scale = cursor.fetchone()
                                        if data_file_data_precision is None:
                                            col1 = ws_column_mapping.cell_value(col_fields, 5)
                                        else:
                                            col1 = data_file_data_scale[0]
                                    elif l_rdbms_dataprecision >= data_precision and l_rdbms_datascale == 0:
                                        ls_sql = "SELECT NVL(TO_DATA_SCALE,0) FROM " + mu.db_schema + ".DATATYPE_TRANSLATION " \
                                                                                                      "where from_db_type = 'ORACLE' and from_data_type = 'NUMBER' and nvl(data_precision,0) >= " + str(
                                            data_precision)
                                        try:
                                            cursor.execute(ls_sql)
                                        except oracledb.DatabaseError as e:
                                            raise

                                        data_file_data_scale = cursor.fetchone()
                                        if data_file_data_precision is None:
                                            col1 = ws_column_mapping.cell_value(col_fields, 5)
                                        else:
                                            col1 = data_file_data_scale[0]

                                    elif l_rdbms_datascale > 0 and l_rdbms_dataprecision > 0:
                                        col1 = ws_column_mapping.cell_value(col_fields, 5)

                            elif col_field_vals == 13 and col1 == '':  # is Nullable to be defaulted to N
                                col1 = 'N'
                            elif col_field_vals == 14 and col1 == '':  # is primary key to be defaulted to N
                                col1 = 'N'
                            elif col_field_vals == 15 and col1 == '':  # is partition key to be defaulted to N
                                col1 = 'N'
                            elif col_field_vals == 16 and col1 == '':  # is sub partition key to be defaulted to N
                                col1 = 'N'
                            elif col_field_vals == 17 and col1 == '':  # is bucket key to be defaulted to N
                                col1 = 'N'
                            elif col_field_vals == 19 and col1 == '':  # BUCKET_SORT_ORDER set to null
                                col1 = ' '
                            elif col_field_vals == 20 and col1 == '':  # is is derived partition required to be defaulted to N
                                col1 = 'N'

                            if len(str(col1)) == 0: col1 = "''"
                            column_mapping_list.extend([col1])  # Load into elements into Column Mapping List

                    # All the column mappings, populate into the database
                    if len(column_mapping_list) > 0:
                        merge_rtl_cols = "Merge into " + mu.db_schema + ".RLTNL_COLUMN " \
                                                                        "Using (select 1 from dual) " \
                                                                        "ON ( RLTNL_TABLE_ID = " + str(
                            seq_rel_table_id) + " " \
                                                "AND COLUMN_NAME = '" + str(column_mapping_list[0]) + "')" \
                                                                                                      "WHEN MATCHED THEN " \
                                                                                                      "UPDATE SET COLUMN_DATATYPE = '" + str(
                            column_mapping_list[1]) + "', " \
                                                      "DATA_LENGTH = " + str(column_mapping_list[2]) + ", " \
                                                                                                       "DATA_PRECISION = " + str(
                            column_mapping_list[3]) + ", " \
                                                      "DATA_SCALE = " + str(column_mapping_list[4]) + ", " \
                                                                                                      "IS_INCR_LOAD_IDENTIFIER = '" + str(
                            column_mapping_list[5]) + "', " \
                                                      "IS_NULLABLE = '" + str(column_mapping_list[12]) + "', " \
                                                                                                         "IS_PRIMARY_KEY = '" + str(
                            column_mapping_list[13]) + "', " \
                                                       "COLUMN_ORDR_NBR = " + str(column_mapping_list[7]) + \
                                         " WHEN NOT MATCHED THEN INSERT (RLTNL_COLUMN_ID, RLTNL_TABLE_ID, COLUMN_NAME, " \
                                         "COLUMN_DATATYPE, DATA_LENGTH, DATA_PRECISION, DATA_SCALE, IS_INCR_LOAD_IDENTIFIER, " \
                                         "IS_NULLABLE, IS_PRIMARY_KEY, COLUMN_ORDR_NBR) " \
                                         "VALUES ( " + mu.db_schema + ".SEQ_RLTNL_COLUMN.NEXTVAL," + str(
                            seq_rel_table_id) + "," + \
                                         "'" + str(column_mapping_list[0]) + "','" + str(
                            column_mapping_list[1]) + "'," + \
                                         str(column_mapping_list[2]) + "," + str(column_mapping_list[3]) + "," + \
                                         str(column_mapping_list[4]) + ",'" + str(column_mapping_list[5]) + "','" + \
                                         str(column_mapping_list[12]) + "','" + str(
                            column_mapping_list[13]) + "'," + str(column_mapping_list[7]) + ")"
                        # if table_mapping_list[0].strip() == 'FT_T_EMPL':
                        #    print(merge_rtl_cols)

                        try:
                            cursor.execute(merge_rtl_cols)
                        except oracledb.DatabaseError as e:
                            raise

                        try:
                            cursor.execute("SELECT RLTNL_COLUMN_ID from " + mu.db_schema + ".RLTNL_COLUMN "
                                                                                           "where RLTNL_TABLE_ID = " + str(
                                seq_rel_table_id) + " and "
                                                    "upper(COLUMN_NAME) = upper('" + str(column_mapping_list[0]) + "')")
                        except oracledb.DatabaseError as e:
                            raise
                        row = cursor.fetchone()
                        if row is not None:
                            seq_relational_col_id = row[0]
                        else:
                            print("Relation Column Id not found, please check")
                            sys.exit()

                        merg_abs_col = "Merge Into " + mu.db_schema + ".ABSTRCTN_TABLE_COLUMN " \
                                                                      "Using (select 1 from dual) " \
                                                                      "ON ( ABSTRCTN_TABLE_ID = " + str(
                            seq_abs_table_id) + " " \
                                                "AND COLUMN_NAME = '" + str(column_mapping_list[6]) + "') " \
                                                                                                      "WHEN MATCHED THEN " \
                                                                                                      "UPDATE SET COLUMN_DATATYPE = '" + str(
                            column_mapping_list[8]) + "', " \
                                                      "DATA_LENGTH  = " + str(column_mapping_list[9]) + ", " \
                                                                                                        "DATA_PRECISION = " + str(
                            column_mapping_list[10]) + ", " \
                                                       "DATA_SCALE = " + str(column_mapping_list[11]) + ", " \
                                                                                                        "IS_PARTITION_KEY = '" + str(
                            column_mapping_list[14]) + "', " \
                                                       "IS_SUBPARTITION_KEY = '" + str(column_mapping_list[15]) + "', " \
                                                                                                                  "IS_BUCKET_KEY = '" + str(
                            column_mapping_list[16]) + "', " \
                                                       "BUCKET_COUNTS = " + str(column_mapping_list[17]) + ", " \
                                                                                                           "BUCKET_SORT_ORDER = '" + str(
                            column_mapping_list[18].strip()) + "', " \
                                                               "IS_DERIVED_PARTITION_REQUIRED = '" + str(
                            column_mapping_list[19]) + "' " \
                                                       "WHEN NOT MATCHED THEN INSERT ( ABSTRCTN_TABLE_COLUMN_ID, ABSTRCTN_TABLE_ID,  " \
                                                       " COLUMN_NAME, COLUMN_DATATYPE, DATA_LENGTH,  " \
                                                       " DATA_PRECISION, DATA_SCALE,  " \
                                                       "IS_PARTITION_KEY, IS_SUBPARTITION_KEY, IS_BUCKET_KEY, BUCKET_COUNTS, BUCKET_SORT_ORDER, IS_DERIVED_PARTITION_REQUIRED) " \
                                                       "VALUES ( " + mu.db_schema + ".SEQ_ABSTRCTN_TABLE_COLUMN.NEXTVAL, " + str(
                            seq_abs_table_id) + ",'" \
                                       + str(column_mapping_list[6]) + "','" + str(
                            column_mapping_list[8]) + "','" + str(column_mapping_list[9]) + "'," \
                                       + str(column_mapping_list[10]) + "," + str(column_mapping_list[11]) + ",'" \
                                       + str(column_mapping_list[14]) + "','" + str(column_mapping_list[15]) + "','" \
                                       + str(column_mapping_list[16]) + "'," + str(
                            column_mapping_list[17]) + ",'" + str(column_mapping_list[18].strip()) + "','" \
                                       + column_mapping_list[19] + "')"

                        # print(merg_abs_col)
                        try:
                            cursor.execute(merg_abs_col)
                        except oracledb.DatabaseError as e:
                            raise

                        try:
                            cursor.execute(
                                "SELECT ABSTRCTN_TABLE_COLUMN_ID from " + mu.db_schema + ".ABSTRCTN_TABLE_COLUMN "
                                                                                         "where ABSTRCTN_TABLE_ID = " + str(
                                    seq_abs_table_id) + " and "
                                                        "upper(COLUMN_NAME) = upper('" + str(
                                    column_mapping_list[6]) + "')")
                        except oracledb.DatabaseError as e:
                            raise
                        row = cursor.fetchone()
                        if row is not None:
                            seq_abs_tbl_col_id = row[0]
                        else:
                            print("Abstraction Column Id not found, please check")
                            sys.exit()

                        merge_rel_abs = "Merge Into " + mu.db_schema + ".RLTNL_ABSTRCTN_COL_MAP " \
                                                                       "Using (select 1 from dual) " \
                                                                       "ON (RLTNL_TABLE_ID = " + str(
                            seq_rel_table_id) + " " \
                                                "AND RLTNL_COLUMN_ID = " + str(seq_relational_col_id) + " " \
                                                                                                        "AND ABSTRCTN_TABLE_ID = " + str(
                            seq_abs_table_id) + " " \
                                                "AND ABSTRCTN_TABLE_COLUMN_ID = " + str(seq_abs_tbl_col_id) + ") " \
                                                                                                              "WHEN NOT MATCHED THEN  INSERT " \
                                                                                                              "(RLTNL_TABLE_ID,RLTNL_COLUMN_ID, ABSTRCTN_TABLE_ID, ABSTRCTN_TABLE_COLUMN_ID) " \
                                                                                                              "Values ( " + str(
                            seq_rel_table_id) + "," + str(seq_relational_col_id) + "," \
                                                                                   "" + str(
                            seq_abs_table_id) + "," + str(seq_abs_tbl_col_id) + ")"

                        # print(merge_rel_abs)
                        try:
                            cursor.execute(merge_rel_abs)
                        except oracledb.DatabaseError as e:
                            raise

                    column_mapping_list = []
                table_mapping_list = []
                counter = counter + round((100/num_table_mapping_rows),2)
                mu.update_progress("Processing Metadata Template : " + input_file, round(counter/100,2))
            cursor.execute('commit')
            mu.update_progress("Processing Metadata Template : " + input_file, 100)
            for part_field in range(2, num_partition_rows):
                for part_field_vals in range(num_partition_cols):
                    col = ws_partition_columns.cell_value(part_field, part_field_vals)
                    if part_field_vals == 0 and col == '':  # Table Name
                        print("Table Mappings: Cannot have Table name blank on row# " + str(part_field + 1))
                        sys.exit()
                    elif part_field_vals == 1 and col == '':  # Partition Order
                        col = ws_partition_columns.cell_value(part_field, 0)
                    elif part_field_vals == 2 and col == '':  # Parition Name
                        col = ws_partition_columns.cell_value(part_field, 0)
                    elif part_field_vals == 3 and col == '':  # Is Partition Derived
                        col = ws_partition_columns.cell_value(part_field, 0)
                    elif part_field_vals == 4:  # Source Column Format
                        col = ws_partition_columns.cell_value(part_field, part_field_vals)
                    elif part_field_vals == 5:  # partition expression
                        col = ws_partition_columns.cell_value(part_field, part_field_vals)

                    if ws_partition_columns.cell_type(part_field, part_field_vals) == 2:
                        col = int(col)

                    partition_columns_list.extend([col])  # Load into elements into Table Mapping List

                if len(partition_columns_list) > 0:
                    ls_rltnl_table_id = "select T.RLTNL_TABLE_ID from  " + mu.db_schema + ".RLTNL_TABLE t " \
                                                                                          "where t.RLTNL_SCHEMA_ID= " + str(
                        seq_rel_db_sch_id) + " and t.TABLE_NAME='" + partition_columns_list[0] + "'"

                    # print(ls_rltnl_table_id)
                    try:
                        cursor.execute(ls_rltnl_table_id)
                    except oracledb.DatabaseError as e:
                        raise
                    row = cursor.fetchone()
                    if row is not None:
                        relational_table_id = row[0]
                        ls_abst_table_id = "Select distinct A.ABSTRCTN_TABLE_ID " \
                                           "from " + mu.db_schema + ".RLTNL_COLUMN r, " + mu.db_schema + ".ABSTRCTN_TABLE_COLUMN a, " + mu.db_schema + ".RLTNL_ABSTRCTN_COL_MAP ra " \
                                                                                                                                                       "where R.RLTNL_TABLE_ID =  " + str(
                            relational_table_id) + " " \
                                                   "and R.RLTNL_COLUMN_ID = RA.RLTNL_COLUMN_ID  " \
                                                   "and A.ABSTRCTN_TABLE_COLUMN_ID =RA.ABSTRCTN_TABLE_COLUMN_ID"
                        try:
                            cursor.execute(ls_abst_table_id)
                        except oracledb.DatabaseError as e:
                            raise
                        row = cursor.fetchone()
                        if row is not None:
                            abstraction_table_id = row[0]

                        # put merge to insert the record into new table
                        merge_abs_part_col = "Merge Into " + mu.db_schema + ".ABSTRCTN_PARTITION_COLUMN " \
                                                                            "Using (select 1 from dual) " \
                                                                            "ON (ABSTRCTN_TABLE_ID = " + str(
                            abstraction_table_id) + "" \
                                                    " AND PARTITION_NAME = '" + str(partition_columns_list[2]) + "')" \
                                                                                                                 "WHEN MATCHED THEN " \
                                                                                                                 "UPDATE SET  " \
                                                                                                                 "PARTITION_ORDER = " + str(
                            partition_columns_list[1]) + ", " \
                                                         "IS_PARTITION_DERIVED = '" + str(
                            partition_columns_list[3]) + "', " \
                                                         "SOURCE_COLUMN_FORMAT = '" + str(
                            partition_columns_list[4]) + "', " \
                                                         "PARTITION_EXPRESSION = '" + str(
                            partition_columns_list[5]) + "' " \
                                                         "WHEN NOT MATCHED THEN INSERT ( ABSTRCTN_PARTITION_COLUMN_ID,ABSTRCTN_TABLE_ID,  " \
                                                         "PARTITION_ORDER, PARTITION_NAME, IS_PARTITION_DERIVED, " \
                                                         "SOURCE_COLUMN_FORMAT, PARTITION_EXPRESSION) VALUES ( " + mu.db_schema \
                                             + ".SEQ_ABSTRCTN_PART_COLUMN.NEXTVAL, " + str(abstraction_table_id) + "," \
                                                                                                                   "" + str(
                            partition_columns_list[1]) + ",'" + str(partition_columns_list[2]) + "','" + str(
                            partition_columns_list[3]) + "'," \
                                                         "'" + str(partition_columns_list[4]) + "','" + str(
                            partition_columns_list[5]) + "')"

                        try:
                            cursor.execute(merge_abs_part_col)
                        except oracledb.DatabaseError as e:
                            raise

                        partition_columns_list = []
    cursor.execute('commit')
    try:
        cursor.close()
        connection.close()
    except oracledb.DatabaseError:
        pass
def list_all_metadata_files(input_path):
    """
    List all the metadata files in the given s3 path
    :param input_path: s3 path (s3://spr-idf-env-raw-zone/folder1/subfolder1/)
    
    :return: set of metadata files (Metadata_*.xlsx)
    """
    if input_path is None:
        raise ValueError("Input Path is not provided")
    bucket_name = input_path.split('/')[2]
    metadata_file_name = '/'.join(input_path.split('/')[3:])
    s3 = boto3.client('s3')
    logging.info(f"Bucket Name : {bucket_name}, File Key : {metadata_file_name}")
    response = s3.list_objects_v2(Bucket=bucket_name, Prefix=metadata_file_name)
    metadata_files = [file_names['Key'].split("/")[-1] for file_names in response['Contents']]
    files = [metadata_file
             for metadata_file in metadata_files
             if metadata_file.startswith('Metadata_') and metadata_file.endswith('.xlsx')]
    return set(files)

def read_excel_from_s3(input_path ,input_file_name):
    """
    Read the Excel file from the s3 path
    """
    bucket_name = None
    metadata_file_name = None
    if input_path.startswith('s3://'):
        bucket_name = input_path.split('/')[2]
        metadata_file_name = '/'.join(input_path.split('/')[3:])
        logging.info(f"Bucket Name : {bucket_name}, File Key : {metadata_file_name}")
    s3 = boto3.client('s3')
    if bucket_name is None or metadata_file_name is None:
        raise ValueError("Bucket Name or File Name is not provided")
    metadata_file_key = os.path.join(metadata_file_name,input_file_name)
    logging.info(f"Reading the file from s3 : {metadata_file_key}")
    s3_object = s3.get_object(Bucket=bucket_name, Key=metadata_file_key)
    metadata_file_content = s3_object['Body'].read()
    file_like_object = io.BytesIO(metadata_file_content)
    return file_like_object

def verify_metadata_file_existence(input_file_name, all_existed_files):
    """
    Verify the existence of the file in the given s3 path
    """
    if input_file_name is None or input_file_name not in all_existed_files:
        logging.error(f"File Name is not provided {input_file_name}")
        return False
    return True



if file_name is not None:
    # Processing single File instead of all files
    logging.info(f"Processing the single Metadata File instead of all :{file_name}" )
    if path.startswith('s3://'):
        set_of_existed_files = list_all_metadata_files(path)
        logging.info(f"Set of Existed Files : {len(set_of_existed_files)}")
        if not verify_metadata_file_existence(file_name, set_of_existed_files):
            logging.error(f"File Name : {file_name} is not existed in the given path {path}")
            raise ValueError(f"File Name : {file_name} is not existed in the given path {path}")
        file_content = read_excel_from_s3(path,file_name)
        perform_validations(file_content)
        logging.info(f"Performing Validations for the file : {type(file_content)}")
        file_content = read_excel_from_s3(path, file_name)
        mu.GetAWSConfig(confilg_file_name)
        load_data(file_content,file_name)
# Processing all files from s3 path
else:
    # Setting the initial path to provide volume name
    logging.info(f"Length of Arguments and {len(sys.argv)} and {sys.argv}")
    initial_path = path
    all_existed_files  = list_all_metadata_files(path)
    logging.info(f"Processing all files : {path} and number of files {len(all_existed_files)}")
    for file_name in all_existed_files:
        logging.info(f"Processing Metadata Template : {file_name}")
        file_content = read_excel_from_s3(path, file_name)
        perform_validations(file_content)
        file_content = read_excel_from_s3(path, file_name)
        mu.GetAWSConfig(confilg_file_name)
        load_data(file_content, file_name)
        logging.info(f"Processing Metadata Template : {file_name} is completed")