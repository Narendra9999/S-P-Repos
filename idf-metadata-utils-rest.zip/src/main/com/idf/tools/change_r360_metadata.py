import boto3
import cx_Oracle
import json
import os, sys
from botocore.config import Config
from main.com.idf.tools.RSMUtil import getpassword
import argparse

event = 0
pkg = 0
table = ''
column = ''


# Create the parser
my_parser = argparse.ArgumentParser(description='Pass the execution arguments')

# Add the arguments
my_parser.add_argument('operation',metavar='operation',type=str,help='operation Copy, Add, or Delete')
my_parser.add_argument('fromDB',metavar='from_db', type=str,help='Copied from DB')
my_parser.add_argument('toDB',metavar='to_db', type=str,help='Copied to DB')
my_parser.add_argument('event_id',metavar='event', type=int,help='the event that you want to copy')

# Execute the parse_args() method
args = my_parser.parse_args()
operation = args.operation


if operation == "Copy":

# if sys.argv[1] == "Copy":

    if len(sys.argv) < 4:
        print('Please provide From Database & To Database for R360 metadata to be copied')
        sys.exit()

    if len(sys.argv) == 5:
        from_db = args.fromDB
        to_db = args.toDB
        event = args.event_id

        print("All params: operation --> " + operation + " From--> " + from_db + " To -->" + to_db)
    # elif len(sys.argv) == 6:
    #     from_db = sys.argv[2]
    #     to_db = sys.argv[3]
    #     event = sys.argv[4]
    #     pkg = sys.argv[5]
    # elif len(sys.argv) == 7:
    #     from_db = sys.argv[2]
    #     to_db = sys.argv[3]
    #     event = sys.argv[4]
    #     pkg = sys.argv[5]
    #     table = sys.argv[6]
    # elif len(sys.argv) == 8:
    #     from_db = sys.argv[2]
    #     to_db = sys.argv[3]
    #     event = sys.argv[4]
    #     pkg = sys.argv[5]
    #     table = sys.argv[6]
    #     column = sys.argv[7]
    # CheckinTest

    if to_db == "DEV":
        config_file_loc = "spr-idf-dev-global-config-loc"
        config_file_name = "spr-idf-dev-global-config-file"
    elif to_db == "QA":
        config_file_loc = "spr-idf-qa-global-config-loc"
        config_file_name = "spr-idf-qa-global-config-file"
    elif to_db == "UAT":
        config_file_loc = "spr-idf-uat-global-config-loc"
        config_file_name = "spr-idf-uat-global-config-file"
    elif to_db == "PROD":
        config_file_loc = "spr-idf-prod-global-config-loc"
        config_file_name = "spr-idf-prod-global-config-file"
    elif to_db == "DEV1":
        config_file_loc = "spr-idf-dev1-global-config-loc"
        config_file_name = "spr-idf-dev1-global-config-file"



else:
    if len(sys.argv) < 3:
        print(
            'Please provide SSM parameter for config file, location, and excel file location for metadata store update')
        sys.exit()

    # confilg_file_loc = args[1]
    # confilg_file_name = args[2]
    # event_id = ''

# if operation == "Add" or operation == "Drop":
#     if len(sys.argv) == 6:
#         alter_db = args[2]
#         event = args[3]
#         pkg = args[4]
#         table = args[5]
#     elif len(sys.argv) == 7:
#         alter_db = args[2]
#         event = args[3]
#         pkg = args[4]
#         table = args[5]
#         column = args[6]
#
#     if alter_db == "DEV":
#         config_file_loc = "spr-idf-dev-global-config-loc"
#         config_file_name = "spr-idf-dev-global-config-file"
#     elif alter_db == "QA":
#         config_file_loc = "spr-idf-qa-global-config-loc"
#         config_file_name = "spr-idf-qa-global-config-file"
#     elif alter_db == "UAT":
#         config_file_loc = "spr-idf-uat-global-config-loc"
#         config_file_name = "spr-idf-uat-global-config-file"
#     elif alter_db == "PROD":
#         config_file_loc = "spr-idf-prod-global-config-loc"
#         config_file_name = "spr-idf-prod-global-config-file"
#     elif alter_db == "DEV1":
#         config_file_loc = "spr-idf-dev1-global-config-loc"
#         config_file_name = "spr-idf-dev1-global-config-file"

# if len(sys.argv) == 4:
#     p_param_type = "EVENT_ID"
#     event_id = args[3]
#     # print(event_id)


def GetAWS_Config(loc, file):
    global db_schema
    global db_usrname
    global db_pswd
    global db_url
    global db_env
    global aws_region
    aws_region = os.getenv("aws_region")

    boto3.client('ssm')
    #print("Proxy Setting are Done....")
    session=boto3.Session(region_name=aws_region)
    #print("Region Setting are Done....")
    ssm=session.client("ssm")
    #print("Just SSM Print  1234", ssm)
    location = ssm.get_parameter(Name=loc, WithDecryption=True)
    global_filename=ssm.get_parameter(Name=file, WithDecryption=True)
    client=boto3.client('s3')
    bucket_value = location['Parameter']['Value']
    gfilename_value = global_filename['Parameter']['Value']
    BUCKET=bucket_value.split("/")[0]
    KEY=bucket_value.split("/")[1] +'/'+bucket_value.split("/")[2]+'/'+gfilename_value
    result = client.get_object(Bucket=BUCKET, Key=KEY)
    text = result["Body"].read().decode()
    #json_str = json.dumps(text)
    read_json = json.loads(text)
    db_usrname = read_json["control_table_conf"]["control_table_db_username"]
    secrect_pwd = read_json["control_table_conf"]["control_table_db_pwd"]
    db_pswd = getpassword(secrect_pwd[6:-1])
    db_url = read_json["control_table_conf"]["control_table_db_url"].split("//")[1]
    db_env = read_json["control_table_conf"]["control_table_db_url"].split("/")[3]
    db_schema = read_json["control_table_conf"]["control_table_schema_owner"]

    print(KEY)
    print(BUCKET)

# def add_r360_metadata():
#     GetAWS_Config(confilg_file_loc, confilg_file_name)
#     try:
#         connstr = db_usrname + "/" + db_pswd + '@' + db_url
#         connection = cx_Oracle.connect(connstr)
#
#     except cx_Oracle.DatabaseError as e:
#         raise
#     cursor = connection.cursor()
#
#     if event != 0 and pkg != 0 and table != '' and column == '':
#         insertBusEventEntity(cursor, pkg, table, 0, gettableId(cursor, db_schema, table), "", "", "", 0, "", "")
#     if event != 0 and pkg != 0 and table != '' and column != '':
#         pkgEntityId = getPkgEntId(cursor, table, pkg)
#         insertBusEventEntAttr(cursor, pkgEntityId, [(column, "", "N", "N")])


def read_file():
    global dev_conn
    global dev1_conn
    global qa_conn
    global si_conn

    # print("inside read file")

    src_params = 'app_params.txt'  # param file location

    filename = open(src_params, "r")
    for line in filename:
        line = line.strip()
        param_value = line.split("=")

        if param_value[0].strip() == "dev_connstr":
            dev_conn = param_value[1].strip()
            # print(dev_conn)
        elif param_value[0].strip() == "dev1_connstr":
            dev1_conn = param_value[1].strip()
            # print(dev1_conn)
        elif param_value[0].strip() == "qa_connstr":
            qa_conn = param_value[1].strip()
        elif param_value[0].strip() == "si_connstr":
            si_conn = param_value[1].strip()

    filename.close()


def copy_r360_metadata():
    # From DB
    if from_db == "DEV":
        connstr = dev_conn
        # print(connstr)
    elif from_db == "QA":
        connstr = qa_conn
    elif from_db == "SI":
        connstr = si_conn
    elif from_db == "DEV1":
        connstr = dev1_conn
        # print(connstr)

    # Connect to Metadata DB #
    try:
        # connstr = db_usrname + "/" + db_pswd + '@' + db_url
        # connstr = 'IDF_METADATA_USER/IDF_METADATA_USER_2018@spdrac-scan.dev.spratingsvpc.com/metadev.world'
        connection = cx_Oracle.connect(connstr)
        from_db_schema = 'IDF_METADATA'

    except cx_Oracle.DatabaseError as e:
        raise
    cursor = connection.cursor()

    # To DB
    GetAWS_Config(config_file_loc, config_file_name)

    # Connect to Metadata DB #
    try:
        to_connstr = db_usrname + "/" + db_pswd + '@' + db_url
        to_connection = cx_Oracle.connect(to_connstr)

        print(to_connstr)
    except cx_Oracle.DatabaseError as e:
        raise
    to_cursor = to_connection.cursor()

    ls_del_bus_event_pkgsql = " DELETE from " + db_schema + ".BUS_EVENT_PKG_SQL"
    # print(ls_del_bus_event_pkgsql)

    try:
        to_cursor.execute(ls_del_bus_event_pkgsql)
    except cx_Oracle.DatabaseError as e:
        raise

    # Get BUS_EVENT_PKG_SQL
    ls_bus_event_pkgsql_sql = "Select SQL_REFERENCE_ID, SQL_TEXT, nvl(DESCRIPTION, '~') from " + from_db_schema + ".BUS_EVENT_PKG_SQL"

    print(ls_bus_event_pkgsql_sql)
    cursor.execute(ls_bus_event_pkgsql_sql)
    bus_event_pkgsql_result = cursor.fetchall()

    if bus_event_pkgsql_result is not None:
        # Put BUS_EVENT_PKG_SQL
        for index0 in range(len(bus_event_pkgsql_result)):
            # deleteBusEvent(to_cursor, bus_event_result[index][0])

            ls_ins_bus_event_pkgsql = " INSERT INTO " + db_schema + ".BUS_EVENT_PKG_SQL (SQL_REFERENCE_ID, SQL_TEXT, DESCRIPTION) " \
                                                                    "VALUES (" + str(
                bus_event_pkgsql_result[index0][0]) + ", '" + \
                                      str(bus_event_pkgsql_result[index0][1]).replace("'", "''") + "', '" + str(
                bus_event_pkgsql_result[index0][2]) + "')"

            # print(ls_ins_bus_event_pkgsql)
            try:
                to_cursor.execute(ls_ins_bus_event_pkgsql)
            except cx_Oracle.DatabaseError as e:
                raise

    # Get BUS_EVENT
    if event != 0:
        # print(event)
        ls_bus_event_sql = "Select business_event_id, bus_event_name, bus_event_description from " + from_db_schema + ".bus_event where business_event_id = " + str(
            event)
    else:
        ls_bus_event_sql = "Select business_event_id, bus_event_name, bus_event_description from " + from_db_schema + ".bus_event "

    # print(ls_bus_event_sql)
    cursor.execute(ls_bus_event_sql)
    bus_event_result = cursor.fetchall()

    if bus_event_result is None:
        # print(" Business Event Id to copy from do not exist in " + from_db_schema + " database")
        sys.exit()

    # Put BUS_EVENT
    for index in range(len(bus_event_result)):
        if pkg == 0:
            deleteBusEvent(to_cursor, bus_event_result[index][0])

            ls_del_attr = "DELETE from " + db_schema + ".BUS_EVENT_PKG_ATTR where PACKAGE_ENTITY_ID in (Select " \
                                                       "PACKAGE_ENTITY_ID from " + db_schema + ".BUS_EVENT_PKG_ENTITY where PACKAGE_ID IN (SELECT " \
                                                                                               "PACKAGE_ID FROM " + db_schema + ".BUS_EVENT_PKG_MAP WHERE BUS_EVENT_ID =" + str(event) + "))"

            # print(ls_del_attr)

            try:
                to_cursor.execute(ls_del_attr)
            except cx_Oracle.DatabaseError as e:
                raise

            ls_ins_bus_event = " INSERT INTO " + db_schema + ".bus_event (business_event_id, bus_event_name, bus_event_description) " \
                                                             "VALUES (" + str(bus_event_result[index][0]) + ", '" + \
                               bus_event_result[index][1] + "', '" + bus_event_result[index][2] + "')"

            # print(ls_ins_bus_event)
            try:
                to_cursor.execute(ls_ins_bus_event)
            except cx_Oracle.DatabaseError as e:
                raise

        # Get BUS_EVENT_DETAIL
        ls_bus_event_dtl_sql = " Select business_event_dtl_id, business_event_id, rlntl_table_id, event_trigger_sql, " \
                               " sql_input_columns, sql_output_columns, " \
                               "active_flg, trigger_sql_entities from " + from_db_schema + ".bus_event_detail where business_event_id = " + str(
            event)

        # print(ls_bus_event_dtl_sql)
        cursor.execute(ls_bus_event_dtl_sql)
        bus_event_dtl_result = cursor.fetchall()

        if bus_event_dtl_result is None:
            # print(" Business Event Details do not exist in " + from_db_schema + " database to copy from for the business event id = " + event)
            sys.exit()

        if pkg == 0:
            # Put BUS_EVENT_DETAIL
            for index in range(len(bus_event_dtl_result)):

                deleteBusEventDtl(to_cursor, event, gettableId(to_cursor, db_schema,
                                                               gettableName(cursor, from_db_schema,
                                                                            bus_event_dtl_result[index][2])))

                ll_bus_event_dtl_id = getMaxPk(to_cursor, "BUS_EVENT_DETAIL")

                ls_ins_bus_event_dtl = "INSERT INTO " + db_schema + ".bus_event_detail (business_event_dtl_id,business_event_id,rlntl_table_id," \
                                                                    "sql_input_columns,sql_output_columns,active_flg, trigger_sql_entities, event_trigger_sql ) " \
                                                                    "VALUES (" + str(ll_bus_event_dtl_id) + ", " + str(
                    bus_event_dtl_result[index][1]) + "," \
                                                      " " + str(gettableId(to_cursor, db_schema,
                                                                           gettableName(cursor, from_db_schema,
                                                                                        bus_event_dtl_result[index][
                                                                                            2]))) + "," \
                                                                                                    " '" + \
                                       bus_event_dtl_result[index][4] + "', '" + bus_event_dtl_result[index][5] + "', " \
                                                                                                                  "'" + \
                                       bus_event_dtl_result[index][6] + "','" + bus_event_dtl_result[index][7] + "'," \
                                                                                                                 "'" + \
                                       bus_event_dtl_result[index][3].replace("'", "''") + "')"

                # print(ls_ins_bus_event_dtl)
                try:
                    to_cursor.execute(ls_ins_bus_event_dtl)
                except cx_Oracle.DatabaseError as e:
                    raise

            # Get BUS_EVENT_PKG_MAP
            ls_bus_event_pkg_map_sql = "Select bus_event_id, package_id from " + from_db_schema + ".bus_event_pkg_map where bus_event_id = " + str(
                event)
        else:
            ls_bus_event_pkg_map_sql = "Select bus_event_id, package_id from " + from_db_schema + ".bus_event_pkg_map where bus_event_id = " + str(
                event) + " and package_id = " + pkg

        # print(ls_bus_event_pkg_map_sql)
        cursor.execute(ls_bus_event_pkg_map_sql)
        bus_event_pkg_map_result = cursor.fetchall()

        if bus_event_pkg_map_result is None and pkg != 0:
            # print("The combination of Business Event Id " + event + " and Package Id " + pkg + " do not exist in " + from_db + " database")
            sys.exit()

        for index in range(len(bus_event_pkg_map_result)):

            if table == '':
                deleteBusEventPkgMap(to_cursor, bus_event_pkg_map_result[index][0], bus_event_pkg_map_result[index][1])

                # Put BUS_EVENT_PKG_MAP
                ls_ins_bus_event_pkg_map = "INSERT INTO " + db_schema + ".bus_event_pkg_map ( bus_event_id, package_id) " \
                                                                        "VALUES (" + str(
                    bus_event_pkg_map_result[index][0]) + ", " + \
                                           str(bus_event_pkg_map_result[index][1]) + ")"

                # print(ls_ins_bus_event_pkg_map)
                try:
                    to_cursor.execute(ls_ins_bus_event_pkg_map)
                except cx_Oracle.DatabaseError as e:
                    raise

            # Get BUS_EVENT_PKG
            ls_bus_event_pkg_sql = "Select package_id, package_name, description from " + from_db_schema + ".bus_event_pkg where package_id = " + str(
                bus_event_pkg_map_result[index][1])
            # print(ls_bus_event_pkg_sql)
            cursor.execute(ls_bus_event_pkg_sql)
            bus_event_pkg_result = cursor.fetchall()

            if bus_event_pkg_result is None:
                # print("Mapping of business event to the package id " + pkg + " do not exist in " + from_db + " database")
                sys.exit()

            for index1 in range(len(bus_event_pkg_result)):

                deleteBusEventPkg(to_cursor, bus_event_pkg_result[index1][0])

                if table == '':
                    # Put BUS_EVENT_PKG
                    ls_ins_bus_event_pkg = "INSERT INTO " + db_schema + ".bus_event_pkg (package_id, package_name, description) " \
                                                                        "VALUES (" + str(
                        bus_event_pkg_result[index1][0]) + ", '" + bus_event_pkg_result[index1][1] + "', " \
                                                                                                     "'" + \
                                           bus_event_pkg_result[index1][2] + "')"

                    # print(ls_ins_bus_event_pkg)
                    try:
                        to_cursor.execute(ls_ins_bus_event_pkg)
                    except cx_Oracle.DatabaseError as e:
                        raise

                    # Get BUS_EVENT_PKG_ENTITY
                    ls_bus_event_ent_sql = "Select package_entity_id, package_id, package_entity_name, rlntl_table_id, nvl(package_entity_type,'T'), nvl(sql_filter,'~'), " \
                                           "nvl(sql_reference_id,0), entity_sort_order, entity_in_keys, nvl(entity_out_keys, '~'), nvl(next_entity_id, '~')" \
                                           " from " + from_db_schema + ".bus_event_pkg_entity where package_id = " + str(
                        bus_event_pkg_result[index1][0])
                else:
                    ls_bus_event_ent_sql = "Select package_entity_id, package_id, package_entity_name, rlntl_table_id, nvl(package_entity_type,'T'), nvl(sql_filter,'~'), " \
                                           "nvl(sql_reference_id,0), entity_sort_order, entity_in_keys, nvl(entity_out_keys, '~'), nvl(next_entity_id, '~')" \
                                           " from " + from_db_schema + ".bus_event_pkg_entity where package_id = " + str(
                        bus_event_pkg_result[index1][0]) + " " \
                                                           "and upper(package_entity_name) = " + table.upper()

                # print(ls_bus_event_ent_sql)
                cursor.execute(ls_bus_event_ent_sql)
                bus_event_ent_result = cursor.fetchall()

                if bus_event_pkg_result is None:
                    # print("None of the entities are associated for the package id " + pkg + " in " + from_db + " database")
                    sys.exit()

                i = 0
                for index2 in range(len(bus_event_ent_result)):
                    i += 1
                    if column == '':

                        if i == 1: deleteBusEventEntity(to_cursor, bus_event_ent_result[index2][1])
                        # Put BUS_EVENT_PKG_ENTITY
                        ls_ins_bus_event_ent = "INSERT INTO " + db_schema + ".bus_event_pkg_entity (package_entity_id,package_id,package_entity_name,rlntl_table_id," \
                                                                            "package_entity_type,sql_filter,sql_reference_id, entity_sort_order,entity_in_keys, entity_out_keys, next_entity_id) " \
                                                                            "VALUES (" + str(
                            getMaxPk(to_cursor, "BUS_EVENT_PKG_ENTITY")) + "," + str(
                            bus_event_ent_result[index2][1]) + "," \
                                                               "'" + bus_event_ent_result[index2][2] + "'," + str(
                            gettableId(to_cursor, db_schema, bus_event_ent_result[index2][2])) + ", " \
                                                                                                 "'" + \
                                               bus_event_ent_result[index2][4] + "','" + bus_event_ent_result[index2][
                                                   5].replace("'", "''") + "'," \
                                                                           "" + str(
                            bus_event_ent_result[index2][6]) + "," \
                                                               "" + str(bus_event_ent_result[index2][7]) + ",'" + \
                                               bus_event_ent_result[index2][8] + "'," \
                                                                                 "'" + bus_event_ent_result[index2][
                                                   9] + "','" + bus_event_ent_result[index2][10] + "')"

                        print(ls_ins_bus_event_ent)
                        try:
                            to_cursor.execute(ls_ins_bus_event_ent)
                        except cx_Oracle.DatabaseError as e:
                            raise

                        ls_upd_bus_event_ent_nextentity = "update " + db_schema + ".bus_event_pkg_entity set next_entity_id = '' where next_entity_id = '~'"
                        ls_upd_bus_event_ent_sqlfilter = "update " + db_schema + ".bus_event_pkg_entity set sql_filter = '' where sql_filter = '~'"
                        ls_upd_bus_event_ent_inkeys = "update " + db_schema + ".bus_event_pkg_entity set ENTITY_IN_KEYS = '' where ENTITY_IN_KEYS = '~'"
                        ls_upd_bus_event_ent_outkeys = "update " + db_schema + ".bus_event_pkg_entity set ENTITY_OUT_KEYS = '' where ENTITY_OUT_KEYS = '~'"

                        # print(ls_upd_bus_event_ent_nextentity)
                        try:
                            to_cursor.execute(ls_upd_bus_event_ent_nextentity)
                            to_cursor.execute(ls_upd_bus_event_ent_sqlfilter)
                            to_cursor.execute(ls_upd_bus_event_ent_inkeys)
                            to_cursor.execute(ls_upd_bus_event_ent_outkeys)
                        except cx_Oracle.DatabaseError as e:
                            raise

                        # Get BUS_EVENT_PKG_ATTR

                        ls_bus_event_attr_sql = "Select a.package_attr_id, a.package_entity_id, a.rltnl_column_id, a.attr_name, nvl(a.sql_reference_id,0), " \
                                                " a.is_natural_key_flg, a.add_to_event_notification_flg, e.package_id, e.package_entity_name" \
                                                " from " + from_db_schema + ".bus_event_pkg_attr a, " + from_db_schema + ".bus_event_pkg_entity e " \
                                                                                                                         " where a.package_entity_id = " + str(
                            bus_event_ent_result[index2][0]) + " " \
                                                               " and a.package_entity_id = e.package_entity_id "
                    else:
                        ls_bus_event_attr_sql = "Select a.package_attr_id, a.package_entity_id, a.rltnl_column_id, a.attr_name, nvl(a.sql_reference_id,0), " \
                                                " a.is_natural_key_flg, a.add_to_event_notification_flg, e.package_id, e.package_entity_name" \
                                                " from " + from_db_schema + ".bus_event_pkg_attr a, " + from_db_schema + ".bus_event_pkg_entity e " \
                                                                                                                         " where a.package_entity_id = " + str(
                            bus_event_ent_result[index2][0]) + " " \
                                                               " and a.package_entity_id = e.package_entity_id and  upper(a.attr_name) = " + column.upper()

                    # print(ls_bus_event_attr_sql)
                    cursor.execute(ls_bus_event_attr_sql)
                    bus_event_attr_result = cursor.fetchall()

                    if bus_event_attr_result is None:
                        # print("Columns are not listed for the tables associated with the package id " + pkg + " in " + from_db + " database")
                        sys.exit()

                    j = 0
                    for index3 in range(len(bus_event_attr_result)):
                        j += 1

                        # Put BUS_EVENT_PKG_ATTR

                        pkgEntityId = getPkgEntId(to_cursor, str(bus_event_attr_result[index3][8]),
                                                  bus_event_attr_result[index3][7])
                        columnId = getColumnId(to_cursor, db_schema, bus_event_attr_result[index3][3])
                        # if j == 1:deleteBusEventEntAttr(to_cursor, pkgEntityId)
                        ls_ins_bus_event_attr = "INSERT INTO " + db_schema + ".bus_event_pkg_attr (package_attr_id,package_entity_id,rltnl_column_id," \
                                                                             "attr_name,sql_reference_id," \
                                                                             "is_natural_key_flg,add_to_event_notification_flg) " \
                                                                             "VALUES (" + str(
                            getMaxPk(to_cursor, "BUS_EVENT_PKG_ATTR")) + ", " \
                                                                         "" + str(pkgEntityId) + ", " + str(
                            columnId) + ",'" + bus_event_attr_result[index3][3] + "'," \
                                                                                  "" + str(
                            bus_event_attr_result[index3][4]) + ",'" + bus_event_attr_result[index3][5] + "','" \
                                                                                                          "" + \
                                                bus_event_attr_result[index3][6] + "')"

                        # print(ls_ins_bus_event_attr)
                        try:
                            to_cursor.execute(ls_ins_bus_event_attr)
                        except cx_Oracle.DatabaseError as e:
                            raise

    to_cursor.execute('commit')
    try:
        to_cursor.close()
        cursor.close()
        connection.close()
    except cx_Oracle.DatabaseError:
        print()


def getMaxPk(cursor, tableName):
    if tableName == "BUS_EVENT_DETAIL":
        ls_sql = "SELECT nvl(max(BUSINESS_EVENT_DTL_ID), 10000) FROM " + db_schema + "." + tableName
    elif tableName == "BUS_EVENT_PKG_ENTITY":
        ls_sql = "SELECT nvl(max(PACKAGE_ENTITY_ID), 10000) FROM " + db_schema + "." + tableName
    elif tableName == "BUS_EVENT_PKG_ATTR":
        ls_sql = " SELECT nvl(Max(PACKAGE_ATTR_ID), 10000) FROM " + db_schema + "." + tableName

    # print(ls_sql)
    try:
        cursor.execute(ls_sql)
    except cx_Oracle.DatabaseError as e:
        raise
    row = cursor.fetchone()

    if row is not None:
        pkId = row[0]
    return pkId + 1


def gettableId(cursor, schema, tableName):


    ls_sql = " SELECT NVL(RLTNL_TABLE_ID,0) FROM " + schema + ".RLTNL_TABLE where upper(table_name) = upper('" + tableName[tableName.find('.') + 1:len(tableName)] + "')"



    print(ls_sql)
    try:
        cursor.execute(ls_sql)
    except cx_Oracle.DatabaseError as e:
        raise
    row = cursor.fetchone()
    if row is not None:
        tableId = row[0]
    else:
        tableId = 0
        print("Table Name not found")
    return tableId


def gettableName(cursor, schema, tableId):

    if tableId == 0:
        tableName = 'No Table Yet'
    else:

        ls_sql = " SELECT nvl(table_name, 'No table') FROM " + schema + ".RLTNL_TABLE where RLTNL_TABLE_ID = '" + str(tableId) + "'"

        print(ls_sql)
        try:
            cursor.execute(ls_sql)
        except cx_Oracle.DatabaseError as e:
            raise
        row = cursor.fetchone()
        if row is not None:
            tableName = row[0]

    return tableName


def getColumnId(cursor, schema, columnName):
    ls_sql = " SELECT RLTNL_COLUMN_ID FROM " + schema + ".RLTNL_COLUMN where upper(COLUMN_NAME) = upper('" + columnName + "')"

    # print(ls_sql)
    try:
        cursor.execute(ls_sql)
    except cx_Oracle.DatabaseError as e:
        raise
    row = cursor.fetchone()
    if row is not None:
        columnId = row[0]
    else:
        columnId = 12345
    return columnId


def deleteBusEvent(cursor, eventId):
    delBusEvent = "Delete from " + db_schema + ".BUS_EVENT WHERE BUSINESS_EVENT_ID = " + str(eventId)
    # print(delBusEvent)

    try:
        cursor.execute(delBusEvent)
    except cx_Oracle.DatabaseError as e:
        raise

    # print(delBusEvent)


def deleteBusEventDtl(cursor, eventId, tableId):
    delBusEventDtl = "Delete from " + db_schema + ".BUS_EVENT_DETAIL WHERE BUSINESS_EVENT_ID = " + str(eventId) + " AND RLNTL_TABLE_ID = " + str(
        tableId)

    print(delBusEventDtl)
    try:
        cursor.execute(delBusEventDtl)
    except cx_Oracle.DatabaseError as e:
        raise


def deleteBusEventPkg(cursor, pkgId):
    delBusEventPkg = "Delete from " + db_schema + ".BUS_EVENT_PKG WHERE PACKAGE_ID = " + str(pkgId)

    # print(delBusEventPkg)
    try:
        cursor.execute(delBusEventPkg)
    except cx_Oracle.DatabaseError as e:
        raise


def deleteBusEventEntity(cursor, pkgId):
    delBusEventEntity = "Delete from " + db_schema + ".BUS_EVENT_PKG_ENTITY WHERE PACKAGE_ID = " + str(pkgId)

    # print(delBusEventEntity)

    try:
        cursor.execute(delBusEventEntity)
    except cx_Oracle.DatabaseError as e:
        raise


def deleteBusEventPkgMap(cursor, eventId, pkgId):
    delBusEventPkgMap = "Delete from " + db_schema + ".BUS_EVENT_PKG_MAP WHERE BUS_EVENT_ID = " + str(
        eventId) + " AND PACKAGE_ID = " + str(pkgId)

    # print(delBusEventPkgMap)
    try:
        cursor.execute(delBusEventPkgMap)
    except cx_Oracle.DatabaseError as e:
        raise


def deleteBusEventEntAttr(cursor, pkgEntId):
    delBusEventEntAttr = "Delete from " + db_schema + ".BUS_EVENT_PKG_ATTR WHERE PACKAGE_ENTITY_ID = " + str(pkgEntId)

    # print(delBusEventEntAttr)
    try:
        cursor.execute(delBusEventEntAttr)
    except cx_Oracle.DatabaseError as e:
        raise


def getPkgEntId(cursor, tableName, pkgId):
    ls_sql = " SELECT PACKAGE_ENTITY_ID FROM " + db_schema + ".BUS_EVENT_PKG_ENTITY WHERE PACKAGE_ID = " + str(
        pkgId) + " " \
                 "AND PACKAGE_ENTITY_NAME = '" + tableName + "'"

    # print(ls_sql)
    try:
        cursor.execute(ls_sql)
    except cx_Oracle.DatabaseError as e:
        raise
    row = cursor.fetchone()
    if row is not None:
        pkgEntityId = row[0]
        return pkgEntityId
    else:
        # print(" Package Entity Id not available for the table " + tableName + " and Package Id " + str(pkgId))
        sys.exit()


def insertBusEventEntity(cursor, pkgId, entName, sortOrder, tableId, nextEnt, entType, sqlFilter, sqlRefId, entInKeys,
                         entOutKeys):
    insBuseventent = "Insert into " + db_schema + ".BUS_EVENT_PKG_ENTITY " \
                                                  "(PACKAGE_ENTITY_ID,PACKAGE_ID,PACKAGE_ENTITY_NAME,ENTITY_SORT_ORDER,RLNTL_TABLE_ID," \
                                                  "NEXT_ENTITY_ID,PACKAGE_ENTITY_TYPE," \
                                                  "SQL_FILTER,SQL_REFERENCE_ID,ENTITY_IN_KEYS,ENTITY_OUT_KEYS) " \
                                                  "values (" + str(
        getMaxPk(cursor, "BUS_EVENT_PKG_ENTITY")) + ", " + str(pkgId) + ", '" + entName + "', " + str(
        sortOrder) + ", " + str(tableId) + ", '" + nextEnt + "','" + entType + "', " \
                                                                               "'" + sqlFilter + "', " + str(
        sqlRefId) + ", '" + entInKeys + "', '" + entOutKeys + "')"

    # print(insBuseventent)
    try:
        cursor.execute(insBuseventent)
    except cx_Oracle.DatabaseError as e:
        raise


def insertBusEventEntAttr(cursor, pkgEntId, attrList):
    deleteBusEventEntAttr(cursor, pkgEntId)

    insBusevententattr_basic = "Insert into " + db_schema + ".BUS_EVENT_PKG_ATTR " \
                                                            "(PACKAGE_ENTITY_ID,PACKAGE_ATTR_ID,RLTNL_COLUMN_ID,ATTR_NAME,SQL_REFERENCE_ID,IS_NATURAL_KEY_FLG,ADD_TO_EVENT_NOTIFICATION_FLG) " \
                                                            "values (" + str(pkgEntId)

    ls_sql = " SELECT nvl(Max(PACKAGE_ATTR_ID), 10000) FROM " + db_schema + ".BUS_EVENT_PKG_ATTR "
    try:
        cursor.execute(ls_sql)
    except cx_Oracle.DatabaseError as e:
        raise
    row = cursor.fetchone()

    if row is not None:
        maxAttrId = row[0]

    for i in attrList:
        maxAttrId = maxAttrId + 1
        # print(str(i))
        insBusevententattr = insBusevententattr_basic + ", " + str(maxAttrId) + ", " + str(
            getColumnId(cursor, str(i[0]))) + ", " + str(i).replace('(', '')  # .replace('[', '')
        # print(insBusevententattr)
        try:
            cursor.execute(insBusevententattr)
        except cx_Oracle.DatabaseError as e:
            raise


if operation == "Copy":
    read_file()
    copy_r360_metadata()
elif operation == "Add":
    add_r360_metadata()
