import boto3
import oracledb
import getopt
import json
import os
import sys
from botocore.config import Config
from main.com.idf.tools.RSMUtil import getpassword

try:
    opts, args = getopt.getopt(sys.argv[1:], 'l:f:d:s:',
                               ['conf_file_location=', 'conf_file_name=', 'database=', 'schema='])
except getopt.GetoptError:
    usage()
    raise Exception('non-dashed options "%s" not recognized' % args)
    sys.exit(2)

for opt, arg in opts:
    if opt in ('-l', '--conf_file_location'):
        conf_file_location = arg
    elif opt in ('-f', '--conf_file_name'):
        conf_file_name = arg
    elif opt in ('-d', '--database'):
        database = arg
    elif opt in ('-s', '--schema'):
        schema = arg
    else:
        usage()
        sys.exit(2)

print('conf_file_location  :', conf_file_location)
print('conf_file_name      :', conf_file_name)
print('database            :', database)
print('schema              :', schema)


def GetAWS_Config():
    global ctl_db_usrname
    global ctl_db_pswd
    global ctl_db_schema
    # global softlink_usrname
    # global softlink_pswd
    global db_url
    global processed_location
    global aws_region
    aws_region = os.getenv("aws_region")

    boto3.client('ssm')
    session = boto3.Session(region_name=aws_region)
    ssm = session.client("ssm")
    location = ssm.get_parameter(Name=conf_file_location, WithDecryption=True)
    global_filename = ssm.get_parameter(Name=conf_file_name, WithDecryption=True)
    client = boto3.client('s3')
    bucket_value = location['Parameter']['Value']
    gfilename_value = global_filename['Parameter']['Value']
    BUCKET = bucket_value.split("/")[0]
    KEY = bucket_value.split("/")[1] + '/' + bucket_value.split("/")[2] + '/' + gfilename_value
    result = client.get_object(Bucket=BUCKET, Key=KEY)
    text = result["Body"].read().decode()
    read_json = json.loads(text)
    ctl_db_usrname = read_json["control_table_conf"]["control_table_db_username"]
    secrect_pwd = read_json["control_table_conf"]["control_table_db_pwd"]
    ctl_db_pswd = getpassword(secrect_pwd[6:-1])
    ctl_db_schema = read_json["control_table_conf"]["control_table_schema_owner"]
    # softlink_usrname = read_json["db_conf"]["db_instance"]["idf_query"]["rdbms_user_name"]
    # softlink_pswd = read_json["db_conf"]["db_instance"]["idf_query"]["rdbms_user_password"]
    db_url = read_json["control_table_conf"]["control_table_db_url"].split("//")[1]
    processed_location = read_json["s3_conf"]["s3_processed_location"]


def Package_Creation():
    try:
        # connstr = 'IDF_METADATA_USER/IDF_METADATA_USER_2018@spdrac-scan.dev.spratingsvpc.com/metadev.world'
        # connstr = 'IDF_METADATA_USER/idf_metadata_user_2018@fgracebs1-scan.qa.spratingsvpc.com:1521/metaqa.world'
        connstr = ctl_db_usrname + "/" + ctl_db_pswd + '@' + db_url
        connection = cx_Oracle.connect(connstr)

    except cx_Oracle.DatabaseError as e:
        raise
    cursor = connection.cursor()

    tables_list = "SELECT RD.DB_INSTANCE_ID, RS.SCHEMA_NAME, RT.TABLE_NAME, to_char(ROWNUM),RT.PACKAGE_FILTER_SQL_TEXT " \
                  "FROM " + ctl_db_schema + ".RLTNL_TABLE RT," + ctl_db_schema + ".RLTNL_SCHEMA RS, " + ctl_db_schema + ".RLTNL_DATABASE_PARAM  RD" \
                  " WHERE rd.rltnl_database_id=rs.rltnl_database_id AND RS.RLTNL_SCHEMA_ID=RT.RLTNL_SCHEMA_ID AND RS.SCHEMA_NAME=upper('" + schema + "') " \
                  "AND RT.RDBMS_PACKAGE_FLAG='Y' AND rd.db_instance_id like upper('" + database + "%') ORDER BY RS.SCHEMA_NAME, RT.TABLE_NAME"

    # print(tables_list)
    cursor.execute(tables_list)
    tables_check = cursor.fetchone()

    if tables_check is None:
        print(
            "There are no tables to process for the mentioned Database " + database + " and the schema " + schema + "!!!")
        sys.exit()
    else:
        PackageDir = "/home/idf/flashback/packages/"
        PackageFilename = "cre_pkg_" + database.lower() + "_" + schema.lower() + "_fb_query.sql"
        # PkgDriveScript = database.lower() + "idf_pkgs.sql"
        if not os.path.exists(PackageDir):
            os.mkdir(PackageDir)
            print("Packages folder Created")
        else:
            print('Packages folder already exists')

        if os.path.exists(PackageDir + PackageFilename):
            os.remove(PackageDir + PackageFilename)
            print("Flashback package file is Removed!")
        else:
            print('Flashback package file does not exists')

        cursor.execute(tables_list)
        tables_loop = cursor.fetchall()

        if not os.path.exists(PackageDir + PackageFilename):
            Packagefile = open(PackageDir + PackageFilename, "w")

            print(PackageDir + PackageFilename)

            Packagefile.write(
                "CREATE OR REPLACE PACKAGE " + schema.lower() + ".pkg_" + schema.lower() + "_fb_query AS \n")
            for PkgSpec in range(len(tables_loop)):
                vTableName = tables_loop[PkgSpec][2].lower()
                if len(vTableName) > 24:
                    TableName = vTableName[0:24] + tables_loop[PkgSpec][3]
                    # print("SPEC--->" + TableName)
                else:
                    TableName = vTableName

                SchemaName = tables_loop[PkgSpec][1].lower()
                Packagefile.write(
                    "  TYPE " + TableName + "_t IS TABLE OF " + SchemaName + "." + vTableName + "%ROWTYPE; \n")
                Packagefile.write(
                    "  FUNCTION " + vTableName + "(p_timestamp TIMESTAMP) RETURN " + TableName + "_t PIPELINED; \n\n")
            Packagefile.write("END; \n/\n\n")

            Packagefile.write(
                "CREATE OR REPLACE PACKAGE BODY " + schema.lower() + ".pkg_" + schema.lower() + "_fb_query AS \n")
            for PkgBody in range(len(tables_loop)):
                vTableName = tables_loop[PkgBody][2].lower()
                if len(vTableName) > 24:
                    TableName = vTableName[0:24] + tables_loop[PkgBody][3]
                    # print("BODY--->" + TableName)
                else:
                    TableName = vTableName
                
                sql_text = "" if (tables_loop[PkgBody][4] is None) else tables_loop[PkgBody][4]
                SchemaName = tables_loop[PkgBody][1].lower()
                Packagefile.write(
                    "\n  FUNCTION " + vTableName + "(p_timestamp TIMESTAMP) RETURN " + TableName + "_t PIPELINED IS \n")
                Packagefile.write("    out_rec " + SchemaName + "." + vTableName + "%ROWTYPE; \n")
                Packagefile.write("    CURSOR cur_get_data_as_of (c_timestamp TIMESTAMP) IS \n")
                Packagefile.write("    SELECT * FROM " + vTableName + " AS OF TIMESTAMP c_timestamp "+ sql_text.replace('"',"'") +"; \n")
                Packagefile.write("  BEGIN \n")
                Packagefile.write("    FOR out_rec IN cur_get_data_as_of(p_timestamp) LOOP \n")
                Packagefile.write("      PIPE ROW(out_rec); \n    END LOOP; \n     RETURN;  \n")
                Packagefile.write("  END " + vTableName + "; \n\n")

            Packagefile.write(
                "END; \n / \n \nGRANT execute ON " + SchemaName + ".pkg_" + SchemaName + "_fb_query TO idf_sqoop_user; \n\n")
            # Packagefile.write("REVOKE IDF_FLASHBACK_ROLE FROM IDF_SQOOP_USER; \n\n")
            # Packagefile.write("EXIT; \n")
            Packagefile.close()


GetAWS_Config()
Package_Creation()
