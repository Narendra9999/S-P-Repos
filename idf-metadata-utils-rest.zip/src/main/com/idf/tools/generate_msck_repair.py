import argparse as argparse
import cx_Oracle
import os, sys
import json
import boto3
import argparse
from botocore.config import Config
from main.com.idf.tools.RSMUtil import getpassword


# Create the parser
my_parser = argparse.ArgumentParser(description='Pass the execution arguments')

# Add the arguments
my_parser.add_argument('confilg_file_loc',metavar='confilg_file_loc',type=str,help='the config file location')
my_parser.add_argument('confilg_file_name',metavar='confilg_file_name',type=str,help='the config file Name')
my_parser.add_argument('param_key',metavar='param_key',nargs='?',type=str,help='param_key')
my_parser.add_argument('param_value',metavar='param_value',nargs='?',type=str,help='param_value')
my_parser.add_argument('param_name',metavar='param_name',nargs='?',type=str,help='param_name')


# Execute the parse_args() method
args = my_parser.parse_args()

if len(sys.argv) > 6:
    print('Please check parameters passed and process again!!!')
    sys.exit()

confilg_file_loc = args.confilg_file_loc
confilg_file_name = args.confilg_file_name

# Parameters that can be used
# Null -> with NO parameter, system generates catalog for all the DBs and all the schemas. The sql will be named after DBs
# DB COREDEV --> Single Id only
# SCHEMA ('CORE', 'GS_GC') --> Can be one or multiple but should be in this format
# TABLE ('RATINGS', 'ISS_DIM') --> Can be one or multiple but should be in this format
# TABLE_ID (231212,343434) --> Can be one or multiple but should be in this format

if len(sys.argv) == 5:
    param_key = args.param_key
    param_value = args.param_value
elif len(sys.argv) == 6:
    param_key = args.param_key
    param_value = args.param_value
    if sys.argv[5]:
        param_name = args.param_name
else:
    param_key = 'DEFAULT'
    param_value = 'ALL'

if param_key == 'TABLE_ID' and len(sys.argv) < 5:
    print('Please provide file name and process again!!!')
    sys.exit()


def GetAWS_Config():
    global db_schema
    global db_usrname
    global db_pswd
    global db_url
    global processed_location
    global aws_region
    aws_region = os.getenv("aws_region")

    boto3.client('ssm')
    session = boto3.Session(region_name=aws_region)
    ssm = session.client("ssm")
    location = ssm.get_parameter(Name=confilg_file_loc, WithDecryption=True)
    global_filename = ssm.get_parameter(Name=confilg_file_name, WithDecryption=True)
    client = boto3.client('s3')
    bucket_value = location['Parameter']['Value']
    gfilename_value = global_filename['Parameter']['Value']
    BUCKET = bucket_value.split("/")[0]
    KEY = bucket_value.split("/")[1] + '/' + bucket_value.split("/")[2] + '/' + gfilename_value
    result = client.get_object(Bucket=BUCKET, Key=KEY)
    text = result["Body"].read().decode()
    read_json = json.loads(text)
    db_usrname = read_json["control_table_conf"]["control_table_db_username"]
    secrect_pwd = read_json["control_table_conf"]["control_table_db_pwd"]
    db_pswd = getpassword(secrect_pwd[6:-1])
    db_url = read_json["control_table_conf"]["control_table_db_url"].split("//")[1]
    processed_location = read_json["s3_conf"]["s3_processed_location"]
    db_schema = read_json["control_table_conf"]["control_table_schema_owner"]


# Connect to database
def Data_Catalog():
    try:
        # connstr = 'IDF_METADATA_USER/IDF_METADATA_USER_2018@spdrac-scan.dev.spratingsvpc.com/metadev.world'
        # connstr = 'IDF_METADATA_USER/idf_metadata_user_2018@fgracebs1-scan.qa.spratingsvpc.com:1521/metaqa.world'
        # processed_location = 's3://spr-idf-dev-processed/'
        connstr = db_usrname + "/" + db_pswd + '@' + db_url
        connection = cx_Oracle.connect(connstr)




    except cx_Oracle.DatabaseError as e:
        raise
    cursor = connection.cursor()

    col_lists = []
    clust_col_lists = []
    part_col_lists = []
    view_col_lists = []
    pk_col_lists = []
    pk_col_in_where_lists = []
    incr_cols = []
    pk_part_by_cols = []
    view_col_a_lists = []
    part_col_lists_the_end = []
    clustered_cols = []

    if len(sys.argv) == 3:
        ls_main = "Select DB_INSTANCE_ID from " + db_schema + ".RLTNL_DATABASE_PARAM d"
    else:
        if param_key == 'DB':
            ls_main = "Select DB_INSTANCE_ID from " + db_schema + ".RLTNL_DATABASE_PARAM d " \
                                                                  "WHERE DB_INSTANCE_ID = '" + str(param_value) + "'"
        elif param_key == 'SCHEMA':
            ls_main = "Select DISTINCT DB_INSTANCE_ID from " + db_schema + ".RLTNL_DATABASE_PARAM d, " + db_schema + ".RLTNL_SCHEMA  s " \
                                                                                                                     "WHERE S.RLTNL_DATABASE_ID = D.RLTNL_DATABASE_ID and S.SCHEMA_NAME IN " + str(
                param_value) + ""
        elif param_key == 'TABLE':
            ls_main = "Select DISTINCT DB_INSTANCE_ID from " + db_schema + ".RLTNL_DATABASE_PARAM d, " + db_schema + ".RLTNL_SCHEMA  s, " + db_schema + ".RLTNL_TABLE  t " \
                                                                                                                                                        "WHERE S.RLTNL_DATABASE_ID = D.RLTNL_DATABASE_ID AND S.RLTNL_SCHEMA_ID = T.RLTNL_SCHEMA_ID AND T.TABLE_NAME IN " + str(
                param_value) + ""
        elif param_key == 'TABLE_ID':
            ls_main = "Select DISTINCT DB_INSTANCE_ID from " + db_schema + ".RLTNL_DATABASE_PARAM d, " + db_schema + ".RLTNL_SCHEMA  s, " + db_schema + ".RLTNL_TABLE  t " \
                                                                                                                                                        "WHERE S.RLTNL_DATABASE_ID = D.RLTNL_DATABASE_ID AND S.RLTNL_SCHEMA_ID = T.RLTNL_SCHEMA_ID AND T.RLTNL_TABLE_ID IN " + param_value + ""

    # print(param_key)
    # print(param_value)
    # print(ls_main)
    cursor.execute(ls_main)
    main_check = cursor.fetchone()

    if main_check is None:
        print("Please check the parameter values and process again!!!")
        sys.exit()

    cursor.execute(ls_main)
    main_loop = cursor.fetchall()

    for ind in range(len(main_loop)):
        ls_rtnl_db = "Select distinct d.RLTNL_DATABASE_ID, D.DB_INSTANCE_ID " \
                     "from " + db_schema + ".RLTNL_DATABASE_PARAM d where d.DB_INSTANCE_ID = " + "'" + str(
            main_loop[ind][0]) + "'"

        cursor.execute(ls_rtnl_db)
        RLTNL_DATABASE_PARAM_result = cursor.fetchall()

        if param_key == 'DB' or param_key == 'DEFAULT':
            f = open(str(main_loop[ind][0]) + "_MSCK.sql", "w")  # +a

        # print(ls_rtnl_db)

        for index in range(len(RLTNL_DATABASE_PARAM_result)):
            ls_rtnl_sch = "Select distinct R.RLTNL_SCHEMA_ID, R.SCHEMA_NAME,  R.REPLICATION_TYPE, R.SCHEMA_CLASSIFICATION, D.DB_INSTANCE_ID, a.DATABASE_NAME " \
                          "from " + db_schema + ".RLTNL_SCHEMA r," + db_schema + ".RLTNL_ABSTRCTN_COL_MAP ra," \
                                                                                 "" + db_schema + ".RLTNL_TABLE t, " + db_schema + ".RLTNL_DATABASE_PARAM d, " \
                                                                                                                                   "" + db_schema + ".ABSTRCTN_TABLE a where r.RLTNL_DATABASE_ID = " + str(
                RLTNL_DATABASE_PARAM_result[index][0]) + " " \
                                                         "AND RA.RLTNL_TABLE_ID = T.RLTNL_TABLE_ID  AND D.RLTNL_DATABASE_ID = r.RLTNL_DATABASE_ID " \
                                                         "and T.RLTNL_SCHEMA_ID = R.RLTNL_SCHEMA_ID " \
                                                         "and A.ABSTRCTN_TABLE_ID = RA.ABSTRCTN_TABLE_ID "

            if param_key == 'SCHEMA':
                ls_rtnl_sch = ls_rtnl_sch + "and R.SCHEMA_NAME in " + str(param_value)
            elif param_key == 'TABLE':
                ls_rtnl_sch = ls_rtnl_sch + "and T.TABLE_NAME IN " + str(param_value)

            cursor.execute(ls_rtnl_sch)
            RLTNL_SCHEMA_result = cursor.fetchall()

            if param_key == 'SCHEMA':
                f = open(str(RLTNL_SCHEMA_result[index][1]) + "_MSCK.sql", "a")  # +a

            # print(ls_rtnl_sch)

            for index1 in range(len(RLTNL_SCHEMA_result)):
                ls_rtnl_tbl = "Select distinct R.RLTNL_TABLE_ID, R.TABLE_NAME,  " \
                              "D.DATA_FOLDER, D.PARENT_FOLDER, R.REPLICATION_TYPE, d.FILE_TYPE " \
                              "from " + db_schema + ".RLTNL_TABLE r, " + db_schema + ".DATA_FILE_PARAM d, " \
                                                                                     "" + db_schema + ".RLTNL_DATA_FILE_COL_MAP rdf " \
                                                                                                      "where   R.RLTNL_SCHEMA_ID = " + str(
                    RLTNL_SCHEMA_result[index1][0]) + "  " \
                                                      "and R.RLTNL_TABLE_ID = RDF.RLTNL_TABLE_ID and D.DATA_FILE_ID = RDF.DATA_FILE_ID  "
                #  "order by R.RLTNL_TABLE_ID "

                # if param_key != 'TABLE' and param_key != 'TABLE_ID':
                #     ls_spark_db_sql = "CREATE DATABASE IF NOT EXISTS " + str(RLTNL_SCHEMA_result[index1][5]) + " " \
                #                                                                                                " COMMENT 'To store RDBMS DB/Schema: " + str(
                #         RLTNL_SCHEMA_result[index1][4]) + "/" + str(RLTNL_SCHEMA_result[index1][1]) + \
                #                       "' LOCATION '" + processed_location + "warehouse/" + str(
                #         RLTNL_SCHEMA_result[index1][5]) + ".db';"
                #     f.write(ls_spark_db_sql + '\n')

                if param_key == 'TABLE':
                    ls_rtnl_tbl = ls_rtnl_tbl + "and R.TABLE_NAME IN " + str(param_value)
                if param_key == 'TABLE_ID':
                    ls_rtnl_tbl = ls_rtnl_tbl + "and R.RLTNL_TABLE_ID IN " + param_value

                cursor.execute(ls_rtnl_tbl)
                RLTNL_TABLE_result = cursor.fetchall()

                if param_key == 'TABLE_ID':
                    f = open(str(param_name) + "_MSCK.sql", "a")  # +a

                if param_key == 'TABLE':
                    f = open(str(RLTNL_TABLE_result[index1][1]) + "_MSCK.sql", "W")  # +a

                for index2 in range(len(RLTNL_TABLE_result)):

                    dbname = str(RLTNL_SCHEMA_result[index1][5])
                    tbl_name = "t_" + str(RLTNL_TABLE_result[index2][2]) + "_base"
                    tbl_name_incr = "t_" + str(RLTNL_TABLE_result[index2][2]) + "_incr"

                    ls_repair_table_base = "Msck repair table " + dbname + "." + tbl_name + ";"#Added by Kiran on 02/20/2019
                    ls_repair_table_incr = "Msck repair table " + dbname + "." + tbl_name_incr + ";"

                    if str(RLTNL_TABLE_result[index2][4]) == 'FULL':
                        f.write(ls_repair_table_base + '\n')
                    else:
                        f.write(ls_repair_table_base + '\n')
                        f.write(ls_repair_table_incr + '\n')

                    # f.write(ls_repair_table + '\n') ##To be UnCommented for repairing the table

                    # clear all

                    part_col_lists.clear()
                    clust_col_lists.clear()
                    col_lists.clear()
                    view_col_lists.clear()
                    view_col_a_lists.clear()
                    pk_col_lists.clear()
                    pk_col_in_where_lists.clear()
                    incr_cols.clear()
                    pk_part_by_cols.clear()
                    part_col_lists_the_end.clear()
                    clust_col_lists.clear()
                    clustered_cols.clear()


GetAWS_Config()  # Get global config params
Data_Catalog()  # Run Data Catlog
