import logging
import json
import os
import pandas as pd
from main.com.idf.tools.RSMUtil import getpassword
from main.com.idf.tools.relationalConifg import DatabaseConfig
from main.com.idf.utils.VolumeManagement import read_data_from_volume
from main.com.idf.utils.metadata_constants import *
from main.com.idf.utils.metadata_json_generation import generate_upload_json
from main.com.idf.utils.DBUtil import get_metadata_db_connection
from main.com.idf.utils.AWSUtil import read_s3_file
import multiprocessing
import pprint

# "SCHEMA" "CORE"
# "WHERE" "t.TABLE_NAME in (' ')"  --> This will result in a json by table-level.json
# "WHEREC" "t.TABLE_NAME in (' ')" "{Customized Json name}"
# Blank --> default to all distinct batches (Done)


logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
def get_control_table_config(config_file:str):
    if config_file.startswith("/Volumes"):
        global_json = read_data_from_volume(config_file)
    elif config_file.startswith("s3://") or config_file.startswith("spr-idf"):
        global_json = read_s3_file(config_file)
    else:
        raise ValueError(f"Invalid Config File Path provided {config_file}")
    #global_json = read_data_from_volume(config_file)
    read_json = json.loads(global_json)
    db_usrname = read_json["control_table_conf"]["control_table_db_username"]
    secrect_pwd = read_json["control_table_conf"]["control_table_db_pwd"]
    db_pswd = getpassword(secrect_pwd[6:-1])
    db_url = read_json["control_table_conf"]["control_table_db_url"].split("//")[1]
    db_env = read_json["control_table_conf"]["control_table_db_url"].split("/")[3]
    db_schema = read_json["control_table_conf"]["control_table_schema_owner"]
    aws_region = os.getenv("aws_env")
    database_config = DatabaseConfig(db_schema, db_usrname, db_pswd, db_url, db_env, aws_region)
    return database_config


def enrich_metadata_dataframe(metadata_dataframe:pd.DataFrame)->pd.DataFrame:
    metadata_dataframe['CDC_FLAG'] = metadata_dataframe['CDC_FLAG'].fillna(
        'N').astype(str)
    metadata_dataframe['RDBMS_PACKAGE_FLAG'] = metadata_dataframe['RDBMS_PACKAGE_FLAG'].fillna(
        'N').astype(str)
    metadata_dataframe['SCHEMA_PACKAGE_NAME'] = metadata_dataframe['SCHEMA_PACKAGE_NAME'].fillna(
        'N').astype(str)

    # ABSTRACTION_DATA_PRECISION & ABSTRACTION_DATA_SCALE
    metadata_dataframe['ABSTRACTION_DATA_PRECISION'] = metadata_dataframe['ABSTRACTION_DATA_PRECISION'].apply(
        lambda x: str(int(x)) if pd.notna(x) else 'None')
    metadata_dataframe['ABSTRACTION_DATA_SCALE'] = metadata_dataframe['ABSTRACTION_DATA_SCALE'].apply(
        lambda x: str(int(x)) if pd.notna(x) else 'None')
    metadata_dataframe['ABSTRACTION_BUCKET_COUNT'] = metadata_dataframe['ABSTRACTION_BUCKET_COUNT'].fillna(0).astype(int)
    metadata_dataframe['ABSTRACTION_BUCKET_SORT_ORDER'] = metadata_dataframe['ABSTRACTION_BUCKET_SORT_ORDER'].fillna('None').astype(
        str)
    rdbms_check_columns = ["STRING" , "TIMESTAMP" , "DATE"]
    #metadata_dataframe.loc[metadata_dataframe['ABSTRACTION_COLUMN_DATATYPE'].isin(rdbms_check_columns), 'RDBMS_DATA_PRECISION'] = 'None'
    metadata_dataframe['ABSTRACTION_DATA_LENGTH'] = metadata_dataframe['ABSTRACTION_DATA_LENGTH'].apply(lambda x: str(int(x)) if pd.notna(x) else 'None')
    metadata_dataframe['RDBMS_SQL_TEXT'] = metadata_dataframe['RDBMS_SQL_TEXT'].fillna('').astype(str)
    # If RDBMS_DATA_SCALE,RDBMS_DATA_LENGTH & RDBMS_DATA_PRECISION  is not a number, then convert it to string else put None
    metadata_dataframe['RDBMS_DATA_PRECISION'] = metadata_dataframe['RDBMS_DATA_PRECISION'].apply(lambda x: str(int(x)) if pd.notna(x) else 'None')
    metadata_dataframe['RDBMS_DATA_SCALE'] = metadata_dataframe['RDBMS_DATA_SCALE'].apply(lambda x: str(int(x)) if pd.notna(x) else 'None')
    metadata_dataframe['RDBMS_DATA_LENGTH'] = metadata_dataframe['RDBMS_DATA_LENGTH'].apply(lambda x: str(int(x)) if pd.notna(x) else 'None')
    return metadata_dataframe



def create_json(volume_name:str , config_file:str ,level:str, level_value:str
                ,customized_json_name:str ):
    control_table_config = get_control_table_config(config_file)
    db_schema = control_table_config.db_schema
    db_username = control_table_config.db_usrname
    db_auth = control_table_config.db_pswd
    db_url = control_table_config.db_url
    db_env = control_table_config.db_env
    env = control_table_config.aws_region
    try:
        metadata_connection = get_metadata_db_connection(db_username, db_auth, db_url)
    except Exception as e:
        logging.error(f"Error in creating connection to metadata database {e}")
        raise ValueError(f"Error in creating connection to metadata database {e}")
    partition_dataframe = pd.read_sql(partition_sql_query,metadata_connection).fillna('')
    if level is not None and (level.upper() == 'TABLE_ID' or level.upper() == "TABLE_NAME" or level.upper() == "SCHEMA"):
        metadata_dataframe = pd.read_sql(metadata_sql_query_table_level,metadata_connection)
    else:
        metadata_dataframe = pd.read_sql(metadata_sql_query, metadata_connection)

    ##metadata_dataframe = pd.read_sql(metadata_sql_query,metadata_connection)
    enrich_metadata_dataframe(metadata_dataframe)
    logging.info("partition_dataframe ===>" + str(len(partition_dataframe)))
    logging.info("metadata_dataframe ===>" + str(len(metadata_dataframe)))


    if level is None and level_value is None and customized_json_name is None:
        logging.info("Processing for all distinct batches")
        distinct_batches = metadata_dataframe['BATCH_NAME'].unique()
        for batch in distinct_batches:
            logging.info("Processing for Batch Level" + batch)
            unique_batch = metadata_dataframe[metadata_dataframe['BATCH_NAME'] == batch]
            generate_upload_json(unique_batch,partition_dataframe,volume_name,batch)
    elif level.upper() == 'SCHEMA':
        if level_value is None:
            raise ValueError("Schema Name is required for SCHEMA condition")
        else:
            schema_name = level_value.upper()
            logging.info(f"Metadata JSON Processing for Schema Level {schema_name}")
            schema_level_dataframe = metadata_dataframe[metadata_dataframe['ABSTRACT_SCHEMA_NAME'] == schema_name]
            logging.info("schema_level_dataframe ===>" + str(len(schema_level_dataframe)))
            json_name = build_json_name(env,schema_name.lower())
            logging.info("Processing for Schema Level ===>" + json_name)
            generate_upload_json(schema_level_dataframe, partition_dataframe, volume_name,json_name,"FULL")

    elif level.upper() == 'TABLE_ID' or level.upper() == "TABLE_NAME":
        if customized_json_name is None:
            raise ValueError("Customized Json Name is required for WHERE condition")
        else:
            logging.info("Metadata JSON Processing for Table Level")
            if level.upper() == "TABLE_NAME" :
                table_list = level_value.split(",")
                where_condition_column = "RDBMS_TABLE_NAME"
                tabel_level_dataframe = metadata_dataframe[metadata_dataframe[where_condition_column].isin(table_list)]
                logging.info("tabel_level_dataframe ===>" + str(len(tabel_level_dataframe)))
                generate_upload_json(tabel_level_dataframe, partition_dataframe, volume_name,customized_json_name,"FULL" )
                logging.info("Processed  table level JSON for input TABLE_NAMES ")
            elif level.upper() == "TABLE_ID" :
                table_list = list(map(int, level_value.split(',')))
                where_condition_column = "RDBMS_TABLE_ID"
                logging.info(f"table_list ===>{table_list}")
                tabel_level_dataframe = metadata_dataframe[metadata_dataframe[where_condition_column].isin(table_list)]
                logging.info("tabel_level_dataframe for IDs ===>" + str(len(tabel_level_dataframe)))
                logging.info(f"Processing the tables ===> {tabel_level_dataframe[where_condition_column].unique().tolist()}")
                logging.info("customized_json_name ===>" + customized_json_name)
                generate_upload_json(tabel_level_dataframe, partition_dataframe, volume_name, customized_json_name,"FULL")
                logging.info("Processed  table level JSON for input TABLE_IDS ")
    elif level.upper() == 'BATCH':
        if level_value is None:
            raise ValueError("Batch Name is required for BATCH condition")
        else:
            batch_name = level_value
            batch_level_dataframe = metadata_dataframe[metadata_dataframe['BATCH_NAME'] == batch_name]
            logging.info("Processing for JSON for given Batch Level")
            generate_upload_json(batch_level_dataframe, partition_dataframe, volume_name, batch_name)
            logging.info(f"Processed  batch level JSON for input BATCH_NAME {batch_name}")

    else:
        logging.error("Unable to produce the required data. Please check the parameters and try again!!!")
        raise ValueError("Unable to produce the required data. Please check the parameters and try again!!!")

def build_json_name(env:str,schema_name:str)->str:
    if env.lower() == 'dev':
        return 'd_ds_idfdb_' + schema_name + '_fullweek'
    elif env.lower() == 'qa':
        return 'q_ds_idfdb_' + schema_name + '_fullweek'
    elif env.lower() == 'si':
        return 's_ds_idfdb_' + schema_name + '_fullweek'
    elif env.lower() == 'uat':
        return 'u_ds_idfdb_' + schema_name + '_fullweek'
    elif env.lower() == 'prod':
        return 'p_ds_idfdb_' + schema_name + '_fullweek'
    elif env.lower() == 'dr':
        return 'p_ds_idfdb_' + schema_name + '_fullweek'


def generate_metadata(args):
    """
    This method is starter method for the metadata json generation
    :param args: Input Arguments
    :return: None
    Expected Input Arguments:
    -volume_name : Example: /Volumes/idf_dev/idfdb_metadata/metadata_volume/(Where the json needs to be stored)
    -config_file : Example: /Volumes/idf_dev/idfdb_metadata/config_volume/metadata_config.json(where the config file is stored)
    -level : Example: SCHEMA, WHERE, WHEREC, BATCH , and BLANK
    -level_value   Example: SCHEMA_NAME, t.TABLE_NAME IN (' '), t.RLTNL_TABLE_ID IN (' '), BATCH_NAME
    -customized_json_name : Example: table-level.json (This is mandatory for WHERE and WHEREC)
    """
    volume_name = args.volume_name
    config_file = args.config_file
    level = args.level
    level_value = args.level_value
    customized_json_name = args.customized_json_name
    create_json(volume_name,config_file,level,level_value,customized_json_name)

