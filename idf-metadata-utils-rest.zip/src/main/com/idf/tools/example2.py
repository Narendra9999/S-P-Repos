import os
import oracledb
import sys
oracledb.version = "8.3.0"
sys.modules["cx_Oracle"] = oracledb
import pandas as pd
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker

from load_metadata_sqls import (relational_db_merge, abs_table_merge,
                                relational_table_merge, relational_schema_merge, relational_column_merge)


def get_sheet_names(input_file:str)->list:
    df = pd.read_excel(input_file,sheet_name=None)
    return list(df.keys())

def get_schema_mapping(input_file:str,env:str)->dict:
    schema_mappings = pd.read_excel(input_file,sheet_name='SCHEMA MAPPINGS')
    schema_mappings.rename(columns={'Unnamed: 0': 'DB_DETAILS'}, inplace=True)
    schema_mappings = schema_mappings[['DB_DETAILS',env]]
    db_details = {}
    for idx,row in schema_mappings.iterrows():
        if row['DB_DETAILS'] == 'DB_INSTANCE':
            db_details['DB_INSTANCE'] = row[env]
        if row['DB_DETAILS'] == 'DB_SERVICE':
            db_details['DB_SERVICE'] = row[env]
        elif row['DB_DETAILS'] == 'DB_HOST':
            db_details['DB_HOST'] = row[env]
        elif row['DB_DETAILS'] == 'DB_PORT':
            db_details['DB_PORT'] = row[env]
        elif row['DB_DETAILS'] == 'RDBMS_SCHEMA':
            db_details['RDBMS_SCHEMA'] = row[env]
        elif row['DB_DETAILS'] == 'SCHEMA CLASSIFICATION':
            db_details['SCHEMA_CLASSIFICATION'] = row[env]
        elif row['DB_DETAILS'] == 'ABSTRACTION SCHEMA NAME':
            db_details['ABSTRACTION_SCHEMA_NAME'] = row[env]
        elif row['DB_DETAILS'] == 'SCHEMA PACKAGE NAME':
            db_details['SCHEMA_PACKAGE_NAME'] = row[env]
    return db_details

def get_table_mappings(input_file:str)->pd.DataFrame:
    table_mappings = pd.read_excel(input_file,sheet_name='TABLE MAPPINGS', header=1)
    table_mappings.rename(columns={'RDBMS_TABLE_NAME':'TABLE_NAME','RDBMS_TABLE_REPL_TYPE':'REPLICATION_TYPE',
                                   'TABLE SIZE CLASSIFICATION***':'TABLE_SIZE_CLASSIFICATION',
                                   'RDBMS_TABLE_SQL_TEXT':'SQL_TEXT','VIEW_FILTER_SQL_TEXT':'VIEW_FILTER_SQL_TEXT',
                                   'PACKAGE_FILTER_SQL_TEXT':'PACKAGE_FILTER_SQL_TEXT','RDBMS_PACKAGE_FLAG':'RDBMS_PACKAGE_FLAG',
                                   'RDBMS_CDC_FLAG':'CDC_FLAG','BATCH TYPE':'REPLICATION_SCHD_TYPE'},inplace=True)
    table_mappings.drop([ 'AUTOSYS JOB ID/NAME', 'HOURS:MINUTES (HH24:MI)','Day of Week','ABSTRACTION TABLE NAME'], axis=1, inplace=True)
    return table_mappings

def get_column_mappings(input_file:str):
    column_mappings = pd.read_excel(input_file, sheet_name='COLUMN MAPPINGS', header=1)
    column_mappings.rename(columns={'RDBMS_TABLE_COLUMNS': 'COLUMN_NAME', 'RDBMS_COLUMN_DATATYPE': 'COLUMN_DATATYPE'
                                    ,'RDBMS_COLUMN_DATA_LENGTH':'DATA_LENGTH','RDBMS_COLUMN_DATA_PRECISION':'DATA_PRECISION'
                                    ,'RDBMS_COLUMN_DATA_SCALE':'DATA_SCALE',
                                    'IS INCREMENTAL LOAD IDENTIFIER?':'IS_INCR_LOAD_IDENTIFIER',
                                    'IS NULLABLE?':'IS_NULLABLE','IS PRIMARY KEY?':'IS_PRIMARY_KEY',
                                    'ABSTRACTION_COLUMN_SEQUENCE':'COLUMN_ORDR_NBR'}
                           ,inplace=True)
    column_mappings.drop(['RDBMS_TABLE_NAME','ABSTRACTION_COLUMNS'
                          ,'ABSTRACTION_DATA_TYPE', 'ABSTRACTION_COLUMN_DATA_LENGTH',
                          'ABSTRACTION_COLUMN_DATA_PRECISION', 'ABSTRACTION_COLUMN_DATA_SCALE',
                          'IS_PARTITION_KEY ?','IS_SUB_PARTITION_KEY ?', 'IS BUCKET KEY?', 'BUCKET_COUNTS?',
                          'BUCKET_SORT_ORDER', 'IS_DERIVED_PARTITION_REQUIRED?'], axis = 1, inplace=True)
    return column_mappings

def get_abs_database_mappings(file_name:str,env:str):
    db_details = get_schema_mapping(file_name, env)
    table_mappings = get_table_mappings(file_name)
    table_mappings['DATABASE_NAME'] = db_details['ABSTRACTION_SCHEMA_NAME']
    table_mappings['ABSTRCTN_TABLE_TYPE'] = 'DELTA'
    table_mappings['ABSTRCTN_FILE_TYPE'] = 'PARQUET'
    table_mappings.rename(columns={'RDBMS_TABLE_NAME':'TABLE_NAME'},inplace=True)
    return table_mappings[['DATABASE_NAME','TABLE_NAME','ABSTRCTN_TABLE_TYPE','ABSTRCTN_FILE_TYPE']]

def get_partition_column_mappings(file_name:str):
    partition_column_mappings = pd.read_excel(file_name, sheet_name='PARTITION COLUMNS', header=1)
    partition_column_mappings= partition_column_mappings[['RDBMS_TABLE_NAME','PARTITION_ORDER',	'PARTITION_NAME','IS_PARTITION_DERIVED','SOURCE_COLUMN_FORMAT','PARTITION_EXPRESSION']]
    return partition_column_mappings


def set_merge_for_relational_db(input_file:str,env_name:str,username:str, pwd:str):
    db_details = get_schema_mapping(input_file, env_name)
    db_schema = 'IDFDB_METADATA'
    db_instance = db_details['DB_INSTANCE']
    schema_db_dataframe = pd.DataFrame([db_details])
    db_dataframe = schema_db_dataframe[['DB_INSTANCE', 'DB_SERVICE', 'DB_HOST', 'DB_PORT']]
    cte_parts = []
    for idx, row in db_dataframe.iterrows():
        cte_parts.append(f"SELECT :DB_INSTANCE{idx} AS DB_INSTANCE_ID, :DB_SERVICE{idx} AS DB_SERVICE_NAME, "
                         f" :DB_HOST{idx} as DB_HOST, :DB_PORT{idx} as DB_CONNECT_PORT_NUM  FROM dual")

    db_merge_sql = relational_db_merge(cte_parts, db_instance, db_schema) # returns merge Statement
    #return db_merge_sql
    params = {}
    for idx, row in db_dataframe.iterrows():
        params[f'DB_INSTANCE{idx}'] = row['DB_INSTANCE']
        params[f'DB_SERVICE{idx}'] = row['DB_SERVICE']
        params[f'DB_HOST{idx}'] = row['DB_HOST']
        params[f'DB_PORT{idx}'] = row['DB_PORT']
    print(params)
    # Create an engine (replace with your actual database URI)
    host = 'dev-1c-db-1.dev.spratingsvpc.com'  # replace with your Oracle DB host (e.g., 'localhost' or an IP address)
    port = 1521  # default Oracle port, but replace if necessary
    service_name = 'metadev.world'  # the service name of your Oracle database (can be found in tnsnames.ora)
    # Connection string format for Oracle
    connection_string = f'oracle+oracledb://{username}:{pwd}@{host}:{port}/?service_name={service_name}'
    engine = create_engine(connection_string)
    # Create a configured "Session" class
    session_maker = sessionmaker(bind=engine)
    # Start a session and transaction
    session = session_maker()
    try:
        session.execute(db_merge_sql, params)
        # Commit the transaction
        session.commit()
        print("Transaction committed successfully.")

    except Exception as e:
        # If an error occurs, rollback the transaction
        session.rollback()
        print(f"Transaction failed: {e}")


def set_merge_for_abs_schema():
    abs_schema_mappings = get_abs_database_mappings(file_name, env)
    cte_parts = []
    db_schema = 'IDFDB_METADATA'
    for idx, row in abs_schema_mappings.iterrows():
        cte_parts.append(f"SELECT :DATABASE_NAME{idx} AS DATABASE_NAME, :TABLE_NAME{idx} AS TABLE_NAME, "
                         f" :ABSTRCTN_TABLE_TYPE{idx} as ABSTRCTN_TABLE_TYPE, :ABSTRCTN_FILE_TYPE{idx} as ABSTRCTN_FILE_TYPE  FROM dual")

    db_merge_sql = abs_table_merge(cte_parts, db_schema) # returns merge Statement
    return db_merge_sql



def set_merge_for_relational_schema(file_name:str, env_name:str, RLTNL_DATABASE_ID:int):
    db_details = get_schema_mapping(file_name, env_name)
    schema_db_dataframe = pd.DataFrame([db_details]).fillna('N')
    schema_dataframe = schema_db_dataframe[['RDBMS_SCHEMA','SCHEMA_CLASSIFICATION', 'ABSTRACTION_SCHEMA_NAME',  'SCHEMA_PACKAGE_NAME']]
    print(schema_dataframe)
    schema_name = db_details['RDBMS_SCHEMA']
    db_schema = 'IDFDB_METADATA'
    cte_parts = []
    for idx, row in schema_dataframe.iterrows():
        cte_parts.append(f"SELECT :RLTNL_DATABASE_ID{idx} AS RLTNL_DATABASE_ID, :SCHEMA_NAME{idx} AS SCHEMA_NAME, "
                         f" :REPLICATION_TYPE{idx} as REPLICATION_TYPE, :SCHEMA_CLASSIFICATION{idx} as SCHEMA_CLASSIFICATION,"
                         f" :PACKAGE_NAME{idx} as PACKAGE_NAME  FROM dual")
    # TODO: Need to add the Relational Database id
    schema_merge_sql = relational_schema_merge(cte_parts, schema_name, RLTNL_DATABASE_ID, db_schema)  # returns merge Statement
    return schema_merge_sql

def set_merge_for_relational_table(file_name:str):
    table_mappings = get_table_mappings(file_name)
    db_schema = 'IDFDB_METADATA'
    cte_parts = []
    for idx, row in table_mappings.iterrows():
        cte_parts.append(f"SELECT :RLTNL_SCHEMA_ID{idx} AS RLTNL_SCHEMA_ID, :TABLE_NAME{idx} AS TABLE_NAME, "
                         f" :REPLICATION_TYPE{idx} as REPLICATION_TYPE, :TABLE_SIZE_CLASSIFICATION{idx} as TABLE_SIZE_CLASSIFICATION,"
                         f" :SQL_TEXT{idx} as SQL_TEXT, :VIEW_FILTER_SQL_TEXT{idx} as VIEW_FILTER_SQL_TEXT, :PACKAGE_FILTER_SQL_TEXT{idx} as PACKAGE_FILTER_SQL_TEXT,"
                         f" :RDBMS_PACKAGE_FLAG{idx} as RDBMS_PACKAGE_FLAG, :CDC_FLAG{idx} as CDC_FLAG, :REPLICATION_SCHD_TYPE{idx} as REPLICATION_SCHD_TYPE  FROM dual")
    ##TODO: Need to add the schema id
    table_merge_sql = relational_table_merge(cte_parts, db_schema, 1) # returns merge Statement
    return table_merge_sql

def set_merge_for_relational_column(file_name:str):
    column_mappings = get_column_mappings(file_name)
    print(column_mappings.columns)
    db_schema = 'IDFDB_METADATA'
    cte_parts = []
    for idx, row in column_mappings.iterrows():
        cte_parts.append(f"SELECT :RLTNL_TABLE_ID{idx} AS RLTNL_TABLE_ID, :COLUMN_NAME{idx} AS COLUMN_NAME, "
                         f" :COLUMN_DATATYPE{idx} as COLUMN_DATATYPE, :DATA_LENGTH{idx} as DATA_LENGTH,"
                         f" :DATA_PRECISION{idx} as DATA_PRECISION, :DATA_SCALE{idx} as DATA_SCALE,"
                         f" :IS_INCR_LOAD_IDENTIFIER{idx} as IS_INCR_LOAD_IDENTIFIER, :IS_NULLABLE{idx} as IS_NULLABLE,"
                         f" :IS_PRIMARY_KEY{idx} as IS_PRIMARY_KEY, :COLUMN_ORDR_NBR{idx} as COLUMN_ORDR_NBR  FROM dual")
    column_merge_sql = relational_column_merge(cte_parts, db_schema)  # returns merge Statement
    return column_merge_sql

def set_merge_abs_table():
    db_schema = 'IDFDB_METADATA'
    cte_parts = []



if __name__ == '__main__':
    env = 'DEV'
    file_name = '/Users/srinivas_dumpala/Downloads/Metadata_bu_pfast.xlsx'
    #sheet_names = get_sheet_names(file_name)
    #print(not all(db_details.values()))
    #print(sheet_names)
    #print(get_table_mappings(file_name).columns)
    print(get_partition_column_mappings(file_name))