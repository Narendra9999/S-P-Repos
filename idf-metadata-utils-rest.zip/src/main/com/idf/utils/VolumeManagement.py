"""
Author: Srinivas Dumpala
Date: 19-09-2024

This module is used to manage the volumes in the databricks

"""

import os

def validate_file_existence(file_path):
    if file_path.startswith("s3://") or file_path.startswith("spr-"):
        return True
    else:
        full_path = os.path.join("Volumes", file_path)
        if not os.path.exists(full_path):
            raise ValueError("Required File not found: " + full_path)
        return True


def write_data_to_volume(catalog:str,schema_name:str,key_name:str)->None:
    """

    :param catalog: Catalog name where we need to read the data
    :param schema_name: schema Name in catalog
    :param key_name: rest of the file structure
    :return: None
    """
    volume_name = "/Volumes/"+catalog+"/"+schema_name+"/"+key_name
    if os.path.exists(volume_name):
        print("File exists")
    else:
        raise FileNotFoundError(f"File not found {volume_name}")

    pass

def read_data_from_volume(config_file)-> str:
    if config_file.startswith("/Volumes"):
        volume_name = config_file
    else:
        volume_name = "/Volumes/" + config_file

    if os.path.exists(volume_name):
        with open(volume_name , "r") as file:
            configuration_data = file.read()
        return configuration_data
    else:
        raise FileNotFoundError(f"File not found {volume_name}")