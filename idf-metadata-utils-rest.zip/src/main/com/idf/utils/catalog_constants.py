

create_table = "CREATE TABLE IF NOT EXISTS {0}.{1} ({2})"
create_view = "CREATE VIEW IF NOT EXISTS {0}.{1} AS {2}"

metadata_sql_query  = """select d.DB_INSTANCE_ID AS db_instance,d.DB_SERVICE_NAME AS db_service , d.DB_HOST AS db_host ,d.DB_CONNECT_PORT_NUM AS db_conn_port,
s.SCHEMA_NAME  AS rdbms_schema_name ,
s.SCHEMA_CLASSIFICATION AS rdbms_schema_classification ,
s.PACKAGE_NAME AS schema_package_name ,
AT.DATABASE_NAME AS abstract_schema_name,
AT.ABSTRCTN_TABLE_ID AS ABSTRCTN_TABLE_ID,
t.TABLE_NAME AS rdbms_table_name,
t.RLTNL_TABLE_ID AS rdbms_table_id,
t.REPLICATION_TYPE AS rdbms_replication_type,
t.SQL_TEXT AS  rdbms_sql_text,
t.VIEW_FILTER_SQL_TEXT as view_filter_sql_text,
t.TABLE_SIZE_CLASSIFICATION  AS rdbms_table_size_classification,
AT.TABLE_NAME  AS abstraction_table_name,
AT.ABSTRCTN_FILE_TYPE  AS abstraction_file_type,
t.CDC_FLAG  AS cdc_flag,
t.RDBMS_PACKAGE_FLAG  AS rdbms_package_flag,
c.COLUMN_NAME AS rdbms_column_name,
c.COLUMN_DATATYPE AS rdbms_column_datatype,
c.DATA_LENGTH AS rdbms_data_length,
c.DATA_LENGTH AS rdbms_data_precision,
c.DATA_SCALE AS rdbms_data_scale,
c.IS_INCR_LOAD_IDENTIFIER  AS rdbms_is_incremental_load_identifier,
c.IS_NULLABLE  AS rdbms_is_nullable,
c.IS_PRIMARY_KEY AS rdbms_is_primary_key,
atc.COLUMN_NAME AS abstraction_column_name,
atc.COLUMN_DATATYPE AS abstraction_column_datatype,
atc.DATA_LENGTH AS abstraction_data_length,
atc.DATA_PRECISION AS abstraction_data_precision,
atc.DATA_SCALE AS abstraction_data_scale,
atc.IS_PARTITION_KEY AS abstraction_partition_key ,
atc.IS_SUBPARTITION_KEY AS abstraction_sub_partition_key,
atc.IS_BUCKET_KEY AS abstraction_is_bucket_key ,
atc.BUCKET_COUNTS AS abstraction_bucket_count,
atc.BUCKET_SORT_ORDER AS abstraction_bucket_sort_order,
atc.IS_DERIVED_PARTITION_REQUIRED AS abstraction_is_derived_partition_required,
mp.BATCH_NAME AS batch_name
from idfdb_metadata.rltnl_database_param d 
join idfdb_metadata.rltnl_schema s on s.rltnl_database_id = d.rltnl_database_id 
join idfdb_metadata.rltnl_table t on t.rltnl_schema_id = s.rltnl_schema_id 
join idfdb_metadata.rltnl_column c on c.rltnl_table_id = t.rltnl_table_id 
join idfdb_metadata.rltnl_abstrctn_col_map clm on clm.rltnl_table_id = t.rltnl_table_id and clm.rltnl_column_id = c.rltnl_column_id 
join idfdb_metadata.abstrctn_table at  on at.abstrctn_table_id = clm.abstrctn_table_id 
join idfdb_metadata.abstrctn_table_column atc on atc.abstrctn_table_id = at.abstrctn_table_id and atc.abstrctn_table_column_id = clm.abstrctn_table_column_id
join IDFDB_METADATA.BATCH_REPLCTN_ENTITY_MAP mp on mp.REPLCTN_SOURCE_ENTITY_ID=t.RLTNL_TABLE_ID"""

partition_sql_query = """select apc.ABSTRCTN_TABLE_ID AS ABSTRCTN_TABLE_ID ,apc.PARTITION_NAME  AS partition_name,apc.IS_PARTITION_DERIVED AS is_partition_derived,
apc.source_column_format AS source_column_format,apc.PARTITION_EXPRESSION AS partition_expression,apc.PARTITION_ORDER  AS partition_order FROM idfdb_metadata.abstrctn_partition_column apc"""
