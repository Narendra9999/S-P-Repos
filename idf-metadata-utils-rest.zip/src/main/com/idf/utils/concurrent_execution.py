from concurrent.futures import ThreadPoolExecutor
def concurrent_generation(worker_function, input_args):
    with ThreadPoolExecutor(max_workers=5) as executor:
        futures = [executor.submit(worker_function, *args) for args in input_args]
        results = [future.result() for future in futures]
    return results


