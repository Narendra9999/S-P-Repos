import json
from logging import basicConfig
import logging
import boto3

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def upload_json_to_s3(s3_path, file_name ,input_data):
    bucket, key = parse_s3_path(s3_path)
    s3 = boto3.client('s3')
    s3.put_object(Bucket=bucket, Key= key+file_name , Body=  input_data)


def parse_s3_path(s3_path):
    if s3_path.lower().startswith('volumes'):
        logging.info("provided location is Volume path not S3 path")
    path = s3_path[5:] if s3_path.lower().startswith('s3://') else s3_path
    logging.info("path ===>" + path)
    bucket, key = path.split('/', 1)
    return bucket, key

def read_s3_file(s3_path):
    bucket, key = parse_s3_path(s3_path)
    s3 = boto3.client('s3')
    response = s3.get_object(Bucket=bucket, Key=key)
    return response['Body'].read().decode('utf-8')