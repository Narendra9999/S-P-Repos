import oracledb

def get_metadata_db_connection(user_name, password, url):
    # Making Control table connection
    db_url = user_name + "/" + password + '@' + url
    connection = oracledb.connect(db_url)
    return connection