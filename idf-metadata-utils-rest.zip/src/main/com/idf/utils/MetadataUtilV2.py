import json
import os, sys
import boto3
from botocore.config import Config
from main.com.idf.utils.RSMUtilV2 import getpassword
from dataclasses import dataclass


@dataclass
class meta_data:
    processed_location:str
    db_schema:str
    db_usrname:str
    db_pswd:str
    db_url:str
    json_metadata_path:str
    BUCKET:str
    KEY:str
    db_env:str
    aws_region:str

def GetAWSConfig(config_secrect_key):
    global session
    aws_region = os.getenv("aws_region")

    boto3.client('ssm', region_name=aws_region)
    session = boto3.Session(region_name=aws_region)

    config_file = getpassword(config_secrect_key[6:-1])
    client = boto3.client('s3')
    BUCKET = config_file.split("/")[2]
    KEY = config_file.split("/")[3] + '/' + config_file.split("/")[4] + '/' + config_file.split("/")[5]
    result = client.get_object(Bucket=BUCKET, Key=KEY)

    text = result["Body"].read().decode()
    read_json = json.loads(text)
    db_usrname = read_json["control_table_conf"]["control_table_db_username"]
    secrect_pwd = read_json["control_table_conf"]["control_table_db_pwd"]
    temp_trx = secrect_pwd[6:-1]
    db_pswd = getpassword(temp_trx)
    json_metadata_path = read_json["metastore_path"]["path"]
    db_url = read_json["control_table_conf"]["control_table_db_url"].split("//")[1]
    db_env = read_json["control_table_conf"]["control_table_db_url"].split("/")[3]
    s3 = boto3.resource("s3").Bucket(BUCKET)
    json.load_s3 = lambda f: json.load(s3.Object(key=f).get()["Body"])
    json.dump_s3 = lambda obj, f: s3.Object(key=f).put(Body=json.dumps(obj))
    processed_location = read_json["s3_conf"]["s3_processed_location"]
    db_schema = read_json["control_table_conf"]["control_table_schema_owner"]
    return meta_data(processed_location, db_schema, db_usrname, db_pswd, db_url, json_metadata_path, BUCKET, KEY, db_env, aws_region)



def update_progress(src_type, progress):
    barLength = 10 # Modify this to change the length of the progress bar
    status = ""
    if isinstance(progress, int):
        progress = float(progress)
    if not isinstance(progress, float):
        progress = 0
        status = "error: progress var must be float\r\n"
    if progress < 0:
        progress = 0
        status = "Halt...\r\n"
    if progress >= 1:
        progress = 1
        status = "Done...\r\n"
    block = int(round(barLength*progress))
    text = "\r" + src_type + " [{0}] {1}% {2}".format("#" * block + "-" * (barLength - block), round(progress * 100,2), status)
    sys.stdout.write(text)
    sys.stdout.flush()