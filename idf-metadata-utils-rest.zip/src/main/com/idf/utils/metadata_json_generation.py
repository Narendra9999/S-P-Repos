import os
import pandas as pd
import json
from .metadata_constants import partition_level_columns, dummy_column_dict
import logging
from .AWSUtil import upload_json_to_s3
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
def lowercase_keys(data):
    if isinstance(data, dict):
        return {k.lower(): lowercase_keys(v) for k, v in data.items()}
    elif isinstance(data, list):
        return [lowercase_keys(item) for item in data]
    else:
        return data

def partition_information(existing_column_info , abstraction_table_id, partition_dataframe):
    existing_partitions = partition_dataframe[partition_dataframe['ABSTRCTN_TABLE_ID'] == abstraction_table_id]
    if not existing_partitions.empty:
        dummy_column_dict['abstraction_partition_derived_columns_list'] = lowercase_keys(existing_partitions[partition_level_columns].to_dict(orient='records'))
        return list(filter(lambda r : r['RDBMS_COLUMN_NAME'] != 'DUMMY_COLUMN', existing_column_info)) + [dummy_column_dict]
    else:
        return existing_column_info

def generate_upload_json(metadata_dataframe:pd.DataFrame , partition_dataframe:pd.DataFrame,volume_name:str,batch_name:str ,
                         replication_type = None) -> None:
    if replication_type is not None:
        metadata_dataframe['RDBMS_REPLICATION_TYPE'] = replication_type
    if batch_name is not None:
        column_group = metadata_dataframe.groupby(
            ['DB_INSTANCE', 'DB_SERVICE', 'DB_HOST', 'DB_CONN_PORT', 'RDBMS_SCHEMA_NAME', 'ABSTRCTN_TABLE_ID',
             'RDBMS_SCHEMA_CLASSIFICATION', 'SCHEMA_PACKAGE_NAME', 'ABSTRACT_SCHEMA_NAME',
             'RDBMS_TABLE_NAME', 'RDBMS_TABLE_ID', 'RDBMS_REPLICATION_TYPE', 'RDBMS_SQL_TEXT',
             'RDBMS_TABLE_SIZE_CLASSIFICATION', 'ABSTRACTION_TABLE_NAME',
             'ABSTRACTION_FILE_TYPE', 'CDC_FLAG', 'RDBMS_PACKAGE_FLAG']).apply(
            lambda column: column[['RDBMS_COLUMN_NAME', 'RDBMS_COLUMN_DATATYPE', 'RDBMS_DATA_LENGTH',
                                   'RDBMS_DATA_PRECISION', 'RDBMS_DATA_SCALE', 'RDBMS_IS_INCREMENTAL_LOAD_IDENTIFIER',
                                   'RDBMS_IS_NULLABLE', 'RDBMS_IS_PRIMARY_KEY', 'ABSTRACTION_COLUMN_NAME',
                                   'ABSTRACTION_COLUMN_DATATYPE',
                                   'ABSTRACTION_DATA_LENGTH', 'ABSTRACTION_DATA_PRECISION', 'ABSTRACTION_DATA_SCALE',
                                   'ABSTRACTION_PARTITION_KEY', 'ABSTRACTION_SUB_PARTITION_KEY',
                                   'ABSTRACTION_IS_BUCKET_KEY',
                                   'ABSTRACTION_BUCKET_COUNT', 'ABSTRACTION_BUCKET_SORT_ORDER','ABSTRACTION_IS_DERIVED_PARTITION_REQUIRED']].assign(
                abstraction_partition_derived_columns_list=[[]] * len(column))
            .to_dict(orient='records')).reset_index().rename(columns={0: 'column_details'})
        logging.info("column_group ===>" + str(len(column_group)))
        column_group['column_details'] = column_group.apply(
            lambda row: partition_information(row['column_details'], row['ABSTRCTN_TABLE_ID'], partition_dataframe),
            axis=1)
        logging.info("column_group after adding partition information ===>" + str(len(column_group)))
        table_group = (
            column_group.groupby(['DB_INSTANCE', 'DB_SERVICE', 'DB_HOST', 'DB_CONN_PORT', 'RDBMS_SCHEMA_NAME',
                                  'RDBMS_SCHEMA_CLASSIFICATION', 'SCHEMA_PACKAGE_NAME', 'ABSTRACT_SCHEMA_NAME'])
            .apply(
                lambda table: table[['RDBMS_TABLE_NAME', 'RDBMS_TABLE_ID', 'RDBMS_REPLICATION_TYPE', 'RDBMS_SQL_TEXT',
                                     'RDBMS_TABLE_SIZE_CLASSIFICATION', 'ABSTRACTION_TABLE_NAME',
                                     'ABSTRACTION_FILE_TYPE', 'CDC_FLAG', 'RDBMS_PACKAGE_FLAG',
                                     'column_details']].to_dict(orient='records')).reset_index().rename(
                columns={0: 'table_details'}))
        logging.info("table_group ===>" + str(len(table_group)))
        schema_group = table_group.groupby(['DB_INSTANCE', 'DB_SERVICE', 'DB_HOST', 'DB_CONN_PORT']).apply(
            lambda schema: schema[['RDBMS_SCHEMA_NAME', 'RDBMS_SCHEMA_CLASSIFICATION',
                                   'SCHEMA_PACKAGE_NAME', 'ABSTRACT_SCHEMA_NAME', 'table_details']].to_dict(
                orient='records')).reset_index().rename(columns={0: 'schema_details'})
        logging.info("schema_group ===>" + str(len(schema_group)))
        schema_group['batch_name'] = batch_name
        batch_group = ((schema_group.groupby(['batch_name'])
                       .apply(lambda database: database[['DB_INSTANCE', 'DB_SERVICE', 'DB_HOST', 'DB_CONN_PORT','schema_details']]
                                                                 .to_dict(orient='records'))
                       .reset_index().rename(columns={0: 'db_instance_details'})).drop(columns=['batch_name']).
                       explode('db_instance_details').reset_index(drop=True))

        # Convert to final nested structure
        metadata_output = batch_group.to_dict(orient='records')
        final_output = {"batch_details":{"batch_name":batch_name,"db_details": metadata_output}}
        logging.info("Success fully created the metadata JSON and upload into the volume")

        if volume_name.lower().startswith('s3://') or volume_name.lower().startswith('spr-idf'):
            upload_json_to_s3(volume_name, batch_name + ".json", json.dumps(lowercase_keys(final_output), indent=2))
        else:
            with open(os.path.join(volume_name,batch_name + ".json"), 'w') as f:
                f.write(json.dumps(lowercase_keys(final_output), indent=2))
