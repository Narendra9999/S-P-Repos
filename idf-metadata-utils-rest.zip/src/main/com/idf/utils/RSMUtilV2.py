import os
import requests

def getpassword(control_table_db_pwd) -> str:
    spr_app_secret_hc_vault_base_url = os.getenv("SPR_APP_SECRET_HC_VAULT_BASE_URL")
    spr_shelf_id = os.getenv("IDF_SHELF_ID")
    spr_app_secret_hc_vault_token = os.getenv("SPR_APP_SECRET_HC_VAULT_TOKEN")
    base_url = spr_app_secret_hc_vault_base_url + "/" + spr_shelf_id
    params = {'secret-keys': control_table_db_pwd}
    headers = {"spr-sm-token": spr_app_secret_hc_vault_token}
    response = requests.get(base_url, headers=headers, params=params)
    data = response.json()
    schema_password = data['data'][control_table_db_pwd]
    return schema_password
