"""
Constants that validates the input arguments
against the list of valid actions
"""

VALID_ACTIONS = ['load_metadata', 'generate_metadata', 'generate_catalog', 'job_create', 'workflow']


def validate_input_arguments_for_json_creation(args):
    pass