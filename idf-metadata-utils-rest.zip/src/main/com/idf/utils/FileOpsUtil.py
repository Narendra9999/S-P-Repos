def create_spark_file(schemaName, tableName, batchId):
    file = open("alter_table.sql", "a+")
    query = "ALTER TABLE " + schemaName + ".t_" + tableName + "_base drop if exists partition ( BATCH_ID = " + str(
        batchId) + ")"
    file.write(str(query) + '\n')
