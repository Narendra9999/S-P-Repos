"""
Author : srinivas.dumpala@spglobal.com
Date : 16-09-2024
Description: This module starter of the workflow to call required Actions
"""
import logging
import argparse
import subprocess
from main.com.idf.tools.databricks_job_management import create_update_databricks_jobs
from main.com.idf.utils.input_args_lib import VALID_ACTIONS
from main.com.idf.tools.load_metadata import *
from main.com.idf.tools.Get_metastore_json import *
from main.com.idf.tools.generate_data_catalog import *

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO, format='%(asctime)s -%(module)s - %(levelname)s - %(message)s')

def run() -> None:
    parser = argparse.ArgumentParser(description="Process input arguments.")
    parser.add_argument('--action', type=str,
                        help='type of action to be formed', required=True,
                        choices=['load_metadata', 'generate_metadata', 'generate_catalog', 'job_create', 'workflow'])
    action_arg,known_args = parser.parse_known_args()
    validate_action(action_arg.action)
    if action_arg.action == 'load_metadata':
        parser.add_argument('--config_file', type=str, help='Full path of the Config file in Volume', required=True)
        parser.add_argument('--metadata_file', type=str, help='Full path of the Metadata file in Volume', required=False,default=None)
        parser.add_argument('--config_file_env', type=str, help='Configuration file that needs to be loaded',
                            required=True)
        parser.add_argument('--volume_name', type=str, help='Configuration file that needs to be loaded',
                            required=True)
        load_metadata_args = parser.parse_args()
        config_file = load_metadata_args.config_file
        metadata_file_env = load_metadata_args.config_file_env
        volume_name = load_metadata_args.volume_name
        metadata_file = load_metadata_args.metadata_file
        logging.info(f"Provided Arguments {load_metadata_args}")
        #process_load_metadata(load_metadata_args)
        if metadata_file is None:
            command = [sys.executable, '-m', 'main.com.idf.tools.load_metadata_v2', '--confilg_file_name',config_file,
                       '--config_file_env' ,metadata_file_env,
                       '--volume_name' ,volume_name]
            subprocess.run(command)
        else:
            command = [sys.executable, '-m', 'main.com.idf.tools.load_metadata_v2', '--confilg_file_name',config_file,
                   '--config_file_env' ,metadata_file_env,
                   '--volume_name' ,volume_name,
                   '--metadata_file',metadata_file]
            subprocess.run(command)


    elif action_arg.action == 'generate_metadata':
        parser.add_argument('--volume_name', type=str, help='Full path of the Volume where the JSON needs to be stored',
                            required=True)
        parser.add_argument('--config_file', type=str, help='Full path of the Config file in Volume',
                            required=True)
        parser.add_argument('--level', metavar='level',
                            nargs='?', type=str, help='SCHEMA or TABLE_ID or TABLE_NAME or Blank BATCH'
                            ,required=False)
        parser.add_argument('--level_value', metavar='level_value',
                            nargs='?', type=str, help='Corresponding value for the level',
                            required=False)
        parser.add_argument('--customized_json_name', metavar='customized_json_name',
                            nargs='?', type=str, help='Customized JSON Name in case of TABLE_ID or TABLE_NAME',
                            required=False)
        args_metadata_json = parser.parse_args()
        validate_input(args_metadata_json)
        generate_metadata(args_metadata_json)
    elif action_arg.action == 'generate_catalog':
        parser.add_argument('--config_file', type=str,
                            help='Name of the catalog',
                            required=True)
        parser.add_argument('--volume_name', type=str,
                            help='Full path of the Volume where the .sql needs to be stored',
                            required=True)
        parser.add_argument('--processed_location', type=str,
                            help='Location attribute for table Creation referred to s3 ',
                            required=True)
        parser.add_argument('--level', metavar='level',
                            nargs='?', type=str, help='SCHEMA or TABLE_ID or TABLE_NAME or Blank BATCH'
                            , required=False)
        parser.add_argument('--level_value', metavar='level_value',
                            nargs='?', type=str, help='Corresponding value for the level',
                            required=False)
        generate_catalog_args = parser.parse_args()
        validate_input(generate_catalog_args)
        catalog_creation(generate_catalog_args)
    elif action_arg.action == 'job_create':
        parser.add_argument('--config_file', type=str,
                            help='RSM Key for global config JSON ', required=True)
        parser.add_argument('--job_action', type=str,
                            help='action that describes job whether create or update', required=True)
        parser.add_argument('--job_id', type=str,
                            help='Name of the Job Key from idf_jobs_metadata table',
                            required=True)
        parser.add_argument('--run_params', type=str,
                            help='Override Job Parameters',
                            required=False,default=None)
        parser.add_argument('--svc_account', type=str,
                            help='Service account to manage the Job life cycle',
                            required=True, default=None)
        job_args = parser.parse_args()
        create_update_databricks_jobs(job_args)

    elif action_arg.action == 'workflow':
        parser.add_argument('--workflow_name', type=str, help='Name of the workflow', required=True)

def validate_input(input_args) -> None:
    if input_args.action == 'load_metadata':
        if input_args.config_file is None or input_args.volume_name is None:
            raise ValueError("Config file and Volume name is required for generate catalog")

    elif input_args.action == 'generate_metadata':
        level = input_args.level
        level_value = input_args.level_value
        customized_json = input_args.customized_json_name
        if level is None and level_value is not None:
            raise ValueError(f"level_value can not be input when level is None")
        if level is not None and level_value is None:
            raise ValueError("level_value should be provided level is not None")
        if (level is not None and level.upper() == 'TABLE_ID') or (level is not None and level.upper()) == 'TABLE_NAME':
            if input_args.customized_json_name is None:
                raise ValueError("Customized Json Name is required for WHERE condition")
        if level is not None and level.upper() == 'BATCH' and level_value is None:
            raise ValueError("Batch Name is required for BATCH condition")
        if level is not None and level.upper() == 'BATCH' and customized_json is not None:
            logging.warning("Ignoring the Customized JSON Name as it is not required for BATCH condition")

    elif input_args.action == 'generate_catalog':
        pass
    elif input_args.action == 'job_create':
        pass
    elif input_args.action == 'workflow':
        pass
    pass

def validate_action(input_action) -> None:
    if input_action not in VALID_ACTIONS:
        raise ValueError(f"Invalid action: {input_action}. Valid actions are {VALID_ACTIONS}")
