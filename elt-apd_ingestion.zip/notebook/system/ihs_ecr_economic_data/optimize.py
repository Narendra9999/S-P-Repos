# Databricks notebook source
# MAGIC %run  ../../../library/0_Common_job_utilities

# COMMAND ----------

from threading import Thread
import time
import os
env = os.environ.get("aws_env")
table_parametre=f"idf_curated_{env}.ecr_economic_data,idf_raw_{env}.ecr_economic_data"
def run_vacuum_optimize(table_name, failed_tables, retries):
    attempts = 0
    while attempts <= retries:
        try:
            spark.sql(f"OPTIMIZE {table_name}")
            print(f"OPTIMIZE completed for table: {table_name}")
            spark.sql(f"VACUUM {table_name}")
            print(f"VACUUM completed for table: {table_name}")
            return
        except Exception as e:
            print(f"Error occurred while processing table {table_name}: {str(e)}")
            attempts += 1
            print(f"Retrying vacuum and optimize for table {table_name}... (Attempt {attempts})")
            time.sleep(1)
 
    failed_tables.append(table_name)
 
def delta_vacuum_optimize(vacuum_optimize_tables, parallelism, retries):
    print("Initiating vacuum and optimize of all tables")
   
    failed_tables = []
    threads = []
 
    for table in vacuum_optimize_tables:
        thread = Thread(target=run_vacuum_optimize, args=(table, failed_tables, retries))
        thread.start()
        threads.append(thread)
 
        if len(threads) >= parallelism:
            for thread in threads:
                thread.join()
            threads.clear()
 
    for thread in threads:
        thread.join()
 
    if failed_tables:
        print("Vacuuming and optimizing completed with the following failed tables:")
        for table in failed_tables:
            print(table)
    else:
        print("Vacuuming and optimizing completed successfully.")
vacuum_optimize_tables = []
# table_parametre = "idf_curated_dev.ecr_economic_data"
param_schemas = list(table_parametre.split(","))
for schema in param_schemas:
    print(f"Schema name : {schema}")
    tables = spark.sql(f"SHOW TABLES IN {schema}")
    if "raw" in schema:
        filtered_tables = tables.filter((tables.tableName.startswith("t_job_control"))| (tables.tableName.startswith("t_process_control"))|(tables.tableName.startswith("t_job_metadata"))|(tables.tableName.startswith("t_process_metadata")))
    else:    
        filtered_tables = tables.filter(tables.tableName.startswith("t_"))
    table_names = [f"{schema}.{row['tableName']}" for row in filtered_tables.collect()]
    vacuum_optimize_tables.extend(table_names)
print(f"Tables to be vacuum and optimize are: {vacuum_optimize_tables}")        
delta_vacuum_optimize(vacuum_optimize_tables,7,2)        
