# Databricks notebook source
# MAGIC %run  ../../../library/0_Common_job_utilities
# MAGIC

# COMMAND ----------

dbutils.widgets.text(name="process_operation",defaultValue="DefaultValue")
dbutils.widgets.text(name="process_status",defaultValue="DefaultValue")
dbutils.widgets.text(name="table_name",defaultValue="DefaultValue")



# COMMAND ----------

from pyspark.dbutils import DBUtils
import os,json

# job_config_dict=bytes_to_dict(read_s3_to_dict('spr-idf-dev-platform-stage','feeds/job_config/job_config.json'))

process_type =dbutils.widgets.get("process_operation")
process_status=dbutils.widgets.get('process_status')
table_name=dbutils.widgets.get('table_name')

env = os.environ.get("aws_env")
metadata_schema=f"idf_raw_{env}.ecr_economic_data"

s3_bucket=f"spr-idf-{env}-platform-config"
file_path = f"platform/config/ihs_ecr_economic_data/{table_name}.json"
json_config=json.loads(read_s3_to_dict(s3_bucket,file_path))
job_id=json_config['job_id']
process_id=json_config['process_id']
print(json_config)

# COMMAND ----------

# from pyspark.dbutils import DBUtils
# import os,json

# # job_config_dict=bytes_to_dict(read_s3_to_dict('spr-idf-dev-platform-stage','feeds/job_config/job_config.json'))

# process_type =dbutils.widgets.get("process_operation")
# process_status=dbutils.widgets.get('process_status')
# table_name=dbutils.widgets.get('table_name')

# env = os.environ.get("aws_env")
# metadata_schema=f"idf_raw_{env}.ecr_economic_data"

# s3_bucket=f"spr-idf-{env}-platform-config"
# file_path = f"streaming_checkpoint/ihs_ecr_economic_data/{table_name}.json"
# json_config=json.loads(read_s3_to_dict(s3_bucket,file_path))
# job_id=json_config['job_id']
# process_id=json_config['process_id']
# print(json_config)

# COMMAND ----------


if process_type =='start':

    ret_code,process_run_id = process_start(int(job_id),metadata_schema,int(process_id))
    process_run_id = process_run_id
    #process_version = process_version
    if ret_code == 0:
        print('process started successfully!')

    else:
        print('process start failed !! there is an existing process in running state.')
        dbutils.notebook.exit("process start failed !! there is an existing process in running state.")
    

elif process_type == 'end':
    process_status = "completed"

    ret_code,job_run_id = fetch_job_run_id(job_id,metadata_schema,process_id)
    print(job_run_id)
    job_run_id =job_run_id[0][0]
    if process_status == 'DefaultValue' or job_run_id=='DefaultValue':
        dbutils.notebook.exit('process_status parameter or job_run_id parameter is not provided.')

    status = process_end(job_id,int(job_run_id),metadata_schema,int(process_id),process_status)

else:
    print('invalid job_type')
    status = 2
