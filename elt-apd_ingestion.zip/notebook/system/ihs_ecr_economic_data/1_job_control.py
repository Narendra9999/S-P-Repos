# Databricks notebook source
# MAGIC %run  ../../../library/0_Common_job_utilities

# COMMAND ----------

dbutils.widgets.text(name="job_operation",defaultValue="DefaultValue")
dbutils.widgets.text(name="job_status",defaultValue="DefaultValue")
dbutils.widgets.text(name="table_name",defaultValue="DefaultValue")

# COMMAND ----------

from pyspark.dbutils import DBUtils
import json,os

job_operation =dbutils.widgets.get("job_operation")
table_name=dbutils.widgets.get('table_name')

env = os.environ.get("aws_env")
metadata_schema=f"idf_raw_{env}.ecr_economic_data"

s3_bucket=f"spr-idf-{env}-platform-config"
file_path = f"platform/config/ihs_ecr_economic_data/{table_name}.json"
json_config=json.loads(read_s3_to_dict(s3_bucket,file_path))
job_id=json_config['job_id']
process_id=json_config['process_id']
print(json_config)
print(metadata_schema)

# COMMAND ----------

# from pyspark.dbutils import DBUtils
# import json,os

# job_operation =dbutils.widgets.get("job_operation")
# table_name=dbutils.widgets.get('table_name')

# env = os.environ.get("aws_env")
# metadata_schema=f"idf_raw_{env}.ecr_economic_data"

# s3_bucket=f"spr-idf-{env}-platform-config"
# file_path = f"streaming_checkpoint/ihs_ecr_economic_data/{table_name}.json"
# json_config=json.loads(read_s3_to_dict(s3_bucket,file_path))
# job_id=json_config['job_id']
# process_id=json_config['process_id']
# print(json_config)
# print(metadata_schema)

# COMMAND ----------

job_config_dict={}
schema=metadata_schema
job_config_dict['job_id'] =job_id
if job_operation =='start':
    ret_code,job_run_id=job_start(job_id,schema)
    if ret_code==0:
        job_config_dict['job_start_status']= 'success'
        job_config_dict['job_run_id']= job_run_id
    else:
        job_config_dict['job_start_status']= 'failed'

    
    #write_dict_to_s3('spr-idf-dev-platform-stage','feeds/job_config/job_config.json',job_config_dict)


elif job_operation == 'end':

    #job_config_dict= bytes_to_dict(read_s3_to_dict('spr-idf-dev-platform-stage','feeds/job_config/job_config.json'))
    job_status = 'COMPLETED'
    job_id = job_config_dict['job_id']
    if job_status is None:
        dbutils.notebook.exit('job_status parameter not provided.')
    job_status =dbutils.widgets.get("job_status")

    job_end(int(job_id),schema,job_status)
else:
    print('invalid job_type')
