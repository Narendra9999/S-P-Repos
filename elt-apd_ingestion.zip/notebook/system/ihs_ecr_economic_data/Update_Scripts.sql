update idf_raw_dev.ecr_economic_data.t_job_control set job_start_time=cast(date_format('2024-05-18 21:10:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where job_id=37  and job_status='NOT STARTED';
update idf_raw_dev.ecr_economic_data.t_process_control set process_start_time=cast(date_format('2024-05-18 21:10:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where process_id=37  and process_status='NOT STARTED';
 
update idf_raw_dev.ecr_economic_data.t_job_control set job_start_time=cast(date_format('2024-05-18 20:00:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where job_id=38  and job_status='NOT STARTED';
update idf_raw_dev.ecr_economic_data.t_process_control set process_start_time=cast(date_format('2024-05-18 20:00:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where process_id=38  and process_status='NOT STARTED';
 
update idf_raw_dev.ecr_economic_data.t_job_control set job_start_time=cast(date_format('2024-05-18 20:40:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where job_id=39  and job_status='NOT STARTED';
update idf_raw_dev.ecr_economic_data.t_process_control set process_start_time=cast(date_format('2024-05-18 20:40:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where process_id=39  and process_status='NOT STARTED';
 
update idf_raw_dev.ecr_economic_data.t_job_control set job_start_time=cast(date_format('2024-05-18 21:30:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where job_id=40  and job_status='NOT STARTED';
update idf_raw_dev.ecr_economic_data.t_process_control set process_start_time=cast(date_format('2024-05-18 21:30:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where process_id=40  and process_status='NOT STARTED';
 
update idf_raw_dev.ecr_economic_data.t_job_control set job_start_time=cast(date_format('2024-05-18 22:20:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where job_id=41  and job_status='NOT STARTED';
update idf_raw_dev.ecr_economic_data.t_process_control set process_start_time=cast(date_format('2024-05-18 22:20:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where process_id=41  and process_status='NOT STARTED';
 
update idf_raw_dev.ecr_economic_data.t_job_control set job_start_time=cast(date_format('2024-05-18 20:50:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where job_id=42  and job_status='NOT STARTED';
update idf_raw_dev.ecr_economic_data.t_process_control set process_start_time=cast(date_format('2024-05-18 20:50:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where process_id=42  and process_status='NOT STARTED';
 
update idf_raw_dev.ecr_economic_data.t_job_control set job_start_time=cast(date_format('2024-05-18 21:50:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where job_id=43  and job_status='NOT STARTED';
update idf_raw_dev.ecr_economic_data.t_process_control set process_start_time=cast(date_format('2024-05-18 21:50:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where process_id=43  and process_status='NOT STARTED';
 
update idf_raw_dev.ecr_economic_data.t_job_control set job_start_time=cast(date_format('2024-05-18 22:10:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where job_id=44  and job_status='NOT STARTED';
update idf_raw_dev.ecr_economic_data.t_process_control set process_start_time=cast(date_format('2024-05-18 22:10:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where process_id=44  and process_status='NOT STARTED';
 
update idf_raw_dev.ecr_economic_data.t_job_control set job_start_time=cast(date_format('2024-05-18 21:20:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where job_id=45  and job_status='NOT STARTED';
update idf_raw_dev.ecr_economic_data.t_process_control set process_start_time=cast(date_format('2024-05-18 21:20:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where process_id=45  and process_status='NOT STARTED';
 
update idf_raw_dev.ecr_economic_data.t_job_control set job_start_time=cast(date_format('2024-05-18 20:10:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where job_id=46  and job_status='NOT STARTED';
update idf_raw_dev.ecr_economic_data.t_process_control set process_start_time=cast(date_format('2024-05-18 20:10:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where process_id=46  and process_status='NOT STARTED';
 
update idf_raw_dev.ecr_economic_data.t_job_control set job_start_time=cast(date_format('2024-05-18 21:40:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where job_id=47  and job_status='NOT STARTED';
update idf_raw_dev.ecr_economic_data.t_process_control set process_start_time=cast(date_format('2024-05-18 21:40:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where process_id=47  and process_status='NOT STARTED';
 
update idf_raw_dev.ecr_economic_data.t_job_control set job_start_time=cast(date_format('2024-05-18 20:30:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where job_id=48  and job_status='NOT STARTED';
update idf_raw_dev.ecr_economic_data.t_process_control set process_start_time=cast(date_format('2024-05-18 20:30:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where process_id=48  and process_status='NOT STARTED';
 
update idf_raw_dev.ecr_economic_data.t_job_control set job_start_time=cast(date_format('2024-05-18 20:20:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where job_id=49  and job_status='NOT STARTED';
update idf_raw_dev.ecr_economic_data.t_process_control set process_start_time=cast(date_format('2024-05-18 20:20:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where process_id=49  and process_status='NOT STARTED';
 
update idf_raw_dev.ecr_economic_data.t_job_control set job_start_time=cast(date_format('2024-05-18 21:00:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where job_id=50  and job_status='NOT STARTED';
update idf_raw_dev.ecr_economic_data.t_process_control set process_start_time=cast(date_format('2024-05-18 21:00:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where process_id=50  and process_status='NOT STARTED';
 
update idf_raw_dev.ecr_economic_data.t_job_control set job_start_time=cast(date_format('2024-05-18 22:40:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where job_id=51  and job_status='NOT STARTED';
update idf_raw_dev.ecr_economic_data.t_process_control set process_start_time=cast(date_format('2024-05-18 22:40:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where process_id=51  and process_status='NOT STARTED';
 
update idf_raw_dev.ecr_economic_data.t_job_control set job_start_time=cast(date_format('2024-05-18 22:00:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where job_id=52  and job_status='NOT STARTED';
update idf_raw_dev.ecr_economic_data.t_process_control set process_start_time=cast(date_format('2024-05-18 22:00:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where process_id=52  and process_status='NOT STARTED';
 
update idf_raw_dev.ecr_economic_data.t_job_control set job_start_time=cast(date_format('2024-05-18 22:30:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where job_id=53  and job_status='NOT STARTED';
update idf_raw_dev.ecr_economic_data.t_process_control set process_start_time=cast(date_format('2024-05-18 22:30:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where process_id=53  and process_status='NOT STARTED';
 
update idf_raw_dev.ecr_economic_data.t_job_control set job_start_time=cast(date_format('2024-05-18 22:50:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where job_id=54  and job_status='NOT STARTED';
update idf_raw_dev.ecr_economic_data.t_process_control set process_start_time=cast(date_format('2024-05-18 22:50:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where process_id=54  and process_status='NOT STARTED';