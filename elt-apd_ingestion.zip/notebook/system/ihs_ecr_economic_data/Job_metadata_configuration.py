# Databricks notebook source
# MAGIC %md
# MAGIC ## Initial job setup
# MAGIC
# MAGIC ### Steps:
# MAGIC     1) create job metadata entry with job info
# MAGIC     2) pass the job_id as input to the job.
# MAGIC     3) create process metadata entry with job_id linking for each step.

# COMMAND ----------

# MAGIC %run ../../../library/0_Common_job_utilities

# COMMAND ----------

import datetime

from pyspark.sql.functions import current_timestamp

# COMMAND ----------

dbutils.widgets.text(name="job_name",defaultValue="DefaultValue")
dbutils.widgets.text(name="load_type",defaultValue="DefaultValue")
dbutils.widgets.text(name="key",defaultValue="DefaultValue")

# COMMAND ----------

### Variable Initialization ####
import os,json

job_name = dbutils.widgets.get("job_name")
env = os.environ.get("aws_env")
metadata_schema=f"idf_raw_{env}.ecr_economic_data"

if (job_name=="DefaultValue"):
    dbutils.notebook.exit("Notebook parameter are not provided")

source_schema=f"idf_raw_{env}.ecr_economic_data"
target_schema=f"idf_curated_{env}.ecr_economic_data"


load_type=dbutils.widgets.get("load_type")
print(load_type)
key=dbutils.widgets.get("key")
print(key)
job_frequency =168

# COMMAND ----------

# delete_statement=f"delete from idf_raw_{env}.ecr_economic_data.t_job_metadata where job_name='{job_name}'"
# result = spark.sql(delete_statement).collect()
# if result:
#     num_records=int(result[0][0])
#     print(num_records)
#     print("job got deleted")    
# else:
#     dbutils.notebook.exit("no action done")

# COMMAND ----------

### Check if there is entry with existing job_name in the table ###

select_statement=f"SELECT * from idf_raw_{env}.ecr_economic_data.t_job_metadata where job_name='{job_name}'"
result = spark.sql(select_statement).collect()
if result:
    num_records=int(result[0][0])
    print(num_records)
    dbutils.notebook.exit("Notebook exiting as the record is already present in db")
else:
    print("no records exists with the job_name")


# COMMAND ----------


source_schema=f"idf_raw_{env}.ecr_economic_data"
target_schema=f"idf_curated_{env}.ecr_economic_data"
job_frequency =168
job_metadata_insert_statement=f"""INSERT INTO idf_raw_{env}.ecr_economic_data.t_job_metadata(job_name, job_desc, job_dependencies,job_source_schema, job_target_schema, job_freq,dq_enabled, dq_id, audit_insert_id, audit_updated_id)
VALUES("{job_name}","{job_name} data",null,"{source_schema}","{target_schema}",{job_frequency},FALSE,null,"nmerla2","nmerla2")"""

spark.sql(job_metadata_insert_statement)


# COMMAND ----------


select_statement=f"SELECT job_id from idf_raw_{env}.ecr_economic_data.t_job_metadata where job_name='{job_name}'"
print(select_statement)

result = spark.sql(select_statement).collect()
job_id=int(result[0][0])
print(job_id)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Job Control Entry

# COMMAND ----------

current_time=str(datetime.datetime.utcnow())
statement=f"""insert into {metadata_schema}.t_job_control(job_id,job_start_time,job_end_time,job_status,job_freq,audit_inserted_ts,audit_updated_ts,audit_insert_id,audit_updated_id) values ({job_id},cast(date_format('1900-01-01 00:00:00', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp),cast(date_format('{current_time}', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp),'NOT STARTED',{job_frequency},cast(date_format('{current_time}', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp),cast(date_format('{current_time}', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp),'nmerla','nmerla')"""
print(statement)
spark.sql(statement)

# COMMAND ----------

select_statement=f"""select job_run_id from {metadata_schema}.t_job_control where job_id={job_id} and job_status='NOT STARTED'"""
result = spark.sql(select_statement).collect()
job_run_id=int(result[0][0])
print(job_run_id)

# COMMAND ----------

# %sql

# select * from  idf_raw_{env}.ecr_economic_data.t_job_control

# COMMAND ----------

# MAGIC %md
# MAGIC #### Process_Metadata Entry ###

# COMMAND ----------



insert_statement=f"""INSERT INTO {metadata_schema}.t_process_metadata(job_id,process_name, process_source_schema,process_target_schema, process_dependencies,process_freq, process_load_type,process_keys, audit_insert_id, audit_updated_id)
VALUES("{job_id}","raw_to_curation","{source_schema}","{target_schema}",null,24,'{load_type}',"{key}","nmerla2","nmerla2")"""


spark.sql(insert_statement)



# COMMAND ----------

select_statement=f"""select process_id from {metadata_schema}.t_process_metadata where job_id={job_id}"""
result = spark.sql(select_statement).collect()
process_id=int(result[0][0])
print(process_id)

# COMMAND ----------

# %sql
# select *  from idf_raw_{env}.ecr_economic_data.t_job_control where job_id=1

# COMMAND ----------

### Making an entry into process Control table ###

# process_name,process_load_type =spark.sql("select process_name,process_load_type from {}.t_process_metadata where job_id={} and process_id={}".format(job_id,process_id)).toPandas().T.values
process_name,process_load_type =spark.sql("select process_name,process_load_type from idf_raw_{}.ecr_economic_data.t_process_metadata where job_id={} and process_id={}".format(env,job_id,process_id)).toPandas().T.values

print(process_name[0])

# COMMAND ----------

current_time=str(datetime.datetime.utcnow())

insert_statement=f"""INSERT INTO idf_raw_{env}.ecr_economic_data.t_process_control(process_id,job_run_id,process_name,process_start_time,process_end_time, process_status,process_source_counts,process_target_counts,process_dq_id,process_freq,table_delta_version,audit_inserted_ts,audit_updated_ts,audit_insert_id,audit_updated_id)
VALUES("{process_id}",{job_run_id},"{process_name[0]}",cast(date_format('1900-01-01 00:00:00', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp),null,"NOT STARTED",null,null,null,168,0,cast(date_format('{current_time}', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp),cast(date_format('{current_time}', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp),"nmerla2","nmerla2")"""


spark.sql(insert_statement)
print("process_control entry made for day-1")

# COMMAND ----------

# %sql
# select * from idf_raw_{env}.ecr_economic_data.t_process_control

# COMMAND ----------

# MAGIC %md
# MAGIC #### Curated layer process entry

# COMMAND ----------

# MAGIC %md
# MAGIC ### Lets make sure we have all the related entries in metadata table

# COMMAND ----------

# %sql
# --- querying the job metadata table 
# select * from idf_raw_{env}.posttrade.job_metadata where job_name like '%ihs_ecr_bank%'

# COMMAND ----------

# %sql
# ALTER TABLE idf_raw_{env}.posttrade.job_control  SET TBLPROPERTIES('delta.minReaderVersion' = 1, 'delta.minWriterVersion' = 2) 

# COMMAND ----------


