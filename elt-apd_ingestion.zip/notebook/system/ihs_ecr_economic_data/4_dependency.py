# Databricks notebook source
# MAGIC %run ../../../library/0_Common_job_utilities

# COMMAND ----------

dbutils.widgets.text(name="dependent_table_name",defaultValue="DefaultValue")
dbutils.widgets.text(name="table_name",defaultValue="DefaultValue")

# COMMAND ----------

from pyspark.dbutils import DBUtils
import json,os

dependent_table_name =dbutils.widgets.get("dependent_table_name")
table_name=dbutils.widgets.get('table_name')

env = os.environ.get("aws_env")
metadata_schema=f"idf_raw_{env}.ecr_economic_data"

s3_bucket=f"spr-idf-{env}-platform-config"
file_path = f"platform/config/ihs_ecr_economic_data/{table_name}.json"
json_config=json.loads(read_s3_to_dict(s3_bucket,file_path))
job_id=json_config['job_id']
process_id=json_config['process_id']
print(json_config)
print(metadata_schema)

dependency_table_list = dependent_table_name.split(",")


# COMMAND ----------

from pyspark.dbutils import DBUtils
import os,json

env = os.environ.get("aws_env")

def fetch_job_process_id(table_name):
    s3_bucket=f"spr-idf-{env}-platform-config"
    dependent_file_path = f"platform/config/ihs_ecr_economic_data/{table_name}.json"
    dependent_json_config=json.loads(read_s3_to_dict(s3_bucket,dependent_file_path))
    dependent_job_id=dependent_json_config['job_id']
    dependent_process_id=dependent_json_config['process_id']
    return dependent_job_id,dependent_process_id

# COMMAND ----------

from datetime import date,datetime
import time

def check_all_tables(dependency_table_list,process_id):
    for table_name in dependency_table_list:
        dependent_job_id,dependent_process_id = fetch_job_process_id(table_name)

        current_date = date.today()
        current_date_str = current_date.strftime('%Y-%m-%d')
        print(f"Current Date: {current_date_str}")    
        previous_processs_date = spark.sql (f"""select cast(max(to_date(audit_inserted_ts,'yyyy-MM-dd')) as string) from idf_Raw_{env}.ecr_economic_data.t_process_control where process_id = {process_id}""").collect()[0][0]
        print(f"Previous proceesed Date: {previous_processs_date}")
        if current_date_str == previous_processs_date:
            process_control_details = spark.sql (f"""select process_status from idf_Raw_{env}.ecr_economic_data.t_process_control where  process_id={dependent_process_id} order by process_run_id desc""").first()['process_status']
            print("Job status is :", process_control_details)
            if process_control_details == "RUNNING":
                print("RUNNING")
                time.sleep(200)
                check_all_tables(dependency_table_list,process_id)
            else:
                print("success")
            print("Dependency Load Order jobs are not running")
        else:
            print(f"Current Date: {current_date_str} and Previous Process Date {previous_processs_date} are not same")
        
check_all_tables(dependency_table_list,process_id)
