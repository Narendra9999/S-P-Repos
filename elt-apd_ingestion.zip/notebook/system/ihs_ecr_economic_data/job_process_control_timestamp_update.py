# Databricks notebook source
dbutils.widgets.text(name="job_id",defaultValue="DefaultValue")
dbutils.widgets.text(name="job_start_time",defaultValue="DefaultValue")
dbutils.widgets.text(name="job_status",defaultValue="DefaultValue")
dbutils.widgets.text(name="process_id",defaultValue="DefaultValue")
dbutils.widgets.text(name="process_status",defaultValue="DefaultValue")
dbutils.widgets.text(name="process_start_time",defaultValue="DefaultValue")

# COMMAND ----------

import os
env = os.environ.get("aws_env")
metadata_schema=f"idf_raw_{env}.ecr_economic_data"
job_id=dbutils.widgets.get('job_id')
job_start_time=dbutils.widgets.get('job_start_time')
job_status=dbutils.widgets.get('job_status')
process_id=dbutils.widgets.get('process_id')
process_status=dbutils.widgets.get('process_status')
process_start_time=dbutils.widgets.get('process_start_time')



job_control_update_statement=f"update {metadata_schema}.t_job_control set job_start_time=cast(date_format('{job_start_time}', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where job_id={job_id}  and job_status='{job_status}'"

print(job_control_update_statement)

spark.sql(job_control_update_statement)



# COMMAND ----------

process_control_update_statement=f"update {metadata_schema}.t_process_control set process_start_time=cast(date_format('{process_start_time}', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where process_id={process_id}  and process_status='{process_status}'"
print(process_control_update_statement)

spark.sql(process_control_update_statement)

# COMMAND ----------


# update idf_raw_uat.ecr_economic_data.t_job_control set job_start_time=cast(date_format('2024-05-18 21:10:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where job_id=37  and job_status='NOT STARTED';

# update idf_raw_uat.ecr_economic_data.t_process_control set process_start_time=cast(date_format('2024-05-18 21:10:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where process_id=37  and process_status='NOT STARTED';

# update idf_raw_uat.ecr_economic_data.t_job_control set job_start_time=cast(date_format('2024-05-18 21:10:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where job_id=37  and job_status='NOT STARTED';
# update idf_raw_uat.ecr_economic_data.t_process_control set process_start_time=cast(date_format('2024-05-18 21:10:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where process_id=37  and process_status='NOT STARTED';
 
# update idf_raw_uat.ecr_economic_data.t_job_control set job_start_time=cast(date_format('2024-05-18 20:00:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where job_id=38  and job_status='NOT STARTED';
# update idf_raw_uat.ecr_economic_data.t_process_control set process_start_time=cast(date_format('2024-05-18 20:00:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where process_id=38  and process_status='NOT STARTED';
 
# update idf_raw_uat.ecr_economic_data.t_job_control set job_start_time=cast(date_format('2024-05-18 20:40:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where job_id=39  and job_status='NOT STARTED';
# update idf_raw_uat.ecr_economic_data.t_process_control set process_start_time=cast(date_format('2024-05-18 20:40:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where process_id=39  and process_status='NOT STARTED';
 
# update idf_raw_uat.ecr_economic_data.t_job_control set job_start_time=cast(date_format('2024-05-18 21:30:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where job_id=40  and job_status='NOT STARTED';
# update idf_raw_uat.ecr_economic_data.t_process_control set process_start_time=cast(date_format('2024-05-18 21:30:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where process_id=40  and process_status='NOT STARTED';
 
# update idf_raw_uat.ecr_economic_data.t_job_control set job_start_time=cast(date_format('2024-05-18 22:20:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where job_id=41  and job_status='NOT STARTED';
# update idf_raw_uat.ecr_economic_data.t_process_control set process_start_time=cast(date_format('2024-05-18 22:20:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where process_id=41  and process_status='NOT STARTED';
 
# update idf_raw_uat.ecr_economic_data.t_job_control set job_start_time=cast(date_format('2024-05-18 20:50:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where job_id=42  and job_status='NOT STARTED';
# update idf_raw_uat.ecr_economic_data.t_process_control set process_start_time=cast(date_format('2024-05-18 20:50:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where process_id=42  and process_status='NOT STARTED';
 
# update idf_raw_uat.ecr_economic_data.t_job_control set job_start_time=cast(date_format('2024-05-18 21:50:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where job_id=43  and job_status='NOT STARTED';
# update idf_raw_uat.ecr_economic_data.t_process_control set process_start_time=cast(date_format('2024-05-18 21:50:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where process_id=43  and process_status='NOT STARTED';
 
# update idf_raw_uat.ecr_economic_data.t_job_control set job_start_time=cast(date_format('2024-05-18 22:10:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where job_id=44  and job_status='NOT STARTED';
# update idf_raw_uat.ecr_economic_data.t_process_control set process_start_time=cast(date_format('2024-05-18 22:10:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where process_id=44  and process_status='NOT STARTED';
 
# update idf_raw_uat.ecr_economic_data.t_job_control set job_start_time=cast(date_format('2024-05-18 21:20:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where job_id=45  and job_status='NOT STARTED';
# update idf_raw_uat.ecr_economic_data.t_process_control set process_start_time=cast(date_format('2024-05-18 21:20:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where process_id=45  and process_status='NOT STARTED';
 
# update idf_raw_uat.ecr_economic_data.t_job_control set job_start_time=cast(date_format('2024-05-18 20:10:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where job_id=46  and job_status='NOT STARTED';
# update idf_raw_uat.ecr_economic_data.t_process_control set process_start_time=cast(date_format('2024-05-18 20:10:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where process_id=46  and process_status='NOT STARTED';
 
# update idf_raw_uat.ecr_economic_data.t_job_control set job_start_time=cast(date_format('2024-05-18 21:40:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where job_id=47  and job_status='NOT STARTED';
# update idf_raw_uat.ecr_economic_data.t_process_control set process_start_time=cast(date_format('2024-05-18 21:40:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where process_id=47  and process_status='NOT STARTED';
 
# update idf_raw_uat.ecr_economic_data.t_job_control set job_start_time=cast(date_format('2024-05-18 20:30:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where job_id=48  and job_status='NOT STARTED';
# update idf_raw_uat.ecr_economic_data.t_process_control set process_start_time=cast(date_format('2024-05-18 20:30:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where process_id=48  and process_status='NOT STARTED';
 
# update idf_raw_uat.ecr_economic_data.t_job_control set job_start_time=cast(date_format('2024-05-18 20:20:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where job_id=49  and job_status='NOT STARTED';
# update idf_raw_uat.ecr_economic_data.t_process_control set process_start_time=cast(date_format('2024-05-18 20:20:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where process_id=49  and process_status='NOT STARTED';
 
# update idf_raw_uat.ecr_economic_data.t_job_control set job_start_time=cast(date_format('2024-05-18 21:00:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where job_id=50  and job_status='NOT STARTED';
# update idf_raw_uat.ecr_economic_data.t_process_control set process_start_time=cast(date_format('2024-05-18 21:00:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where process_id=50  and process_status='NOT STARTED';
 
# update idf_raw_uat.ecr_economic_data.t_job_control set job_start_time=cast(date_format('2024-05-18 22:40:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where job_id=56  and job_status='NOT STARTED';
# update idf_raw_uat.ecr_economic_data.t_process_control set process_start_time=cast(date_format('2024-05-18 22:40:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where process_id=56  and process_status='NOT STARTED';
 
# update idf_raw_uat.ecr_economic_data.t_job_control set job_start_time=cast(date_format('2024-05-18 22:00:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where job_id=52  and job_status='NOT STARTED';
# update idf_raw_uat.ecr_economic_data.t_process_control set process_start_time=cast(date_format('2024-05-18 22:00:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where process_id=52  and process_status='NOT STARTED';
 
# update idf_raw_uat.ecr_economic_data.t_job_control set job_start_time=cast(date_format('2024-05-18 22:30:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where job_id=53  and job_status='NOT STARTED';
# update idf_raw_uat.ecr_economic_data.t_process_control set process_start_time=cast(date_format('2024-05-18 22:30:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where process_id=53  and process_status='NOT STARTED';
 
# update idf_raw_uat.ecr_economic_data.t_job_control set job_start_time=cast(date_format('2024-05-18 22:50:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where job_id=54  and job_status='NOT STARTED';
# update idf_raw_uat.ecr_economic_data.t_process_control set process_start_time=cast(date_format('2024-05-18 22:50:00.000', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where process_id=54  and process_status='NOT STARTED';
