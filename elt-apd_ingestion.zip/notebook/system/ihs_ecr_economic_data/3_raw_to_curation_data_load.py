# Databricks notebook source
# MAGIC %run  ../../../library/0_Common_job_utilities

# COMMAND ----------

dbutils.widgets.text(name="table_name",defaultValue="DefaultValue")


# COMMAND ----------

import json,os

table_name=dbutils.widgets.get('table_name')


env = os.environ.get("aws_env")
metadata_schema=f"idf_raw_{env}.ecr_economic_data"

s3_bucket=f"spr-idf-{env}-platform-config"
file_path = f"platform/config/ihs_ecr_economic_data/{table_name}.json"
json_obj=json.loads(read_s3_to_dict(s3_bucket,file_path))
job_id=json_obj['job_id']
process_id=json_obj['process_id']
print(json_obj)

# COMMAND ----------

# import json,os

# table_name=dbutils.widgets.get('table_name')


# env = os.environ.get("aws_env")
# metadata_schema=f"idf_raw_{env}.ecr_economic_data"

# s3_bucket=f"spr-idf-{env}-platform-config"
# file_path = f"streaming_checkpoint/ihs_ecr_economic_data/{table_name}.json"
# json_obj=json.loads(read_s3_to_dict(s3_bucket,file_path))
# job_id=json_obj['job_id']
# process_id=json_obj['process_id']
# print(json_obj)

# COMMAND ----------

### Fetching active job_run_id ###

ret_code,job_run_id = fetch_job_run_id(job_id,metadata_schema,process_id)
job_run_id = job_run_id[0][0]
print(job_run_id)
job_name,job_desc,job_dependencies,job_source_schema,job_target_schema,job_freq = fetch_job_metadata(job_id=job_id,schema=metadata_schema)
print(job_name[0])
# file_path = f"./config/{job_name[0].lower()}.json"

### Setting json file Variables ####
# json_obj = read_json_file(file_path)
target_column_mapping=json_obj['target_to_source_mapping']
table_name = json_obj['table_name']
key_columns = json_obj['keys']
surrogate_key=json_obj['surrogate_key']
ignore_columns = json_obj['ignorable_columns']
audit_columns = json_obj['audit_columns']
raw_table = job_source_schema[0]+"."+json_obj['raw_table']
column_transformations = json_obj.get('column_transformations', [])

#raw_table=raw_table+"_temp"
curated_table_path = json_obj['curated_table_path']
print(job_source_schema)
print(raw_table)

### Fetching active process_run_id
print(f"process_id is {process_id}, job_run_id is {job_run_id}")
process_ret_code,process_run_id = fetch_process_run_id(job_run_id,metadata_schema,process_id)
print(f"process_run_id is {process_run_id}")


### Fetching Process Metadata ###
incremental_start_ts= fetch_process_control_start_time(job_run_id,process_id,process_run_id,metadata_schema)
incremental_start_ts= incremental_start_ts.astype(str)
print(f"incremental_start_ts is {incremental_start_ts}")

process_name,process_source_schema,process_target_schema,process_freq,process_load_type,process_keys=fetch_process_metadata(process_id,job_id,metadata_schema)

process_name=process_name[0]
source_schema=process_source_schema[0]
target_schema=process_target_schema[0]
load_type=process_load_type[0]
freq=process_freq[0]
keys=",".join(key for key in process_keys)
print(keys)
print(target_column_mapping)
print(load_type)


# COMMAND ----------

# MAGIC %md
# MAGIC ### Fetching Metadata from config and process control tables

# COMMAND ----------

import json
if load_type=='delta_upsert_type_1':
    result= dbutils.notebook.run("../../../common/type_1_data_load_with_lookup", 1500,{'table_name':table_name,'metadata_schema':metadata_schema})
elif load_type=='full_load_scd_type_2':
    result= dbutils.notebook.run("../../../common/full_load_scd_type_2", 15000,{'table_name':table_name,'metadata_schema':metadata_schema})
elif load_type=='scd_type_1_data_load_with_historical_seggregation':
    result= dbutils.notebook.run("../../../common/scd_type_1_data_load_with_historical_seggregation", 3000,{'table_name':table_name,'metadata_schema':metadata_schema})
elif load_type=='incremental_load_scd_type_2':
    result= dbutils.notebook.run("../../../common/incremental_load_scd_type_2", 15000,{'table_name':table_name,'metadata_schema':metadata_schema})

print(result)

result=json.loads(result.replace("'","\""))
if result["status_code"]==0:
    dbutils.notebook.exit(0)
else:
    print(f"Loading the data failed for process_id-{process_id}")
    raise
