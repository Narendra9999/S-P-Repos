# Databricks notebook source
# MAGIC %run ../../../library/0_Common_job_utilities

# COMMAND ----------

dbutils.widgets.text(name="job_id",defaultValue="DefaultValue")
dbutils.widgets.text(name="job_run_id",defaultValue="DefaultValue")
dbutils.widgets.text(name="process_id",defaultValue="DefaultValue")
dbutils.widgets.text(name="process_run_id",defaultValue="DefaultValue")

# COMMAND ----------

import os,json

env = os.environ.get("aws_env")

from pyspark.dbutils import DBUtils

job_id = dbutils.widgets.get("job_id")
job_run_id =dbutils.widgets.get("job_run_id")
process_id = dbutils.widgets.get("process_id")
process_run_id =dbutils.widgets.get("process_run_id")


if (job_id=="DefaultValue"  or job_run_id=="DefaultValue" or process_id=="DefaultValue"  or process_run_id=="DefaultValue"):
    dbutils.notebook.exit("Notebook parameter are not provided")

# COMMAND ----------

select_statement = spark.sql(f"""select * from idf_Raw_{env}.ecr_economic_data.t_job_control where job_id = {job_id} and job_run_id in(select max(job_run_id) from idf_Raw_{env}.ecr_economic_data.t_job_control where job_id = {job_id})""")
select_statement.show()

# COMMAND ----------

spark.sql(f"""update idf_Raw_{env}.ecr_economic_data.t_job_control 
set job_status = 'NOT STARTED'
where job_id = '{job_id}' and job_run_id = '{job_run_id}'""")


# COMMAND ----------

# MAGIC %md
# MAGIC PROCESS CONTROL

# COMMAND ----------

select_statement = spark.sql(f"""select * from idf_Raw_{env}.ecr_economic_data.t_process_control where process_id = {process_id} and job_run_id = (job_run_id)""")
select_statement.show()

# COMMAND ----------

spark.sql(f"""update idf_Raw_{env}.ecr_economic_data.t_process_control
set process_status = 'NOT STARTED'
where process_id = '{process_id}' and job_run_id = '{job_run_id}' and  process_run_id = '{process_run_id}'""")

