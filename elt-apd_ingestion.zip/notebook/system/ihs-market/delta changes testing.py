# Databricks notebook source
table_name='v_ecrbank'
source_schema='idf_raw_dev.ecr_economic_data'
target_schema='idf_curated_dev.ecr_economic_data'
source_df=spark.read.table(f"{source_schema}.{table_name}").show()

# COMMAND ----------

#writing the source data to a temp table
temp_table_name=table_name+"_temp"
source_df.write.format('delta').mode('overwrite').saveAsTable(f"{source_schema}.{temp_table_name}")

# COMMAND ----------

temp_df=spark.read.table(f"{source_schema}.{temp_table_name}").show(10)

### Updating the few columns in temp datafram

# COMMAND ----------



records_to_update= spark.sql(f'select * from {source_schema}.{table_name} where orderunderparent in (2,4)').count()
print(records_to_update)
records_to_delete=spark.sql(f"select * from {source_schema}.{table_name} where bankid ='CONSENTH'").count()
print(records_to_delete)


# COMMAND ----------

### Updating the few columns in temp dataframe
import datetime
current_time=str(datetime.datetime.utcnow())

update_statement=f'update {source_schema}.{temp_table_name} set orderunderparent=9876 where orderunderparent in (2,4)'
delete_statement=f"delete from {source_schema}.{temp_table_name} where bankid='CONSENTH'"
insert_satement=f"insert into {source_schema}.{temp_table_name} (bankid,modificationtime,name,orderunderparent,parentid,PACVERTOFEEDPOP) values ('YASHNA',cast(date_format('{current_time}','yyyy-MM-dd HH:mm:ss.SSS') as timestamp),'YASHASVI',2024,'1987',1992)"

# COMMAND ----------

#spark.sql(update_statement)
#spark.sql(delete_statement)
spark.sql(insert_satement)

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select count(*) from idf_curated_dev.ecr_economic_data.t_ecr_bank 

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from idf_raw_dev.ecr_economic_data.v_ecrbank
