# Databricks notebook source
# MAGIC %run  ../../../library/0_Common_job_utilities

# COMMAND ----------

dbutils.widgets.text(name="process_operation",defaultValue="DefaultValue")
dbutils.widgets.text(name="process_id",defaultValue="DefaultValue")
dbutils.widgets.text(name="process_status",defaultValue="DefaultValue")
dbutils.widgets.text(name="job_id",defaultValue="DefaultValue")
dbutils.widgets.text(name="metadata_schema",defaultValue="idf_raw_dev.ecr_economic_data")

# COMMAND ----------

from pyspark.dbutils import DBUtils

# job_config_dict=bytes_to_dict(read_s3_to_dict('spr-idf-dev-platform-stage','feeds/job_config/job_config.json'))

process_type =dbutils.widgets.get("process_operation")
process_id = dbutils.widgets.get("process_id")
job_id = dbutils.widgets.get("job_id")
metadata_schema=dbutils.widgets.get('metadata_schema')
process_status=dbutils.widgets.get('process_status')

if (job_id=="DefaultValue"  or process_id=="DefaultValue" or process_type=="DefaultValue"):
    dbutils.notebook.exit("Notebook parameter are not provided")

# COMMAND ----------


if process_type =='start':

    ret_code,process_run_id = process_start(int(job_id),metadata_schema,int(process_id))
    process_run_id = process_run_id
    #process_version = process_version
    if ret_code == 0:
        print('process started successfully!')

    else:
        print('process start failed !! there is an existing process in running state.')
        dbutils.notebook.exit("process start failed !! there is an existing process in running state.")
    

elif process_type == 'end':
    process_status = "completed"

    ret_code,job_run_id = fetch_job_run_id(job_id,metadata_schema,process_id)
    print(job_run_id)
    job_run_id =job_run_id[0][0]
    if process_status == 'DefaultValue' or job_run_id=='DefaultValue':
        dbutils.notebook.exit('process_status parameter or job_run_id parameter is not provided.')

    status = process_end(job_id,int(job_run_id),metadata_schema,int(process_id),process_status)

else:
    print('invalid job_type')
    status = 2

# COMMAND ----------

# %sql 
# select max(job_run_id) from idf_raw_dev.ecr_economic_data.t_job_control where job_id in (select job_id from idf_raw_dev.ecr_economic_data.t_process_metadata where process_id =1 ) and job_status='RUNNING'
