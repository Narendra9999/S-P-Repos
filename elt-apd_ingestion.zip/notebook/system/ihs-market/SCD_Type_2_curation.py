# Databricks notebook source
source_cols = source_df.columns
audit_cols = ['audit_job_id','audit_dml_action_cd','current_record_ind','audit_inserted_ts','audit_updated_ts','eff_ts','exp_ts','eff_dt','exp_dt']
target_cols = source_cols + audit_cols
key_cols = 'product_id'
audit_job_id =2
source_path='s3://spr-idf-dev-platform-landing/catalog/posttrade/raw_product_details'
target_path="s3://spr-idf-dev-platform-landing/catalog/posttrade/curated_product_details"
for old_name, new_name in column_mapping.items():
    outputDF2 = outputDF2.withColumnRenamed(old_name, new_name)


# COMMAND ----------


import json
from datetime import datetime
import datetime as dt
from pyspark import SparkConf
from pyspark.context import SparkContext
from pyspark.sql.functions import *
from pyspark.sql.window import *
from pyspark import StorageLevel
from pyspark.sql.types import StringType
import hashlib, sys, operator, logging, json, time, math, os, stat, requests, logging
from pyspark.sql.types import StructType
from pyspark.sql.functions import from_json, col
import pyspark.sql.types as t
import traceback
# Turning default logger info off
logging.getLogger("py4j").setLevel(logging.ERROR)


INCR_TS_STRING = "2023-03-29 12:34:00"
AUDIT_JOB_ID = 3
table_name = "curated_product_details"
source_name = 'raw_product_details'
exp_ts = "9999-12-31 11:59:59"

# Initializing logger
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', datefmt='%Y-%m-%d %H:%M:%S')
logger = logging.getLogger(table_name)
logger.info("Logger initialized")

#Prepare incremental start and end dates
incr_date_string = INCR_TS_STRING[:10]
incr_date = datetime.strptime(incr_date_string,'%Y-%m-%d')
print("Printing incremental start date ")
print(incr_date,incr_date_string)
incr_ts = incr_date_string + ' 00:00:00'
expire_day = (incr_date - dt.timedelta(days=1)).strftime('%Y-%m-%d')
expire_ts = expire_day+' 23:59:59'
day_id = incr_date_string
audit_columns = 'purchased_at,audit_dml_action_cd,audit_job_id,audit_inserted_ts,audit_updated_ts,current_record_ind,eff_dt,eff_ts,exp_ts,exp_dt'.split(',')

source_path='s3://spr-idf-dev-platform-landing/catalog/posttrade/raw_product_details'
destination="s3://spr-idf-dev-platform-landing/catalog/posttrade/curated_product_details"
tmp_dir = "s3://spr-idf-dev-platform-stage/feeds/posttrade/tmp_product_details"


logger.info("SOURCE_PATH : {}, DESTINATION : {}, TMP_DIR : {} ".format(source_path, destination, tmp_dir))


NK = key_cols
  
key_columns = NK.split(',')
logger.info("Natural key for table is  : {}".format(NK))


# Function to generate hashkey
def digest(in_str):
  return hashlib.md5(in_str.encode('utf-8')).hexdigest()
digest_udf = udf(digest, StringType())

# Function to check if active partition is empty
def file_exists(path):
  try:
    dbutils.fs.ls(path)
    return True
  except Exception as e:
    if 'java.io.FileNotFoundException' in str(e):
      return False
    else:
      raise



if file_exists(source_path):
  logger.info("Data present in landing path for table {} for the day_id:{} ".format(table_name,day_id))
else:
  if table_name in skip_depenency_list:
    ## temporary raise value error to resolve issues , will comment out below line
    #raise ValueError("There is no data present in landing path for table {} for the day_id:{} ".format(table_name,day_id))
    logger.info("Table is part of skip dependency list, so we can skip dependecy of landing files and mark the job as succeeded.")
    return_values = {"STATUS":"No Data in landing zone", "SOURCE_COUNT":0, "TARGET_COUNT":0, "EXPIRED_COUNT":0, "UNCHANGED_COUNT":0, "UPDATED_COUNT":0}
    dbutils.notebook.exit(return_values)
  elif file_exists(backfill_source_path):
    logger.info("Data present in backfill landing path for table {} for the day_id:{} ".format(table_name,day_id))
    source_path = backfill_source_path
  else:
    logger.info("There is no data present in landing path for table {} for the day_id:{} ".format(table_name,day_id))
    raise ValueError("There is no data present in landing path for table {} for the day_id:{} ".format(table_name,day_id))

# COMMAND ----------

# DBTITLE 1,ref type 2 code
logger.info("Started running ref template  for table {} for the day_id:{} ".format(table_name,day_id))
try:
    # Reading input data
    logger.info("Reading input data")
    input_df = spark.read.format("delta").load(source_path)
    INPUT_COUNT = input_df.count()
    active_partition = "exp_dt = '9999-12-31'"
    if not file_exists('{}/exp_dt=9999-12-31'.format(destination)):
        logger.info("PA is empty, job running for 1st time")
        df_active = input_df.withColumn("source_name",lit(source_name)).withColumn("audit_dml_action_cd",lit("I")).withColumn("audit_job_id",lit(AUDIT_JOB_ID)).withColumn("audit_inserted_ts",lit(current_timestamp())).withColumn("audit_updated_ts",lit(current_timestamp())).withColumn("current_record_ind",lit("Y")).withColumn("eff_dt",lit(incr_date_string).cast('date')).withColumn("eff_ts",lit(incr_ts).cast("timestamp")).withColumn("exp_ts",lit(exp_ts).cast("timestamp")).withColumn('exp_dt',lit('9999-12-31').cast('date'))
        source_cols=[x.lower() for x in df_active.columns]
        complete_df = df_active
        for c in (set(target_schema_json.keys()) - set(source_cols)):
            complete_df = complete_df.withColumn(c, lit(None).cast(target_schema_json.get(c)))
        casted_df = complete_df.select([ col(c).cast(target_schema_json.get(c)) for c in sorted(target_schema_json.keys()) ])
        casted_df.cache()
        ACTIVE_COUNT = casted_df.count()
        partition = "exp_dt = '9999-12-31'"
        logger.info("i am here")
        casted_df.write.mode('overwrite').format('delta').option("replaceWhere", active_partition).save(destination)
        return_values = {"STATUS":"SUCCESS", "SOURCE_COUNT":INPUT_COUNT, "TARGET_COUNT":ACTIVE_COUNT, "EXPIRED_COUNT":0, "UNCHANGED_COUNT":0, "UPDATED_COUNT":0}
    else:
        source_cols=[x.lower() for x in input_df.columns]
        casted_src = input_df
        for c in (set(target_schema_json.keys()) - set(source_cols)):
            casted_src = casted_src.withColumn(c, lit(None).cast(target_schema_json.get(c)))
        casted_df = casted_src.select([ col(c).cast(target_schema_json.get(c)) for c in target_schema_json.keys() ])
        casted_df.repartition(1).write.mode('overwrite').format('delta').save('{}'.format(tmp_dir))
        processed_src_df = spark.read.format('delta').load('{}'.format(tmp_dir))
        logger.info("Reading data from taget active path")
        tgt_raw = spark.read.format('delta').load('{}'.format(destination)).filter(col('exp_dt')=='9999-12-31')
        logger.info("Cast target columns")
        tgt = tgt_raw.select([ col(c).cast(target_schema_json.get(c)) for c in target_schema_json.keys() ])
        tgt.printSchema()
        value_columns = set(tgt.columns) - set(audit_columns) - set(key_columns)
        hashed_src = processed_src_df.withColumn("value_hash", digest_udf(concat_ws('||', *value_columns))).withColumn("key_hash", digest_udf(concat_ws('||', *key_columns))).alias('src').withColumn('cdc_order', lit(2))
        hashed_tgt = tgt.withColumn("value_hash", digest_udf(concat_ws('||', *value_columns))).withColumn("key_hash", digest_udf(concat_ws('||', *key_columns))).alias('tgt').withColumn('cdc_order', lit(1))
        unionDf = hashed_src.union(hashed_tgt) .withColumn("last_value_hash",lag(col("value_hash"), 1).over(Window.partitionBy(*key_columns).orderBy(asc("cdc_order")))).withColumn("next_value_hash",lead(col("value_hash"), 1).over(Window.partitionBy(*key_columns).orderBy(asc("cdc_order"))))
        unionDf.createOrReplaceTempView("unionDf_T")
        final_df=spark.sql("\
                  select *, \
                  case when last_value_hash is null and next_value_hash is null and cdc_order=2 then 'new' \
                  when last_value_hash is null and next_value_hash is null and cdc_order=1 then 'deleted' \
                  when last_value_hash is not null and value_hash!=last_value_hash then 'changed_new' \
                  when next_value_hash is not null and value_hash!=next_value_hash then 'changed_old' \
                  when next_value_hash is not null and value_hash=next_value_hash then 'unchanged' \
                  else null end as cdc_code \
                  from unionDf_T").drop("cdc_order", "last_value_hash", "next_value_hash", "value_hash", "key_hash")
        final_df.cache()
        new_df = final_df.filter(col("cdc_code")==lit("new")).withColumn("audit_dml_action_cd",lit("I")).withColumn("audit_job_id",lit(AUDIT_JOB_ID)).withColumn("audit_inserted_ts",lit(current_timestamp())).withColumn("audit_updated_ts",lit(current_timestamp())).withColumn("current_record_ind",lit("Y")).withColumn("eff_dt",lit(incr_date_string).cast('date')).withColumn("eff_ts",lit(incr_ts).cast("timestamp")).withColumn("exp_ts",lit(exp_ts).cast("timestamp"))
        new_df.printSchema()
        new_df_cols=new_df.columns
        logger.info("Fetching unchanged records")
        unchanged_df_cols= final_df.filter(col("cdc_code")==lit("unchanged")).columns
        logger.info(f'unchanged_column list {unchanged_df_cols}')
        logger.info(f'new cols list. {new_df_cols}')
        unchanged_df = final_df.filter(col("cdc_code")==lit("unchanged"))
        unchanged_df.cache()
        UNCHANGED_COUNT = unchanged_df.count()
        logger.info("Fetching changed records")
        changed_new_df = final_df.filter(col("cdc_code")==lit("changed_new")).withColumn("audit_dml_action_cd",lit("U")).withColumn("audit_job_id",lit(AUDIT_JOB_ID)).withColumn("audit_inserted_ts",lit(current_timestamp())).withColumn("audit_updated_ts",lit(current_timestamp())).withColumn("current_record_ind",lit("Y")).withColumn("eff_dt",lit(incr_date_string).cast('date')).withColumn("eff_ts",lit(incr_ts).cast("timestamp")).withColumn("exp_ts",lit(exp_ts).cast("timestamp"))
        changed_new_df.cache()
        UPDATED_COUNT = changed_new_df.count()
        changed_old_df = final_df.filter(col("cdc_code")==lit("changed_old")).withColumn("audit_updated_ts",lit(current_timestamp())).withColumn("current_record_ind",lit("N")).withColumn("exp_ts",lit(expire_ts).cast("timestamp"))
        deleted_df     = final_df.filter(col("cdc_code")==lit("deleted")).withColumn("audit_updated_ts",lit(current_timestamp())). withColumn("current_record_ind",lit("N")).withColumn("audit_dml_action_cd",lit("D")).withColumn("exp_ts",lit(expire_ts).cast("timestamp"))
        deleted_df.cache()
        logger.info("Fetching deleted records")
        DELETED_COUNT = deleted_df.count()
        logger.info("Fetching active records")
        active_df = new_df.union(unchanged_df).union(changed_new_df).drop('cdc_code')
        logger.info("Fetching history records")
        history_df = changed_old_df.union(deleted_df).drop('cdc_code')
        history_partition = f"exp_dt = '{day_id}'"
        active_df = active_df.select([ col(c).cast(target_schema_json.get(c)) for c in sorted(target_schema_json.keys()) ]).withColumn('exp_dt',lit('9999-12-31').cast('date'))
        history_df = history_df.select([ col(c).cast(target_schema_json.get(c)) for c in sorted(target_schema_json.keys()) ]).withColumn('exp_dt',lit(day_id).cast('date'))
        
        # Writing to Temp path before writing to actual path
        active_df.cache()
        ACTIVE_COUNT = active_df.count()
        active_df.repartition(1).write.mode('overwrite').format('delta').save('{}/exp_dt=9999-12-31'.format(tmp_dir))
        
        # Writing to actual path
        if INPUT_COUNT == ACTIVE_COUNT:
            logger.info(f'history partition is  {history_partition}')
            history_df.repartition(1).write.mode('append').format('delta').option("replaceWhere", history_partition).save('{}'.format(destination))
            active_df_temp = spark.read.format('delta').load('{}/exp_dt=9999-12-31'.format(tmp_dir))
            active_df_temp.repartition(1).write.mode('overwrite').option("partitionOverwriteMode", "dynamic").format('delta').save('{}'.format(destination))
        else:
            logger.info("Input count from source and final active count that will be written into target is not matching, SOURCE_COUNT : {}, ACTIVE_COUNT : {}".format(INPUT_COUNT, ACTIVE_COUNT))
            raise ValueError("Input count from source and final active count that will be written into target is not matching, SOURCE_COUNT : {}, ACTIVE_COUNT : {}".format(INPUT_COUNT, ACTIVE_COUNT))
        
        return_values = {"STATUS":"SUCCESS", "SOURCE_COUNT":INPUT_COUNT, "TARGET_COUNT":ACTIVE_COUNT, "EXPIRED_COUNT":DELETED_COUNT, "UNCHANGED_COUNT":UNCHANGED_COUNT, "UPDATED_COUNT":UPDATED_COUNT}
        print(return_values)
    logger.info("Table : {} load completed successfully".format(table_name))
except Exception as e:
    logger.info("Type-2 execution failed for table : {} with error : {}".format(table_name, e))
    logger.info(traceback.format_exc())
    raise

# COMMAND ----------

# DBTITLE 1,return the DQ results
dbutils.notebook.exit(return_values)


# COMMAND ----------


