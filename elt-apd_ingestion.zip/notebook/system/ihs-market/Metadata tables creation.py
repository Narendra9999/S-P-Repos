# Databricks notebook source
# MAGIC %md
# MAGIC ### Creating job control table for version management

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace table idf_raw_dev.ecr_economic_data.t_job_metadata (
# MAGIC   job_id long GENERATED ALWAYS AS IDENTITY,
# MAGIC   job_name varchar(100),
# MAGIC   job_desc varchar(200),
# MAGIC   job_dependencies varchar(3000),
# MAGIC   job_source_schema varchar(200),
# MAGIC   job_target_schema varchar(300),
# MAGIC   job_freq int,
# MAGIC   dq_enabled varchar(10),
# MAGIC   dq_id  varchar(1000),
# MAGIC   audit_insert_id varchar(200),
# MAGIC   audit_updated_id varchar(200)
# MAGIC )
# MAGIC using delta
# MAGIC LOCATION 's3://spr-idf-dev-platform-landing/catalog/ecr_economic_data/job_metadata'
# MAGIC tblproperties ('delta.enableChangeDataFeed'=True)

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace table idf_raw_dev.ecr_economic_data.t_job_control (
# MAGIC   job_id long,
# MAGIC   job_run_id long GENERATED ALWAYS AS IDENTITY,
# MAGIC   job_start_time timestamp,
# MAGIC   job_end_time timestamp,
# MAGIC   job_status varchar(200),
# MAGIC   job_freq int,
# MAGIC   audit_inserted_ts timestamp,
# MAGIC   audit_updated_ts timestamp,
# MAGIC   audit_insert_id varchar(200),
# MAGIC   audit_updated_id varchar(200)
# MAGIC )
# MAGIC using delta
# MAGIC LOCATION 's3://spr-idf-dev-platform-landing/catalog/ecr_economic_data/job_control'
# MAGIC TBLPROPERTIES('delta.minReaderVersion' = 3, 'delta.minWriterVersion' = 7)

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace table idf_raw_dev.ecr_economic_data.t_process_metadata (
# MAGIC   process_id long GENERATED ALWAYS AS IDENTITY,
# MAGIC   job_id long,
# MAGIC   process_name varchar(100),
# MAGIC   process_source_schema varchar(200),
# MAGIC   process_target_schema varchar(200),
# MAGIC   process_dependencies varchar(300),
# MAGIC   process_freq long,
# MAGIC   process_load_type varchar(300),
# MAGIC   process_keys varchar(300),
# MAGIC   audit_insert_id varchar(200),
# MAGIC   audit_updated_id varchar(200)
# MAGIC )
# MAGIC using delta
# MAGIC LOCATION 's3://spr-idf-dev-platform-landing/catalog/ecr_economic_data/process_metadata'
# MAGIC tblproperties ('delta.enableChangeDataFeed'=True)

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace table idf_raw_dev.ecr_economic_data.t_process_control (
# MAGIC   process_run_id long GENERATED ALWAYS AS IDENTITY,
# MAGIC   process_id long,
# MAGIC   job_run_id long,
# MAGIC   process_name varchar(100),
# MAGIC   process_start_time timestamp,
# MAGIC   process_end_time timestamp,
# MAGIC   process_status varchar(200),
# MAGIC   process_source_counts varchar(4),
# MAGIC   process_target_counts  varchar(1000),
# MAGIC   process_dq_id int,
# MAGIC   process_freq int,
# MAGIC   audit_inserted_ts timestamp,
# MAGIC   audit_updated_ts timestamp,
# MAGIC   audit_insert_id varchar(200),
# MAGIC   audit_updated_id varchar(200)
# MAGIC )
# MAGIC using delta
# MAGIC LOCATION 's3://spr-idf-dev-platform-landing/catalog/ecr_economic_data/process_control'
# MAGIC tblproperties ('delta.enableChangeDataFeed'=True)

# COMMAND ----------

# MAGIC %sql
# MAGIC -- create table version_control (
# MAGIC --   version_id int,
# MAGIC --   task_id int,
# MAGIC --   job_id int,
# MAGIC --   feed_name varchar(100),
# MAGIC --   feed_date timestamp,
# MAGIC --   processed_date timestamp,
# MAGIC --   feed_type varchar(4),
# MAGIC --   feed_status  varchar(1000),
# MAGIC --   feed_counts int,
# MAGIC --   audit_insert_id varchar(200),
# MAGIC --   audit_updated_id varchar(200)
# MAGIC -- )
# MAGIC -- using delta
# MAGIC -- LOCATION 's3://spr-idf-dev-platform-landing/catalog/posttrade/version_control'
# MAGIC -- tblproperties ('delta.enableChangeDataFeed'=True)

# COMMAND ----------

### JOB START ENTRY
### JOB END ENTRY as separate notebooks
###  PROCESS CONTROL at beginning and end of each task
### Reading job and process control entries across different steps

# COMMAND ----------

from pyspark.sql.functions import current_timestamp

# COMMAND ----------

# MAGIC %md
# MAGIC #### Raw layer process entry

# COMMAND ----------

# MAGIC %md
# MAGIC #### Curated layer process entry

# COMMAND ----------


