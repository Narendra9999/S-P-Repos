# Databricks notebook source
# MAGIC %run  ../../../library/0_Common_job_utilities

# COMMAND ----------

dbutils.widgets.text(name="job_operation",defaultValue="DefaultValue")
dbutils.widgets.text(name="job_id",defaultValue="DefaultValue")
dbutils.widgets.text(name="job_status",defaultValue="DefaultValue")

# COMMAND ----------

from pyspark.dbutils import DBUtils

job_operation =dbutils.widgets.get("job_operation")
job_id = dbutils.widgets.get("job_id")

if (job_id=="DefaultValue"  or job_operation=="DefaultValue"):
    dbutils.notebook.exit("Notebook parameter are not provided")

# COMMAND ----------

job_config_dict={}
schema="idf_raw_dev.ecr_economic_data"
job_config_dict['job_id'] =job_id
if job_operation =='start':
    ret_code,job_run_id=job_start(job_id,schema)
    if ret_code==0:
        job_config_dict['job_start_status']= 'success'
        job_config_dict['job_run_id']= job_run_id
    else:
        job_config_dict['job_start_status']= 'failed'

    
    #write_dict_to_s3('spr-idf-dev-platform-stage','feeds/job_config/job_config.json',job_config_dict)


elif job_operation == 'end':

    #job_config_dict= bytes_to_dict(read_s3_to_dict('spr-idf-dev-platform-stage','feeds/job_config/job_config.json'))
    job_status = 'COMPLETED'
    job_id = job_config_dict['job_id']
    if job_status is None:
        dbutils.notebook.exit('job_status parameter not provided.')
    job_status =dbutils.widgets.get("job_status")

    job_end(int(job_id),schema,job_status)
else:
    print('invalid job_type')

# COMMAND ----------


# statement= f"select * from idf_Raw_dev.ecr_economic_data.t_job_control"
# display(spark.sql("update idf_raw_dev.ecr_economic_data.t_job_control set job_end_time=cast(date_format('2024-04-29 20:43:16.260338', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp), job_status='RUNNING' where job_run_id=5"))


# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select * from idf_Raw_dev.ecr_economic_data.t_job_metadata

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from idf_raw_dev.ecr_economic_data.t_job_control where job_id=1
