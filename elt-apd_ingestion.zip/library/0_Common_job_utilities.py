# Databricks notebook source
# MAGIC %md
# MAGIC ### JOB START FUNCTION 
# MAGIC     1. Takes job_id from job_metadata table as input 
# MAGIC     2. Updates the status as running and job_start_time
# MAGIC     3. Validates if there is an existing job is running.
# MAGIC     4. returns job_status as output

# COMMAND ----------

from pyspark.sql import functions as F
import datetime
import numpy as np
from pyspark.sql.functions import current_timestamp
def job_control_entry(job_id,schema,job_start_time):

    ### -------- Check if there is an active job ----------

    max_job_run_id = spark.sql("select max(job_run_id) from {}.t_job_control where job_id={}".format(schema,job_id)).toPandas().T.values

    entry_type=""
    if np.isnan(max_job_run_id):
        print("No entry exists in the job control table")
        return 2

    else:
        print(max_job_run_id)

        status,job_freq= spark.sql('select job_status,job_freq from {}.t_job_control where job_run_id={}'.format(schema,max_job_run_id[0][0])).toPandas().T.values
    print(f'status in job_control_entry is {status}')
    #print(status)
    if status[0]=='COMPLETED':

        ### -------- insert the job control entry with the required details -------
        statement="insert into {}.t_job_control(job_id,job_start_time,job_end_time,job_status,job_freq,audit_insert_id,audit_updated_id) values ({},cast(date_format('{}', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp),null,'{}',{},'{}','{}')".format(schema,job_id,job_start_time,'NOT STARTED',job_freq[0],'nmerla','nmerla')
        print(statement)
        spark.sql(statement)
        job_run_id = spark.sql("select max(job_run_id) from {}.t_job_control where job_status='NOT STARTED' and job_id={}".format(schema,job_id)).toPandas().T.values

        print("job control entry is successful")
        print(job_run_id)
        return 0,job_run_id[0][0]
    else:
        print('job control entry failed as there is an active job or a failed job!')
        return 1,None

# COMMAND ----------

from pyspark.sql import functions as F
import datetime
import numpy as np
from pyspark.sql.functions import current_timestamp
def job_start(job_id,schema):
    job_run_id = spark.sql('select job_run_id from {}.t_job_control where job_id={} and job_status="NOT STARTED"'.format(schema,job_id)).toPandas().T.values

    if np.isnan(job_run_id):
        print("There is no entry in the job control table with status 'NOT STARTED' nor an active job is still running")
        return 2
    else:
        print('Job Entry found !! Updating the status of the job entry!')
        current_time=str(datetime.datetime.utcnow())
        job_run_id=job_run_id[0][0]
        update_stmt= f"update {schema}.t_job_control set job_status='RUNNING',audit_inserted_ts=cast(date_format('{current_time}', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp)  where job_run_id={job_run_id} and job_id={job_id}"
        
        try:
            print(update_stmt)
            spark.sql(update_stmt)
            print(f'job started successfully for job_id-{job_id} and job_run_id -{job_run_id}')
            return 0,job_run_id
        except:
            print(f'unable to update the job start for job_id ={job_id} and job_run_id-{job_run_id}')
            raise
            return 2,job_run_id

# COMMAND ----------

#display(spark.sql("select * from idf_raw_dev.ecr_economic_data.t_job_control limit 3"))

# COMMAND ----------

# MAGIC %md
# MAGIC ### JOB END FUNCTION 
# MAGIC     1. Takes job_id from job_metadata table and status from process as inputs
# MAGIC     2. Updates the status from running to respective state - failed/success/complete and updates job_end_time
# MAGIC     3. Check if there is an existing job is running.
# MAGIC     4. returns job_status as output

# COMMAND ----------

from pyspark.sql import functions as F
import datetime
from datetime import timedelta
from dateutil.parser import parse
import numpy as np
from pyspark.sql.functions import current_timestamp
def job_end(job_id,schema,job_complete_status):

    ### -------- Check if there is an active job ----------

    max_job_run_id = spark.sql("select max(job_run_id) from {}.t_job_control where job_id={}".format(schema,job_id)).toPandas().T.values

    entry_type=""
    if np.isnan(max_job_run_id):
        print("No entry exists in the job control table")
        entry_type="new"

    else:
        print(max_job_run_id)

        status,job_end_time = spark.sql('select job_status,job_end_time from {}.t_job_control where job_run_id={}'.format(schema,max_job_run_id[0][0])).toPandas().T.values

        entry_type='existing'
        print(status,job_end_time)
    
    if  status[0] =='RUNNING' and entry_type!='new':

        ### -------- Read the metadata for the respective job_id ----------
        df=spark.sql('select * from {}.t_job_metadata where job_id={}'.format(schema,job_id))
        job_id,job_name,job_desc,job_dependencies,job_source_schema,job_target_schema,job_freq,dq_enabled,dq_id,insert_id,updated_id =df.toPandas().T.values

        ### -------- insert the job control entry with the required details -------
        job_id= job_id[0]
        current_time=str(datetime.datetime.utcnow())
        statement="update {}.t_job_control set job_end_time=cast(date_format('{}', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp), job_status='{}',audit_updated_ts=cast(date_format('{}', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp) where job_run_id={}".format(schema,current_time,job_complete_status,current_time,max_job_run_id[0][0])
        print(statement)
        spark.sql(statement)

        print("job end completed successfully")
        print("creating the job control entry for the next day!!")
        sql_statement=f"select job_end_time from {schema}.t_job_control where job_run_id={max_job_run_id[0][0]} and job_id={job_id}"
        job_end_time=spark.sql(sql_statement).toPandas().T.values
        print(job_freq)
        print(job_end_time[0][0])
        job_end_time = job_end_time[0][0]
        
    
        # Add 168 hours (7 days) to the datetime object
        hours=int(job_freq[0])
        delta = np.timedelta64(hours, 'h')
        dt_plus_168_hours = job_end_time + delta
        print(dt_plus_168_hours)
        print(type(dt_plus_168_hours))
        # Convert the numpy.datetime64 object to a datetime object
        dt = pd.to_datetime(dt_plus_168_hours)

        # Convert the datetime object to an ISO format string
        job_start_time = dt.isoformat()
        try:
            ret_code,job_run_id= job_control_entry(job_id,schema,job_start_time)
            if ret_code!=0:
                print(ret_code, job_run_id)
                raise Exception
        
            return 0
        except:
            print('job end failed as there no an active job in running status!')
            return 1

# COMMAND ----------

# MAGIC %md
# MAGIC ### Process Control Start 
# MAGIC     1. take inputs - job_id,process_id
# MAGIC     2. insert an entry into process control table with job_id,job_run_id ,process_name,process_start
# MAGIC     3. validate if there is a existing process already running.
# MAGIC     4. return process_status as output

# COMMAND ----------

from pyspark.sql import functions as F
import datetime
import numpy as np
from pyspark.sql.functions import current_timestamp
def process_start(job_id,schema,process_id):

    ### -------- Check if there is an active job in process metadata ----------

    process_name,process_load_type =spark.sql("select process_name,process_load_type from {}.t_process_metadata where job_id={} and process_id={}".format(schema,job_id,process_id)).toPandas().T.values

    job_run_id = spark.sql("select max(job_run_id) from {}.t_job_control where job_id={} and job_status='RUNNING'".format(schema,job_id)).toPandas().T.values

    print(job_run_id[0][0])

    if np.isnan(job_run_id):
        print('No active job present. Please trigger job control entry before starting the process!')
        raise Exception
    else:
        print('Found active job!! job_run_id is'.format(job_run_id[0][0]))

    print(process_name)
    print('process id is {} and process name is {}'.format(process_id,process_name[0]))
    
    if  np.isnan(job_run_id) :
        print('No entry exists in  job metadata or process metadata table')
        raise Exception
    else:
        print('Fetched process id , validating if there is an active process running!!')
        
        process_run_id = spark.sql("select max(process_run_id) from {}.t_process_control where process_id={} and process_status='NOT STARTED'".format(schema,process_id)).toPandas().T.values

        print(process_run_id)
        
        process_run_id=process_run_id[0][0]

        if np.isnan(process_run_id):
            process_version=None
            print(f'No process exist in the process control table for process_run_id -{process_run_id}!!')
            raise Exception

        else:    
         ### -------- insert the job control entry with the required details -------
            job_run_id= job_run_id[0][0]
            current_time=str(datetime.datetime.utcnow())
            updt_statment= f"update {schema}.t_process_control set process_status='RUNNING',job_run_id={job_run_id} where process_run_id= {process_run_id} and process_id={process_id}"

            try:
                print(updt_statment)
                spark.sql(updt_statment)

                process_run_id = spark.sql("select max(process_run_id) from {}.t_process_control where process_status='RUNNING' and job_run_id={}".format(schema,job_run_id)).toPandas().T.values

                print("process start completed successfully")
                return 0,process_run_id[0][0]
            except:
                print('Error updating the process control status')
                raise Exception

# COMMAND ----------

from pyspark.sql import functions as F
import datetime
import numpy as np
from pyspark.sql.functions import current_timestamp
def process_control_entry(job_run_id,schema,process_id,process_start_time,table_delta_version):

    fetch_process_data=f"select process_name,process_freq from {schema}.t_process_control where process_id={process_id} and job_run_id={job_run_id}"
    process_name,process_freq=(spark.sql(fetch_process_data).toPandas().T.values)
    process_name=process_name[0]
    process_freq=process_freq[0]
    ### -------- insert the job control entry with the required details -------
    
    current_time=str(datetime.datetime.utcnow())
    statement="insert into {}.t_process_control(process_id,job_run_id,process_name,process_start_time,process_end_time,process_status,process_source_counts,process_target_counts,process_dq_id,process_freq,table_delta_version,audit_inserted_ts,audit_updated_ts,audit_insert_id,audit_updated_id) values ({},null,'{}',cast(date_format('{}', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp),null,'{}',null,null,null,{},{},cast(date_format('{}', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp),cast(date_format('{}', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp),'{}','{}')".format(schema,process_id,process_name,process_start_time,'NOT STARTED',process_freq,table_delta_version,current_time,current_time,'nmerla','nmerla')
    print(statement)
    try:
        spark.sql(statement)
        print("process Control entry for next load made  successfully")
        return 0
    except:
        print('Unable to make the entry into process control table.. check the statement below!')
        print(statement)
        return 1

# COMMAND ----------

# MAGIC %md
# MAGIC ### Process Control End 
# MAGIC     1. take inputs - job_run_id,process_id,process_status
# MAGIC     2. validate if there is a existing process already running.
# MAGIC     3. close the existing process with process_end_time and status field values.
# MAGIC     4. return process_task update as output

# COMMAND ----------

from pyspark.sql import functions as F
from datetime import datetime
import pandas as pd
import numpy as np
from pyspark.sql.functions import current_timestamp
def process_end(job_id,job_run_id,schema,process_id,process_status):

    ### -------- Check if there is an active job in process control table ----------

    process_run_id,process_freq,table_delta_version=spark.sql("select process_run_id,process_freq,table_delta_version from {}.t_process_control where process_id={} and job_run_id={} and process_status='RUNNING'".format(schema,process_id,job_run_id)).toPandas().T.values
    print(process_run_id)

    if np.isnan(table_delta_version) or  not table_delta_version.size >0 :
        print("table_delta_version is not set,so defaulting to 0")
        print(f"type of table_delta_version is {type(table_delta_version)}")
        table_delta_version = np.array([], dtype='int16')
        table_delta_version=np.append(table_delta_version,[0])


    if np.isnan(process_run_id):
        print('No active job present. Please trigger process control entry before ending the process!')
        print('process end failed as there is no active process in running status!')
        return 1
    else:
        print('Found active process!! process_run_id is'.format(process_run_id))
        ### -------- insert the process control entry with the required details -------
        process_run_id= process_run_id[0]
        table_delta_version = table_delta_version[0]
        current_time=str(datetime.datetime.utcnow())
        process_complete_status='completed'
        statement="update {}.t_process_control set process_end_time=cast(date_format('{}', 'yyyy-MM-dd HH:mm:ss.SSS') as timestamp), process_status='{}' where job_run_id={} and process_run_id={}".format(schema,current_time,process_complete_status,job_run_id,process_run_id)
        print(statement)
        spark.sql(statement)

        print("process end completed successfully")

        sql_statement=f"select process_end_time from {schema}.t_process_control where job_run_id={job_run_id} and process_run_id={process_run_id} and process_id={process_id}"
        process_end_time=spark.sql(sql_statement).toPandas().T.values

   
        process_end_time = process_end_time[0][0]
        # Add 168 hours (7 days) to the datetime object
        hours=int(process_freq[0])
        delta = np.timedelta64(hours, 'h')
        hours=int(process_freq[0])
        dt_plus_168_hours = process_end_time + delta
        # Convert the numpy.datetime64 object to a datetime object
        dt = pd.to_datetime(dt_plus_168_hours)

        # Convert the datetime object to an ISO format string
        process_start_time = dt.isoformat()
        print(process_start_time)
        ret_code= process_control_entry(job_run_id,schema,process_id,process_start_time,table_delta_version)
        if ret_code!=0:
            raise Exception
        
        return 0

# COMMAND ----------

# MAGIC %md
# MAGIC ### Function to fetch job_run_id details ###

# COMMAND ----------

from pyspark.sql import functions as F
import datetime
import numpy as np
import sys
from pyspark.sql.functions import current_timestamp


def fetch_job_run_id(job_id,schema,process_id):

    ### fetch the job run id for that job_id which is in running status.

    # -------- Check if there is an active job ----------


    job_run_id= spark.sql("select max(job_run_id) from {}.t_job_control where job_id in (select job_id from {}.t_process_metadata where process_id ={} ) and job_status='RUNNING'".format(schema,schema,process_id)).toPandas().T.values

    entry_type=""
    if np.isnan(job_run_id):
        print(f"No active entry exists in the job control table with status running for job_id-{job_id}!!")
        return 2,None
    else:
        print(job_run_id)
        return 0,job_run_id


# COMMAND ----------

from pyspark.sql import functions as F
import datetime
import numpy as np
import sys
from pyspark.sql.functions import current_timestamp


def fetch_job_metadata(job_id,schema):
    ### -------- Read the metadata for the respective job_id ----------
    df=spark.sql('select * from {}.t_job_metadata where job_id={}'.format(schema,job_id))


    job_id,job_name,job_desc,job_dependencies,job_source_schema,job_target_schema,job_freq,dq_enabled,dq_id,insert_id,updated_id =df.toPandas().T.values

    return job_name,job_desc,job_dependencies,job_source_schema,job_target_schema,job_freq



# COMMAND ----------

# MAGIC %md
# MAGIC ### Methods for Process Operational Data and Metadata Fetch ###
# MAGIC -----------
# MAGIC 1.  Includes method to fetch_process_run_id to fetch the active process_run_id
# MAGIC 2.  Includes method to fetch process_control_start_time
# MAGIC 3.  Includes method to fetch process metadata

# COMMAND ----------

from pyspark.sql import functions as F
import datetime
import numpy as np
from pyspark.sql.functions import current_timestamp
def fetch_process_run_id(job_run_id,schema,process_id):

    ### -------- Check if there is an active job in process control table ----------

    process_run_id=spark.sql("select max(process_run_id) from {}.t_process_control where process_id={} and job_run_id={} and process_status='RUNNING'".format(schema,process_id,job_run_id)).toPandas().T.values

    if np.isnan(process_run_id[0][0]):
        print('No active job present. Please trigger process control entry before ending the process!')
        print('fetching process_run_id failed as there is no active process in running status!')
        return 1,None
    else:
        print('Found active process!! process_run_id is'.format(process_run_id))
        return 0,process_run_id[0][0]
    
def fetch_process_control_start_time(job_run_id,process_id,process_run_id,schema):
    process_start_time= spark.sql("select process_start_time from {}.t_process_control where process_run_id={} and job_run_id={} and process_id ={}".format(schema,process_run_id,job_run_id,process_id)).toPandas().T.values

    return process_start_time[0][0]

def fetch_process_metadata(process_id,job_id,schema):
    ### -------- Read the metadata for the respective job_id and process_id ----------
    df=spark.sql('select process_name,process_source_schema,process_target_schema,process_freq,process_load_type,process_keys from {}.t_process_metadata  where job_id={} and process_id={}'.format(schema,job_id,process_id))
    process_name,process_source_schema,process_target_schema,process_freq,process_load_type,process_keys=df.toPandas().T.values

    return process_name,process_source_schema,process_target_schema,process_freq,process_load_type,process_keys

def fetch_process_run_delta_version(job_run_id,schema,process_id):
    try:
        status_code,process_run_id=fetch_process_run_id(job_run_id,schema,process_id)
        if status_code==0:
            print(f"Fetching process_run_details for process_run_id - {process_run_id}")
            process_run_delta_version= spark.sql("select table_delta_version from {}.t_process_control where process_run_id={} and process_id={}".format(schema,process_run_id,process_id)).toPandas().T.values
        return process_run_delta_version
    except Exception as e:
        print("error occurred while fetching process_delta_version")
        print(e)
        raise

def update_process_run_delta_version(job_run_id,schema,process_id,delta_version):
    try:
        status_code,process_run_id=fetch_process_run_id(job_run_id,schema,process_id)
        if status_code==0:
            print(f"Fetching process_run_details for process_run_id - {process_run_id}")
            update_statement=f'update {schema}.t_process_control set table_delta_version={delta_version} where process_run_id={process_run_id} and process_id={process_id}'
            spark.sql(update_statement)
        return 0
    except Exception as e:
        print("error occurred while updating process_delta_version")
        print(e)
        raise



# COMMAND ----------

# MAGIC %md
# MAGIC ### Methods to read and write s3 object 
# MAGIC     1. write s3 function with bucket, key and data as parameters
# MAGIC     2. read s3 function with bucket and key as parameters
# MAGIC     3. update dict objects with dict,key and key as parameters

# COMMAND ----------

import boto3

def dict_to_bytes(dict):
        return str(dict).encode('utf-8')
    
def bytes_to_dict(bytes):
        return eval(bytes.decode('utf-8'))
    
def write_dict_to_s3(bucket, key, data):
    s3 = boto3.client('s3')
    s3.put_object(Bucket=bucket, Key=key, Body=dict_to_bytes(data))
    return 's3://{}/{}'.format(bucket, key)
    
# def read_s3_to_dict(bucket, key):
#     s3 = boto3.client('s3')
#     obj = s3.get_object(Bucket=bucket, Key=key)
#     return obj['Body'].read()

import boto3
import botocore

def read_s3_to_dict(bucket, key):
    s3 = boto3.resource('s3')

    try:
        obj = s3.Object(bucket, key)
        content = obj.get()['Body'].read().decode('utf-8')
        return content
    except botocore.exceptions.ClientError as e:
        if e.response['Error']['Code'] == "NoSuchKey":
            # The object does not exist.
            return None
        else:
            # Something else has gone wrong.
            raise

def add_update_dict(dict, key, value):
    dict[key] = value
    return dict


# COMMAND ----------

import boto3

def check_and_update_s3_file(bucket, key, content):
    s3 = boto3.resource('s3')

    # Try to get the object
    try:
        s3.Object(bucket, key).load()
    except botocore.exceptions.ClientError as e:
        if e.response['Error']['Code'] == "404":
            # The object does not exist, create it
            write_dict_to_s3(bucket, key, content)
            #s3.Object(bucket, key).put(Body=content)
            print(f'File {key} created in bucket {bucket}.')
        else:
            # Something else has gone wrong
            raise
    else:
        # The object does exist, update it
        write_dict_to_s3(bucket, key, content)
        #s3.Object(bucket, key).put(Body=content)
        print(f'File {key} updated in bucket {bucket}.')



# COMMAND ----------

# MAGIC %md
# MAGIC ### Methods to read and write to json object###
# MAGIC     1.  Json file read to buffer.
# MAGIC

# COMMAND ----------

import json
def read_json_file(file_path):
    with open(file_path, 'r') as file:
        json_content = json.load(file)
    return json_content

# COMMAND ----------

# MAGIC %md
# MAGIC ### Method to transform columns or derive col values

# COMMAND ----------

from pyspark.sql.functions import col, to_date, upper
import json

def transform_columns(df, transformations):
    # Apply the transformations
    for transformation in transformations:
        column = transformation['column']
        expression = transformation['transformation']
        df = df.withColumn(column, eval(expression))
    return df

# COMMAND ----------

# ### Method to refer lookup tables 
# def process_lookup_tables(lookup_table_list,input_df):
#     for lookup_dict in lookup_table_list:
#         for lookup_table, mapping in lookup_dict.items():
#             # Load the lookup DataFrame
#             # Extract the join column and the reference column
#             reference_column,join_column = list(mapping.items())[0]
#             print(join_column, reference_column)
#             lookup_df = spark.read.table(lookup_table).filter(col('cur_ind')=='Y').select(join_column,reference_column)
    
#             # Join the base DataFrame with the lookup DataFrame
#             input_df = input_df.join(lookup_df, input_df[join_column] == lookup_df[join_column], "left").drop(input_df[reference_column],lookup_df[join_column])
#     return input_df


# COMMAND ----------

### Method to refer lookup tables 
def process_lookup_tables(lookup_table_list,input_df):
    for lookup_item in lookup_table_list:
        for lookup_table, details in lookup_item.items():
            reference_column,join_column = list(details.items())[0]
            print(details.get('condition'))
            condition = details.get('condition')
            filter_condition = None
            if condition:
                for column, value in condition.items():
                    new_condition = col(column) == value
                    if filter_condition is None:
                        filter_condition = new_condition
                    else:
                        filter_condition = filter_condition & new_condition
            print(filter_condition)
            lookup_df = spark.read.table(lookup_table).filter(filter_condition).select(join_column,reference_column)
            input_df = input_df.join(lookup_df, input_df[join_column] == lookup_df[join_column], "left").drop(input_df[reference_column],lookup_df[join_column])
    return input_df

# COMMAND ----------


from pyspark.sql.functions import col
import functools

def join_with_lookup_data(base_df, lookup_table_list):

    for table_info in lookup_table_list:
        # Convert all column names in base_df to lowercase
        base_df=base_df.select(*[col(c).alias(c.lower()) for c in base_df.columns])

        for table_name, details in table_info.items():
            # Load the lookup table
            lookup_df = spark.read.table(table_name)

            # Convert all column names in lookup_df to lowercase
            lookup_df = lookup_df.select(*[col(c).alias(c.lower()) for c in lookup_df.columns])

            # Extract details from the dictionary
            join_condition = details['join_condition']
            fetch_value = details['fetch_value'].lower()
            filter_condition = details['condition']

            # Check that the join condition attributes are present in the DataFrames
            base_df_col, lookup_df_col = list(join_condition.items())[0]
            base_df_col = base_df_col.lower()
            lookup_df_col = lookup_df_col.lower()


            # Create join expression
            join_expr = base_df[base_df_col] == lookup_df[lookup_df_col]

            # Filter the lookup DataFrame
            # for column, value in filter_condition.items():
            #     lookup_df = lookup_df.filter(lookup_df[column.lower()] == value)

            filter_conditions = [F.col(column.lower()) == value for column, value in filter_condition.items()]
            print(filter_conditions)
            lookup_df = lookup_df.filter(functools.reduce(lambda a, b: a & b, filter_conditions))
        
            print(base_df_col)
            print(lookup_df_col)
      
            # Join the base DataFrame with the lookup DataFrame
            base_cols=base_df.columns
            if fetch_value in base_cols:
                base_cols.remove(fetch_value)
            base_cols=['a.'+colname  for colname in base_cols]
            look_cols=['b.'+fetch_value]
            total_required_cols=base_cols+look_cols
            base_df = base_df.alias('a').join(lookup_df.alias('b'), on=join_expr, how='left').select(*total_required_cols)

            # If there's a column name conflict, drop the column from the base DataFrame and rename the column from the lookup DataFrame
            if fetch_value in base_df.columns:
                base_df = base_df.drop('a.' + fetch_value)
                base_df = base_df.withColumnRenamed('b.' + fetch_value, fetch_value)

    return base_df



# COMMAND ----------

# MAGIC %md
# MAGIC ###Hash Key Generator

# COMMAND ----------

# Function to generate hashkey
def digest(in_str):
  return hashlib.md5(in_str.encode('utf-8')).hexdigest()


# COMMAND ----------

from delta.tables import DeltaTable
from pyspark.sql.functions import *

def get_table_version(table_name):

    # Set up connection to your Delta Lake table
    table_details = spark.sql(f"DESCRIBE DETAIL {table_name}")

    # Get the location of the table
    location = table_details.select("location").first()[0]

    deltaTable = DeltaTable.forPath(spark, location)
    historyDF = deltaTable.history()

    latest_version = deltaTable.history().select("version").orderBy(desc("timestamp")).first()[0]
    return latest_version

# COMMAND ----------


