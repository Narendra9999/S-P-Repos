# Databricks notebook source
# MAGIC %md
# MAGIC ##### Installing the packages

# COMMAND ----------

# MAGIC %pip install boto3==1.33.2
# MAGIC %pip install requests==2.31.0
# MAGIC %pip install botocore==1.33.2
# MAGIC %pip install s3transfer==0.8.0
# MAGIC %pip install urllib3
# MAGIC %pip install smart-open

# COMMAND ----------

### Importing package dependencies ####
from functools import wraps
from itertools import chain
from time import sleep
import logging,datetime,time
import requests,json
import urllib3
from requests.auth import HTTPBasicAuth
from typing import Final, Dict,Tuple
from pyspark.sql.session import SparkSession
from pyspark.sql import DataFrame as SDF
from pyspark.sql.functions import *


# COMMAND ----------

###** Retry decorator incase of api function call failures **###
def retry(num_retry, sleep_sec):
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            """A wrapper function"""
            for retry_num in range(1, num_retry):
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    logging.error(e)
                    logging.error(f"Number of retry - {retry_num}")
                    sleep(sleep_sec)
        return wrapper
    return decorator

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC Authentication Call

# COMMAND ----------


def generate_api_header(auth_type,username,password,header):
    """
    Generating the api_header to accomdate basic authentication combining user_name and password.
    """
    credentials_encoding = f'{user_name}:{password}'.encode('utf-8')
    encoded_string = base64.b64encode(credentials_encoding).decode("utf-8")
    authorization = {'Authorization': f'Basic {encoded_string}'}
    if type(header) is str:    
        res = ast.literal_eval(header)
    else:
        res = header
    api_header = res|authorization
    return api_header

def generate_token_basic_auth_query_params(url, method, username, password,output_type):
    # Make a request to the specified URL with the given method and query parameters
    response = requests.request(method, url, params={'username': username, 'password': password})
    
    # Check if the request was successful
    if response.status_code == 200:
        # Extract the access token from the response
        if output_type=='txt':
            print(response.text)
            access_token = response.text
        else:
            access_token = response.json().get('access_token')
        return access_token
    else:
        # If the request was not successful, raise an exception or handle the error accordingly
        raise Exception(f"Request failed with status code {response.status_code}")


def generate_token(auth_type,url,request_type,**kwargs):
    """
    Multiple options are enabled for authentication

    1) Basic Authentication using username & password
    2) Basic Authentication using Token
    3) Bearer Token Authentication 
    """   
    print("generating temp token for the session")
    api_header = generate_api_header(auth_type,user_name,password,kwargs['header'])
    fields=ast.literal_eval(kwargs['query_params'])
    if auth_type == 'Bearer':      
        response = urllib3.PoolManager().request(request_type,url=url,headers=api_header,fields=fields,encode_multipart = False)
    return response
    

def get_authentication_details(user_name,password):
    return HTTPBasicAuth(user_name,password)

# COMMAND ----------


def rename_dataframe_cols(df:SDF, col_names:Dict[str,str])->SDF:
    """
    Rename all columns in dataframe
    """
    return df.select(*[col(col_name).alias(col_names.get(col_name,col_name)) for col_name in df.columns])

# COMMAND ----------

def update_column_names(df:SDF,index:int)->SDF:
    df_temp = df
    all_cols = df_temp.columns
    new_cols = dict((column,f"{column}_{index}") for column in all_cols)
    df_temp = df_temp.transform(lambda df_x: rename_dataframe_cols(df_x,new_cols))

    return df_temp

# COMMAND ----------

def flatten_json(df_arg:SDF,index: int=1)-> SDF:
    """
    Flatten Json in a spark dataframe using recursion.
    """
    
    #update all column names with index 1
    df = update_column_names(df_arg,index) if index == 1 else df_arg
    
    # get all field names from the dataframe
    fields = df.schema.fields

    # For all columns in the dataframe
    for field in fields:
        data_type = str(field.dataType)
        column_name = field.name
        
        first_10_chars =data_type[0:10]
        
        # if it is an Array column
        if first_10_chars =='ArrayType(':
            #explode Array column
            df_temp = df.withColumn(column_name, explode_outer(col(column_name)))
            return flatten_json(df_temp, index + 1)
        # if it is a json object
        elif first_10_chars == 'StructType':
            current_col = column_name
            append_str = current_col
            
            # Get data type of current column
            data_type_str = str(df.schema[current_col].dataType)
            
            #change the column name if the current column name exists in the data type string
            df_temp = df.withColumnRenamed(column_name, column_name+"#1") if column_name in data_type_str else df
            current_col = current_col + "#1" if column_name in data_type_str else current_col
            
            # Expand struct column values
            df_before_expanding = df_temp.select(f"{current_col}.*")
            newly_gen_cols = df_before_expanding.columns
            
            #Find next level value for the column
            begin_index = append_str.rfind('_')
            end_index = len(append_str)
            level = append_str[begin_index + 1: end_index]
            next_level = int(level) + 1
            
            # update column names with new level
            custom_cols = dict((field, f"{append_str}->{field}_{next_level}") for field in newly_gen_cols)
            df_temp2 = df_temp.select("*",f"{current_col}.*").drop(current_col)
            df_temp3 = df_temp2.transform(lambda df_x: rename_dataframe_cols(df_x,custom_cols))
            return flatten_json(df_temp3, index + 1)
    return df

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Configuring the number of cores for multi-processing

# COMMAND ----------

# MAGIC %scala
# MAGIC // Fetching the total number of available cores for multi-processing
# MAGIC spark.conf.set("cores",java.lang.Runtime.getRuntime.availableProcessors * (sc.statusTracker.getExecutorInfos.length -1))

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Fetch the data for initial load

# COMMAND ----------

import requests

def fetch_data(access_token, api_url):
    headers = {
        'Authorization': f'Bearer {access_token}'
    }
    response = requests.get(api_url, headers=headers)
    if response.status_code == 200:
        return response.json()
    else:
        raise Exception(f"Failed to fetch data. Status code: {response.status_code}")

# COMMAND ----------

@retry(3,3)
def get_data(base_url,request_type,header,**kwargs):
    response=requests.request(request_type,base_url,headers=header,**kwargs)
    if response.status_code!=200:
        raise Exception
        logging.error(response.status_code)
        logging.error(response.text)
    else:
        return response.json()

# COMMAND ----------

import requests
def retry_data_request(url,request_type, header,total=4, status_forcelist=[429, 500, 502, 503, 504,524], **kwargs):
    # Make number of requests required
    for _ in range(total):
        try:
            response=requests.request(request_type,url,headers=header,**kwargs)
            if response.status_code in status_forcelist:
                print(f"retrying {_}")
                time.sleep(2)
                continue
        except requests.exceptions.ConnectionError as ce:
            print("Could not connect. Trying to connect for the {} time".format(_ + 1))
            print(ce)
            print(response)
        except requests.exceptions.ReadTimeout as rt:
            print("Could not connect. Trying to connect for the {} time".format(_ + 1))
            print(f"Readtimeout error for - {url}")
        except requests.exceptions.Timeout as to:
            print("Could not connect. Trying to connect for the {} time".format(_ + 1))
            print(f"timeout error for - {url}")
        except requests.exceptions.ChunkedEncodingError:
            print("Could not connect. Trying to connect for the {} time".format(_ +1))
            print(f"chunk encoding error for - {url}")
    return response

# COMMAND ----------

@retry(3,3)
def get_ids(request_type,api_url,header):
    try:
        response = urllib3.request(method=request_type,url=api_url,headers=header)
        print(response.json())
    except (urllib3.exceptions.ReadTimeoutError,requests.ConnectionError,urllib3.connection.ConnectionError,urllib3.exceptions.MaxRetryError,urllib3.exceptions.ConnectTimeoutError,urllib3.exceptions.TimeoutError) as e:
        print(e)
    if response != None and response.status == 200:
        jsonResponse = response.json()
    return jsonResponse

# COMMAND ----------


def get_record_level_data(api_url,request_type,header,record_id):
    record_url = api_url+str(record_id)
    print(record_url)
    response=retry_data_request(record_url,request_type,header,timeout=5)
    if response != None and  response.status_code==200:
        response = response.json()
    else:
        print(response.text)
        print(response.status_code)
        response = {'api_error_code':response.status_code,'api_error_type':response.text}
    return({str(record_id):response})

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Extract the results from the pool

# COMMAND ----------

def processing_api_pool_results(results):
    error_records={}
    data_records={}
    for res in results:
        for k,v in res.items():
            if type(v)==dict and 'api_error_code' in v.keys():
                error_records[k]=v
            else:
                data_records[k]=v
    return error_records,data_records

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Writing the dataset results to dbfs temp location

# COMMAND ----------

def resultset_to_dbfs_file(recordset,dbfs_file_location):
    try:
        with open(dbfs_file_location, 'w') as f:
            for k,v in recordset.items():
                jsoned_data = json.dumps(v)
                f.write(jsoned_data)
                f.write('\n')
    except IOError:
        print(IOError)
        print("Couldn't open the file")
        return False
    return True

# COMMAND ----------

# MAGIC %md
# MAGIC ### Method to read with pagination for IHS APIs

# COMMAND ----------

import requests
import smart_open
import datetime


def fetch_data_with_pagination(access_token, api_url,query_params, s3_bucket,schema_name,feed_name,is_paginated,paginated_field,auth_url,auth_request_type,username,password,output_type):
    headers = {
        'Authorization': f'Bearer {access_token}'
    }
    accumalated_data=[]
    response = requests.get(api_url, headers=headers,params=query_params)
    print(response.url)
    response.raise_for_status()  # Raise exception if status code is not 200
    data = response.json()
    accumalated_data.append(data)
    total_size = 0
    timestamp = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
    while True:
        # Write data to S3 when size hits 100 MB
        if total_size >= 100 * 1024 * 1024 or paginated_field not in data:
            s3_key = f'{schema_name}/{feed_name}/{feed_name}_data_{timestamp}.json'
            s3_location = f's3://{s3_bucket}/{s3_key}'
            with smart_open.open(s3_location, 'w') as f:
                f.write(json.dumps(accumalated_data))
        # Reset data and total size
            accumalated_data=[]
            total_size = 0
            timestamp = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
        # Check if there are more pages
        if paginated_field in data:
            next_page_url = data[paginated_field]
            try:
                response = requests.get(next_page_url, headers=headers)
                print(next_page_url)
                response.raise_for_status()
                data = response.json()
                accumalated_data.append(data)
                total_size += len(response.content)
            except (requests.exceptions.RequestException, ValueError):
                print(ValueError)
            #Handle invalid token or timeout
                access_token = generate_token_basic_auth_query_params(auth_url,auth_request_type,username,password,output_type)
        else:
            print(data)
            break
    return 0

