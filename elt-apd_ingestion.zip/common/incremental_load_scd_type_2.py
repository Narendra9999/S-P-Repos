# Databricks notebook source
# MAGIC %md
# MAGIC ### Raw to Curation ###
# MAGIC
# MAGIC ----------------
# MAGIC ### Steps in this notebook ###
# MAGIC 1) Fetch the metadata from the job_metadata and process_metadata tables.(source_schema,source_table,target_schema,target_table,load_type,job_run_frequency)
# MAGIC 2) Check if there is an existing job/process already running.
# MAGIC 3) If there is no active job/process running,exit the notebook.
# MAGIC 4) Else Fetch the incremental_start_date,job_run_id,process_run_id from the process_control table
# MAGIC 5) Fetch the additional configs based json config whose naming convention  should follow {table_name}.config. It should be present in the config folder.
# MAGIC 6) Run the load based on the template
# MAGIC 7) Send the stats to the metadata table
# MAGIC --------------------

# COMMAND ----------

# MAGIC %run ../library/0_Common_job_utilities

# COMMAND ----------

# MAGIC %md
# MAGIC ### Initializing the variables ###

# COMMAND ----------

# MAGIC %md
# MAGIC --------------------------------------------------------------
# MAGIC ### Things to do ####
# MAGIC 1) Work on source_to_column mapping
# MAGIC 2) Parameterize the template for ECR_BANK table
# MAGIC 3) Identify variables needed like keys, partition columns etc.
# MAGIC 4) work on parameterizing and fetching the values from json configs.
# MAGIC 5) Finally integrate the pipeline with job_control and process_control
# MAGIC 6) Validate these for all the 10 tables
# MAGIC 7) Work on the second template for remaining 9 tables.
# MAGIC ----------------------------------------------------------------
# MAGIC

# COMMAND ----------

dbutils.widgets.text(name="table_name",defaultValue="DefaultValue")

# COMMAND ----------

import json,os
from functools import reduce
from pyspark.sql.functions import year


table_name=dbutils.widgets.get('table_name')


env = os.environ.get("aws_env")
metadata_schema=f"idf_raw_{env}.ecr_economic_data"

s3_bucket=f"spr-idf-{env}-platform-config"
file_path = f"platform/config/ihs_ecr_economic_data/{table_name}.json"
operational_file_path=f"streaming_checkpoint/ihs_ecr_economic_data/{table_name}.json"

s3_object=read_s3_to_dict(s3_bucket,file_path)
if s3_object is not None:
    json_obj=json.loads(s3_object)
    job_id=json_obj['job_id']
    process_id=json_obj['process_id']
    print(json_obj)
else:
    print(f"s3_object is not found with filename - {file_path}")
    ret_values={'status_code':2,"job_status":f"failed with exception Json metadata not found!!"}
    dbutils.notebook.exit(ret_values)

# COMMAND ----------

# MAGIC %md
# MAGIC Reading OPERATIONAL_METADATA file for DELTA Version

# COMMAND ----------

status,job_run_id=fetch_job_run_id(job_id,metadata_schema,process_id)
job_run_id=job_run_id[0][0]
delta_starting_version=fetch_process_run_delta_version(job_run_id,metadata_schema,process_id)[0][0]
print(delta_starting_version) 

# COMMAND ----------

### Fetching active job_run_id ###

ret_code,job_run_id = fetch_job_run_id(job_id,metadata_schema,process_id)
job_run_id = job_run_id[0][0]
print(job_run_id)
job_name,job_desc,job_dependencies,job_source_schema,job_target_schema,job_freq = fetch_job_metadata(job_id=job_id,schema=metadata_schema)
print(job_name[0])
# file_path = f"../config/{job_name[0].lower()}.json"

### Setting json file Variables ####
# json_obj = read_json_file(file_path)
target_column_mapping=json_obj['target_to_source_mapping']
table_name = json_obj['table_name']
key_columns = json_obj['keys']
surrogate_key=json_obj['surrogate_key']
ignore_columns = json_obj['ignorable_columns']
audit_columns = json_obj['audit_columns']
print(audit_columns)

#raw_table = job_source_schema[0]+"."+json_obj['raw_table']
raw_table = json_obj['raw_table']
column_transformations = json_obj.get('column_transformations', [])
lookup_table_list=json_obj.get('lookup_table_list',[])
#delta_starting_version=json_obj.get('delta_starting_version',[])
#raw_table=raw_table+"_temp"
curated_table_path = json_obj['curated_table_path']
print(job_source_schema)
print(raw_table)
print(delta_starting_version)
print(f"this is lookup_table_list {lookup_table_list}")
print(surrogate_key)
### Fetching active process_run_id
print(f"process_id is {process_id}, job_run_id is {job_run_id}")
process_ret_code,process_run_id = fetch_process_run_id(job_run_id,metadata_schema,process_id)
print(f"process_run_id is {process_run_id}")


### Fetching Process Metadata ###
incremental_start_ts= fetch_process_control_start_time(job_run_id,process_id,process_run_id,metadata_schema)
incremental_start_ts= incremental_start_ts.astype(str)
print(f"incremental_start_ts is {incremental_start_ts}")

process_name,process_source_schema,process_target_schema,process_freq,process_load_type,process_keys=fetch_process_metadata(process_id,job_id,metadata_schema)

process_name=process_name[0]
source_schema=process_source_schema[0]
target_schema=process_target_schema[0]
load_type=process_load_type[0]
freq=process_freq[0]
print(f"these are the keys -{key_columns}")
key_columns_list = [item.lower() for item in key_columns.split(",")]
print(key_columns_list)
print(target_column_mapping)


# COMMAND ----------

# Function to generate hashkey
def digest(in_str):
  return hashlib.md5(in_str.encode('utf-8')).hexdigest()


# COMMAND ----------

# MAGIC %md
# MAGIC ### Reading the Raw Layer ####

# COMMAND ----------

import json
from datetime import datetime
import datetime as dt
from pyspark import SparkConf
from pyspark.context import SparkContext
from pyspark.sql.functions import *
from pyspark.sql.window import *
from pyspark import StorageLevel
from pyspark.sql.types import StringType
import hashlib, sys, operator, logging, json, time, math, os, stat, requests, logging
from pyspark.sql.types import LongType, StringType, TimestampType, IntegerType, DateType,DecimalType
from pyspark.sql.functions import lit
from pyspark.sql.functions import from_json, col
import pyspark.sql.types as t
import traceback,re
from pyspark.sql import functions as F, Window

try:
    audit_job_id = str(process_run_id)
    exp_ts = "9999-12-31 11:59:59"

    incr_date_string = incremental_start_ts[:10]
    incr_date = datetime.strptime(incr_date_string,'%Y-%m-%d')
    print("Printing incremental start date ")
    print(incr_date,incr_date_string)
    incr_ts = incr_date_string + ' 00:00:00'
    expire_day = (incr_date - dt.timedelta(days=1)).strftime('%Y-%m-%d')
    expire_ts = expire_day+' 23:59:59'
    day_id = incr_date_string

    digest_udf = udf(digest, StringType())

    #Reading the source table
    #input_df = spark.read.table(f"{raw_table}")
    if delta_starting_version == 0:
        input_df = spark.read.table(f"{raw_table}")
    else:    
        input_df = spark.read.format("delta") \
        .option("readChangeFeed", "true") \
        .option("startingVersion", delta_starting_version) \
        .table(raw_table)\
        .filter(col('_change_type') != 'update_preimage')
        # .filter(col('_change_type')=='update_postimage')

    # Define the window specification
    windowSpec = Window.partitionBy("ASOF","TIMESERIESID","PRODUCTNUMBER").orderBy(col("LASTUPDATETIME").desc())

    # Assign row numbers
    df_with_row_number = input_df.withColumn("row_number", row_number().over(windowSpec))

    # Filter to get only the rows with the latest timestamp per category
    input_df = df_with_row_number.filter(col("row_number") == 1).drop("row_number")

    #display(input_df)

    #Mapping the columns to the target naming convention.
    for new_name,old_name in target_column_mapping.items():
        print(new_name,old_name)
        input_df = input_df.withColumn(new_name,input_df[old_name])
    
    # Check if the transformations object is not empty
    if len(column_transformations) > 0:
        # Transform the columns
        input_df = transform_columns(input_df, column_transformations)
        #display(df)

    else:
        print("No transformations to apply")
    input_df=input_df.drop_duplicates(key_columns_list)

    input_df=join_with_lookup_data(input_df, lookup_table_list)
    casted_src = input_df
    #Reading the target table
    tgt_df = spark.read.format('delta').load('{}'.format(curated_table_path)).filter(col('end_date')=='9999-12-31')
    target_active_count=tgt_df.count()
    schema = tgt_df.schema
    # Convert the schema to a JSON string
    schema_json = schema.json()
    schema = json.loads(schema_json)

    type_mapping = {
        'long': LongType(),
        'string': StringType(),
        'timestamp': TimestampType(),
        'integer': IntegerType(),
        'date': DateType(),
        'decimal': DecimalType()
    }

    for field in schema['fields']:
        column_name = field['name']
        column_type = field['type']
        casted_src_columns = [column.lower() for column in casted_src.columns]

        if 'decimal' in column_type:
            match = re.match(r'decimal\((\d+),(\d+)\)', column_type)
            if match:
                precision, scale = map(int, match.groups())
                type_mapping[column_type] = DecimalType(precision, scale)

        if column_name in casted_src_columns:
            print(f"I am inside the mapped column {column_name}")
            # if 'date' in column_type or ('timestamp' in column_type and column_name in key_columns_list):
            if 'date' in column_type:
                casted_src=casted_src.withColumn(column_name, F.to_date(column_name, 'yyyy-MM-dd'))
            casted_src = casted_src.withColumn(column_name, casted_src[column_name].cast(type_mapping[column_type]))
        else:
            print(f"{column_name} is not matching")
            print(casted_src.columns)
            casted_src = casted_src.withColumn(column_name, lit(None).cast(type_mapping[column_type]))


    target_cols = tgt_df.columns
    key_columns = key_columns_list
    print(key_columns)

    casted_df = casted_src.withColumn('actv_ind',lit('Y')).withColumn('cur_ind',lit('Y')).withColumn('create_usr_id',lit(audit_job_id)).withColumn('last_upd_usr_id',lit(audit_job_id)).withColumn('create_dttm',lit(current_timestamp())).withColumn('last_upd_dttm',lit(current_timestamp())).withColumn("start_date",lit(incr_date_string).cast('date')).withColumn("start_dttm",lit(incr_ts).cast("timestamp")).withColumn("end_dttm",lit(exp_ts).cast("timestamp")).withColumn('end_date',lit('9999-12-31').cast('date'))

    value_columns = set(tgt_df.columns) - set(audit_columns) -set(ignore_columns)-set([surrogate_key.lower()])
    print("these are value columns")
    print(value_columns)
    casted_df.printSchema()
    hashed_src = casted_df.withColumn("value_hash", digest_udf(concat_ws('||', *value_columns))).withColumn("key_hash", digest_udf(concat_ws('||', *key_columns))).alias('src').withColumn('cdc_order', lit(2))


    #display(hashed_src)
    hashed_tgt = tgt_df.withColumn("value_hash", digest_udf(concat_ws('||', *value_columns))).withColumn("key_hash", digest_udf(concat_ws('||', *key_columns))).alias('tgt').withColumn('cdc_order', lit(1))
    
    hashed_src.cache()
    hashed_tgt.cache()
except Exception as e:
    print(e)
    raise

# COMMAND ----------

print(value_columns)
print(key_columns)
print(key_columns_list)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Identifying the updates,new and expired records and merging them ####
# MAGIC

# COMMAND ----------

val_col_list=list(value_columns)
print(val_col_list)

# COMMAND ----------

spark.catalog.clearCache()

# COMMAND ----------

try:
    print(val_col_list)

    source_alias='updates'
    target_alias='original'
    cond = (hashed_src.key_hash.eqNullSafe(hashed_tgt.key_hash) & hashed_src.value_hash.eqNullSafe(hashed_tgt.value_hash))

    hashed_src.alias('source').cache()
    hashed_tgt.alias('target').cache()
    RowsToUpdate = hashed_src \
        .join(hashed_tgt,cond,'leftanti')\
        .select(*target_cols)

    key_predicate=' AND '.join([f'{source_alias}.{c.lower()} = {target_alias}.{c.lower()}' for c in key_columns])
    print(key_predicate)
    update_predicate = ' or '.join([
        f'{source_alias}.{c} <> {target_alias}.{c}' for c in value_columns])
    print(update_predicate)
    print(RowsToUpdate.count())
    RowsToUpdate.cache()
    print(target_cols)
except Exception as e:
    print(e)
    raise


# COMMAND ----------

try:
    key_predicate = ' AND '.join([f'{source_alias}.{c.lower()} = {target_alias}.{c.lower()}' for c in key_columns])
    DeltaTable.forPath(spark, curated_table_path).alias("original").merge(
        source=RowsToUpdate.alias("updates"),
        condition=key_predicate
    ).whenMatchedUpdate(
        condition=f"original.cur_ind = 'Y' AND original.actv_ind = 'Y'",
        set={
            "cur_ind": "'N'",
            "last_upd_dttm": lit(current_timestamp()),
            "end_dttm": lit(expire_ts).cast("timestamp"),
            "end_date": lit(expire_day).cast('date')
        }
    ).execute()
except Exception as e:
    print(e)
    raise

# COMMAND ----------

updated_row_count=RowsToUpdate.count()
print(f'updated_row_count is {updated_row_count}')


# COMMAND ----------

try:
    columns = RowsToUpdate.columns
    surrogate_key = (surrogate_key).lower()
    if surrogate_key in columns:
        columns.remove(surrogate_key)
    print(columns)
    print(f'target active counts are {target_active_count}')

    if target_active_count == 0:
        print('No records found in the active partitions ,so loading as day-0.')
        RowsToUpdate.select(*columns).write.mode("overwrite").format("delta").save(curated_table_path)
    else:
        print('Found records in the active partition, so doing load based on freq and loadtype')
        RowsToUpdate.select(*columns).write.mode("Append").format("delta").save(curated_table_path)
        latest_version = get_table_version(raw_table)
        update_process_run_delta_version(job_run_id, metadata_schema, process_id, latest_version)
        status = "success"
        ret_values = {'status_code': 0, 'job_status': status}
except Exception as e:
    print(e)
    raise

# COMMAND ----------

dbutils.notebook.exit(ret_values)

# COMMAND ----------

#### Identifying the deleted records ####

# COMMAND ----------

# try:
#     source_alias='src'
#     target_alias='tgt'

#     delete_predicate = [col(f'{source_alias}.{column.lower()}') == col(f'{target_alias}.{column.lower()}') for column in key_columns]

#     print(delete_predicate)
#     RowsToDelete = tgt_df.alias(target_alias).where("cur_ind = 'Y' AND actv_ind = 'Y'") \
#         .join(hashed_src.alias(source_alias),delete_predicate, "leftanti")

#     # RowsToDelete.show()
#     deleted_record_count=RowsToDelete.count()
#     print(f"total number of records that are deleted are {deleted_record_count}")
# # except:
#     raise

# COMMAND ----------


# try:
#     # Merge statement to mark as deleted records
#     source_alias='original'
#     target_alias='deletes'
#     key_predicate=' AND '.join([
#              f'{source_alias}.{c.lower()} = {target_alias}.{c.lower()}' for c in key_columns
#     ])
#     DeltaTable.forPath(spark, curated_table_path).alias(source_alias).merge(
#         source = RowsToDelete.alias(target_alias),
#         condition = key_predicate
#     ).whenMatchedUpdate(
#         condition = "original.cur_ind = 'Y' AND original.actv_ind = 'Y'",
#         set = {                                      
#             "actv_ind": lit('Y'),
#             "cur_ind":lit('N'),
#             "end_date": lit(expire_day).cast('date'),
#             "end_dttm":lit(expire_ts).cast("timestamp"),
#             "last_upd_dttm":lit(current_timestamp())
#         }
#     ).execute()
#     status="success"
#     ret_values={'status_code':0,'job_status':status}
# except Exception as e:
#     print('error occurred while writing to the target table  !!')
#     raise
#     message=e
#     ret_code=2
#     ret_values={'status_code':2,"job_status":f"failed with exception {e}"}

# dbutils.notebook.exit(ret_values)

# COMMAND ----------

# from pyspark.sql.functions import from_json, col

# df=spark.read.format('delta').load('{}'.format(curated_table_path))
# df.select("vendorbankid").distinct().count()

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC describe  idf_curated_dev.ecr_economic_data.t_ecr_observationproduct
