# Databricks notebook source
if load_type=='delta_upsert_type_1':
    result= dbutils.notebook.run("./type_1_data_load_with_lookup", 300,{'job_id':11,'process_id':11,'metadata_schema':'idf_raw_dev.ecr_economic_data'})
elif load_type=='full_load_scd_type_2':
    result= dbutils.notebook.run("./type_1_data_load_with_lookup", 300,{'job_id':11,'process_id':11,'metadata_schema':'idf_raw_dev.ecr_economic_data'})

if result["status_code"]==0:
    dbutils.notebook.exit(0)
else:
    print(f"Loading the data failed for process_id-{process_id}")
    raise

# COMMAND ----------

# MAGIC %sql
# MAGIC update idf_raw_dev.ecr_economic_data.t_job_control set job_status='NOT STARTED' where job_id=1 and job_status='RUNNING'

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select * from idf_raw_dev.ecr_economic_data.t_process_control where  process_id=1

# COMMAND ----------

# MAGIC %sql
# MAGIC update idf_raw_dev.ecr_economic_data.t_process_control set process_status='NOT STARTED' where process_id=1 and process_status='RUNNING' 
