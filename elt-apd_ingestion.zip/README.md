# ETL Curation Framework - Databricks

A modern, production-ready Python ETL framework built with Poetry for data processing and curation in Databricks environments.

## Getting Started

### 1. Clone and Install

```bash
git clone <repository-url>
cd elt-curation-framework-databricks
```

### 2. Usage

#### Streaming Pipelines
```bash
# Auto-detect streaming pipeline
poetry run apd_ingestion_framework --pipeline_name ihs_feed_ingestion --env dev

# Explicitly specify streaming
poetry run apd_ingestion_framework --pipeline_name ihs_feed_ingestion --env dev --streaming
```

#### Non-Streaming Jobs
```bash
# Batch job execution
poetry run apd_ingestion_framework --pipeline_name mydataIncremental --env dev
```
## Local Development Setup

For local development and testing, complete the following setup:

### Prerequisites

- **Python 3.10+** - [Download Python](https://www.python.org/downloads/)
- **Poetry** - [Install Poetry](https://python-poetry.org/docs/#installation)
- **Hadoop Utils** - Required for local Spark development

### 1. Install Poetry

```powershell
# Windows (PowerShell)
(Invoke-WebRequest -Uri https://install.python-poetry.org -UseBasicParsing).Content | python -

# Or using pip
pip install poetry
```

### 2. Install Hadoop Utils (Windows)

```powershell
# Download and extract Hadoop (example path)
# Download hadoop-2.10.1.tar.gz from Apache Hadoop releases
# Extract to: C:\Users\sunil_swarna\Downloads\hadoop

# Download winutils.exe and hadoop.dll from winutils repository
# Place both files in hadoop\bin\ directory

```
### 3 Setup in Local

### 3a. Environment Variables
```powershell

#We can execute this in a single line which will set all the required environment variables
# Set required vault token (replace with the actual token)
$env:LOCAL_TESTING="true"; $env:HADOOP_HOME="C:\Users\sunil_swarna\Downloads\hadoop"; $env:PATH="$env:HADOOP_HOME\bin;$env:PATH"; $env:IDF_GRDP_DOP_SHELF_ID="grdp-dop/dev"; $env:SPR_APP_SECRET_HC_GRDP_DOP_VAULT_TOKEN="REPLACE_WITH_TOKEN"
```
### 3b. application-local.yml Variables
1) Obtain the Non-Prod Kafka JKS file, place it in a local directory of your choice, and update the `truststore_location` variable in your config to point to this file.
2) Create a local folder to use as your checkpoint location, and update the `base_s3_path` variable in your config with this folder path.
3) Update the `spark.pyspark.python` and `spark.pyspark.driver.python` variables in your config to the full path of your local Python executable.

### 4. Run Local Pipelines

```bash
# Run streaming pipeline locally
poetry run apd_ingestion_framework --pipeline_name ihs_feed_ingestion --env local

# Run batch job locally
poetry run apd_ingestion_framework --pipeline_name mydataIncremental --env local
```

**Note:** The `SPR_APP_SECRET_HC_GRDP_DOP_VAULT_TOKEN` is required for local testing. You must provide your own token.



