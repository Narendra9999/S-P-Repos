# Databricks notebook source
from pyspark.sql import SparkSession
import uuid
import logging
import sys
import traceback
from pyspark.sql import functions as F
from apd_ingestion.ihs.ihs_utils import insert_process_status_started,update_process_status,get_last_processed_date,get_main_process_id
# Configure Logging
logging.basicConfig(stream=sys.stdout, level=logging.INFO)
logger = logging.getLogger(__name__)
spark = SparkSession.builder.appName("Load_Econ_Data_MnemonicMapping").getOrCreate()

# ---------- Helper Functions ----------

def generate_process_id():
    return str(uuid.uuid4())


def load_mnemonic_df(env, ihs_last_date):
    table = f"idf_curated_{env}.ecr_economic_data.t_mnemonicmapping"
    return spark.read.table(table).filter(f"last_upd_dttm is null or last_upd_dttm >= '{ihs_last_date}'")

def merge_mnemonicmapping(df, env, user, process_id):
    target_table = f"idf_raw_{env}.ihs_econ.t_ecr_mnemonicmapping"
    try:
        df.createOrReplaceTempView("staging_mnemonic")

        merge_sql = f"""
        MERGE INTO {target_table} AS target
        USING staging_mnemonic AS source
        ON target.ECR_TIMESERIESID = source.ECR_TIMESERIESID
        WHEN MATCHED THEN UPDATE SET
            target.IHS_CONNECT_MNEM = source.IHS_CONNECT_MNEM,
            target.ACTV_IND = source.ACTV_IND,
            target.CREATE_USR_ID = source.CREATE_USR_ID,
            target.CREATE_DTTM = source.CREATE_DTTM,
            target.LAST_UPD_USR_ID = source.LAST_UPD_USR_ID,
            target.LAST_UPD_DTTM = source.LAST_UPD_DTTM
        WHEN NOT MATCHED THEN INSERT (
            ECR_TIMESERIESID, IHS_CONNECT_MNEM, ACTV_IND, CREATE_USR_ID, CREATE_DTTM, LAST_UPD_USR_ID, LAST_UPD_DTTM
        ) VALUES (
            source.ECR_TIMESERIESID, source.IHS_CONNECT_MNEM, source.ACTV_IND, source.CREATE_USR_ID, source.CREATE_DTTM, source.LAST_UPD_USR_ID, source.LAST_UPD_DTTM
        )
        """
        spark.sql(merge_sql)
        logger.info("✅ Merge into ecr_mnemonicmapping successful.")

    except Exception as e:
        error_message = f"❌ Merge failed: {str(e)}"
        logger.error(error_message)
        update_process_status(env, user, process_id, status="FAILED", error_message=error_message)
        raise



# ---------- Main Execution Function ----------

def run_load_ecr_mnemonicmapping(env: str, user: str,run_type:str, start_date:str= None):

    main_process_id=get_main_process_id(env,run_type)
    if start_date:
        ihs_last_date=start_date
    else:
        ihs_last_date = get_last_processed_date(env,run_type,start_date,main_process_id)

    print(ihs_last_date)

    process_id = generate_process_id()
    try:
        print(f"🚀 Starting process ID: {process_id}")
        insert_process_status_started(env, user, process_id,main_process_id,run_type,table_name='ECR_MNEMONICMAPPING')
        print("✅ Process status updated to STARTED.")
        mnemonic_df = load_mnemonic_df( env, ihs_last_date)
        record_count = mnemonic_df.count()
        print(f"✅ Loaded {record_count} records to be merged.")
        merge_mnemonicmapping(mnemonic_df, env, user, process_id)
        #update_processed_date( env, user, process_id)
        update_process_status(env, user, process_id, status="COMPLETED")
        update_process_status(env, user, main_process_id, status="COMPLETED")

        print("🎉 load_ecr_mnemonicmapping task completed successfully.")

    except Exception as e:
        error_message = traceback.format_exc()
        logger.error(f"❌ Execution failed:\n{error_message}")
        update_process_status( env, user, process_id, status="FAILED", error_message=error_message)
        raise


#run_load_ecr_mnemonicmapping(env="dev", user="dop_user", fallback_date="2025-01-01")
