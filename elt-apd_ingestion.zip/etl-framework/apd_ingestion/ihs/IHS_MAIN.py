# Databricks notebook source
# Logging setup
import logging
from datetime import datetime
from pyspark.sql import SparkSession
from pyspark.sql.functions import lit, current_timestamp,col
from delta.tables import DeltaTable
from pyspark.sql.functions import current_timestamp, lit, expr
import traceback
import uuid
import traceback
import os
from apd_ingestion.constants.enum_vars import RunType
from pyspark.sql import functions as F
from apd_ingestion.ihs.ihs_utils import insert_batch_process_status_started, insert_process_status_started,update_process_status,get_last_processed_date

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("ETL_LOGGER")

spark = SparkSession.builder.appName("Load_Econ_Data_Pnt").getOrCreate()


def generate_process_id():
    return str(uuid.uuid4())


def deactivate_non_current_frmla_maps():
    try:
        logger.info("Deactivating non-current formula map IDs...")
        spark.sql(f"""
            UPDATE idf_raw_dev.ihs_econ.t_econ_data_pnt a
            SET
            a.end_dttm = (
                SELECT MAX(b.end_dttm)
                FROM idf_dev.finanalytic.t_de_ver_st_frmla_map b
                WHERE a.fa_de_ver_st_frmla_map_id = b.de_ver_st_frmla_map_id
                AND b.cur_ind = 'N'
                AND b.fm_data_source_id = 26
            ),
            a.cur_ind = 'N',
            a.last_upd_dttm = current_timestamp(),
            a.last_upd_usr_id = 'RAP'
            WHERE a.cur_ind = 'Y'
            AND a.fa_de_ver_st_frmla_map_id IN (
                SELECT c.de_ver_st_frmla_map_id
                FROM idf_dev.finanalytic.t_de_ver_st_frmla_map c
                WHERE c.cur_ind = 'N'
                AND c.fm_data_source_id = 26
            )

        """)
        logger.info("Deactivation complete.")
    except Exception as e:
        logger.error(f"Failed to deactivate formula maps: {e}")
        raise

# def get_last_processed_date(env_name, fallback_date: str = "2025-01-01"):
#     try:

#         df = spark.read.table(f"idf_raw_{env_name}.apd_control.t_process_status")
#         filtered_df = df.filter(F.col("PROCESS_NAME") == "IHS_BATCH_PROCESS")
#         latest_row = filtered_df.orderBy(F.col("LAST_PROCESSED_DTTM").desc()).limit(1)
#         rows = latest_row.selectExpr(
#             "CAST(LAST_PROCESSED_DTTM AS STRING) AS LAST_PROCESSED_DTTM"
#         ).collect()

#         return rows[0]['LAST_PROCESSED_DTTM'] if rows and rows[0]['LAST_PROCESSED_DTTM'] else fallback_date

#     except Exception as e:
#         logger.warning(f"Using fallback date due to error: {e}")
#         return fallback_date

def load_script2_df(env_name,user,ihs_last_date_script2):
    
    print(f"Loading Script2 data since: {ihs_last_date_script2}")

   
    query = f"""
    select
      ts.ecr_timeseriesid,
      ts.vendortimeseriesid,
      ts.mnemonic, 
      ts.longlabel, 
      ts.shortlabel, 
      ts.defaultmnemonic, 
      ts.legacyid,
      ts.vendorstartdate, 
      ts.vendorcreationtimestamp, 
      ts.vendorvaluestimestamp, 
      ts.attributetimestamp, 
      ts.baseperiodbegin,
      ts.baseperiodend, 
      ts.baseperiodvalue, 
      ts.ecr_concepttypeid, 
      ct.vendoreconomicconceptid, 
      ct.name concepttypename, 
      ts.ecr_frequencytypeid, 
      f.vendorfrequencyid, 
      f.name frequencytypename, 
      ts.ecr_geographiclocationid, 
      egl.vendorgeographiclocationid, 
      egl.name geolocationname, 
      ts.ecr_industryid, 
      i.vendorindustryclassificationid, 
      i.name industryname, 
      ts.ecr_scaleid, 
      sct.vendorscaleid, 
      sct.name scaletypename, 
      ts.ecr_seriestypeid, 
      st.vendorseriestypeid, 
      st.name seriestypename, 
      ts.ecr_unittypeid, 
      ut.vendorunitid, 
      ut.name unittypename, 
      c.currencyname, 
      c.isocode currencyisocode, 
      ts.historyforecastdate,
      ts.realnominal, 
      ts.seasonaladjustment,
      eb.ecr_bankid, 
      eb.vendorbankid, 
      eb.name bankname
    from idf_curated_{env_name}.ecr_economic_data.v_ecr_timeseries ts
    join idf_curated_{env_name}.ecr_economic_data.v_ecr_concepttype ct 
              on coalesce(ts.ecr_concepttypeid, -999999) = ct.ecr_concepttypeid 
              and ct.cur_ind = 'Y' and ct.actv_ind = 'Y'
    left join idf_curated_{env_name}.ecr_economic_data.v_ecr_seriestype st
              on coalesce(ts.ecr_seriestypeid, -999999) = st.ecr_seriestypeid
              and st.cur_ind = 'Y' and st.actv_ind = 'Y'
    left join idf_curated_{env_name}.ecr_economic_data.v_ecr_scaletype sct
              on coalesce(ts.ecr_scaleid, -999999) = sct.ecr_scaleid
              and sct.cur_ind = 'Y' and sct.actv_ind = 'Y'
    left join idf_curated_{env_name}.ecr_economic_data.v_ecr_frequencytype f
              on coalesce(ts.ecr_frequencytypeid, -999999) = f.ecr_frequencytypeid
              and f.actv_ind = 'Y' and f.cur_ind = 'Y'
    left join idf_curated_{env_name}.ecr_economic_data.v_ecr_industry i
              on coalesce(ts.ecr_industryid, -999999) = i.ecr_industryid
              and i.cur_ind = 'Y' and i.actv_ind = 'Y'
    left join idf_curated_{env_name}.ecr_economic_data.v_ecr_geographiclocation egl
              on coalesce(ts.ecr_geographiclocationid, -999999) = egl.ecr_geographiclocationid
              and egl.cur_ind = 'Y' and egl.actv_ind = 'Y'
    left join idf_curated_{env_name}.ecr_economic_data.v_ecr_unittype ut
              on coalesce(ts.ecr_unittypeid, -999999) = ut.ecr_unittypeid
              and ut.cur_ind = 'Y' and ut.actv_ind = 'Y'
    left join idf_curated_{env_name}.ecr_economic_data.v_ecr_unittype_currency utc
              on ut.ecr_unittypeid = utc.ecr_unittypeid
              and utc.actv_ind = 'Y'
    left join idf_curated_{env_name}.ecr_economic_data.v_currency c
              on utc.currencyid = c.currencyid
              and c.actv_ind = 'Y'
    join idf_curated_{env_name}.ecr_economic_data.v_ecr_timeseriesbank etb 
              on ts.ecr_timeseriesid = etb.ecr_timeseriesid
              and etb.actv_ind = 'Y'
    join idf_curated_{env_name}.ecr_economic_data.v_ecr_bank eb
              on etb.ecr_bankid = eb.ecr_bankid
              and eb.cur_ind = 'Y' and eb.actv_ind = 'Y'
    where f.vendorfrequencyid = 'ANNL'
    and (
         ts.create_Dttm >= cast('{ihs_last_date_script2}' as TIMESTAMP)
         or ts.last_upd_Dttm >= cast('{ihs_last_date_script2}' as TIMESTAMP)
         or ct.create_dttm >= cast('{ihs_last_date_script2}' as TIMESTAMP)
         or ct.last_upd_Dttm >= cast('{ihs_last_date_script2}' as TIMESTAMP)
         or st.create_dttm >= cast('{ihs_last_date_script2}' as TIMESTAMP)
         or st.last_upd_Dttm >= cast('{ihs_last_date_script2}' as TIMESTAMP)
         or sct.create_dttm >= cast('{ihs_last_date_script2}' as TIMESTAMP)
         or sct.last_upd_Dttm >= cast('{ihs_last_date_script2}' as TIMESTAMP)
         or f.create_dttm >= cast('{ihs_last_date_script2}' as TIMESTAMP)
         or f.last_upd_Dttm >= cast('{ihs_last_date_script2}' as TIMESTAMP)
         or i.create_dttm >= cast('{ihs_last_date_script2}' as TIMESTAMP)
         or i.last_upd_dttm >= cast('{ihs_last_date_script2}' as TIMESTAMP)
         or egl.create_dttm >= cast('{ihs_last_date_script2}' as TIMESTAMP)
         or egl.last_upd_dttm >= cast('{ihs_last_date_script2}' as TIMESTAMP)
         or ut.create_dttm >= cast('{ihs_last_date_script2}' as TIMESTAMP)
         or ut.last_upd_dttm >= cast('{ihs_last_date_script2}' as TIMESTAMP)
         or utc.create_dttm >= cast('{ihs_last_date_script2}' as TIMESTAMP)
         or utc.last_upd_Dttm >= cast('{ihs_last_date_script2}' as TIMESTAMP)
         or c.create_dttm >= cast('{ihs_last_date_script2}' as TIMESTAMP)
         or c.last_upd_dttm >= cast('{ihs_last_date_script2}' as TIMESTAMP)
         or etb.create_dttm >= cast('{ihs_last_date_script2}' as TIMESTAMP)
         or etb.last_upd_dttm >= cast('{ihs_last_date_script2}' as TIMESTAMP)
         or eb.create_dttm >= cast('{ihs_last_date_script2}' as TIMESTAMP)
         or eb.last_upd_dttm >= cast('{ihs_last_date_script2}' as TIMESTAMP)
    )
    """

    df = spark.sql(query)

    df = df.withColumn("LAST_UPD_USR_ID", lit(user)) \
           .withColumn("LAST_UPD_DTTM", current_timestamp()).selectExpr(
            "ecr_timeseriesid", "vendortimeseriesid", "mnemonic", "longlabel", "shortlabel", 
            "defaultmnemonic", "legacyid", "vendorstartdate", "vendorcreationtimestamp", 
            "vendorvaluestimestamp", "attributetimestamp", "baseperiodbegin", "baseperiodend", 
            "baseperiodvalue", "ecr_concepttypeid", "vendoreconomicconceptid", "concepttypename", 
            "ecr_frequencytypeid", "vendorfrequencyid", "frequencytypename", 
            "ecr_geographiclocationid", "vendorgeographiclocationid", "geolocationname", 
            "ecr_industryid", "vendorindustryclassificationid", "industryname", 
            "ecr_scaleid", "vendorscaleid", "scaletypename", 
            "ecr_seriestypeid", "vendorseriestypeid", "seriestypename", 
            "ecr_unittypeid", "vendorunitid", "unittypename", 
            "currencyname", "currencyisocode", "historyforecastdate", 
            "realnominal", "seasonaladjustment", "ecr_bankid", "vendorbankid", 
            "bankname", "LAST_UPD_USR_ID", "LAST_UPD_DTTM"
        )

    return df


def merge_script2_to_target(env_name,user,process_id,df_script2,target_table):
    

    print("Batch Execution:: Merge to ihs_econ.ECON_DATA_PNT Delta table has started")

    try:
        # Assuming script2_data is already defined as a DataFrame
        
        delta_table = DeltaTable.forName(spark, target_table)

        merge_condition = (
            (col("target.ECR_TIMESERIESID") == col("source.ECR_TIMESERIESID")) &
            (col("target.VENDORBANKID") == col("source.VENDORBANKID")) &
            (col("target.cur_ind") == "Y")
        )

        delta_table.alias("target").merge(
            df_script2.alias("source"),
            merge_condition
        ).whenMatchedUpdate(set =
            {
                "MNEMONIC": col("source.MNEMONIC"),
                "ECR_GEOGRAPHICLOCATIONID": col("source.ECR_GEOGRAPHICLOCATIONID"),
                "VENDORGEOGRAPHICLOCATIONID": col("source.VENDORGEOGRAPHICLOCATIONID"),
                "GEOLOCATIONNAME": col("source.GEOLOCATIONNAME"),
                "VENDORTIMESERIESID": col("source.VENDORTIMESERIESID"),
                "LONGLABEL": col("source.LONGLABEL"),
                "SHORTLABEL": col("source.SHORTLABEL"),
                "REALNOMINAL": col("source.REALNOMINAL"),
                "SEASONALADJUSTMENT": col("source.SEASONALADJUSTMENT"),
                "ECR_BANKID": col("source.ECR_BANKID"),
                "BANKNAME": col("source.BANKNAME"),
                "ECR_CONCEPTTYPEID": col("source.ECR_CONCEPTTYPEID"),
                "VENDORECONOMICCONCEPTID": col("source.VENDORECONOMICCONCEPTID"),
                "CONCEPTTYPENAME": col("source.CONCEPTTYPENAME"),
                "ECR_FREQUENCYTYPEID": col("source.ECR_FREQUENCYTYPEID"),
                "VENDORFREQUENCYID": col("source.VENDORFREQUENCYID"),
                "FREQUENCYTYPENAME": col("source.FREQUENCYTYPENAME"),
                "ECR_INDUSTRYID": col("source.ECR_INDUSTRYID"),
                "VENDORINDUSTRYCLASSIFICATIONID": col("source.VENDORINDUSTRYCLASSIFICATIONID"),
                "INDUSTRYNAME": col("source.INDUSTRYNAME"),
                "ECR_SCALEID": col("source.ECR_SCALEID"),
                "VENDORSCALEID": col("source.VENDORSCALEID"),
                "SCALETYPENAME": col("source.SCALETYPENAME"),
                "ECR_SERIESTYPEID": col("source.ECR_SERIESTYPEID"),
                "VENDORSERIESTYPEID": col("source.VENDORSERIESTYPEID"),
                "SERIESTYPENAME": col("source.SERIESTYPENAME"),
                "ECR_UNITTYPEID": col("source.ECR_UNITTYPEID"),
                "VENDORUNITID": col("source.VENDORUNITID"),
                "UNITTYPENAME": col("source.UNITTYPENAME"),
                "CURRENCYNAME": col("source.CURRENCYNAME"),
                "CURRENCYISOCODE": col("source.CURRENCYISOCODE"),
                "DEFAULTMNEMONIC": col("source.DEFAULTMNEMONIC"),
                "LEGACYID": col("source.LEGACYID"),
                "VENDORSTARTDATE": col("source.VENDORSTARTDATE"),
                "VENDORCREATIONTIMESTAMP": col("source.VENDORCREATIONTIMESTAMP"),
                "VENDORVALUESTIMESTAMP": col("source.VENDORVALUESTIMESTAMP"),
                "ATTRIBUTETIMESTAMP": col("source.ATTRIBUTETIMESTAMP"),
                "BASEPERIODBEGIN": col("source.BASEPERIODBEGIN"),
                "BASEPERIODEND": col("source.BASEPERIODEND"),
                "BASEPERIODVALUE": col("source.BASEPERIODVALUE"),
                "HISTORYFORECASTDATE": col("source.HISTORYFORECASTDATE"),
                "LAST_UPD_USR_ID": col("source.LAST_UPD_USR_ID"),
                "LAST_UPD_DTTM": col("source.LAST_UPD_DTTM")
            }
        ).execute()

        print("Load_ECON_DATA_PNT Delta table merge execution has completed")

    except Exception as e:
        error_message = f"Load_ECON_DATA_PNT task merge to Delta table has failed: {str(e)}\n{traceback.format_exc()}"
        print(error_message)

        # failure_insert_sql =  f"""
        #     INSERT INTO idf_raw_{env_name}.apd_control.t_process_status (
        #         PROCESS_ID,
        #         TABLE_NAME,
        #         S3_PATH,
        #         FILE_TIMESTAMP,
        #         STATUS,
        #         PROCESS_STARTTIME,
        #         PROCESS_ENDTIME,
        #         ERROR,
        #         THRESHOLD,
        #         CREATE_DATE,
        #         CREATE_BY,
        #         UPDATE_DATE,
        #         UPDATE_BY
        #     ) 
        #     SELECT 
        #         uuid(),
        #         'ihs_econ.ECON_DATA_PNT',
        #         NULL,
        #         current_timestamp(),
        #         'FAILED',
        #         NULL,
        #         NULL,
        #         '{error_msg}',
        #         NULL,
        #         current_timestamp(),
        #         '{user}',
        #         current_timestamp(),
        #         '{user}'
        #     """

        # spark.sql(failure_insert_sql)
        update_process_status(env_name, user, process_id, status="FAILED",error_message=error_message)



def load_script3_df(env_name, user, ihs_last_date_script2):
    """
    Load observation products that are no longer current and were recently created/updated.
    """
    query = f"""
    SELECT 
        ecr_observationproductid, 
        end_dttm, 
        cur_ind, 
        vendorasof 
    FROM idf_curated_{env_name}.ecr_economic_data.v_ecr_observationproduct
    WHERE cur_ind = 'N'
      AND (
          create_dttm >= CAST('{ihs_last_date_script2}' AS TIMESTAMP) OR 
          last_upd_dttm >= CAST('{ihs_last_date_script2}' AS TIMESTAMP)
      )
    """

    script3_df = spark.sql(query)

    script3_data = (
        script3_df
        .withColumn("LAST_UPD_USR_ID", lit(user))
        .withColumn("LAST_UPD_DTTM", current_timestamp())
        .select(
            "ECR_OBSERVATIONPRODUCTID", 
            "END_DTTM", 
            "CUR_IND", 
            "LAST_UPD_USR_ID", 
            "LAST_UPD_DTTM"
        )
    )

    return script3_data


def merge_script3_to_target(env_name, user, process_id, target_table, ihs_last_date_script2):
    """
    Merge data from script3 into the target Delta table (Databricks Catalog).
    """
    try:
        print("Starting Script3 merge logic...")

        # Load the filtered data
        script3_data = load_script3_df(env_name, user, ihs_last_date_script2)

        # Get a handle to the Delta Table
        delta_table = DeltaTable.forName(spark, target_table)

        # Perform merge (only update rows where cur_ind = 'Y')
        delta_table.alias("tgt").merge(
            source=script3_data.alias("src"),
            condition="""
                tgt.ECR_OBSERVATIONPRODUCTID = src.ECR_OBSERVATIONPRODUCTID
                AND tgt.CUR_IND = 'Y'
            """
        ).whenMatchedUpdate(set={
            "END_DTTM": "src.END_DTTM",
            "CUR_IND": "src.CUR_IND",
            "LAST_UPD_USR_ID": "src.LAST_UPD_USR_ID",
            "LAST_UPD_DTTM": "src.LAST_UPD_DTTM"
        }).execute()

        print("✅ ECON_DATA_PNT table successfully updated with script3 logic.")

    except Exception as e:
        error_msg = f"❌ Script3 failed to update ECON_DATA_PNT: {str(e)}"
        print(error_msg)

        
        update_process_status(
            env_name=env_name,
            user=user,
            process_id=process_id,
            status="FAILED",
            error_message=error_msg
        )



def load_script4_df(env_name, user, ihs_last_date, filter_ids=None):
    # Convert list to SQL IN clause
    frmla_map_filter = "1=1"
    if filter_ids and filter_ids.get("formula_map_ids"):
        # Ensure values are properly escaped and comma-separated
        formatted_ids = ",".join(f"'{str(id)}'" for id in filter_ids["formula_map_ids"])
        frmla_map_filter = f"frml.DE_VER_ST_FRMLA_MAP_ID IN ({formatted_ids})"

    query = f"""
    WITH params AS (
        SELECT dv.ent_mnem_cd, frml.frmla_text, substr(frmla_text, 1, instr(frmla_text, '***') - 1) prefix,
               frml.FM_DATA_SOURCE_ID, frml.start_dttm, frml.end_dttm, vend.VENDORSERIESTYPEID, vend.VENDORFREQUENCYID,
               vend.VENDORGEOGRAPHICLOCATIONID, dv.create_dttm dv_create_dttm, dv.LAST_UPD_DTTM dv_last_upd_dttm,
               dvs.CREATE_DTTM dvs_create_dttm, dvs.LAST_UPD_DTTM dvs_last_upd_dttm, frml.CREATE_DTTM frml_create_dttm,
               frml.LAST_UPD_DTTM frml_last_upd_dttm, ent.ent_mnem_denom_name, frml.DE_VER_ST_FRMLA_MAP_ID,
               ent.CREATE_DTIME ent_create_dtime, ent.UPDATE_DTIME ent_update_dtime,vend.CREATE_DTTM vend_create_dttm,
               vend.LAST_UPD_DTTM vend_last_upd_dttm
          FROM idf_{env_name}.finanalytic.v_de_ver dv
          JOIN idf_{env_name}.finanalytic.v_de_ver_st dvs ON dv.de_ver_id = dvs.de_ver_id AND dvs.CUR_IND = 'Y'
          JOIN idf_{env_name}.finanalytic.v_de_ver_st_frmla_map frml
               ON dvs.DE_VER_ST_ID = frml.de_ver_st_id AND frml.cur_ind = 'Y' AND frml.frmla_text LIKE '%***' AND frml.FM_DATA_SOURCE_ID = 26
          JOIN idf_{env_name}.finanalytic.v_de_frmla_map_vendor_attr vend
               ON frml.DE_VER_ST_FRMLA_MAP_ID = vend.de_ver_st_frmla_map_id AND vend.ACTV_IND = 'Y'
          JOIN idf_{env_name}.mnem_map.v_ent_mnem ent
               ON dv.ENT_MNEM_CD = ent.ent_mnem_cd
              AND ent.MNEMONIC_TYPE = 'Financial'
              AND ent.MNEMONIC_SUBTYPE = 'Reported'
              AND ent.IS_DELETED = 'N'
         WHERE dv.CUR_IND = 'Y'
         AND ({frmla_map_filter})
    )
    SELECT 
        ts.ecr_timeseriesid, ts.vendortimeseriesid, ts.mnemonic, ts.longlabel, ts.shortlabel, ts.defaultmnemonic, ts.legacyid,
        ts.vendorstartdate, ts.vendorcreationtimestamp, ts.vendorvaluestimestamp, ts.attributetimestamp, ts.baseperiodbegin,
        ts.baseperiodend, ts.baseperiodvalue, ts.ecr_concepttypeid, ct.vendoreconomicconceptid, ct.name concepttypename, 
        ts.ecr_frequencytypeid, f.vendorfrequencyid, f.name frequencytypename, ts.ecr_geographiclocationid, 
        egl.vendorgeographiclocationid, egl.name geolocationname, ts.ecr_industryid, i.vendorindustryclassificationid, i.name industryname, 
        ts.ecr_scaleid, sct.vendorscaleid, sct.name scaletypename, ts.ecr_seriestypeid, st.vendorseriestypeid, st.name seriestypename, 
        ts.ecr_unittypeid, ut.vendorunitid, ut.name unittypename, c.currencyname, c.isocode currencyisocode, ts.historyforecastdate,
        ts.realnominal, ts.seasonaladjustment, eop.ecr_observationproductid, eop.vendorasof, eop.value, eop.vendormodificationtime,
        eop.vendorlastupdatetime, eop.start_dttm, eop.end_dttm, eop.vendorproductnumber, eb.ecr_bankid, eb.vendorbankid, eb.name bankname,
        eop.cur_ind,
        params.ent_mnem_cd, params.frmla_text, params.prefix, params.FM_DATA_SOURCE_ID, params.ent_mnem_denom_name, params.DE_VER_ST_FRMLA_MAP_ID AS FA_DE_VER_ST_FRMLA_MAP_ID
    FROM idf_curated_{env_name}.ecr_economic_data.v_ecr_timeseries ts
    LEFT JOIN idf_curated_{env_name}.ecr_economic_data.v_ecr_concepttype ct 
          ON nvl(ts.ecr_concepttypeid, -999999) = ct.ecr_concepttypeid 
          AND ct.cur_ind = 'Y' AND ct.actv_ind = 'Y'
    LEFT JOIN idf_curated_{env_name}.ecr_economic_data.v_ecr_seriestype st
          ON nvl(ts.ecr_seriestypeid, -999999) = st.ecr_seriestypeid
          AND st.cur_ind = 'Y' AND st.actv_ind = 'Y'
    LEFT JOIN idf_curated_{env_name}.ecr_economic_data.v_ecr_scaletype sct
          ON nvl(ts.ecr_scaleid, -999999) = sct.ecr_scaleid
          AND sct.cur_ind = 'Y' AND sct.actv_ind = 'Y'
    LEFT JOIN idf_curated_{env_name}.ecr_economic_Data.v_ecr_frequencytype f
          ON nvl(ts.ecr_frequencytypeid, -999999) = f.ecr_frequencytypeid
          AND f.actv_ind = 'Y' AND f.cur_ind = 'Y'
    LEFT JOIN idf_curated_{env_name}.ecr_economic_data.v_ecr_industry i
          ON nvl(ts.ecr_industryid, -999999) = i.ecr_industryid
          AND i.cur_ind = 'Y' AND i.actv_ind = 'Y'
    LEFT JOIN idf_curated_{env_name}.ecr_economic_data.v_ecr_geographiclocation egl
          ON nvl(ts.ecr_geographiclocationid, -999999) = egl.ecr_geographiclocationid
          AND egl.cur_ind = 'Y' AND egl.actv_ind = 'Y'
    LEFT JOIN idf_curated_{env_name}.ecr_economic_data.v_ecr_unittype ut
          ON nvl(ts.ecr_unittypeid, -999999) = ut.ecr_unittypeid
          AND ut.cur_ind = 'Y' AND ut.actv_ind = 'Y'
    LEFT JOIN idf_curated_{env_name}.ecr_economic_data.v_ecr_unittype_currency utc
          ON ut.ecr_unittypeid = utc.ecr_unittypeid
          AND utc.actv_ind = 'Y'
    LEFT JOIN idf_curated_{env_name}.ecr_economic_data.v_currency c
          ON utc.currencyid = c.currencyid
          AND c.actv_ind = 'Y'
    JOIN idf_curated_{env_name}.ecr_economic_data.v_ecr_observationproduct eop
          ON ts.ecr_timeseriesid = eop.ecr_timeseriesid
          AND eop.cur_ind = 'Y' AND eop.actv_ind = 'Y'
    JOIN idf_curated_{env_name}.ecr_economic_data.v_ecr_timeseriesbank etb 
          ON ts.ecr_timeseriesid = etb.ecr_timeseriesid
          AND etb.actv_ind = 'Y'
    JOIN idf_curated_{env_name}.ecr_economic_data.v_ecr_bank eb
          ON etb.ecr_bankid = eb.ecr_bankid
          AND eb.cur_ind = 'Y' AND eb.actv_ind = 'Y'
    JOIN params ON params.prefix = substr(ts.mnemonic, 1, length(params.prefix))
              AND st.vendorseriestypeid = params.vendorseriestypeid
              AND f.vendorfrequencyid = params.vendorfrequencyid
              AND ((params.vendorgeographiclocationid IS NOT NULL AND params.vendorgeographiclocationid = egl.vendorgeographiclocationid) OR params.vendorgeographiclocationid IS NULL)
    WHERE ts.actv_ind = 'Y'
      AND f.vendorfrequencyid = 'ANNL'
      AND eop.vendorasof BETWEEN '1900-01-01' AND '9999-12-31'
      AND (
         ts.create_Dttm >= CAST('{ihs_last_date}' AS TIMESTAMP)
         OR ts.last_upd_Dttm >= CAST('{ihs_last_date}' AS TIMESTAMP)
         OR ct.create_dttm >= CAST('{ihs_last_date}' AS TIMESTAMP)
         OR ct.last_upd_Dttm >= CAST('{ihs_last_date}' AS TIMESTAMP)
         OR st.create_dttm >= CAST('{ihs_last_date}' AS TIMESTAMP)
         OR st.last_upd_Dttm >= CAST('{ihs_last_date}' AS TIMESTAMP)
         OR sct.create_dttm >= CAST('{ihs_last_date}' AS TIMESTAMP)
         OR sct.last_upd_Dttm >= CAST('{ihs_last_date}' AS TIMESTAMP)
         OR f.create_dttm >= CAST('{ihs_last_date}' AS TIMESTAMP)
         OR f.last_upd_Dttm >= CAST('{ihs_last_date}' AS TIMESTAMP)
         OR i.create_dttm >= CAST('{ihs_last_date}' AS TIMESTAMP)
         OR i.last_upd_dttm >= CAST('{ihs_last_date}' AS TIMESTAMP)
         OR egl.create_dttm >= CAST('{ihs_last_date}' AS TIMESTAMP)
         OR egl.last_upd_dttm >= CAST('{ihs_last_date}' AS TIMESTAMP)
         OR ut.create_dttm >= CAST('{ihs_last_date}' AS TIMESTAMP)
         OR ut.last_upd_dttm >= CAST('{ihs_last_date}' AS TIMESTAMP)
         OR utc.create_dttm >= CAST('{ihs_last_date}' AS TIMESTAMP)
         OR utc.last_upd_Dttm >= CAST('{ihs_last_date}' AS TIMESTAMP)
         OR c.create_dttm >= CAST('{ihs_last_date}' AS TIMESTAMP)
         OR c.last_upd_dttm >= CAST('{ihs_last_date}' AS TIMESTAMP)
         OR eop.create_dttm >= CAST('{ihs_last_date}' AS TIMESTAMP)
         OR eop.last_upd_dttm >= CAST('{ihs_last_date}' AS TIMESTAMP)
         OR etb.create_dttm >= CAST('{ihs_last_date}' AS TIMESTAMP)
         OR etb.last_upd_dttm >= CAST('{ihs_last_date}' AS TIMESTAMP)
         OR eb.create_dttm >= CAST('{ihs_last_date}' AS TIMESTAMP)
         OR eb.last_upd_dttm >= CAST('{ihs_last_date}' AS TIMESTAMP)
         OR params.dv_create_dttm >= CAST('{ihs_last_date}' AS TIMESTAMP)
         OR params.dv_last_upd_dttm >= CAST('{ihs_last_date}' AS TIMESTAMP)
         OR params.dvs_create_dttm >= CAST('{ihs_last_date}' AS TIMESTAMP)
         OR params.dvs_last_upd_dttm >= CAST('{ihs_last_date}' AS TIMESTAMP)
         OR params.frml_create_dttm >= CAST('{ihs_last_date}' AS TIMESTAMP)
         OR params.frml_last_upd_dttm >= CAST('{ihs_last_date}' AS TIMESTAMP)
         OR params.vend_create_dttm >= CAST('{ihs_last_date}' AS TIMESTAMP)
         OR params.vend_last_upd_dttm >= CAST('{ihs_last_date}' AS TIMESTAMP)
         OR params.ent_create_dtime >= CAST('{ihs_last_date}' AS TIMESTAMP)
         OR params.ent_update_dtime >= CAST('{ihs_last_date}' AS TIMESTAMP)
      )
    """
    
    script4_df = spark.sql(query)
    
    script4_data = (
        script4_df
        .withColumn("ECON_DATA_PNT_ID", lit(0).cast("long"))
        .withColumn("CREATE_USR_ID", lit(user))
        .withColumn("CREATE_DTTM", current_timestamp())
        .withColumn("LAST_UPD_USR_ID", lit(user))
        .withColumn("LAST_UPD_DTTM", current_timestamp())
        .selectExpr(
            "ECON_DATA_PNT_ID",
            "ECR_OBSERVATIONPRODUCTID",
            "VENDORBANKID",
            "VENDORASOF",
            "MNEMONIC",
            "VALUE",
            "ECR_GEOGRAPHICLOCATIONID",
            "VENDORGEOGRAPHICLOCATIONID",
            "GEOLOCATIONNAME",
            "ECR_TIMESERIESID",
            "VENDORTIMESERIESID",
            "START_DTTM",
            "END_DTTM",
            "CUR_IND",
            "ENT_MNEM_CD",
            "FM_DATA_SOURCE_ID",
            "FA_DE_VER_ST_FRMLA_MAP_ID",
            "LONGLABEL",
            "SHORTLABEL",
            "REALNOMINAL",
            "SEASONALADJUSTMENT",
            "VENDORPRODUCTNUMBER",
            "ECR_BANKID",
            "BANKNAME",
            "ECR_CONCEPTTYPEID",
            "VENDORECONOMICCONCEPTID",
            "CONCEPTTYPENAME",
            "ECR_FREQUENCYTYPEID",
            "VENDORFREQUENCYID",
            "FREQUENCYTYPENAME",
            "ECR_INDUSTRYID",
            "VENDORINDUSTRYCLASSIFICATIONID",
            "INDUSTRYNAME",
            "ECR_SCALEID",
            "VENDORSCALEID",
            "SCALETYPENAME",
            "ECR_SERIESTYPEID",
            "VENDORSERIESTYPEID",
            "SERIESTYPENAME",
            "ECR_UNITTYPEID",
            "VENDORUNITID",
            "UNITTYPENAME",
            "CURRENCYNAME",
            "CURRENCYISOCODE",
            "DEFAULTMNEMONIC",
            "LEGACYID",
            "VENDORSTARTDATE",
            "VENDORCREATIONTIMESTAMP",
            "VENDORVALUESTIMESTAMP",
            "ATTRIBUTETIMESTAMP",
            "BASEPERIODBEGIN",
            "BASEPERIODEND",
            "BASEPERIODVALUE",
            "HISTORYFORECASTDATE",
            "VENDORMODIFICATIONTIME",
            "VENDORLASTUPDATETIME",
            "CREATE_USR_ID",
            "CREATE_DTTM",
            "LAST_UPD_USR_ID",
            "LAST_UPD_DTTM",
            "ENT_MNEM_DENOM_NAME"
        )
    )
    
    return script4_data

def merge_script4_to_target(env_name,user,df_script4,process_id,target_table):
    try:
        print("Batch Execution:: Merge to Databricks Delta Table has started")

        # Add metadata columns
        script4_data = df_script4 \
            .withColumn("ECON_DATA_PNT_ID", lit(0)) \
            .withColumn("CREATE_USR_ID", lit(user)) \
            .withColumn("CREATE_DTTM", current_timestamp()) \
            .withColumn("LAST_UPD_USR_ID", lit(user)) \
            .withColumn("LAST_UPD_DTTM", current_timestamp())

        # Define target table
        target_table = DeltaTable.forName(spark, target_table)

        # Perform merge (upsert)
        target_table.alias("a").merge(
            script4_data.alias("b"),
            """
            a.ECR_OBSERVATIONPRODUCTID = b.ECR_OBSERVATIONPRODUCTID AND
            a.VENDORBANKID = b.VENDORBANKID AND
            a.FA_DE_VER_ST_FRMLA_MAP_ID = b.FA_DE_VER_ST_FRMLA_MAP_ID
            """
        ).whenMatchedUpdate(set={
            "ECON_DATA_PNT_ID": col("a.ECON_DATA_PNT_ID"),
            "VENDORASOF": col("b.VENDORASOF"),
            "MNEMONIC": col("b.MNEMONIC"),
            "VALUE": col("b.VALUE"),
            "ECR_GEOGRAPHICLOCATIONID": col("b.ECR_GEOGRAPHICLOCATIONID"),
            "VENDORGEOGRAPHICLOCATIONID": col("b.VENDORGEOGRAPHICLOCATIONID"),
            "GEOLOCATIONNAME": col("b.GEOLOCATIONNAME"),
            "ECR_TIMESERIESID": col("b.ECR_TIMESERIESID"),
            "VENDORTIMESERIESID": col("b.VENDORTIMESERIESID"),
            "START_DTTM": col("b.START_DTTM"),
            "END_DTTM": col("b.END_DTTM"),
            "CUR_IND": col("b.CUR_IND"),
            "ENT_MNEM_CD": col("b.ENT_MNEM_CD"),
            "FM_DATA_SOURCE_ID": col("b.FM_DATA_SOURCE_ID"),
            "LONGLABEL": col("b.LONGLABEL"),
            "SHORTLABEL": col("b.SHORTLABEL"),
            "REALNOMINAL": col("b.REALNOMINAL"),
            "SEASONALADJUSTMENT": col("b.SEASONALADJUSTMENT"),
            "VENDORPRODUCTNUMBER": col("b.VENDORPRODUCTNUMBER"),
            "ECR_BANKID": col("b.ECR_BANKID"),
            "BANKNAME": col("b.BANKNAME"),
            "ECR_CONCEPTTYPEID": col("b.ECR_CONCEPTTYPEID"),
            "VENDORECONOMICCONCEPTID": col("b.VENDORECONOMICCONCEPTID"),
            "CONCEPTTYPENAME": col("b.CONCEPTTYPENAME"),
            "ECR_FREQUENCYTYPEID": col("b.ECR_FREQUENCYTYPEID"),
            "VENDORFREQUENCYID": col("b.VENDORFREQUENCYID"),
            "FREQUENCYTYPENAME": col("b.FREQUENCYTYPENAME"),
            "ECR_INDUSTRYID": col("b.ECR_INDUSTRYID"),
            "VENDORINDUSTRYCLASSIFICATIONID": col("b.VENDORINDUSTRYCLASSIFICATIONID"),
            "INDUSTRYNAME": col("b.INDUSTRYNAME"),
            "ECR_SCALEID": col("b.ECR_SCALEID"),
            "VENDORSCALEID": col("b.VENDORSCALEID"),
            "SCALETYPENAME": col("b.SCALETYPENAME"),
            "ECR_SERIESTYPEID": col("b.ECR_SERIESTYPEID"),
            "VENDORSERIESTYPEID": col("b.VENDORSERIESTYPEID"),
            "SERIESTYPENAME": col("b.SERIESTYPENAME"),
            "ECR_UNITTYPEID": col("b.ECR_UNITTYPEID"),
            "VENDORUNITID": col("b.VENDORUNITID"),
            "UNITTYPENAME": col("b.UNITTYPENAME"),
            "CURRENCYNAME": col("b.CURRENCYNAME"),
            "CURRENCYISOCODE": col("b.CURRENCYISOCODE"),
            "DEFAULTMNEMONIC": col("b.DEFAULTMNEMONIC"),
            "LEGACYID": col("b.LEGACYID"),
            "VENDORSTARTDATE": col("b.VENDORSTARTDATE"),
            "VENDORCREATIONTIMESTAMP": col("b.VENDORCREATIONTIMESTAMP"),
            "VENDORVALUESTIMESTAMP": col("b.VENDORVALUESTIMESTAMP"),
            "ATTRIBUTETIMESTAMP": col("b.ATTRIBUTETIMESTAMP"),
            "BASEPERIODBEGIN": col("b.BASEPERIODBEGIN"),
            "BASEPERIODEND": col("b.BASEPERIODEND"),
            "BASEPERIODVALUE": col("b.BASEPERIODVALUE"),
            "HISTORYFORECASTDATE": col("b.HISTORYFORECASTDATE"),
            "VENDORMODIFICATIONTIME": col("b.VENDORMODIFICATIONTIME"),
            "VENDORLASTUPDATETIME": col("b.VENDORLASTUPDATETIME"),
            "CREATE_USR_ID": col("b.CREATE_USR_ID"),
            "CREATE_DTTM": col("b.CREATE_DTTM"),
            "LAST_UPD_USR_ID": col("b.LAST_UPD_USR_ID"),
            "LAST_UPD_DTTM": col("b.LAST_UPD_DTTM"),
            "ENT_MNEM_DENOM_NAME": col("b.ENT_MNEM_DENOM_NAME")
        }).whenNotMatchedInsert(values={
            "ECON_DATA_PNT_ID": lit(None),  # Will be populated by sequence or auto-ID
            "ECR_OBSERVATIONPRODUCTID": col("b.ECR_OBSERVATIONPRODUCTID"),
            "VENDORBANKID": col("b.VENDORBANKID"),
            "VENDORASOF": col("b.VENDORASOF"),
            "MNEMONIC": col("b.MNEMONIC"),
            "VALUE": col("b.VALUE"),
            "ECR_GEOGRAPHICLOCATIONID": col("b.ECR_GEOGRAPHICLOCATIONID"),
            "VENDORGEOGRAPHICLOCATIONID": col("b.VENDORGEOGRAPHICLOCATIONID"),
            "GEOLOCATIONNAME": col("b.GEOLOCATIONNAME"),
            "ECR_TIMESERIESID": col("b.ECR_TIMESERIESID"),
            "VENDORTIMESERIESID": col("b.VENDORTIMESERIESID"),
            "START_DTTM": col("b.START_DTTM"),
            "END_DTTM": col("b.END_DTTM"),
            "CUR_IND": col("b.CUR_IND"),
            "ENT_MNEM_CD": col("b.ENT_MNEM_CD"),
            "FM_DATA_SOURCE_ID": col("b.FM_DATA_SOURCE_ID"),
            "FA_DE_VER_ST_FRMLA_MAP_ID": col("b.FA_DE_VER_ST_FRMLA_MAP_ID"),
            "LONGLABEL": col("b.LONGLABEL"),
            "SHORTLABEL": col("b.SHORTLABEL"),
            "REALNOMINAL": col("b.REALNOMINAL"),
            "SEASONALADJUSTMENT": col("b.SEASONALADJUSTMENT"),
            "VENDORPRODUCTNUMBER": col("b.VENDORPRODUCTNUMBER"),
            "ECR_BANKID": col("b.ECR_BANKID"),
            "BANKNAME": col("b.BANKNAME"),
            "ECR_CONCEPTTYPEID": col("b.ECR_CONCEPTTYPEID"),
            "VENDORECONOMICCONCEPTID": col("b.VENDORECONOMICCONCEPTID"),
            "CONCEPTTYPENAME": col("b.CONCEPTTYPENAME"),
            "ECR_FREQUENCYTYPEID": col("b.ECR_FREQUENCYTYPEID"),
            "VENDORFREQUENCYID": col("b.VENDORFREQUENCYID"),
            "FREQUENCYTYPENAME": col("b.FREQUENCYTYPENAME"),
            "ECR_INDUSTRYID": col("b.ECR_INDUSTRYID"),
            "VENDORINDUSTRYCLASSIFICATIONID": col("b.VENDORINDUSTRYCLASSIFICATIONID"),
            "INDUSTRYNAME": col("b.INDUSTRYNAME"),
            "ECR_SCALEID": col("b.ECR_SCALEID"),
            "VENDORSCALEID": col("b.VENDORSCALEID"),
            "SCALETYPENAME": col("b.SCALETYPENAME"),
            "ECR_SERIESTYPEID": col("b.ECR_SERIESTYPEID"),
            "VENDORSERIESTYPEID": col("b.VENDORSERIESTYPEID"),
            "SERIESTYPENAME": col("b.SERIESTYPENAME"),
            "ECR_UNITTYPEID": col("b.ECR_UNITTYPEID"),
            "VENDORUNITID": col("b.VENDORUNITID"),
            "UNITTYPENAME": col("b.UNITTYPENAME"),
            "CURRENCYNAME": col("b.CURRENCYNAME"),
            "CURRENCYISOCODE": col("b.CURRENCYISOCODE"),
            "DEFAULTMNEMONIC": col("b.DEFAULTMNEMONIC"),
            "LEGACYID": col("b.LEGACYID"),
            "VENDORSTARTDATE": col("b.VENDORSTARTDATE"),
            "VENDORCREATIONTIMESTAMP": col("b.VENDORCREATIONTIMESTAMP"),
            "VENDORVALUESTIMESTAMP": col("b.VENDORVALUESTIMESTAMP"),
            "ATTRIBUTETIMESTAMP": col("b.ATTRIBUTETIMESTAMP"),
            "BASEPERIODBEGIN": col("b.BASEPERIODBEGIN"),
            "BASEPERIODEND": col("b.BASEPERIODEND"),
            "BASEPERIODVALUE": col("b.BASEPERIODVALUE"),
            "HISTORYFORECASTDATE": col("b.HISTORYFORECASTDATE"),
            "VENDORMODIFICATIONTIME": col("b.VENDORMODIFICATIONTIME"),
            "VENDORLASTUPDATETIME": col("b.VENDORLASTUPDATETIME"),
            "CREATE_USR_ID": col("b.CREATE_USR_ID"),
            "CREATE_DTTM": col("b.CREATE_DTTM"),
            "LAST_UPD_USR_ID": col("b.LAST_UPD_USR_ID"),
            "LAST_UPD_DTTM": col("b.LAST_UPD_DTTM"),
            "ENT_MNEM_DENOM_NAME": col("b.ENT_MNEM_DENOM_NAME")
        }).execute()

        print("Load_ECON_DATA_PNT task execution has completed successfully.")

    except Exception as e:
        error_message = f"Load_ECON_DATA_PNT task merge failed: {str(e)}"
        print(error_message)

        # spark.sql(f"""
        #     INSERT INTO idf_raw_{env_name}.apd_control.t_process_status (
        #         PROCESS_ID,TABLE_NAME, S3_PATH, FILE_TIMESTAMP, STATUS,
        #         PROCESS_STARTTIME, PROCESS_ENDTIME, ERROR,
        #         THRESHOLD, CREATE_DATE, CREATE_BY, UPDATE_DATE, UPDATE_BY
        #     ) VALUES (
        #         uuid(),'ihs_econ.ECON_DATA_PNT', null, current_timestamp(), 'FAILED',
        #         null, null, '{error_message}', null,
        #         current_timestamp(), '{user}', current_timestamp(), '{user}'
        #     )
        # """)
        update_process_status(env_name, user, process_id, status="FAILED",error_message=error_message)


def run_etl(user,env_name,run_type,start_date=None,filters=None):
    if start_date:
        ihs_last_date=start_date
    else:
        ihs_last_date = get_last_processed_date(env_name,run_type,start_date)
    print(f"Last processed date: {ihs_last_date}")
    print(run_type)
    batch_process_id=generate_process_id()
    insert_batch_process_status_started(env_name,user,batch_process_id,run_type,status="STARTED")
    print("batch_process_id",batch_process_id)
    process_id=generate_process_id()
    print(process_id)
    insert_process_status_started(env_name,user,process_id, batch_process_id,run_type,table_name='ECON_DATA_PNT')
    deactivate_non_current_frmla_maps()
    ihs_last_date_script2 = datetime.now().strftime("%Y-%m-%d") if ihs_last_date == "1900-01-01" else ihs_last_date
    df_script2 = load_script2_df(env_name, user, ihs_last_date_script2)
    print(f"Script2 records: {df_script2.count()}")
    merge_script2_to_target(env_name,user,process_id,df_script2,target_table=f"idf_raw_{env_name}.ihs_econ.t_econ_data_pnt")

    merge_script3_to_target(env_name, user, process_id, f"idf_raw_{env_name}.ihs_econ.t_econ_data_pnt", ihs_last_date_script2)

      # Pass filters to script4 ONLY if run_type is "stream"
    if run_type in (RunType.FINANALYTIC_STREAM.value, RunType.USPF_STREAM.value):
        df_script4 = load_script4_df(env_name, user, ihs_last_date, filter_ids=filters)
    else:
        df_script4 = load_script4_df(env_name, user, ihs_last_date)
    print(f"Script4 records: {df_script4.count()}")
    merge_script4_to_target(env_name,user,df_script4,process_id,target_table= f"idf_raw_{env_name}.ihs_econ.t_econ_data_pnt")
    update_process_status(env_name, user, process_id, status="COMPLETED")
    print("ETL process completed successfully ✅")

#run_etl(env_name='dev',user="dop_user", fallback_date="2025-01-01")
    