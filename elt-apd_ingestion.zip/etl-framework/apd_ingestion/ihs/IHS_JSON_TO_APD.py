from pyspark import StorageLevel
from pyspark.sql import functions as F
from pyspark.sql.functions import col, when, struct, lit, udf, to_json, from_json, to_timestamp,from_json, date_format
from pyspark.sql.types import DoubleType, StructType, StructField, StringType,DoubleType, ArrayType,TimestampType
import time
from pyspark.sql import SparkSession
from pyspark.sql import DataFrame
from datetime import datetime
from typing import Dict,List, Optional
from apd_ingestion.database.postgres.adp_postgres_handler import ADPPostgresHandler
from apd_ingestion.constants.enum_vars import RunType,LoadType
from apd_ingestion.ihs.ihs_utils import get_last_processed_date,is_ihs_batch_completed,get_main_process_id
from pyspark.sql.functions import get_json_object
import logging
import sys
logging.basicConfig(stream=sys.stdout, level=logging.INFO)
logger = logging.getLogger(__name__)




def build_in_clause(column_name, values):
    """
    Utility to build SQL IN clause string safely for multiple values.
    """
    if not values:
        return ""
    quoted_values = ", ".join(f"'{val}'" for val in values)
    return f"AND {column_name} IN ({quoted_values})"



def load_input_dataframes(spark,is_incremental,env,run_type,ihs_last_date, filter_ids=None):
    """
    Load and filter all input DataFrames using optional filters for geo_unit_ids and org_ids.

    :param spark: SparkSession
    :param geo_unit_ids: List of geo_unit_id strings
    :param org_ids: List of org_id strings
    :return: Tuple of DataFrames
    """

    fips_code = filter_ids.get("fips_code") if filter_ids else None
    org_ids = filter_ids.get("org_ids") if filter_ids else None

    # Handle strings passed instead of lists
    if isinstance(fips_code, str):
        fips_code = [fips_code]
    if isinstance(org_ids, str):
        org_ids = [org_ids]

    geo_filter_clause = build_in_clause("fgr.fips_code", fips_code)
    org_filter_clause = build_in_clause("co.cs_org_id", org_ids)

    print("🔍 Applying filters:")
    print(f" - geo_filter_clause: {geo_filter_clause}")
    print(f" - org_filter_clause: {org_filter_clause}")
        


    print("🔄 Loading FinOrg Data...")

    finOrg_sql =  f"""
    select 
    fa.state_code state,
    fa.finorg_id finOrg,
    fsem.source_entity_id entityid,
    fa.finorg_name finorgname,
    fa.obligor_re_org_id red_org_id, 
    reo.legal_name re_org_name,
    fa.country_code countrycd,
    fa.fin_sector_name sectorname,
    fa.fye_day_mth_text as fye
    from idf_{env}.uspf_apr.t_finorg_attr fa
    join idf_{env}.uspf_apr.t_finorg_source_entity_map fsem on fa.finorg_id = fsem.finorg_id and source_code = 'PHOENIXUSPF' and fsem.active_ind = 'Y'
    left join idf_{env}.uspf_apr.t_ratings_entity_org reo on fa.obligor_re_org_id = reo.re_org_id and reo.END_DTTM = '31-dec-9999'
    where 1=1
    {org_filter_clause}
    """


    entfinfndl_sql = f"""
    SELECT eff.vend_ent_id AS finorgid, eff.vend_ent_id_typ,
           LPAD(fy_end_day_mth_text, 4, '0') AS fye,
           fd.per_end_date
    FROM idf_{env}.finanalytic.t_ent_fin_fndl eff
    JOIN idf_{env}.finanalytic.t_fin_dataset fd
        ON eff.obj_sp_id = fd.obj_sp_id
    WHERE eff.cur_ind = 'Y'
      AND eff.actv_ind = 'Y'
      AND eff.vend_ent_id_typ IN ('CSID', 'PAID')
      AND fd.actv_ind = 'Y'
      AND fd.analtl_crit_dataset_cd = 'NA'
      AND eff.fy_end_day_mth_text IS NOT NULL
    """

    finorggeolink_sql = f"""
        select fgr.finorg_id finorgid, gu.geo_unit_cd gu_id, gu.geo_unit_typ gu_typ, fgr.purpose_type, fgr.fips_code as fipscode, ihs.id_value ihsid, bea.id_value bea, bls.id_value blsid, eds.id_value edsid, fa.fin_sector_name sector
        from idf_{env}.uspf_apr.t_finorg_geo_rel fgr
        join idf_{env}.uspf_apr.t_fips_geo_unit fgu on fgr.fips_code = fgu.fips_code and fgu.cur_ind = 'Y' and fgu.fips_validity_end_date >= current_date()
        join idf_{env}.uspf_apr.t_geographic_unit gu on fgu.geo_unit_id = gu.geo_unit_id
        left join idf_{env}.uspf_apr.t_fips_id_link ihs on ihs.cur_ind = 'Y' and ihs.id_fips_validity_end_date = '9999-12-31' and ihs.id_source = 'IHSID' and fgr.fips_code = ihs.fips_code
        left join idf_{env}.uspf_apr.t_fips_id_link bea on bea.cur_ind = 'Y' and bea.id_fips_validity_end_date = '9999-12-31' and bea.id_source = 'BEA' and fgr.fips_code = bea.fips_code
        left join idf_{env}.uspf_apr.t_fips_id_link eds on eds.cur_ind = 'Y' and eds.id_fips_validity_end_date = '9999-12-31' and eds.id_source = 'EDSID' and fgr.fips_code = eds.fips_code
        left join idf_{env}.uspf_apr.t_fips_id_link bls on bls.cur_ind = 'Y' and bls.id_fips_validity_end_date = '9999-12-31' and bls.id_source = 'BLSID' and fgr.fips_code = bls.fips_code
        join idf_{env}.uspf_apr.t_finorg_attr fa on fa.active_ind = 'Y' and fa.end_dttm = '9999-12-31' and fgr.finorg_id = fa.finorg_id
        where fgr.cur_ind = 'Y'
        {geo_filter_clause}
    """

    econ_sql = f"""
    SELECT 
        b.cmp_indus_lvl2_clsf_cd,
        edp.*,
        edp.VALUE AS vendor_asis_value,
        CASE 
            WHEN d.denom_name IS NULL THEN 1
            ELSE d.multr
        END AS ent_mnem_denom_multiplier
    FROM idf_raw_{env}.ihs_econ.t_econ_data_pnt edp
    LEFT JOIN idf_{env}.finanalytic.t_denom d 
        ON edp.ent_mnem_denom_name = d.denom_name AND d.actv_ind = 'Y'
    INNER JOIN idf_{env}.finanalytic.t_de_ver_st_frmla_map b 
        ON edp.fa_de_ver_st_frmla_map_id = b.de_ver_st_frmla_map_id
    """

    
    filters = []

    if is_incremental:
        print("Updating query for incremental run")
        print(f"Last updated date: {ihs_last_date}")
        filters.append(f"edp.LAST_UPD_DTTM >= TIMESTAMP('{ihs_last_date}')")

    if filter_ids and filter_ids.get("formula_map_ids"):
        formatted_ids = ",".join(f"'{str(id)}'" for id in filter_ids["formula_map_ids"])
        filters.append(f"edp.fa_de_ver_st_frmla_map_id IN ({formatted_ids})")

    if filters:
        econ_sql += " WHERE " + " AND ".join(filters)

  


    # Run queries
    finorg_df = spark.sql(finOrg_sql).dropDuplicates()
    #spid_df = spark.sql(spid_sql).dropDuplicates()
    entfinfndl_df = spark.sql(entfinfndl_sql).dropDuplicates()
    finorggeolink_df = spark.sql(finorggeolink_sql).dropDuplicates()
    econdatapnt_df = spark.sql(econ_sql).dropDuplicates()

    # Print row counts
    print(f"✅ FinOrg count:        {finorg_df.count()}")
    #print(f"✅ SPID count:          {spid_df.count()}")
    print(f"✅ EntFinFndl count:    {entfinfndl_df.count()}")
    print(f"✅ FinOrgGeoLink count: {finorggeolink_df.count()}")
    print(f"✅ EconDataPnt count:   {econdatapnt_df.count()}")

    return finorg_df, entfinfndl_df, finorggeolink_df, econdatapnt_df







def calculate_denominated_value(econdatapnt_df: DataFrame) -> DataFrame:
    """
    Applies scale multipliers and computes denominated_value for economic data.

    Parameters:
    - econdatapnt_df (DataFrame): Input DataFrame with raw economic values.

    Returns:
    - econ_df (DataFrame): DataFrame with `vendor_scale_multiplier` and `denominated_value` added.
    """

    # Static multiplier mapping
    scale_multiplier_dict = {
        'PHT': 100_000,
        'HBL': 100_000_000_000,
        'HUN': 100,
        'BIL': 1_000_000_000,
        'TTH': 10_000,
        'QUA': 1_000_000_000_000_000,
        'TRI': 1_000_000_000_000,
        'TBL': 10_000_000_000,
        'TML': 10_000_000,
        'OHT': 100_000,
        'THO': 1_000,
        'TYT': 20_000,
        'MIL': 1_000_000,
        'HML': 100_000_000,
        'HTH': 100_000,
        'TEN': 10,
        'UNI': 1
    }

    # UDF for computing multiplier
    def get_scale_multiplier(vendorscaleid, vendorunitid):
        if (vendorscaleid is None or vendorscaleid == 'UNI') and vendorunitid in ('241', '2330'):
            return 0.01
        return scale_multiplier_dict.get(vendorscaleid, 1.0)

    get_scale_multiplier_udf = udf(get_scale_multiplier)

    # Apply transformations
    econ_df = econdatapnt_df.withColumn(
        "vendor_scale_multiplier",
        get_scale_multiplier_udf(col("vendorscaleid"), col("vendorunitid"))
    ).withColumn(
        "denominated_value",
        (col("vendor_asis_value") * col("vendor_scale_multiplier")) / col("ent_mnem_denom_multiplier")
    )

    return econ_df





def filter_input_dataframes(finorg_df,  entfinfndl_df,finorggeolink_df, econ_df, finorg_ids=None, geo_ids=None):
    """
    Filters all input DataFrames based on finorg_ids and geo_ids.
    
    :param finorg_df: Spark DataFrame for finOrg
    :param spid_df: Spark DataFrame for SPID
    :param finorggeolink_df: Spark DataFrame for finOrgGeoLink
    :param econ_df: Spark DataFrame for econDataPnt
    :param entfinfndl_df: Spark DataFrame for EntFinFndl
    :param finorg_ids: List of finorgids to filter
    :param geo_ids: List of geo_unit_ids to filter
    :return: Tuple of filtered DataFrames
    """

    # if finorg_ids:
    #     finorg_df = finorg_df.filter(F.col("finorg").isin(finorg_ids))
    #     spid_df = spid_df.filter(F.col("id_value").isin(finorg_ids))
    #     finorggeolink_df = finorggeolink_df.filter(F.col("finorgid").isin(finorg_ids))
    #     entfinfndl_df = entfinfndl_df.filter(F.col("finorgid").isin(finorg_ids))

    # if geo_ids:
    #     econ_df = econ_df.filter(F.col("vendorgeographiclocationid").isin(geo_ids))
    #     finorggeolink_df = finorggeolink_df.filter(F.col("ihsid").isin(geo_ids))
    #core_org_ids = [row['core_org_id'] for row in finorg_df.select("core_org_id").distinct().collect()]

    # Step 2: Filter SPID to only relevant core_org_ids
    #spid_df_filtered = spid_df.filter(F.col("id_value").isin(core_org_ids))
    finorg_ids = [row['finOrg'] for row in finorg_df.select("finOrg").distinct().collect()]
       
    print("\n🔄 Filtering finorggeolink_df by finorg_ids...")
    finorggeolink_filtered = finorggeolink_df.filter(F.col("finorgid").isin(finorg_ids))
    print(f"finorggeolink_df count after filter: {finorggeolink_filtered.count()}")

    print("\n🔄 Filtering econ_df by vendorgeographiclocationid in finorggeolink_filtered...")
    geo_ids = [row['ihsid'] for row in finorggeolink_filtered.select("ihsid").distinct().collect()]
    econ_filtered = econ_df.filter(F.col("vendorgeographiclocationid").isin(geo_ids))
    print(f"econ_df count after filter: {econ_filtered.count()}")

    print("\n🔄 Filtering entfinfndl_df by finorg_ids...")
    entfinfndl_filtered = entfinfndl_df.filter(F.col("finorgid").isin(finorg_ids))
    print(f"entfinfndl_df count after filter: {entfinfndl_filtered.count()}")
           

    # Drop duplicates after filtering (optional but recommended)
    print("📦 Deduplicating after filtering...")
    finorg_df = finorg_df.dropDuplicates()
    #spid_df = spid_df_filtered.dropDuplicates()
    finorggeolink_df = finorggeolink_filtered.dropDuplicates()
    econ_df = econ_filtered.dropDuplicates()
    entfinfndl_df = entfinfndl_filtered.dropDuplicates()

    print("✅ Filtered + Deduplicated Counts:")
    print(f" - finorg_df:         {finorg_df.count()}")
    #print(f" - spid_df:           {spid_df.count()}")
    print(f" - finorggeolink_df:  {finorggeolink_df.count()}")
    print(f" - econ_df:           {econ_df.count()}")
    print(f" - entfinfndl_df:     {entfinfndl_df.count()}")

    return finorg_df, finorggeolink_df, econ_df, entfinfndl_df






# def join_finorg_with_spid(finorg_df, spid_df):
#     """
#     Join FinOrg with SPID on core_org_id = id_value.
#     Filters SPID before join to improve efficiency.
#     Returns deduplicated joined DataFrame.
#     """


#     finorg_spid_df = finorg_df.alias("fo") \
#         .join(spid_df.alias("sp"),
#               F.col("fo.core_org_id") == F.col("sp.id_value"),
#               "left") \
#         .select(
#             F.col("fo.finOrg"),
#             F.col("fo.core_org_id"),
#             F.col("fo.sectorname").alias("sectorName"),
#             F.col("sp.sp_org_id").alias("org_sp_id"),
#             F.col("sp.primary_name").alias("org_name")
#         )

#     # Step 4: Print sample and count before and after deduplication
#     print("\n--- FinOrg + SPID Join (Before Deduplication) ---")
#     #finorg_spid_df.show(5)
#     print(f"Count before dedup: {finorg_spid_df.count()}")

#     # Step 5: Drop duplicates
#     finorg_spid_df = finorg_spid_df.dropDuplicates()

#     print(f"Count after dedup:  {finorg_spid_df.count()}")

#     return finorg_spid_df






def join_econ_with_periods(finorg_ids, econ_filtered, finorggeolink_filtered, entfinfndl_filtered):
    """
    Filters DataFrames by finorg_ids before joining and computes periodEndDate.
    Deduplicates and prints counts before/after.

    :return: period_end_df (finorgid, vendorgeographiclocationid, periodEndDate)
    """

    # Join econ + finorggeolink on vendorgeographiclocationid == ihsid
    print("\n🔄 Joining econ_filtered and finorggeolink_filtered...")
    econ_geo_df = econ_filtered.alias("econ").join(
        finorggeolink_filtered.alias("fog"),
        (F.col("econ.vendorgeographiclocationid") == F.col("fog.ihsid")) &
        (F.col("econ.cmp_indus_lvl2_clsf_cd") == F.col("fog.sector")),
        "inner"
    ).withColumn("vendor_year", F.year("econ.vendorasof")) \
     .select(
        F.col("fog.finorgid"),
        F.col("fog.purpose_type"),
        F.col("fog.gu_typ"),
        F.col("econ.vendorgeographiclocationid"),
        F.col("vendor_year")
    )

    print(f"econ_geo_df count BEFORE dedup: {econ_geo_df.count()}")
    econ_geo_df = econ_geo_df.dropDuplicates()
    print(f"econ_geo_df count AFTER dedup: {econ_geo_df.count()}")


    print("\n🔄 Deduplicating entfinfndl_filtered...")

    entfinfndl_dedup=entfinfndl_filtered.dropDuplicates()
    entfinfndl_dedup.count()

    # Join econ_geo_df and entfinfndl_dedup on finorgid and year
    print("\n🔄 Joining econ_geo_df with entfinfndl_dedup...")
    period_end_df = econ_geo_df.alias("jeg").join(
        entfinfndl_dedup.alias("ent"),
        (F.col("jeg.finorgid") == F.col("ent.finorgid")) &
        (F.col("jeg.vendor_year") == F.year("ent.per_end_date")),
        "inner"
    ).withColumn(
        "periodEndDate",
        F.when(F.col("ent.per_end_date").isNotNull(),
               F.col("ent.per_end_date").cast("date"))
        .otherwise(
            F.to_date(
                F.concat_ws("-",
                            F.col("jeg.vendor_year").cast("string"),
                            F.substring(F.col("ent.fye"), 1, 2),
                            F.substring(F.col("ent.fye"), 3, 2)),
                "yyyy-MM-dd"
            )
        )
    ).select(
        F.col("jeg.finorgid"),
        F.col("jeg.vendorgeographiclocationid"),
        # F.col("jeg.purpose_type"),
        # F.col("jeg.vendor_year"),   
        # F.col("ent.fye"),
        # F.col("jeg.gu_typ"),
        F.col("periodEndDate")
    )

    print(f"period_end_df count BEFORE dedup: {period_end_df.count()}")
    period_end_df = period_end_df.dropDuplicates()
    print(f"period_end_df count AFTER dedup: {period_end_df.count()}")
    period_end_df.show(10, truncate=False)

    return period_end_df




def build_outer_structure_df(finorg_df, period_end_df):
    """
    Joins finorg_spid_df with period_end_df to build the outer structure
    containing org and period metadata.

    :param finorg_spid_df: DataFrame with finOrg, org_sp_id, org_name, sectorName
    :param period_end_df: DataFrame with finorgid, vendorgeographiclocationid, periodEndDate
    :return: outer_df (joined, deduplicated DataFrame)
    """

    print("\n🔄 Joining finorg_spid_df with period_end_df...")

    outer_df = finorg_df.alias("fs") \
        .join(period_end_df.alias("fp"),
              F.col("fs.finOrg") == F.col("fp.finorgid"),
              "inner") \
        .select(
            F.col("fs.finOrg"),
            F.col("fs.red_org_id"),
            F.col("fs.re_org_name"),
            F.col("fs.finorgname"),
            F.col("fs.sectorName"),
            F.col("fp.vendorgeographiclocationid"),
            F.col("fp.periodEndDate"),
            F.lit("IHS").alias("source")
        )

    print(f"\nRow count BEFORE dedup (outer_df): {outer_df.count()}")
    outer_df = outer_df.dropDuplicates()
    print(f"Row count AFTER dedup (outer_df):  {outer_df.count()}")

    #outer_df.show(20, truncate=False)

    return outer_df



def create_econdata_json(econ_df: DataFrame, finorggeolink_df: DataFrame) -> DataFrame:
    
    """
    Creates a structured JSON-like DataFrame for economic data per vendor geographic location.
    
    Parameters:
    - econ_df (DataFrame): Economic time series data.
    - finorggeolink_df (DataFrame): Mapping between vendors and geographic locations.
    
    Returns:
    - DataFrame: Final JSON structure with finDataPoints grouped by geographic location.
    """
   
    # Step 1: Separate current and non-current data
    econ_cur_df = econ_df.filter(F.col("cur_ind") == "Y")
    econ_noncur_df = econ_df.filter(F.col("cur_ind") == "N")

    # Step 2: Build value trail from non-current data
    value_trail_df = econ_noncur_df.select(
        "vendortimeseriesid",
        "bankname",
        "vendorasof",
        "ent_mnem_cd",
        "fa_de_ver_st_frmla_map_id",
        F.coalesce(F.col("last_upd_dttm"), F.col("create_dttm")).alias("valueAsOf"),
        F.coalesce(F.col("last_upd_usr_id"), F.col("create_usr_id")).alias("valueUpdatedBy"),
        F.col("denominated_value").alias("value")
    ).withColumn(
        "valueTrailItem",
        F.struct("valueAsOf", "valueUpdatedBy", "value")
    ).groupBy(
        "vendortimeseriesid", "bankname", "vendorasof", "ent_mnem_cd", "fa_de_ver_st_frmla_map_id"
    ).agg(
        F.collect_list("valueTrailItem").alias("valueTrail")
    )

    # Step 3: Current metadata (latest values)
    econ_cur_metadata_df = econ_cur_df.select(
        "vendortimeseriesid", "bankname", "vendorasof", "ent_mnem_cd", "fa_de_ver_st_frmla_map_id",
        F.col("denominated_value").alias("currentValue"),
        F.coalesce(F.col("last_upd_usr_id"), F.col("create_usr_id")).alias("valueUpdatedBy"),
        F.coalesce(F.col("last_upd_dttm"), F.col("create_dttm")).alias("valueAsOf")
    ).groupBy(
        "vendortimeseriesid", "bankname", "vendorasof", "ent_mnem_cd", "fa_de_ver_st_frmla_map_id"
    ).agg(
        F.first("currentValue", ignorenulls=True).alias("currentValue"),
        F.first("valueUpdatedBy", ignorenulls=True).alias("valueUpdatedBy"),
        F.first("valueAsOf", ignorenulls=True).alias("valueAsOf")
    )

    # Step 4: Base data for each finDataPoint
    econ_data_base_df = econ_df.select(
        "vendorgeographiclocationid", "mnemonic", "ent_mnem_cd", "fa_de_ver_st_frmla_map_id", "vendorasof",
        "vendortimeseriesid", "bankname",
        "vendor_asis_value", "scaletypename", "vendor_scale_multiplier",
        "ent_mnem_denom_name", "ent_mnem_denom_multiplier",
        "vendorproductnumber", "vendoreconomicconceptid", "vendorfrequencyid",
        "vendorseriestypeid", "vendorunitid", "unittypename", "denominated_value"
    ).dropDuplicates().withColumn(
    "econYear", F.year("vendorasof")
)

    # Step 5: Join base with current metadata and value trail
    joined_df = econ_data_base_df \
        .join(econ_cur_metadata_df, [
            "vendortimeseriesid", "bankname", "vendorasof", "ent_mnem_cd", "fa_de_ver_st_frmla_map_id"
        ], "left") \
        .join(value_trail_df, [
            "vendortimeseriesid", "bankname", "vendorasof", "ent_mnem_cd", "fa_de_ver_st_frmla_map_id"
        ], "left")
    
    finDataPoint_schema = StructType([
        StructField("sourceMnemonic", StringType(), True),
        StructField("sourcevalue", StringType(), True),
        StructField("sourceDataMagnitude", StringType(), True),
        StructField("sourcescalemultiplier", StringType(), True),
        StructField("mnemonic", StringType(), True),
        StructField("magnitude", StringType(), True),
        StructField("scaleMultiplier", StringType(), True),
        StructField("denominatedValue", DoubleType(), True),
        StructField("FaDEVerStFrmlaMapId", StringType(), True),
        StructField("sourceProductNumber", StringType(), True),
        StructField("sourceBankName", StringType(), True),
        StructField("sourceEconomicConceptId", StringType(), True),
        StructField("sourceFrequencyId", StringType(), True),
        StructField("sourceSeriesTypeId", StringType(), True),
        StructField("sourcetimeseriesid", StringType(), True),
        StructField("sourceUnitId", StringType(), True),
        StructField("sourceUnitTypeName", StringType(), True),
        StructField("sourceAsOf", TimestampType(), True),
        StructField("currentValue", DoubleType(), True),
        StructField("valueUpdatedBy", StringType(), True),
        StructField("valueAsOf", TimestampType(), True),
        StructField("valueTrail", ArrayType(
            StructType([
                StructField("valueAsOf", TimestampType(), True),
                StructField("valueUpdatedBy", StringType(), True),
                StructField("value", DoubleType(), True)
            ])
        ), True)
    ])

    # Step 6: Create finDataPoint struct
    finDataPoint = [
        F.col("mnemonic").alias("sourceMnemonic"),
        F.col("vendor_asis_value").alias("sourcevalue"),
        F.col("scaletypename").alias("sourceDataMagnitude"),
        F.col("vendor_scale_multiplier").alias("sourcescalemultiplier"),
        F.col("ent_mnem_cd").alias("mnemonic"),
        F.col("ent_mnem_denom_name").alias("magnitude"),
        F.col("ent_mnem_denom_multiplier").alias("scaleMultiplier"),
        F.col("denominated_value").alias("denominatedValue"),
        F.col("fa_de_ver_st_frmla_map_id").alias("FaDEVerStFrmlaMapId"),
        F.col("vendorproductnumber").alias("sourceProductNumber"),
        F.col("bankname").alias("sourceBankName"),
        F.col("vendoreconomicconceptid").alias("sourceEconomicConceptId"),
        F.col("vendorfrequencyid").alias("sourceFrequencyId"),
        F.col("vendorseriestypeid").alias("sourceSeriesTypeId"),
        F.col("vendortimeseriesid").alias("sourcetimeseriesid"),
        F.col("vendorunitid").alias("sourceUnitId"),
        F.col("unittypename").alias("sourceUnitTypeName"),
        F.col("vendorasof").alias("sourceAsOf"),
        F.col("currentValue"),
        F.col("valueUpdatedBy"),
        F.col("valueAsOf"),
        F.col("valueTrail")
    ]
    joined_df = joined_df.withColumn(
        "finDataPoint", 
        F.struct(*finDataPoint).cast(finDataPoint_schema)
    )

    # Step 7: Group by vendorgeographiclocationid to collect finDataPoints
    grouped_fin_data_df = joined_df \
        .groupBy("vendorgeographiclocationid","econYear") \
        .agg(F.collect_list("finDataPoint").alias("finDataPoints"))
    
    print(f"Row count (grouped_fin_data_df):  {grouped_fin_data_df.count()}")
    print(f"Row count before dedup(finorggeolink_df):  {finorggeolink_df.count()}")
     

    # Step 8: Deduplicate finorggeolink and join to add sourceId and metadata
    finorggeolink_df_dedup = finorggeolink_df \
        .select("ihsid", "purpose_type", "gu_typ") \
        .dropDuplicates(["ihsid"])
    
    #finorggeolink_df_dedup.show()
    print(f"Row count AFTER dedup (finorggeolink_df_dedup):  {finorggeolink_df_dedup.count()}")
      

    final_econData_df = grouped_fin_data_df.alias("g") \
        .join(
            finorggeolink_df_dedup.select(
                col("ihsid").alias("sourceId"),
                col("purpose_type").alias("purposeType"),
                col("gu_typ").alias("guType")
            ),
            grouped_fin_data_df.vendorgeographiclocationid == col("sourceId"),
            "inner"
        ).select("sourceId", "purposeType", "guType","econYear","finDataPoints")
    print(f"\nRow count BEFORE dedup (final_econData_df): {final_econData_df.count()}")
                  
    final_econData_df = final_econData_df.dropDuplicates()
    print(f"Row count AFTER dedup (final_econData_df):  {final_econData_df.count()}")
    #final_econData_df.show(5)
    #print(f"Schema of final_econData_df: {final_econData_df.schema}")
    return final_econData_df







def create_final_econ_json(outer_df: DataFrame, final_econData_df: DataFrame) -> DataFrame:
    """
    Joins the financial org data (outer_df) with economic data (final_econData_df),
    and returns a DataFrame containing JSON strings for export.

    Parameters:
    - outer_df (DataFrame): Data containing financial organization and period end date.
    - final_econData_df (DataFrame): Structured economic data grouped by geo ID.

    Returns:
    - DataFrame: A DataFrame with a single column 'json_string' containing full JSON objects.
    """
    outer_df = outer_df.withColumn("period_year", F.year("periodEndDate"))
    # Join outer_df with final_econData_df on vendorgeographiclocationid
    result_df = outer_df.alias("fs").join(
        final_econData_df.alias("ed"),
        (col("fs.vendorgeographiclocationid") == col("ed.sourceId"))&
        (col("fs.period_year") == col("ed.econYear")),
        "inner"
    ).select(
        col("fs.finOrg"),
        col("fs.red_org_id").alias("redOrgId"),
        col("fs.finorgname").alias("finOrgname"),
        col("fs.sectorName"),
        col("fs.periodEndDate"),
        lit("IHS").alias("source"),
        F.struct(
            col("ed.sourceId"),
            col("ed.purposeType"),
            col("ed.guType"),
            col("ed.finDataPoints")
        ).alias("econData")
    )

    # Ensure nulls are preserved in the JSON output
    result_df.sparkSession.conf.set("spark.sql.jsonGenerator.ignoreNullFields", "false")

    # Convert each row into a JSON string
    final_json_df = result_df.select(
        F.to_json(
            F.struct(
                col("finOrg"),
                col("redOrgId"),
                col("finOrgname"),
                col("sectorName"),
                col("periodEndDate"),
                col("source"),
                col("econData")
            )
        ).alias("json_string")
    )

    return final_json_df






def parse_econ_json_to_metadata(json_str_df: DataFrame) -> DataFrame:
    """
    Parses metadata fields from JSON strings without disturbing the JSON order,
    and keeps the original JSON in a 'dataset' column.

    Parameters:
    - json_str_df (DataFrame): DataFrame with 'json_string' column containing full JSON strings.

    Returns:
    - metadata_df (DataFrame): DataFrame with selected metadata columns + intact JSON in 'dataset'.
    """

    # Extract only top-level metadata fields using JSONPath-style access
    metadata_df = json_str_df.select(
        get_json_object(col("json_string"), "$.redOrgId").alias("re_org_id"),
        get_json_object(col("json_string"), "$.finOrgName").alias("org_name"),
        get_json_object(col("json_string"), "$.finOrg").alias("fin_entity_id"),
        get_json_object(col("json_string"), "$.periodEndDate").alias("period_end_date"),
        col("json_string").alias("dataset")
    ).withColumn("dataset_source", lit("IHS"))

    before_count = metadata_df.count()
    print(f"Total rows before deduplication: {before_count}")

    # Deduplicate based on specific columns
    metadata_df = metadata_df.dropDuplicates(["fin_entity_id", "re_org_id", "period_end_date"])
    after_count = metadata_df.count()
    print(f"Total rows after deduplication: {after_count}")
    #print(metadata_df.select("dataset").first()["dataset"])
    return metadata_df





def get_spark_session():
    return SparkSession.builder.appName("Load_IHS_into_APD").getOrCreate()


def run_pipeline(is_incremental,env,run_type,ihs_last_date,filter_ids=None):
    """
    Runs the full economic data pipeline, logging start and end time, and computing total runtime.
    """
 
    # 🕓 Start timer
    start_time = time.time()
    print(f"🚀 Pipeline started at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    # Extract org_ids and geo_ids from filter_ids dict
    org_ids = filter_ids.get("org_ids") if filter_ids else None
    geo_ids = filter_ids.get("fips_code") if filter_ids else None

    print(f"Org IDs: {org_ids}")
    print(f"Geo IDs: {geo_ids}")

    spark = get_spark_session()

    # 🔹 Step 1: Load data with filters
    finorg_df,  entfinfndl_df, finorggeolink_df, econdatapnt_df = load_input_dataframes(
        spark, is_incremental, env, run_type, ihs_last_date, filter_ids=filter_ids
    )

    if econdatapnt_df.count() == 0:
        print("⚠️ No data found in EconDataPoints during initial load. Skipping pipeline execution.")

        end_time = time.time()
        total_time = end_time - start_time

        print(f"✅ Pipeline exited early at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"⏱️ Total runtime: {total_time:.2f} seconds ({total_time / 60:.2f} minutes)")
        return None

    # 🔹 Step 2: Preprocess econ data
    econdatapnt_df = calculate_denominated_value(econdatapnt_df)
    print(f"✅ Econ data point count: {econdatapnt_df.count()}")

    # 🔹 Step 3: Filter input data
    if org_ids or geo_ids:
        print(f"🔍 Filtering input data for selected orgs and geos")
        if org_ids:
            print(f"   • Selected org_ids: {org_ids}")
        if geo_ids:
            print(f"   • Selected geo_ids: {geo_ids}")

        # Apply filtering logic (assumes internal filter_input_dataframes handles filtering based on org/geo)
        finorg_df, finorggeolink_df, econdatapnt_df, entfinfndl_df = filter_input_dataframes(
            finorg_df, entfinfndl_df, finorggeolink_df, econdatapnt_df
        )

    # 🔹 Step 4: Join FinOrg + SPID
    # finorg_spid_df = join_finorg_with_spid(finorg_df, spid_df)
    finorg_ids = [row['finOrg'] for row in finorg_df.select("finOrg").distinct().collect()]
    # print(f"✅ Found {len(finorg_ids)} unique finorg_ids")

    # 🔹 Step 5: Join econ + periods
    period_end_df = join_econ_with_periods(finorg_ids, econdatapnt_df, finorggeolink_df, entfinfndl_df)
    print(f"✅ Period End DataFrame count: {period_end_df.count()}")

    # 🔹 Step 6: Build outer structure
    outer_df = build_outer_structure_df(finorg_df, period_end_df)
    print(f"✅ Outer structure DataFrame count: {outer_df.count()}")

    # 🔹 Step 7: Create econdata JSON structure
    econdata_json_df = create_econdata_json(econdatapnt_df, finorggeolink_df)
    print(f"✅ EconData JSON DataFrame count: {econdata_json_df.count()}")

    # 🔹 Step 8: Create final JSON output
    json_final_df = create_final_econ_json(outer_df, econdata_json_df)

    # # ✅ MATERIALIZE ONCE: prevents re-generating JSON strings during save
    # json_final_df = json_final_df.persist(StorageLevel.DISK_ONLY)
    # _ = json_final_df.count()  # trigger materialization once, safel
    print(f"✅ Final JSON DataFrame count: {json_final_df.count()}")
    
    # 🔹 Step 9: Parse final JSON into metadata
    metadata_df = parse_econ_json_to_metadata(json_final_df)
    print(f"✅ Metadata DataFrame count: {metadata_df.count()}")

    # # ✅ MATERIALIZE ONCE: prevents re-computation during database writes
    # metadata_df = metadata_df.persist(StorageLevel.DISK_ONLY)
    # _ = metadata_df.count()  # trigger materialization once
    # print(f"✅ Metadata DataFrame persisted for efficient database writing")
    
    end_time = time.time()
    total_time = end_time - start_time

    print(f"✅ Pipeline completed at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"⏱️ Total runtime: {total_time:.2f} seconds ({total_time/60:.2f} minutes)")
    return metadata_df
    




# ------------------------------
# Entry Point
# ------------------------------

def main(
    env: str,
    user: str,
    run_type: str,
    start_date:str= None,
        filter_ids: Optional[Dict[str, List[str]]] = None
):
    """
    Entry point to run the pipeline.

    Args:
      env (str): environment name
      user (str): user triggering the pipeline
      run_type (str): batch or stream
      start_date (str, optional): start date override
      filter_ids (dict, optional): dictionary of filters like {
          "org_ids": [...],
          "geo_unit_ids": [...],
          "formula_map_ids": [...]
      }
    """
    # Ensure filter_ids is at least an empty dict
    filter_ids = filter_ids or {}

    print(f"Run Type is {run_type}")
    print(f"📌 Filters passed: {filter_ids}")
    print(f"Run Type is {run_type}")

    if run_type in (RunType.BATCH.value, RunType.FINANALYTIC_STREAM.value, RunType.USPF_STREAM.value):
        print("debugging Runtype")
        if is_ihs_batch_completed(env,run_type):
            is_incremental=True
            if start_date:
                ihs_last_date=start_date
            else:
                main_process_id=get_main_process_id(env,run_type)
                ihs_last_date = get_last_processed_date(env,run_type,exclude_process_id=main_process_id)
            output_df=run_pipeline(is_incremental, env,run_type, ihs_last_date,filter_ids=filter_ids)
            print("Pipeline run complete.")
            if output_df is not None and not output_df.rdd.isEmpty():
                adpHandler = ADPPostgresHandler()
                adpHandler.write_into_db(output_df,load_type=LoadType.INCREMENTAL, run_type = run_type)
            else:
                print("No new records")

        else:
            print(f"Latest IHS_{run_type}_PROCESS has not completed. main() will not run.")
    else:
        print("Non batch run type")
        is_incremental=False
        output_df = run_pipeline(is_incremental, env,run_type,start_date, filter_ids=filter_ids)
        print("Pipeline run complete.")
        print(output_df.select("dataset").first()["dataset"])
        adpHandler = ADPPostgresHandler()
        adpHandler.write_into_db(output_df)
    
    



