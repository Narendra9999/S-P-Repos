# Databricks notebook source
from pyspark.sql import SparkSession
from pyspark.sql.functions import current_timestamp
import logging
import sys
import uuid
import traceback
from apd_ingestion.constants.enum_vars import RunType
from pyspark.sql import functions as F
from apd_ingestion.ihs.ihs_utils import insert_process_status_started,update_process_status,get_last_processed_date,get_main_process_id
# Configure logging
logging.basicConfig(stream=sys.stdout, level=logging.INFO)
logger = logging.getLogger(__name__)
spark = SparkSession.builder.appName("Load_Econ_Data_Proc_Log").getOrCreate()
# --------------------- Helpers ---------------------

def generate_process_id():
    return str(uuid.uuid4())


def build_source_df(env_name, ihs_last_date_str,filter_ids=None):
    # Convert list to SQL IN clause
    frmla_map_filter = "1=1"
    if filter_ids.get("formula_map_ids"):
        # Ensure values are properly escaped and comma-separated
        formatted_ids = ",".join(f"'{str(id)}'" for id in filter_ids["formula_map_ids"])
        frmla_map_filter = f"frml.DE_VER_ST_FRMLA_MAP_ID IN ({formatted_ids})"

    query = f"""
with params as (
    select dv.ent_mnem_cd, frml.frmla_text, substr(frmla_text, 1, instr(frmla_text, '***')-1) prefix,
        frml.FM_DATA_SOURCE_ID, frml.start_dttm, frml.end_dttm, vend.VENDORSERIESTYPEID, vend.VENDORFREQUENCYID,
        vend.VENDORGEOGRAPHICLOCATIONID, dv.create_dttm dv_create_dttm, dv.LAST_UPD_DTTM dv_last_upd_dttm,
        dvs.CREATE_DTTM dvs_create_dttm, dvs.LAST_UPD_DTTM dvs_last_upd_dttm, frml.CREATE_DTTM frml_create_dttm, frml.LAST_UPD_DTTM frml_last_upd_dttm,
        ent.ent_mnem_denom_name, frml.DE_VER_ST_FRMLA_MAP_ID, ent.CREATE_DTIME ent_create_dtime, ent.UPDATE_DTIME ent_update_dtime
    from idf_{env_name}.finanalytic.v_de_ver dv
    join idf_{env_name}.finanalytic.v_de_ver_st dvs on dv.de_ver_id = dvs.de_ver_id and dvs.CUR_IND = 'Y'
    join idf_{env_name}.finanalytic.v_de_ver_st_frmla_map frml on dvs.DE_VER_ST_ID = frml.de_ver_st_id and frml.cur_ind = 'Y' and frml.frmla_text like '%***' and frml.FM_DATA_SOURCE_ID = 26
    join idf_{env_name}.finanalytic.v_de_frmla_map_vendor_attr vend on frml.DE_VER_ST_FRMLA_MAP_ID = vend.de_ver_st_frmla_map_id and vend.ACTV_IND = 'Y'
    join idf_{env_name}.mnem_map.v_ent_mnem ent on dv.ENT_MNEM_CD = ent.ent_mnem_cd and ent.MNEMONIC_TYPE = 'Financial' and ent.MNEMONIC_SUBTYPE = 'Reported' and ent.IS_DELETED = 'N'
    where dv.CUR_IND = 'Y'
    AND ({frmla_map_filter})
)
select 
    ts.ecr_timeseriesid, ts.vendortimeseriesid, ts.mnemonic, ts.longlabel, ts.shortlabel, ts.defaultmnemonic, ts.legacyid,
    ts.vendorstartdate, ts.vendorcreationtimestamp, ts.vendorvaluestimestamp, ts.attributetimestamp, ts.baseperiodbegin,
    ts.baseperiodend, ts.baseperiodvalue, ts.ecr_concepttypeid, ct.vendoreconomicconceptid, ct.name concepttypename, 
    ts.ecr_frequencytypeid, f.vendorfrequencyid, f.name frequencytypename, ts.ecr_geographiclocationid, 
    egl.vendorgeographiclocationid as VENDORGEOGRAPHICLOCATIONID, egl.name geolocationname, eop.vendorasof as VENDORASOF
from idf_curated_{env_name}.ecr_economic_data.v_ecr_timeseries ts
join idf_curated_{env_name}.ecr_economic_data.v_ecr_observationproduct eop
  on ts.ecr_timeseriesid = eop.ecr_timeseriesid and eop.cur_ind = 'Y' and eop.actv_ind = 'Y'
join idf_curated_{env_name}.ecr_economic_data.v_ecr_timeseriesbank etb 
  on ts.ecr_timeseriesid = etb.ecr_timeseriesid and etb.actv_ind = 'Y'
join idf_curated_{env_name}.ecr_economic_data.v_ecr_bank eb
  on etb.ecr_bankid = eb.ecr_bankid and eb.cur_ind = 'Y' and eb.actv_ind = 'Y'
join idf_curated_{env_name}.ecr_economic_data.v_ecr_seriestype st
  on ts.ecr_seriestypeid = st.ecr_seriestypeid and st.cur_ind = 'Y' and st.actv_ind = 'Y'
join idf_curated_{env_name}.ecr_economic_data.v_ecr_frequencytype f
  on ts.ecr_frequencytypeid = f.ecr_frequencytypeid and f.cur_ind = 'Y' and f.actv_ind = 'Y'
join idf_curated_{env_name}.ecr_economic_data.v_ecr_geographiclocation egl
  on ts.ecr_geographiclocationid = egl.ecr_geographiclocationid and egl.cur_ind = 'Y' and egl.actv_ind = 'Y'
join idf_curated_{env_name}.ecr_economic_data.v_ecr_concepttype ct
  on ts.ecr_concepttypeid = ct.ecr_concepttypeid and ct.cur_ind = 'Y' and ct.actv_ind = 'Y'
join params on params.prefix = substr(ts.mnemonic, 1, length(params.prefix))
            and st.vendorseriestypeid = params.vendorseriestypeid
            and f.vendorfrequencyid = params.vendorfrequencyid
            and ((params.vendorgeographiclocationid is not null and params.vendorgeographiclocationid = egl.vendorgeographiclocationid) or params.vendorgeographiclocationid is null)
where ts.actv_ind = 'Y'
  and f.vendorfrequencyid = 'ANNL'
  and eop.vendorasof between '1900-01-01' and '9999-12-31'
  and (
      ts.create_Dttm >= cast('{ihs_last_date_str}' as TIMESTAMP)
      or ts.last_upd_Dttm >= cast('{ihs_last_date_str}' as TIMESTAMP)
      or eop.create_dttm >= cast('{ihs_last_date_str}' as TIMESTAMP)
      or eop.last_upd_dttm >= cast('{ihs_last_date_str}' as TIMESTAMP)
  )
    """
    
    return spark.sql(query)
  

def create_proc_log_df(source_df):
    return (
        source_df
        .select("VENDORGEOGRAPHICLOCATIONID", "VENDORASOF")
        .distinct()
        .withColumn("LAST_UPD_DTTM", current_timestamp())
    )

def insert_proc_log(proc_log_df,  env_name, user, process_id):
    try:
        proc_log_df.write.mode("append").saveAsTable(f"idf_raw_{env_name}.ihs_econ.ECON_DATA_PNT_PROC_LOG")
        logger.info("✅ ECON_DATA_PNT_PROC_LOG table insertion succeeded")
    except Exception as e:
        error_message = f"❌ ECON_DATA_PNT_PROC_LOG table insertion failed: {str(e)}"
        logger.error(error_message)
        update_process_status( env_name, user, process_id, status="FAILED", error_message=error_message)
        raise

# --------------------- Main Execution ---------------------

def run_proc_log( env_name: str, user: str,run_type:str, start_date:str= None, filters: dict = None):
    main_process_id=get_main_process_id(env_name,run_type)

    if start_date:
        ihs_last_date_str=start_date
    else:
        ihs_last_date_str = get_last_processed_date(env_name,run_type,start_date,main_process_id)
  
    print(f"Using ihs_last_date: {ihs_last_date_str}")
    process_id = generate_process_id() 
    try:
        print(f"🔧 Running ETL for env: {env_name}, user: {user}")
        insert_process_status_started( env_name, user,process_id,main_process_id,run_type,table_name='ECON_DATA_PNT_PROC_LOG')



        if run_type in (RunType.FINANALYTIC_STREAM.value, RunType.USPF_STREAM.value):
            source_df = build_source_df(env_name, ihs_last_date_str, filter_ids=filters)
        else:
            source_df = build_source_df(env_name, ihs_last_date_str)
        proc_log_df = create_proc_log_df(source_df)
        insert_proc_log(proc_log_df, env_name, user, process_id)

        update_process_status(env_name, user, process_id, status="COMPLETED")
        print("✅ ETL process completed successfully.")

    except Exception as e:
        error_message = traceback.format_exc()
        logger.error("❌ ETL failed with error:\n" + error_message)
        update_process_status(env_name, user, process_id, status="FAILED", error_message=error_message)
        raise


#run_proc_log(env_name="dev", user="dop_user", fallback_date="2025-01-01")
