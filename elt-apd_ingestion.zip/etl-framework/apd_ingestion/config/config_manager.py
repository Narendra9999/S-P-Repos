"""
Configuration Manager for ETL Framework.

Provides centralized configuration management with support for:
- Environment-specific YAML configuration files
- Environment variable substitution
- RSM secret resolution
- Singleton pattern for consistent configuration access
"""

import os
from pathlib import Path
import yaml
from typing import Dict, Any
import re
from apd_ingestion.utils.vault_rsm import get_secret_from_vault
from apd_ingestion.constants.env_vars import GeneralEnvVars

import logging

logger = logging.getLogger(__name__)

class ConfigManager:
    """
    Singleton configuration manager for loading and managing application config.
    
    Supports environment-specific YAML files, environment variable substitution,
    and RSM secret resolution.
    """
    _instance = None
    _loaded_config = None

    @classmethod
    def _reset_instance(cls):
        """Reset the singleton instance and cached config. Used for testing."""
        cls._instance = None
        cls._loaded_config = None

    @staticmethod
    def is_databricks() -> bool:
        """Check if we're running in Databricks environment."""
        return os.getenv('LOCAL_TESTING', '').lower() != 'true'

    def __new__(cls, resource_root: Path = None):
        """Create or return singleton instance."""
        if cls._instance is None:
            cls._instance = super(ConfigManager, cls).__new__(cls)
            # Set resource_root to the apd_ingestion directory by default
            if resource_root is None:
                # Get the apd_ingestion directory (parent of config)
                apd_ingestion_dir = Path(__file__).parent.parent
                cls._instance._resource_root = apd_ingestion_dir
            else:
                cls._instance._resource_root = resource_root
        return cls._instance

    def __init__(self, resource_root: Path = None):
        """Initialize the configuration manager."""
        # Only initialize once for singleton
        if not hasattr(self, '_initialized'):
            # The _resource_root is already set in __new__
            # Don't override it here unless explicitly provided
            if resource_root is not None:
                self._resource_root = resource_root
            self._initialized = True

    def _resolve_credentials(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """
        Recursively resolve RSM credential placeholders in configuration.
        
        Searches for patterns like 'rsm{secret_name}' and replaces them with
        actual secret values from the vault.
        
        Args:
            config: Configuration dictionary or list to process
            
        Returns:
            Configuration with resolved credentials
        """
        rsm_pattern = re.compile(r'rsm\{([^}]+)\}')
        
        if isinstance(config, dict):
            for key, value in config.items():
                if isinstance(value, str):
                    match = rsm_pattern.fullmatch(value.strip())
                    if match:
                        secret_name = match.group(1)
                        try:
                            config[key] = get_secret_from_vault(secret_name)
                            logger.debug(f"Resolved RSM secret: {secret_name}")
                        except Exception as e:
                            logger.error(f"Failed to resolve RSM secret '{secret_name}': {e}")
                            raise
                elif isinstance(value, (dict, list)):
                    self._resolve_credentials(value)
                    
        elif isinstance(config, list):
            for idx, item in enumerate(config):
                if isinstance(item, str):
                    match = rsm_pattern.fullmatch(item.strip())
                    if match:
                        secret_name = match.group(1)
                        try:
                            config[idx] = get_secret_from_vault(secret_name)
                            logger.debug(f"Resolved RSM secret: {secret_name}")
                        except Exception as e:
                            logger.error(f"Failed to resolve RSM secret '{secret_name}': {e}")
                            raise
                elif isinstance(item, (dict, list)):
                    self._resolve_credentials(item)
                    
        return config

    def _deep_merge(self, base: Dict[str, Any], override: Dict[str, Any]) -> Dict[str, Any]:
        """
        Deep merge two dictionaries. Override values take precedence.
        
        Args:
            base: Base configuration dictionary
            override: Override configuration dictionary
            
        Returns:
            Merged configuration dictionary
        """
        result = base.copy()
        
        for key, value in override.items():
            if key in result and isinstance(result[key], dict) and isinstance(value, dict):
                # Recursively merge nested dictionaries
                result[key] = self._deep_merge(result[key], value)
            else:
                # Override the value
                result[key] = value
                
        return result

    def _load_base_config(self) -> Dict[str, Any]:
        """
        Load base application.yaml configuration file from framework resources.
        
        Returns:
            Base configuration dictionary or empty dict if not found
        """
        # The resources folder is now inside the apd_ingestion package
        config_path = self._resource_root / "resources" / "application.yaml"
        
        if config_path.exists():
            logger.debug(f"Loading base configuration from: {config_path}")
            try:
                with open(config_path, 'r', encoding='utf-8') as file:
                    return yaml.safe_load(file) or {}
            except Exception as e:
                logger.warning(f"Error loading base config: {e}")
                    
        logger.info("No base configuration (resources/application.yaml) found, using empty base")
        return {}

    @classmethod
    def load_application_config(cls) -> Dict[str, Any]:
        """
        Load configuration using Spring Boot-style hierarchy:
        1. Load base config from etl-framework/framework/resources/application.yaml (if exists)
        2. Load environment config from etl-framework/framework/resources/application-{env}.yaml
        3. Merge configs (environment overrides base)
        4. Replace ${VAR_NAME} with environment variables
        5. Resolve rsm{secret_name} with vault secrets
        
        Returns:
            Fully resolved application configuration
        """
        if cls._loaded_config is not None:
            return cls._loaded_config

        env = os.getenv(GeneralEnvVars.APP_ENV.value, 'dev')
        logger.info(f"Loading configuration for environment: {env}")
        
        # Ensure instance exists
        if cls._instance is None:
            cls._instance = cls()
            
        # Step 1: Load base configuration from framework resources
        base_config = cls._instance._load_base_config()
        
        # Step 2: Load environment-specific configuration from framework resources
        env_config_path = cls._instance._resource_root / "resources" / f"application-{env}.yaml"
        
        if not env_config_path.exists():
            raise FileNotFoundError(f"Environment configuration not found: {env_config_path}")

        logger.info(f"Loading environment configuration from: {env_config_path}")
        with open(env_config_path, 'r', encoding='utf-8') as file:
            env_config = yaml.safe_load(file) or {}

        # Step 3: Merge configurations (environment overrides base)
        if base_config:
            logger.debug("Merging base configuration with environment overrides")
            config = cls._instance._deep_merge(base_config, env_config)
        else:
            config = env_config

        # Step 4: Replace environment variable placeholders (support ${VAR:default})
        config_str = yaml.dump(config)
        pattern = re.compile(r'\${([^}:]+)(?::([^}]+))?}')

        def replacer(match):
            var = match.group(1)
            default = match.group(2)
            # 1. Try environment variable
            value = os.getenv(var)
            # 2. Try config dictionary if env var not found
            if value is None:
                value = config.get(var, default)
            if value is None:
                raise ValueError(f"Required environment variable or config property not set: {var}")
            logger.info(f"Resolved environment variable: {var} (default: {default}) -> {value}")
            return value

        config_str = pattern.sub(replacer, config_str)
        config = yaml.safe_load(config_str)

        # Step 5: Resolve RSM credentials
        config = cls._instance._resolve_credentials(config)
        
        cls._loaded_config = config
        logger.info(f"Configuration loaded successfully for environment: {env}")
        return config
    
    @classmethod
    def get_config(cls) -> Dict[str, Any]:
        """Get the loaded configuration, loading it if necessary."""
        return cls.load_application_config()
    
    @classmethod
    def reload_config(cls) -> Dict[str, Any]:
        """Force reload of configuration (clears cache)."""
        cls._loaded_config = None
        return cls.load_application_config()
    
    @classmethod
    def get_config_value(cls, key_path: str, default: Any = None) -> Any:
        """
        Get configuration value using dot notation.
        
        Args:
            key_path: Dot-separated key path (e.g., 'Infrastructure.host_url')
            default: Default value if key is not found
            
        Returns:
            Configuration value or default
            
        Example:
            host = ConfigManager.get_config_value('Infrastructure.host_url')
            db_host = ConfigManager.get_config_value('Database.postgres.host', 'localhost')
        """
        config = cls.get_config()
        keys = key_path.split('.')
        current = config
        
        try:
            for key in keys:
                if isinstance(current, dict) and key in current:
                    current = current[key]
                else:
                    return default
            return current
        except (TypeError, KeyError):
            return default

def get_config_value(key_path: str, default: Any = None) -> Any:
    return ConfigManager.get_config_value(key_path, default)