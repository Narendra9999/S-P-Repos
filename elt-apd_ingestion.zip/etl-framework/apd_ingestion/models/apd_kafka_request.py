"""
Dataclasses for Kafka message structures.

Handles Formula and Non-Formula (Org) message types from the incoming topic.
"""

from dataclasses import dataclass
from datetime import datetime
from typing import List, Union
from enum import Enum


class DataSetType(Enum):  
    """Dataset type enumeration."""
    FINANCIAL = "Financial"


class ChangeType(Enum):
    """Change type enumeration."""
    FORMULA = "Formula"
    ORG = "Org"


@dataclass
class FormulaChangedPeriod:
    """Changed period for Formula change type."""
    action: str
    vendor_name: str
    mnemonic: Union[str, List[str]]  # Could be a single string or array


@dataclass
class OrgChangedPeriod:
    """Changed period for Org change type."""
    action: str
    fips_code: str
    vendor_id: str
    vendor_name: str


@dataclass
class FormulaOrg:
    """Organization data for Formula change type."""
    change_type: str
    datasets: List[str]  # Fixed to "Economic Financials"
    changed_periods: List[FormulaChangedPeriod]


@dataclass
class NonFormulaOrg:
    """Organization data for Non-Formula (Org) change type."""
    org_id: str
    org_name: str
    sector: str
    change_type: str
    datasets: List[str]  # Fixed to "Economic Financials"
    changed_periods: List[OrgChangedPeriod]


@dataclass
class EventParticipantList:
    """Event participant list containing organizations."""
    orgs: List[Union[FormulaOrg, NonFormulaOrg]]


@dataclass
class BaseAPDKafkaRequest:
    """Base structure for all Kafka messages."""
    event_name: str
    data_set_type: str
    event_source: str
    event_date: datetime
    message_type: str  # "FormulaOrg" or "NonFormulaOrg" - set at message creation
    event_participant_list: EventParticipantList


@dataclass
class FormulaAPDKafkaRequest(BaseAPDKafkaRequest):
    """Kafka message for Formula change type."""
    pass

@dataclass
class NonFormulaAPDKafkaRequest(BaseAPDKafkaRequest):
    """Kafka message for Non-Formula (Org) change type."""
    pass


class KafkaMessageParser:
    """Parser for Kafka messages to appropriate dataclasses."""
    
    @staticmethod
    def parse_changed_period(period_data: dict, change_type: str) -> Union[FormulaChangedPeriod, OrgChangedPeriod]:
        """Parse changed period based on change type."""
        if change_type == ChangeType.FORMULA.value:
            return FormulaChangedPeriod(
                action=period_data.get("action"),
                vendor_name=period_data.get("vendorName"),
                mnemonic=period_data.get("mnemonic")
            )
        else:  # Org change type
            return OrgChangedPeriod(
                action=period_data.get("action"),
                fips_code=period_data.get("fipsCode"),
                vendor_id=period_data.get("vendorId"),
                vendor_name=period_data.get("vendorName")
            )
    
    @staticmethod
    def parse_org(org_data: dict) -> Union[FormulaOrg, NonFormulaOrg]:
        """Parse organization data based on change type."""
        change_type = org_data.get("changeType")
        datasets = org_data.get("datasets", [])
        
        # Parse changed periods
        changed_periods_data = org_data.get("changedPeriods", [])
        changed_periods = [
            KafkaMessageParser.parse_changed_period(period, change_type)
            for period in changed_periods_data
        ]
        
        if change_type == ChangeType.FORMULA.value:
            return FormulaOrg(
                change_type=change_type,
                datasets=datasets,
                changed_periods=changed_periods
            )
        else:  # Org change type
            return NonFormulaOrg(
                org_id=org_data.get("orgID"),
                org_name=org_data.get("orgName"),
                sector=org_data.get("sector"),
                change_type=change_type,
                datasets=datasets,
                changed_periods=changed_periods
            )
    
    @staticmethod
    def parse_message(message_data: dict) -> Union[FormulaAPDKafkaRequest, NonFormulaAPDKafkaRequest]:
        """
        Parse incoming Kafka message to appropriate dataclass.
        
        Args:
            message_data: Raw message data from Kafka
            
        Returns:
            Parsed message as appropriate dataclass
        """
        participant_list_data = (message_data.get("eventParticipantList") or {})
        orgs_data = participant_list_data.get("orgs", [])
        
        # Parse organizations
        orgs = [KafkaMessageParser.parse_org(org_data) for org_data in orgs_data]
        
        event_participant_list = EventParticipantList(orgs=orgs)
        
        event_date_str = message_data.get("eventDate")
        if event_date_str is None:
            # Use current time as default if no event_date provided
            event_date = datetime.now()
        elif isinstance(event_date_str, str):
            event_date = datetime.fromisoformat(event_date_str.replace('Z', '+00:00'))
        else:
            # Assume it's a timestamp
            event_date = datetime.fromtimestamp(event_date_str)
        
        # Determine message type
        if orgs and orgs[0].change_type == ChangeType.FORMULA.value:
            message_type = ChangeType.FORMULA.value
        else:
            message_type = ChangeType.ORG.value

        # Base message data (handle both snake_case and camelCase)
        base_data = {
            "event_name": message_data.get("eventName"),
            "data_set_type": message_data.get("dataSetType"),
            "event_source": message_data.get("eventSource"),
            "event_date": event_date,
            "message_type": message_type,
            "event_participant_list": event_participant_list
        }
        
        # Return appropriate message type
        if message_type == ChangeType.FORMULA.value:
            return FormulaAPDKafkaRequest(**base_data)
        else:
            return NonFormulaAPDKafkaRequest(**base_data)


# Convenience functions for working with messages
def is_formula_message(message: BaseAPDKafkaRequest) -> bool:
    """Check if message is a Formula type message."""
    return isinstance(message, FormulaAPDKafkaRequest)


def is_org_message(message: BaseAPDKafkaRequest) -> bool:
    """Check if message is an Org type message."""
    return isinstance(message, NonFormulaAPDKafkaRequest)


def get_change_type(message: BaseAPDKafkaRequest) -> str:
    """Get the change type from the first organization in the message."""
    if message.event_participant_list.orgs:
        return message.event_participant_list.orgs[0].change_type
    return ""