"""
Simple Kafka response message builder.
"""

from datetime import datetime, timezone
from typing import List, Dict, Any
from pyspark.sql import DataFrame
import json
from apd_ingestion.constants.enum_vars import  DataSetType
from apd_ingestion.constants.table_columns import ADPTableColumns
# Constants
DEFAULT_EVENT_NAME = "NEW"
DEFAULT_DATA_SET_TYPE = "Financials"

def create_kafka_messages(df: DataFrame, event_source: str) -> tuple[List[str], List[Dict[str, str]]]:
    """
    Create Kafka response messages from DataFrame grouped by FIN_ENTITY_ID.
    
    Args:
        df: DataFrame with dataset column containing JSON
        event_source: Source of the event
        
    Returns:
        Tuple containing:
        - List of JSON strings ready for Kafka (one per FIN_ENTITY_ID group)
        - List of header dictionaries with datasource and dataset_type info
    """
    from pyspark.sql.functions import get_json_object, collect_list, first, col, lit, struct
    
    messages = []
    header_list = []
    current_time = datetime.now(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00', 'Z')
    
    # Extract sectorName from dataset JSON and group by FIN_ENTITY_ID
    df_with_sector = df.withColumn("sectorName", get_json_object(df[ADPTableColumns.DATASET], "$.sectorName"))
    
    # Group by FIN_ENTITY_ID and collect all periods for each group
    grouped_df = df_with_sector.groupBy(ADPTableColumns.FIN_ENTITY_ID).agg(
        first(ADPTableColumns.ORG_NAME).alias("org_name"),
        first("sectorName").alias("sector"),
        collect_list(
            struct(
                lit("update").alias("action"),
                col(ADPTableColumns.DATASET_SOURCE).alias("vendorName"),
                col(ADPTableColumns.PERIOD_END_DATE).alias("periodEndDate")
            )
        ).alias("changedPeriods")
    )
    
    # Collect grouped data
    grouped_rows = grouped_df.collect()
    
    for group_row in grouped_rows:
        fin_entity_id = getattr(group_row, ADPTableColumns.FIN_ENTITY_ID, None)
        org_name = getattr(group_row, "org_name", None)
        sector = getattr(group_row, "sector", None)
        changed_periods = getattr(group_row, "changedPeriods", [])
        
        # Convert changed_periods to list of dicts
        periods_list = []
        for period in changed_periods:
            periods_list.append({
                "action": period["action"],
                "vendorName": period["vendorName"], 
                "periodEndDate": str(period["periodEndDate"]) if period["periodEndDate"] else None
            })
        
        # Create eventParticipantList structure
        event_participant = {
            "orgId": fin_entity_id,
            "orgName": org_name,
            "sector": sector,
            "datasets": [DataSetType.ECONOMIC_FINANCIAL.value],
            "changedPeriods": periods_list
        }
        
        # Create message for this group
        message = {
            "eventName": DEFAULT_EVENT_NAME,
            "dataSetType": DEFAULT_DATA_SET_TYPE, 
            "eventSource": event_source,
            "eventDate": current_time,
            "eventParticipantList": [
                {
                    "orgs": [event_participant]
                }
            ]
        }

        messages.append(json.dumps(message))
        
        # Create header info for this group
        header_info = {
            "datasource": event_source,
            "dataset_type": DEFAULT_DATA_SET_TYPE
        }
        header_list.append(header_info)

    return messages, header_list