import logging
import time
from datetime import datetime, timedelta
from typing import Dict, Any
from apd_ingestion.utils.spark_utils import SparkUtils
from pyspark.sql.functions import *

# Import your existing enums
from apd_ingestion.constants.enum_vars import RunType

class JobMonitorUtility:
    """
    Simple job coordination utility - ONLY checks status and waits
    Job registration is handled by separate process
    """
    
    def __init__(self, coordination_table: str, 
                 job_name: str = None,
                 process_name_filter: str = None,
                 table_name_filter: str = None,
                 alert_threshold_minutes: int = 60):
        self.spark = SparkUtils.get_spark_session()
        self.coordination_table = coordination_table
        self.job_name = job_name
        self.process_name_filter = process_name_filter
        self.table_name_filter = table_name_filter
        self.alert_threshold = timedelta(minutes=alert_threshold_minutes)
        self.logger = logging.getLogger(self.__class__.__name__)
        
        self.logger.info(f"Job coordinator initialized - Job: {self.job_name}, Process: {self.process_name_filter}, Table: {self.table_name_filter}")

    def can_job_start(self, run_type: str) -> bool:
        """
        Simple check: if any recent entry for this process/table is RUNNING/STARTED, block the job
        This is the main method - just checks, doesn't register anything
        Uses instance variables for process_name and table_name filters
        """
        try:
            # Use instance variables for coordination check
            if self.process_name_filter and self.table_name_filter:
                return self._check_process_status()
            else:
                # If no specific process/table configured, always allow (no coordination needed)
                self.logger.info("No process_name_filter/table_name_filter configured - job ALLOWED")
                return True
            
        except Exception as e:
            self.logger.error(f"Error checking job coordination: {str(e)}")
            return True  # Fail open like your existing logic
    
    def _check_process_status(self) -> bool:
        """
        Simple single query: Check if any recent entry for this process/table is RUNNING/STARTED
        If yes -> BLOCK, if no -> ALLOW
        Uses instance variables for process_name and table_name
        """
        try:
            # Single optimized query with partition pruning using instance variables
            status_df = self.spark.sql(f"""
                SELECT STATUS, PROCESS_STARTTIME, CREATE_DATE
                FROM {self.coordination_table}
                WHERE PROCESS_NAME = '{self.process_name_filter}'
                  AND TABLE_NAME = '{self.table_name_filter}'
                  AND DATE(CREATE_DATE) >= CURRENT_DATE() - INTERVAL 3 DAYS
                ORDER BY CREATE_DATE DESC 
                LIMIT 1
            """)

            # Get the most recent entry
            row = status_df.first()
            
            if row:
                status = row.STATUS
                process_start = row.PROCESS_STARTTIME
                create_date = row.CREATE_DATE

                # Simple logic: if latest entry is RUNNING/STARTED -> BLOCK
                if status in ['STARTED', 'RUNNING']:
                    self.logger.info(f"Process {status} - Job BLOCKED. Process: {self.process_name_filter}, Table: {self.table_name_filter}, Started: {process_start}, Created: {create_date}")
                    return False
                else:
                    # Any other status (COMPLETED, FAILED, SUCCESS, etc.) -> ALLOW
                    self.logger.info(f"Process {status} - Job ALLOWED. Process: {self.process_name_filter}, Table: {self.table_name_filter}, Last run: {create_date}")
                    return True
            else:
                # No entry found -> ALLOW (first time or old entries outside 3-day window)
                self.logger.info(f"No recent control record found for {self.process_name_filter}/{self.table_name_filter} - job ALLOWED")
                return True

        except Exception as e:
            self.logger.error(f"Failed to check process status: {str(e)} - defaulting to ALLOW")
            return True  # Fail open
    

    
    def wait_with_alerting(self, run_type: str, max_attempts: int = 25, 
                          check_interval_minutes: int = 10) -> bool:
        """
        Wait for job slot with alerting for long waits (no indefinite waiting)
        ONLY waits and checks - uses instance variables for job_name, process_name, table_name
        """
        start_time = datetime.now()
        
        job_display_name = self.job_name or "Unknown Job"
        self.logger.info(f"Checking if {job_display_name} ({run_type}) can start...")
        
        for attempt in range(1, max_attempts + 1):
            # Check if job can start
            if self.can_job_start(run_type):
                elapsed = datetime.now() - start_time
                self.logger.info(f"{job_display_name} can start after {elapsed.total_seconds():.0f} seconds")
                return True
            
            # Calculate elapsed time and check for alert threshold
            elapsed = datetime.now() - start_time
            
            # # Send alert if waiting too long
            # if elapsed > self.alert_threshold:
            #     self._send_waiting_alert(run_type, elapsed)
            self._send_waiting_alert(run_type, elapsed)
            # Log wait status
            self.logger.info(
                f"{job_display_name} waiting... (attempt {attempt}/{max_attempts}, "
                f"elapsed: {elapsed.total_seconds()/60:.1f}min, "
                f"next check in {check_interval_minutes}min)"
            )
            
            # Don't sleep on the last attempt
            if attempt < max_attempts:
                time.sleep(check_interval_minutes * 60)  # Convert to seconds
        
        # Timeout reached
        total_elapsed = datetime.now() - start_time
        self.logger.error(
            f"{job_display_name} TIMEOUT after {total_elapsed.total_seconds()/60:.1f} minutes "
            f"({max_attempts} attempts)"
        )
        
        # Send timeout alert
        self._send_timeout_alert(run_type, total_elapsed)
        
        return False
    
    def get_blocking_jobs_info(self) -> Dict[str, Any]:
        """Get detailed info about what jobs are blocking this process/table using instance variables"""
        try:
            # Use instance variables for process/table filtering
            if self.process_name_filter and self.table_name_filter:
                # Check specific process/table from instance variables
                blocking_df = self.spark.sql(f"""
                    SELECT 
                        PROCESS_NAME,
                        TABLE_NAME,
                        STATUS,
                        PROCESS_STARTTIME,
                        CREATE_DATE,
                        RUN_TYPE
                    FROM {self.coordination_table}
                    WHERE PROCESS_NAME = '{self.process_name_filter}'
                      AND TABLE_NAME = '{self.table_name_filter}'
                      AND STATUS IN ('RUNNING', 'STARTED')
                      AND DATE(CREATE_DATE) >= CURRENT_DATE() - INTERVAL 3 DAYS
                    ORDER BY CREATE_DATE DESC
                    LIMIT 1
                """)
            else:
                # Check all running jobs (for general monitoring)
                blocking_df = self.spark.sql(f"""
                    SELECT 
                        PROCESS_NAME,
                        TABLE_NAME,
                        STATUS,
                        PROCESS_STARTTIME,
                        CREATE_DATE,
                        RUN_TYPE
                    FROM {self.coordination_table}
                    WHERE STATUS IN ('RUNNING', 'STARTED')
                      AND DATE(CREATE_DATE) >= CURRENT_DATE() - INTERVAL 3 DAYS
                    ORDER BY CREATE_DATE DESC
                    LIMIT 50
                """)
            
            blocking_jobs = blocking_df.collect()
            
            result = {
                "can_start": len(blocking_jobs) == 0,
                "blocking_count": len(blocking_jobs),
                "blocking_jobs": []
            }
            
            for job in blocking_jobs:
                runtime_seconds = 0
                if job.PROCESS_STARTTIME:
                    runtime_seconds = (datetime.now() - job.PROCESS_STARTTIME).total_seconds()
                
                result["blocking_jobs"].append({
                    "process_name": job.PROCESS_NAME or "N/A",
                    "table_name": job.TABLE_NAME or "N/A", 
                    "status": job.STATUS,
                    "runtime_minutes": runtime_seconds / 60,
                    "run_type": job.RUN_TYPE or "N/A",
                    "started": job.PROCESS_STARTTIME,
                    "created": job.CREATE_DATE
                })
            
            return result
            
        except Exception as e:
            self.logger.error(f"Failed to get blocking jobs info: {str(e)}")
            return {"can_start": True, "blocking_count": 0, "blocking_jobs": [], "error": str(e)}
    
    def _send_waiting_alert(self, run_type: RunType, elapsed_time: timedelta):
        """Send alert when job has been waiting too long - uses instance variables"""
        try:
            blocking_info = self.get_blocking_jobs_info()
            
            job_display_name = self.job_name or "Unknown Job"
            alert_message = (
                f"⚠️ JOB WAITING TOO LONG ⚠️\n"
                f"Job: {job_display_name} ({run_type.value})\n"
                f"Waiting Time: {elapsed_time.total_seconds()/60:.1f} minutes\n"
                f"Process: {self.process_name_filter or 'N/A'}\n"
                f"Table: {self.table_name_filter or 'N/A'}\n"
                f"Blocked by {blocking_info['blocking_count']} jobs:\n"
            )
            
            for job in blocking_info["blocking_jobs"]:
                alert_message += f"  - {job['process_name']}/{job['table_name']} ({job['status']}) running {job['runtime_minutes']:.1f}min\n"
            
            alert_message += f"Threshold: {self.alert_threshold.total_seconds()/60:.0f} minutes"
            
            self.logger.warning(alert_message)
            
            # TODO: Add your alerting mechanism here (email, Slack, etc.)
            # self._send_to_alert_system(alert_message)
            
        except Exception as e:
            self.logger.error(f"Failed to send waiting alert: {str(e)}")
    
    def _send_timeout_alert(self, run_type: RunType, total_time: timedelta):
        """Send alert when job times out - uses instance variables"""
        try:
            blocking_info = self.get_blocking_jobs_info()
            
            job_display_name = self.job_name or "Unknown Job"
            alert_message = (
                f"🚨 JOB TIMEOUT 🚨\n"
                f"Job: {job_display_name} ({run_type.value})\n"
                f"Total Wait Time: {total_time.total_seconds()/60:.1f} minutes\n"
                f"Process: {self.process_name_filter or 'N/A'}\n"
                f"Table: {self.table_name_filter or 'N/A'}\n"
                f"STATUS: GIVING UP\n"
                f"Was blocked by {blocking_info['blocking_count']} jobs"
            )
            
            self.logger.error(alert_message)
            
            # TODO: Add your alerting mechanism here (email, Slack, etc.)
            # self._send_to_alert_system(alert_message, severity="HIGH")
            
        except Exception as e:
            self.logger.error(f"Failed to send timeout alert: {str(e)}")
    
    def is_processing_enabled(self, run_type: RunType) -> bool:
        """
        Simple wrapper for your existing _is_processing_enabled logic
        Just returns True/False - no waiting - uses instance variables
        """
        return self.can_job_start(run_type)
    
    def get_job_status_summary(self) -> Dict[str, Any]:
        """Get summary of all job statuses for monitoring/debugging with partition pruning"""
        try:
            status_df = self.spark.sql(f"""
                SELECT 
                    run_type,
                    status,
                    COUNT(*) as count,
                    MIN(process_starttime) as earliest_start,
                    MAX(process_starttime) as latest_start
                FROM {self.coordination_table}
                WHERE status IN ('RUNNING', 'STARTED')
                  AND run_type IS NOT NULL
                  AND DATE(CREATE_DATE) >= CURRENT_DATE() - INTERVAL 7 DAYS
                GROUP BY run_type, status
                ORDER BY run_type, status
            """)
            
            summary = {
                "total_running": 0,
                "by_run_type": {},
                "longest_running": None
            }
            
            for row in status_df.collect():
                run_type = row.run_type
                if run_type not in summary["by_run_type"]:
                    summary["by_run_type"][run_type] = {}
                
                summary["by_run_type"][run_type][row.status] = {
                    "count": row.count,
                    "earliest_start": row.earliest_start,
                    "latest_start": row.latest_start
                }
                summary["total_running"] += row.count
            
            return summary
            
        except Exception as e:
            self.logger.error(f"Failed to get job status summary: {str(e)}")
            return {"error": str(e)}