"""
Vault RSM (Remote Secret Manager) Integration Module.

This module provides functionality to fetch secrets from HashiCorp Vault
using RSM authentication. It supports environment-based configuration
and caching for performance optimization.
"""

import os
import requests
import logging
from functools import lru_cache
from typing import Dict

from apd_ingestion.constants.env_vars import VaultEnvVars, GeneralEnvVars
from apd_ingestion.utils.decorators import log_decorator
# Configure module logger
logger = logging.getLogger(__name__)


@lru_cache(maxsize=1)
@log_decorator
def _get_vault_secrets() -> Dict[str, str]:
    """
    Fetch secrets from Vault using RSM authentication.
    
    Returns:
        dict: The secrets retrieved from the vault (empty dict if RSM disabled)
        
    Raises:
        ValueError: If required environment variables are missing
        requests.RequestException: If the HTTP request to the vault fails
        KeyError: If the expected 'data' field is missing in the vault response
    """
    # Check if RSM is enabled
    rsm_enable = os.getenv(VaultEnvVars.RSM_ENABLE.value, "true").lower() == "true"
    if not rsm_enable:
        logger.info("RSM is disabled. Skipping vault secret fetch.")
        return {}

    # Get environment and vault URL
    logger.info(f"{GeneralEnvVars.APP_ENV.value} environment variable: {os.getenv(GeneralEnvVars.APP_ENV.value)}")

    env = os.getenv(GeneralEnvVars.APP_ENV.value, "dev").lower()
    base_url = VaultEnvVars.get_vault_url(env)

    
    # Get required credentials
    token = os.getenv(VaultEnvVars.VAULT_TOKEN.value)
    shelf_id = os.getenv(VaultEnvVars.VAULT_SHELF_ID.value)

    # Validate required configuration
    if not token:
        raise ValueError(f"Environment variable {VaultEnvVars.VAULT_TOKEN.value} is required")
    if not shelf_id:
        raise ValueError(f"Environment variable {VaultEnvVars.VAULT_SHELF_ID.value} is required")

    # Build vault URL
    full_url = f"{base_url.rstrip('/')}/{shelf_id}"
    headers = {"spr-sm-token": token}

    logger.info(f"Fetching secrets from Vault: {full_url} (env: {env})")
    
    try:
        response = requests.get(full_url, headers=headers)
        response.raise_for_status()
        data = response.json()
        
        if "data" not in data:
            raise KeyError("Vault response missing 'data' field")
            
        logger.info("Successfully fetched secrets from Vault")
        return data["data"]
        
    except requests.RequestException as e:
        logger.error(f"Failed to fetch secrets from vault: {e}")
        raise
    except (ValueError, KeyError) as e:
        logger.error(f"Invalid vault response: {e}")
        raise


def get_secret_from_vault(secret_name: str) -> str:
    """
    Fetch a single secret from the cached vault secrets.
    
    Args:
        secret_name: Name of the secret to retrieve
        
    Returns:
        str: The secret value
        
    Raises:
        ValueError: If secret is not found or vault is not accessible
    """
    secrets = _get_vault_secrets()
    
    if not secrets:
        raise ValueError("No secrets available. Ensure RSM is enabled and vault is accessible")
    
    if secret_name not in secrets:
        raise ValueError(f"Secret '{secret_name}' not found in vault")
    
    logger.debug(f"Retrieved secret '{secret_name}' from vault")
    return secrets[secret_name]