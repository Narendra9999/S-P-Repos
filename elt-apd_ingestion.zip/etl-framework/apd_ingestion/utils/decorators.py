import logging
import time
import functools
from typing import Any, Callable
from functools import wraps

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def log_decorator(func: Callable) -> Callable:
    @functools.wraps(func)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        logger.info(f"Calling function: {func.__name__}")
        try:
            result = func(*args, **kwargs)
            logger.info(f"Function {func.__name__} completed successfully")
            return result
        except Exception as e:
            logger.error(f"Error in function {func.__name__}: {str(e)}")
            raise
    return wrapper

def timer_decorator(func: Callable) -> Callable:
    @functools.wraps(func)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        start_time = time.time()
        result = func(*args, **kwargs)
        end_time = time.time()
        logger.info(f"Function {func.__name__} took {end_time - start_time:.2f} seconds to execute")
        return result
    return wrapper

def retry_decorator(max_retries=3, delay=1, exceptions=(Exception,)):
    """
    A decorator that retries the decorated function on failure.
    
    Args:
        max_retries (int): Maximum number of retry attempts
        delay (int): Initial delay between retries in seconds
        exceptions (tuple): Tuple of exceptions to catch and retry on
    """
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            retries = 0
            current_delay = delay
            
            while retries < max_retries:
                try:
                    return func(*args, **kwargs)
                except exceptions as e:
                    retries += 1
                    if retries == max_retries:
                        logging.error(f"Final retry attempt failed for {func.__name__}: {str(e)}")
                        raise  # Re-raise the last exception if all retries failed
                    
                    logging.warning(
                        f"Retry attempt {retries}/{max_retries} for {func.__name__} "
                        f"failed: {str(e)}. Retrying in {current_delay} seconds..."
                    )
                    
                    time.sleep(current_delay)
                    # Exponential backoff: double the delay for next retry
                    current_delay *= 2
            
            return func(*args, **kwargs)  # Final attempt
        return wrapper
    return decorator 