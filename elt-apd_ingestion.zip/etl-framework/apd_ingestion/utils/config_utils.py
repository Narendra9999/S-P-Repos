"""
Configuration utilities for secure handling and logging of configuration data.
"""

import copy
import re
from typing import Dict, Any, List

def get_safe_config_for_logging(config: Dict[str, Any], custom_sensitive_keys: List[str] = None, mask_value: str = "***MASKED***") -> Dict[str, Any]:
    """
    Create a deep copy of configuration with sensitive values masked for safe logging.
    
    Args:
        config: Configuration dictionary to mask
        custom_sensitive_keys: Additional keys to treat as sensitive
        mask_value: Value to use for masking sensitive data
        
    Returns:
        Deep copy of config with sensitive values masked
    """
    if not isinstance(config, dict):
        return config
        
    # Create a deep copy to avoid modifying original
    safe_config = copy.deepcopy(config)
    
    # Default sensitive keys
    sensitive_keys = {
        'password', 'passwd', 'pwd', 'secret', 'token', 'key', 'api_key', 'apikey',
        'auth_token', 'access_token', 'refresh_token', 'private_key', 'cert', 'certificate'
    }
    
    # Add custom sensitive keys if provided
    if custom_sensitive_keys:
        sensitive_keys.update(custom_sensitive_keys)
    
    return mask_sensitive_config(safe_config, sensitive_keys, mask_value)

def mask_sensitive_config(config: Any, sensitive_keys: set, mask_value: str = "***MASKED***") -> Any:
    """
    Recursively mask sensitive configuration values.
    
    Args:
        config: Configuration object (dict, list, or primitive)
        sensitive_keys: Set of keys considered sensitive
        mask_value: Value to use for masking
        
    Returns:
        Configuration with sensitive values masked
    """
    if isinstance(config, dict):
        masked = {}
        for key, value in config.items():
            key_lower = key.lower()
            
            # Handle JAAS config specially
            if 'jaas' in key_lower and isinstance(value, str):
                masked[key] = mask_kafka_jaas_config(value, mask_value)
            # Check if key matches sensitive patterns
            elif any(sensitive_key in key_lower for sensitive_key in sensitive_keys):
                masked[key] = mask_value
            else:
                # Recursively process nested structures
                masked[key] = mask_sensitive_config(value, sensitive_keys, mask_value)
        return masked
    
    elif isinstance(config, list):
        return [mask_sensitive_config(item, sensitive_keys, mask_value) for item in config]
    
    else:
        # Primitive value, return as-is
        return config

def mask_kafka_jaas_config(jaas_config: str, mask_value: str = "***MASKED***") -> str:
    """
    Mask passwords in Kafka JAAS configuration strings.
    
    Example:
        Input: 'org.apache.kafka.common.security.plain.PlainLoginModule required username="user" password="secret";'
        Output: 'org.apache.kafka.common.security.plain.PlainLoginModule required username="user" password="***MASKED***";'
    
    Args:
        jaas_config: JAAS configuration string
        mask_value: Value to use for masking passwords
        
    Returns:
        JAAS config string with password masked
    """
    if not isinstance(jaas_config, str):
        return jaas_config
    
    # Pattern to match password="value" or password='value' in JAAS config
    password_pattern = r'password\s*=\s*["\'][^"\']*["\']'
    
    # Replace with masked password
    masked_config = re.sub(
        password_pattern, 
        f'password="{mask_value}"', 
        jaas_config, 
        flags=re.IGNORECASE
    )
    
    return masked_config