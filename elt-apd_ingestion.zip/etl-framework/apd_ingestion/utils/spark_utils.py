from pyspark.sql import SparkSession

class SparkUtils:

    @staticmethod
    def get_spark_session():
        return SparkSession.builder.appName("APD_INGESTION").getOrCreate()