"""
Spark-based Kafka Producer using DataFrames 
"""

import logging
import json
from typing import Dict, List, Union, Optional
from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType, ArrayType, BinaryType
import threading
import os

from apd_ingestion.utils.config_utils import get_safe_config_for_logging

logger = logging.getLogger(__name__)


class SparkKafkaProducer:
    """
    Spark-based Singleton Kafka producer using DataFrames.
    """
    
    _instances = {}
    _lock = threading.Lock()

    def __new__(cls, connection_name: str = "confluent_kafka"):
        """Create a new instance per connection name if it doesn't exist."""
        with cls._lock:
            if connection_name not in cls._instances:
                instance = super(SparkKafkaProducer, cls).__new__(cls)
                instance._initialized = False
                cls._instances[connection_name] = instance
            return cls._instances[connection_name]

    def __init__(self, connection_name: str = "confluent_kafka"):
        """Initialize Spark Kafka producer with connection configuration."""
        # Prevent re-initialization of singleton
        if hasattr(self, '_initialized') and self._initialized:
            return
            
        self.connection_name = connection_name
        self.spark = None
        self._kafka_options = None
        
        self._setup_spark_and_kafka()
        self._initialized = True

    def _get_jaas_config(self, username: str, password: str) -> str:
        """Generate JAAS configuration string based on environment"""
        from apd_ingestion.config.config_manager import ConfigManager

        if ConfigManager.is_databricks():
            login_module = 'kafkashaded.org.apache.kafka.common.security.plain.PlainLoginModule'
        else:
            login_module = 'org.apache.kafka.common.security.plain.PlainLoginModule'
        
        return f'{login_module} required username="{username}" password="{password}";'

    def _setup_spark_and_kafka(self):
        """Set up Spark session and Kafka configuration (reuses existing Spark session)."""
        # Get connection config
        from apd_ingestion.config.config_manager import get_config_value
        connection_config = get_config_value(f'kafka.connections.{self.connection_name}')
        if not connection_config:
            raise ValueError(f"Kafka connection '{self.connection_name}' not found in configuration")

        # Always try to reuse existing Spark session first
        self.spark = SparkSession.getActiveSession()
        if not self.spark:
            logger.warning("No active Spark session found. Creating a minimal one for Kafka producer.")
            self.spark = self._create_minimal_spark_session()
        else:
            logger.info(f"Reusing existing Spark session: {self.spark.sparkContext.appName}")

        # Build Kafka options (same logic as your streaming processor)
        self._kafka_options = {
            "kafka.bootstrap.servers": connection_config['bootstrap_servers']
        }
        
        # Add producer-specific config from YAML
        producer_config = get_config_value('kafka.producer', {})
        for key, value in producer_config.items():
            # Convert producer config keys to Spark format
            spark_key = f"kafka.{key}"
            self._kafka_options[spark_key] = str(value)
        
        # Security configuration
        security_config = connection_config.get('security', {})
        if security_config.get('protocol'):
            self._kafka_options["kafka.security.protocol"] = security_config['protocol']
        
        # SASL configuration 
        sasl_config = security_config.get('sasl', {})
        if sasl_config:
            if sasl_config.get('mechanism'):
                self._kafka_options["kafka.sasl.mechanism"] = sasl_config['mechanism']
            if sasl_config.get('username') and sasl_config.get('password'):
                jaas_config = self._get_jaas_config(sasl_config["username"], sasl_config["password"])
                self._kafka_options["kafka.sasl.jaas.config"] = jaas_config

        # SSL configuration handles JKS files natively
        ssl_config = connection_config.get('ssl', {})
        if ssl_config:
            logger.info("Adding SSL configuration for Kafka connection")
            if ssl_config.get('truststore_location'):
                self._kafka_options["kafka.ssl.truststore.location"] = ssl_config['truststore_location']
                logger.debug(f"SSL truststore location: {ssl_config['truststore_location']}")

        # Log safe config
        safe_options = get_safe_config_for_logging(self._kafka_options)
        logger.info(f"Spark Kafka producer options: {safe_options}")

    def _create_minimal_spark_session(self) -> SparkSession:
        """Create a minimal Spark session only when no active session exists."""
        app_name = f"ETL_Framework_KafkaProducer_{self.connection_name}"
        from apd_ingestion.config.config_manager import ConfigManager
        if ConfigManager.is_databricks():
            logger.info("Creating minimal Databricks Spark session for Kafka producer")
            # In Databricks, use the simplest possible session
            builder = SparkSession.builder.appName(app_name)
        else:
            logger.info("Creating minimal local Spark session for Kafka producer")
            # Minimal local session - just what's needed for Kafka
            builder = SparkSession.builder \
                .appName(app_name) \
                .master("local[*]") \
                .config("spark.sql.warehouse.dir", "/tmp/spark-warehouse") \
                .config("spark.jars.packages", "io.delta:delta-core_2.12:2.4.0,org.apache.spark:spark-sql-kafka-0-10_2.12:3.5.0")
        
        return builder.getOrCreate()

    def send_message(self, topic: str, message: Union[Dict, str], key: Optional[str] = None, 
                    headers: Optional[Dict[str, str]] = None) -> bool:
        """
        Send a single message to Kafka topic using Spark DataFrame.
        
        Args:
            topic: Kafka topic name
            message: Message to send (dict will be JSON serialized)
            key: Optional message key
            headers: Optional message headers as dict
            
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            # Convert message to JSON string if it's a dict
            if isinstance(message, dict):
                value = json.dumps(message)
            else:
                value = str(message)

            # Convert headers to the format Spark expects: array<struct<key:string,value:binary>>
            headers_array = None
            if headers:
                # Convert to array of structs format
                headers_array = [{"key": k, "value": str(v).encode('utf-8')} for k, v in headers.items()]
            
            # Define schema with proper headers format
            headers_schema = ArrayType(StructType([
                StructField("key", StringType(), False),
                StructField("value", BinaryType(), False)
            ]))
            
            schema = StructType([
                StructField("key", StringType(), True),
                StructField("value", StringType(), False),
                StructField("topic", StringType(), False),
                StructField("headers", headers_schema, True)
            ])
            
            message_data = [(key, value, topic, headers_array)]
            df = self.spark.createDataFrame(message_data, schema)
            
            # Write to Kafka using your existing Kafka options
            writer = df.write.format("kafka")
            for option_key, option_value in self._kafka_options.items():
                writer = writer.option(option_key, option_value)
            
            writer.save()
            logger.info(f"Message sent to topic '{topic}' with headers: {list(headers.keys()) if headers else 'none'}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to send message to topic '{topic}': {e}")
            return False

    def send_batch(self, topic: str, messages: List[Union[Dict, str]], keys: Optional[List[str]] = None,
                  headers_list: Optional[List[Dict[str, str]]] = None) -> int:
        """
        Send multiple messages to Kafka topic as a batch.
        
        Args:
            topic: Kafka topic name
            messages: List of messages to send
            keys: Optional list of message keys (must match messages length)
            headers_list: Optional list of headers dicts (must match messages length)
            
        Returns:
            int: Number of messages sent successfully
        """
        try:
            if not messages:
                return 0
                
            # Validate keys length if provided
            if keys and len(keys) != len(messages):
                raise ValueError("Keys list must have same length as messages list")
                
            # Validate headers length if provided
            if headers_list and len(headers_list) != len(messages):
                raise ValueError("Headers list must have same length as messages list")
            
            # Prepare data for DataFrame
            message_data = []
            for i, msg in enumerate(messages):
                # Convert to JSON if dict
                if isinstance(msg, dict):
                    value = json.dumps(msg)
                else:
                    value = str(msg)
                
                key = keys[i] if keys else None
                
                # Convert headers to array of structs format
                headers_array = None
                if headers_list and i < len(headers_list) and headers_list[i]:
                    headers_array = [{"key": k, "value": str(v).encode('utf-8')} for k, v in headers_list[i].items()]
                
                message_data.append((key, value, topic, headers_array))
                        
            # Define schema with proper headers format
            headers_schema = ArrayType(StructType([
                StructField("key", StringType(), False),
                StructField("value", BinaryType(), False)
            ]))
            
            schema = StructType([
                StructField("key", StringType(), True),
                StructField("value", StringType(), False), 
                StructField("topic", StringType(), False),
                StructField("headers", headers_schema, True)
            ])
            
            df = self.spark.createDataFrame(message_data, schema)
            
            # Write batch to Kafka
            writer = df.write.format("kafka")
            for option_key, option_value in self._kafka_options.items():
                writer = writer.option(option_key, option_value)
            
            writer.save()
            logger.info(f"Batch of {len(messages)} messages sent to topic '{topic}' successfully")
            return len(messages)
            
        except Exception as e:
            logger.error(f"Failed to send batch to topic '{topic}': {e}")
            return 0

    @classmethod
    def get_instance(cls, connection_name: str = "confluent_kafka"):
        """Get singleton instance for a connection."""
        return cls(connection_name)

    def close(self):
        """Close resources (but don't stop shared Spark session)."""
        # Don't stop Spark session as it might be shared with other components
        # Let the main application manage Spark lifecycle
        if self.spark:
            logger.info("Kafka producer resources cleaned up (Spark session left running for reuse)")
        self.spark = None

    @classmethod
    def close_all(cls):
        """Close all singleton producer instances (but preserve shared Spark sessions)."""
        with cls._lock:
            for connection_name, instance in cls._instances.items():
                instance.close()
                logger.info(f"Closed Kafka producer for connection: {connection_name}")
            cls._instances.clear()


def send_kafka_message(topic: str, message: Union[Dict, str], key: Optional[str] = None, 
                      headers: Optional[Dict[str, str]] = None,
                      connection_name: str = "confluent_kafka") -> bool:
    """Send a message to Kafka using Spark DataFrame with headers."""
    producer = SparkKafkaProducer.get_instance(connection_name)
    return producer.send_message(topic, message, key, headers)


def send_kafka_batch(topic: str, messages: List[Union[Dict, str]], keys: Optional[List[str]] = None,
                    headers_list: Optional[List[Dict[str, str]]] = None,
                    connection_name: str = "confluent_kafka") -> int:
    """Send multiple messages to Kafka using Spark DataFrame with headers."""
    producer = SparkKafkaProducer.get_instance(connection_name)
    return producer.send_batch(topic, messages, keys, headers_list)
