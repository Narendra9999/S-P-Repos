import boto3
import logging
from typing import List, Optional, Callable

# Configure logging
logger = logging.getLogger(__name__)

class S3Utils:
    """Common S3 utility functions for file operations"""
    
    def __init__(self, bucket_name: str, aws_region: Optional[str] = None):
        """
        Initialize S3 utilities
        
        Args:
            bucket_name: S3 bucket name
            aws_region: AWS region (optional, uses default if not provided)
        """
        self.bucket_name = bucket_name
        self.s3_client = boto3.client('s3', region_name=aws_region) if aws_region else boto3.client('s3')
        
    def list_files(
        self, 
        folder_prefix: str, 
        file_extensions: Optional[List[str]] = None,
        file_prefixes: Optional[List[str]] = None,
        custom_filter: Optional[Callable[[str], bool]] = None
    ) -> List[str]:
        """
        List files in S3 bucket with flexible filtering options
        
        Args:
            folder_prefix: S3 folder prefix to search in
            file_extensions: List of file extensions to filter by (e.g., ['.DAT', '.csv'])
            file_prefixes: List of filename prefixes to match
            custom_filter: Custom filter function that takes a file key and returns bool
            
        Returns:
            List of S3 file keys that match the criteria
        """
        try:
            response = self.s3_client.list_objects_v2(
                Bucket=self.bucket_name, 
                Prefix=folder_prefix, 
                Delimiter='/'
            )
            all_files = response.get('Contents', [])
            
            # Extract file keys
            file_keys = [obj['Key'] for obj in all_files]
            
            # Apply filters
            filtered_files = file_keys
            
            # Filter by file extensions
            if file_extensions:
                filtered_files = [
                    key for key in filtered_files 
                    if any(key.lower().endswith(ext.lower()) for ext in file_extensions)
                ]
            
            # Filter by file prefixes
            if file_prefixes:
                filtered_files = [
                    key for key in filtered_files 
                    if any(self._extract_filename(key).startswith(prefix) for prefix in file_prefixes)
                ]
            
            # Apply custom filter
            if custom_filter:
                filtered_files = [key for key in filtered_files if custom_filter(key)]
            
            logger.info(f"Found {len(filtered_files)} files matching criteria out of {len(file_keys)} total files")
            logger.debug(f"Filtered files: {filtered_files}")
            
            return filtered_files
            
        except Exception as e:
            logger.error(f"Error listing S3 files in {self.bucket_name}/{folder_prefix}: {str(e)}")
            raise
    
    def download_file(self, file_key: str, local_filename: str) -> None:
        """
        Download file from S3 to local filesystem
        
        Args:
            file_key: S3 object key
            local_filename: Local file path to save to
        """
        try:
            obj = self.s3_client.get_object(Bucket=self.bucket_name, Key=file_key)
            content = obj['Body'].read()
            
            with open(local_filename, 'wb') as f:
                f.write(content)
            
            logger.info(f"Downloaded {file_key} to {local_filename}")
            
        except Exception as e:
            logger.error(f"Error downloading file {file_key}: {str(e)}")
            raise
    
    def upload_file(self, local_filename: str, s3_key: str) -> None:
        """
        Upload file from local filesystem to S3
        
        Args:
            local_filename: Local file path to upload
            s3_key: S3 object key to save as
        """
        try:
            with open(local_filename, 'rb') as f:
                self.s3_client.put_object(
                    Bucket=self.bucket_name,
                    Key=s3_key,
                    Body=f.read()
                )
            
            logger.info(f"Uploaded {local_filename} to {s3_key}")
            
        except Exception as e:
            logger.error(f"Error uploading file {local_filename}: {str(e)}")
            raise
    
    def move_to_archive(self, source_key: str, archive_prefix: str = 'archive') -> str:
        """
        Move file to archive folder in S3
        
        Args:
            source_key: Source S3 object key
            archive_prefix: Archive folder prefix
            
        Returns:
            Destination key where file was moved
        """
        try:
            file_name = self._extract_filename(source_key)
            destination_key = f"{archive_prefix}/{file_name}"
            
            # Copy to archive
            self.s3_client.copy_object(
                Bucket=self.bucket_name,
                CopySource={'Bucket': self.bucket_name, 'Key': source_key},
                Key=destination_key
            )
            
            # Delete original
            self.s3_client.delete_object(Bucket=self.bucket_name, Key=source_key)
            
            logger.info(f"Moved {source_key} to {destination_key}")
            return destination_key
            
        except Exception as e:
            logger.error(f"Error moving file to archive: {str(e)}")
            raise
    
    def copy_file(self, source_key: str, destination_key: str) -> None:
        """
        Copy file within S3 bucket
        
        Args:
            source_key: Source S3 object key
            destination_key: Destination S3 object key
        """
        try:
            self.s3_client.copy_object(
                Bucket=self.bucket_name,
                CopySource={'Bucket': self.bucket_name, 'Key': source_key},
                Key=destination_key
            )
            
            logger.info(f"Copied {source_key} to {destination_key}")
            
        except Exception as e:
            logger.error(f"Error copying file: {str(e)}")
            raise
    
    def delete_file(self, file_key: str) -> None:
        """
        Delete file from S3
        
        Args:
            file_key: S3 object key to delete
        """
        try:
            self.s3_client.delete_object(Bucket=self.bucket_name, Key=file_key)
            logger.info(f"Deleted {file_key}")
            
        except Exception as e:
            logger.error(f"Error deleting file {file_key}: {str(e)}")
            raise
    
    def file_exists(self, file_key: str) -> bool:
        """
        Check if file exists in S3
        
        Args:
            file_key: S3 object key to check
            
        Returns:
            True if file exists, False otherwise
        """
        try:
            self.s3_client.head_object(Bucket=self.bucket_name, Key=file_key)
            return True
        except Exception:
            return False
    
    def get_file_size(self, file_key: str) -> Optional[int]:
        """
        Get file size in bytes
        
        Args:
            file_key: S3 object key
            
        Returns:
            File size in bytes, or None if file doesn't exist
        """
        try:
            response = self.s3_client.head_object(Bucket=self.bucket_name, Key=file_key)
            return response['ContentLength']
        except Exception as e:
            logger.warning(f"Could not get file size for {file_key}: {str(e)}")
            return None
    
    def _extract_filename(self, file_key: str) -> str:
        """Extract filename from S3 key"""
        return file_key.split('/')[-1]