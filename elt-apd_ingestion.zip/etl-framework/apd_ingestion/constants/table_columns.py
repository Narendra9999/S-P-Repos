"""
ADP Table Column Constants

This module contains column name constants for ADP dataset tables.
"""

class ADPTableColumns:
    # All columns in the ADP dataset table
    FIN_ENTITY_ID = "fin_entity_id"
    RE_ORG_ID = "re_org_id"
    DATASET_SOURCE = "dataset_source"
    PERIOD_END_DATE = "period_end_date"
    ORG_NAME = "org_name"
    DATASET_TYPE = "dataset_type"
    DATASET_STATUS = "dataset_status"
    DATASET_VERSION = "dataset_version"
    CURRENT_IND = "current_ind"
    LAST_UPD_DATETIME = "last_upd_datetime"
    LAST_UPD_USER_ID = "last_upd_user_id"
    CREATE_USER_ID = "create_user_id"
    CREATE_DATETIME = "create_datetime"
    DATASET = "dataset"
    # Add more columns as needed

    # Business keys for SCD2 logic
    BUSINESS_KEYS = [FIN_ENTITY_ID, RE_ORG_ID, DATASET_SOURCE, PERIOD_END_DATE]
    # Required columns for upsert
    REQUIRED = [FIN_ENTITY_ID, RE_ORG_ID, DATASET_SOURCE, PERIOD_END_DATE, DATASET_TYPE, DATASET_STATUS, CURRENT_IND]