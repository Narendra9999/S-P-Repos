"""
Environment Variables Constants for ETL Framework.

This module defines all environment variable constants used throughout the ETL framework,
organized by category for better maintainability and type safety.
"""

from enum import Enum, unique
from typing import Dict


@unique
class DatabaseEnvVars(Enum):
    """Database-related environment variables."""
    
    DATABASE_URL = "DATABASE_URL"
    DB_USER = "DB_USER"
    DB_PASSWORD = "DB_PASSWORD"
    DB_HOST = "DB_HOST"
    DB_PORT = "DB_PORT"
    DB_NAME = "DB_NAME"
    DB_SCHEMA = "DB_SCHEMA"
    DB_DRIVER = "DB_DRIVER"

    def __str__(self) -> str:
        return self.value

@unique
class GeneralEnvVars(Enum):
    """General application environment variables."""
    
    APP_ENV = "aws_env"
    LOG_LEVEL = "LOG_LEVEL"
    APP_NAME = "APP_NAME"
    APP_VERSION = "APP_VERSION"
    DEBUG = "DEBUG"
    
    # Environment types
    DEV_ENV = "dev"
    QA_ENV = "qa"
    PROD_ENV = "prod"
    UAT_ENV = "uat"
    DR_ENV = "dr"
    SSD_DEV_ENV = "ssddev"
    SSD_QA_ENV = "ssdqa"
    SI_ENV = "si"
    LOCAL_ENV = "local"

    def __str__(self) -> str:
        return self.value
    
    @classmethod
    def get_valid_environments(cls) -> list[str]:
        """Get list of valid environment names."""
        return [
            cls.DEV_ENV.value,
            cls.QA_ENV.value,
            cls.PROD_ENV.value,
            cls.UAT_ENV.value,
            cls.DR_ENV.value,
            cls.SSD_DEV_ENV.value,
            cls.SSD_QA_ENV.value,
            cls.SI_ENV.value,
            cls.LOCAL_ENV.value
        ]

@unique  
class VaultEnvVars(Enum):
    """Vault and RSM-related environment variables."""
    
    RSM_ENABLE = "RSM_ENABLE"
    VAULT_TOKEN = "SPR_APP_SECRET_HC_GRDP_DOP_VAULT_TOKEN"
    VAULT_SHELF_ID = "IDF_GRDP_DOP_SHELF_ID"
    VAULT_BASE_URL = "SPR_APP_SECRET_HC_VAULT_BASE_URL"

    def __str__(self) -> str:
        return self.value
    
    @classmethod
    def get_vault_urls(cls) -> Dict[str, str]:
        """Get vault URLs for different environments."""
        return {
            "dev": "https://sm-vault.dev.spratingsvpc.com",
            "qa": "https://sm-vault.dev.spratingsvpc.com",
            "si": "https://sm-vault.dev.spratingsvpc.com",
            "uat": "https://sm-vault.dev.spratingsvpc.com",
            "prod": "https://secretsmanager.mge.spratingsvpc.com",
            "dr": "https://secretsmanager.mge.spratingsvpc.com",
            "ssddev": "https://sm-vault.dev.spratingsvpc.com",
            "ssdqa": "https://sm-vault.dev.spratingsvpc.com",
            "local": "https://sm-vault.dev.spratingsvpc.com"
        }
    
    @classmethod
    def get_vault_url_for_env(cls, environment: str) -> str:
        """
        Get vault URL for a specific environment.
        
        Args:
            environment: The environment name (dev, qa, prod, etc.)
            
        Returns:
            The vault URL for the environment
            
        Raises:
            ValueError: If environment is not supported
        """
        vault_urls = cls.get_vault_urls()
        if environment not in vault_urls:
            raise ValueError(
                f"Unsupported environment: {environment}. "
                f"Supported environments: {list(vault_urls.keys())}"
            )
        return vault_urls[environment]
    
    @classmethod
    def get_vault_url(cls, environment: str = None) -> str:
        """
        Get vault URL, preferring environment variable over hardcoded URLs.
        
        Args:
            environment: The environment name (dev, qa, prod, etc.). 
                        If None, will try to get from APP_ENV
            
        Returns:
            The vault URL - either from SPR_APP_SECRET_HC_VAULT_BASE_URL env var
            or from hardcoded URLs based on environment
            
        Raises:
            ValueError: If environment is not supported and no env var is set
        """
        import os
        import logging
        
        logger = logging.getLogger(__name__)
        
        # First check if the base URL is set via environment variable
        vault_base_url = os.getenv(cls.VAULT_BASE_URL.value)
        if vault_base_url:
            logger.info(f"Vault URL fetched from environment variable {cls.VAULT_BASE_URL.value}: {vault_base_url}")
            return vault_base_url
        
        # Fall back to environment-specific URLs
        if environment is None:
            environment = os.getenv(GeneralEnvVars.APP_ENV.value, "dev")
            logger.info(f"Environment determined from {GeneralEnvVars.APP_ENV.value}: {environment}")
        else:
            logger.info(f"Environment provided: {environment}")
        
        vault_url = cls.get_vault_url_for_env(environment)
        logger.info(f"Vault URL fetched from hardcoded configuration for environment '{environment}': {vault_url}")
        
        return vault_url