from enum import Enum

class LoadType(Enum):
    ZERO_DAY = "zero_day"
    INCREMENTAL = "incremental"

class RunType(Enum):
    BATCH="BATCH"
    FINANALYTIC_STREAM="FINANALYTIC_STREAM"
    USPF_STREAM="USPF_STREAM"

class DataSetStatus(Enum):
    PROVISIONAL = "PROVISIONAL"
    FINAL = "FINAL"

class DataSetType(Enum):
    ECONOMIC_FINANCIAL = "Economic Financial"
    
class StreamType(Enum):
    IHS_FINANALYTIC = "IHS_FINANALYTIC"
    BLS_FINANALYTIC = "BLS_FINANALYTIC"
    EDS_FINANALYTIC = "EDS_FINANALYTIC"
    IHS_USPF = "IHS_USPF"
    BLS_USPF = "BLS_USPF"
    
class EdsStatus(Enum):
    RAW_LOADED = "RAW_LOADED"
    CURATED_LOADED = "CURATED_LOADED"