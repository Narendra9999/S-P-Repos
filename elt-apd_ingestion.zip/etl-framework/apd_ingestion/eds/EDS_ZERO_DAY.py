"""
EDS Zero Day Data Loader - Refactored Version
Loads EDS data from FinMaster to curated layer for all geography levels.
Supports environment parameterization (dev, qa, prod, etc.)
"""
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, lit, concat_ws,trim,  when, current_timestamp
import logging
import sys

logging.basicConfig(stream=sys.stdout, level=logging.INFO)
logger = logging.getLogger(__name__)


def get_spark_session():
    """Get or create Spark session"""
    return SparkSession.builder.appName("EDS_ZeroDay_Loader").getOrCreate()


def load_county_level_data(env: str, user: str = "dop_user"):
    """
    Load County level EDS data from FinMaster to curated layer
    
    Args:
        env: Environment (dev, qa, prod)
        user: User ID for audit fields
    """
    logger.info(f"Loading County level data for environment: {env}")
    spark = get_spark_session()
    
    # Delete existing County data before loading
    logger.info("Deleting existing County level data...")
    spark.sql(f"""
        DELETE FROM idf_curated_{env}.eds.t_eds_data_pnt 
        WHERE Geography_Type = 'COUNTY'
    """)
    logger.info("Existing County level data deleted successfully")
    
    # Run the FinMaster SQL query
    finmaster_df = spark.sql(f"""
        SELECT ENTITY_ID_TEXT, PERIOD_END_DATE, PERIOD_NAME, PERIOD_TYPE, SOURCE_MNEMONIC_TEXT, DATA_ELEMENT_NAME, DATA_ELEMENT_DESCR, DB_DATA_TYPE, DATA_UNIT_TYPE, VALUE_TEXT, YEAR, COUNTY_NAME, FIPS_STATE_CODE, STATE_NAME, CBS_AREA_CODE, CBS_AREA_NAME, X.CREATE_DATETIME,X.UPDATE_DATETIME, X.LATEST_VALUE_FLAG, SOURCE_FILENAME 
        FROM 
        (SELECT /*+ PARALLEL (10) */ ENTITY_ID_TEXT,DPD.PERIOD_END_DATE,DPD.SUB_SOURCE_NAME,
        DDP.ACCOUNTING_STANDARD_NAME, DDP.ACCOUNTING_BASIS_NAME, 
        DDP.PERIOD_NAME, DDP.PERIOD_TYPE,DDP.DATASET_CONTEXT_NAME, DDP.CURRENCY_ISO_CODE, DDP.PERIOD_NAME,
        DDP.CONFIDENTIAL_FLAG, DDP.NUMBER_OF_MONTHS_IN_PERIOD, DDP.NUMBER_OF_WEEKS_IN_PERIOD, DDP.AUDIT_STATUS,FDP.SOURCE_DATA_ELEMENT_ID,
        DSDE.UNIQUE_MNEMONIC_TEXT,DSDE.SOURCE_MNEMONIC_TEXT,DSDE.DATA_ELEMENT_NAME,DSDE.DATA_ELEMENT_DESCR,DSDE.DB_DATA_TYPE,DSDE.DATA_UNIT_TYPE,VALUE_TEXT, FDP.CREATE_DTIME as CREATE_DATETIME, FDP.NOT_LATEST_IN_DATASET_DTIME as UPDATE_DATETIME, FDP.LATEST_IN_DATASET_FLAG as LATEST_VALUE_FLAG, EXTRACT(YEAR FROM fdp.PERIOD_END_DATE) as YEAR
        FROM idf_{env}.finmaster.t_dim_DATA_SOURCE_ENTITY DDSE, idf_{env}.finmaster.t_dim_PERIOD_DATASET DPD, idf_{env}.finmaster.t_dim_DATASET_PROFILE DDP, idf_{env}.finmaster.t_fact_data_point FDP,idf_{env}.finmaster.t_dim_SOURCE_DATA_ELEMENT DSDE
        WHERE 1=1
        AND DDSE.FM_DATA_SOURCE_ID='6'
        AND DDSE.DATA_SOURCE_ENTITY_ID=DPD.DATA_SOURCE_ENTITY_ID
        AND DPD.FM_DATA_SOURCE_ID='6'
        AND DPD.LATEST_IN_CONTEXT_FLAG='Y'
        AND DPD.PERIOD_END_DATE >= TO_DATE('01/01/2013', 'MM/dd/yyyy')
        AND DPD.EXPIRY_DTIME = TO_DATE('12/31/9999', 'MM/dd/yyyy')
        AND DPD.DATASET_PROFILE_ID=DDP.DATASET_PROFILE_ID
        AND FDP.FM_DATA_SOURCE_ID='6'
        AND FDP.AUDIT_ID='6'
        AND DPD.PERIOD_DATASET_ID=FDP.PERIOD_DATASET_ID
        AND DPD.PERIOD_END_DATE=FDP.PERIOD_END_DATE
        AND DSDE.FM_DATA_SOURCE_ID='6'
        AND FDP.SOURCE_DATA_ELEMENT_ID=DSDE.SOURCE_DATA_ELEMENT_ID) X,
        (SELECT * FROM idf_{env}.EDS.t_EDS_COUNTY WHERE FIPS_COUNTY_CODE IN
        (SELECT ENTITY_ID_TEXT FROM idf_{env}.finmaster.t_dim_DATA_SOURCE_ENTITY WHERE FM_DATA_SOURCE_ID=6) 
        AND ACTION IN ('INSERT','UPDATE')) Y
        WHERE X.ENTITY_ID_TEXT=Y.FIPS_COUNTY_CODE
        AND PERIOD_END_DATE >= TO_DATE('01/01/2013', 'MM/dd/yyyy')
    """)

    # Transform to curated schema
    curated_df = finmaster_df.select(
        col("ENTITY_ID_TEXT").alias("Geography_Unit_Code"),
        lit("COUNTY").alias("Geography_Type"),
        lit("United States").alias("Country_Name"),
        col("ENTITY_ID_TEXT").alias("County_FIPS_Code"),
        col("COUNTY_NAME").alias("County_Name"),
        col("FIPS_STATE_CODE").alias("State_FIPS_Code"),
        col("STATE_NAME").alias("State_Name"),
        col("CBS_AREA_CODE").alias("Core_Based_Statistical_Area_Code"),
        col("CBS_AREA_NAME").alias("Core_Based_Statistical_Area_Name"),
        lit(None).alias("Minor_Civil_Division_Code"),
        lit(None).alias("Minor_Civil_Division_Name"),
        lit(None).alias("Place_Code"),
        lit(None).alias("Place_Name"),
        lit(None).alias("School_District_Code"),
        lit(None).alias("School_District_Name"),
        lit(None).alias("Longitude"),
        lit(None).alias("Latitude"),
        col("SOURCE_FILENAME").alias("Reference_Data_Source"),
        col("YEAR").cast("string").alias("Data_Point_Year"),
        when(col("PERIOD_NAME") == "A", "0")
            .when(col("PERIOD_NAME") == "Q1", "1")
            .when(col("PERIOD_NAME") == "Q2", "2")
            .when(col("PERIOD_NAME") == "Q3", "3")
            .when(col("PERIOD_NAME") == "Q4", "4")
            .otherwise(None).alias("Data_Point_Quarter"),
        lit("3").alias("Geography_Level"),
        lit(None).alias("Data_Point_Source"),
        col("SOURCE_MNEMONIC_TEXT").alias("Data_Point_Attribute"),
        col("DATA_ELEMENT_NAME").alias("Data_Point_Attribute_Name"),
        col("DATA_ELEMENT_DESCR").alias("Data_Point_Attribute_Short_Description"),
        col("VALUE_TEXT").alias("Data_Point_Value"),
        col("DB_DATA_TYPE").alias("Data_Point_Data_Type"),
        col("PERIOD_TYPE").alias("Data_Point_Period_Type"),
        when(col("PERIOD_NAME") == "A", "Annual")
            .when(col("PERIOD_NAME") == "Q1", "First Quarter")
            .when(col("PERIOD_NAME") == "Q2", "Second Quarter")
            .when(col("PERIOD_NAME") == "Q3", "Third Quarter")
            .when(col("PERIOD_NAME") == "Q4", "Fourth Quarter")
            .otherwise(None).alias("Data_Point_Period_Name"),
        col("PERIOD_END_DATE").cast("string").alias("Data_Point_Period_End_Date"),
        col("CREATE_DATETIME").alias("Start_Dttm"),
        when(col("LATEST_VALUE_FLAG") == "Y", lit("9999-12-31").cast("timestamp"))
            .otherwise(col("UPDATE_DATETIME")).alias("End_Dttm"),
        col("LATEST_VALUE_FLAG").cast("boolean").alias("Current_Ind"),
        lit(user).alias("Create_User_Id"),
        current_timestamp().alias("Create_Dttm"),
        lit(user).alias("Last_Update_User_Id"),
        lit(None).alias("Last_Update_Dttm"),
        lit(None).alias("Source_Filename")
)


    # Repartition for parallelism and write
    curated_df = curated_df.repartition(200)
    curated_df.write.format("delta").mode("append").saveAsTable(f"idf_curated_{env}.eds.t_eds_data_pnt")
    
    logger.info(f"County level data loaded successfully for environment: {env}")


def load_country_level_data(env: str, user: str = "dop_user"):
    """
    Load Country level EDS data from FinMaster to curated layer
    
    Args:
        env: Environment (dev, qa, prod)
        user: User ID for audit fields
    """
    logger.info(f"Loading Country level data for environment: {env}")
    spark = get_spark_session()
    
    # Delete existing Country data before loading
    logger.info("Deleting existing Country level data...")
    spark.sql(f"""
        DELETE FROM idf_curated_{env}.eds.t_eds_data_pnt 
        WHERE Geography_Type = 'COUNTRY'
    """)
    logger.info("Existing Country level data deleted successfully")
    
    # Run the FinMaster SQL query
    finmaster_df = spark.sql(f"""
    SELECT ENTITY_ID_TEXT, PERIOD_END_DATE, PERIOD_NAME, PERIOD_TYPE, SOURCE_MNEMONIC_TEXT, DATA_ELEMENT_NAME, DATA_ELEMENT_DESCR, DB_DATA_TYPE, DATA_UNIT_TYPE, VALUE_TEXT, X.CREATE_DATETIME,X.UPDATE_DATETIME, X.LATEST_VALUE_FLAG, YEAR FROM
    (SELECT /*+ PARALLEL (10) */ ENTITY_ID_TEXT,DPD.PERIOD_END_DATE,DPD.SUB_SOURCE_NAME,
    DDP.ACCOUNTING_STANDARD_NAME, DDP.ACCOUNTING_BASIS_NAME, 
    DDP.PERIOD_NAME, DDP.PERIOD_TYPE,DDP.DATASET_CONTEXT_NAME, DDP.CURRENCY_ISO_CODE, 
    DDP.CONFIDENTIAL_FLAG, DDP.NUMBER_OF_MONTHS_IN_PERIOD, DDP.NUMBER_OF_WEEKS_IN_PERIOD, DDP.AUDIT_STATUS,FDP.SOURCE_DATA_ELEMENT_ID, FDP.CREATE_DTIME as CREATE_DATETIME, FDP.NOT_LATEST_IN_DATASET_DTIME as UPDATE_DATETIME, FDP.LATEST_IN_DATASET_FLAG as LATEST_VALUE_FLAG,
    DSDE.UNIQUE_MNEMONIC_TEXT,DSDE.SOURCE_MNEMONIC_TEXT,DSDE.DATA_ELEMENT_NAME,DSDE.DATA_ELEMENT_DESCR,DSDE.DB_DATA_TYPE,DSDE.DATA_UNIT_TYPE,VALUE_TEXT, EXTRACT(YEAR FROM fdp.PERIOD_END_DATE) as YEAR
    FROM idf_{env}.finmaster.t_dim_DATA_SOURCE_ENTITY DDSE, idf_{env}.finmaster.t_dim_PERIOD_DATASET DPD, idf_{env}.finmaster.t_dim_DATASET_PROFILE DDP,idf_{env}.finmaster.t_FACT_DATA_POINT FDP,idf_{env}.finmaster.t_dim_SOURCE_DATA_ELEMENT DSDE
    WHERE 1=1
    AND DDSE.FM_DATA_SOURCE_ID='6'
    AND DDSE.DATA_SOURCE_ENTITY_ID=DPD.DATA_SOURCE_ENTITY_ID
    AND DPD.FM_DATA_SOURCE_ID='6'
    AND DPD.LATEST_IN_CONTEXT_FLAG='Y'
    AND DPD.PERIOD_END_DATE >=TO_DATE('01/01/2013','MM/dd/yyyy')
    AND DPD.EXPIRY_DTIME=TO_DATE('12/31/9999','MM/dd/yyyy')
    AND DPD.DATASET_PROFILE_ID=DDP.DATASET_PROFILE_ID
    AND FDP.FM_DATA_SOURCE_ID='6'
    AND FDP.AUDIT_ID='6'
    AND DPD.PERIOD_DATASET_ID=FDP.PERIOD_DATASET_ID
    AND DPD.PERIOD_END_DATE=FDP.PERIOD_END_DATE
    AND DSDE.FM_DATA_SOURCE_ID='6'
    AND FDP.SOURCE_DATA_ELEMENT_ID=DSDE.SOURCE_DATA_ELEMENT_ID
    AND ENTITY_ID_TEXT='00') X,
    (SELECT * FROM idf_{env}.EDS.t_EDS_STATE WHERE 1=1
    AND STATE_FIPS_CODE='00'
    AND STATE_FIPS_CODE IN
    (SELECT ENTITY_ID_TEXT FROM idf_{env}.finmaster.t_dim_DATA_SOURCE_ENTITY
    WHERE 1=1
    AND FM_DATA_SOURCE_ID=6)) Y
    WHERE 1=1
    AND X.ENTITY_ID_TEXT=Y.STATE_FIPS_CODE
    AND PERIOD_END_DATE >=TO_DATE('01/01/2013','MM/dd/yyyy')
    ORDER BY 1,2
    """)

    # Transform to curated schema
    curated_df = finmaster_df.select(
        col("ENTITY_ID_TEXT").alias("Geography_Unit_Code"),
        lit("COUNTRY").alias("Geography_Type"),
        lit("United States").alias("Country_Name"),
        lit(None).alias("County_FIPS_Code"),
        lit(None).alias("County_Name"),
        lit(None).alias("State_FIPS_Code"),
        lit(None).alias("State_Name"),
        lit(None).alias("Core_Based_Statistical_Area_Code"),
        lit(None).alias("Core_Based_Statistical_Area_Name"),
        lit(None).alias("Minor_Civil_Division_Code"),
        lit(None).alias("Minor_Civil_Division_Name"),
        lit(None).alias("Place_Code"),
        lit(None).alias("Place_Name"),
        lit(None).alias("School_District_Code"),
        lit(None).alias("School_District_Name"),
        lit(None).alias("Longitude"),
        lit(None).alias("Latitude"),
        lit("Manual").alias("Reference_Data_Source"),
        col("YEAR").cast("string").alias("Data_Point_Year"),
        when(col("PERIOD_NAME") == "A", "0")
            .when(col("PERIOD_NAME") == "Q1", "1")
            .when(col("PERIOD_NAME") == "Q2", "2")
            .when(col("PERIOD_NAME") == "Q3", "3")
            .when(col("PERIOD_NAME") == "Q4", "4")
            .otherwise(None).alias("Data_Point_Quarter"),
        lit("1").alias("Geography_Level"),
        lit(None).alias("Data_Point_Source"),
        col("SOURCE_MNEMONIC_TEXT").alias("Data_Point_Attribute"),
        col("DATA_ELEMENT_NAME").alias("Data_Point_Attribute_Name"),
        col("DATA_ELEMENT_DESCR").alias("Data_Point_Attribute_Short_Description"),
        col("VALUE_TEXT").alias("Data_Point_Value"),
        col("DB_DATA_TYPE").alias("Data_Point_Data_Type"),
        col("PERIOD_TYPE").alias("Data_Point_Period_Type"),
        when(col("PERIOD_NAME") == "A", "Annual")
            .when(col("PERIOD_NAME") == "Q1", "First Quarter")
            .when(col("PERIOD_NAME") == "Q2", "Second Quarter")
            .when(col("PERIOD_NAME") == "Q3", "Third Quarter")
            .when(col("PERIOD_NAME") == "Q4", "Fourth Quarter")
            .otherwise(None).alias("Data_Point_Period_Name"),
        col("PERIOD_END_DATE").cast("string").alias("Data_Point_Period_End_Date"),
        col("CREATE_DATETIME").alias("Start_Dttm"),
        when(col("LATEST_VALUE_FLAG") == "Y", lit("9999-12-31").cast("timestamp"))
            .otherwise(col("UPDATE_DATETIME")).alias("End_Dttm"),
        col("LATEST_VALUE_FLAG").cast("boolean").alias("Current_Ind"),
        lit(user).alias("Create_User_Id"),
        current_timestamp().alias("Create_Dttm"),
        lit(user).alias("Last_Update_User_Id"),
        lit(None).alias("Last_Update_Dttm"),
        lit("zero_day_load").alias("Source_Filename")
    )

    # Repartition for parallelism and write
    curated_df = curated_df.repartition(200)
    curated_df.write.format("delta").mode("append").saveAsTable(f"idf_curated_{env}.eds.t_eds_data_pnt")
    
    logger.info(f"Country level data loaded successfully for environment: {env}")


def load_state_level_data(env: str, user: str = "dop_user"):
    """
    Load State level EDS data from FinMaster to curated layer
    
    Args:
        env: Environment (dev, qa, prod)
        user: User ID for audit fields
    """
    logger.info(f"Loading State level data for environment: {env}")
    spark = get_spark_session()
    
    # Delete existing State data before loading
    logger.info("Deleting existing State level data...")
    spark.sql(f"""
        DELETE FROM idf_curated_{env}.eds.t_eds_data_pnt 
        WHERE Geography_Type = 'STATE'
    """)
    logger.info("Existing State level data deleted successfully")
    
    # Run the FinMaster SQL query
    finmaster_df = spark.sql(f"""
    SELECT ENTITY_ID_TEXT, PERIOD_END_DATE, PERIOD_NAME, PERIOD_TYPE, SOURCE_MNEMONIC_TEXT, DATA_ELEMENT_NAME, DATA_ELEMENT_DESCR, DB_DATA_TYPE, DATA_UNIT_TYPE, VALUE_TEXT, X.CREATE_DATETIME,X.UPDATE_DATETIME, X.LATEST_VALUE_FLAG, YEAR, STATE_NAME FROM
    (SELECT /*+ PARALLEL (10) */ ENTITY_ID_TEXT,DPD.PERIOD_END_DATE,DPD.SUB_SOURCE_NAME,
    DDP.ACCOUNTING_STANDARD_NAME, DDP.ACCOUNTING_BASIS_NAME, 
    DDP.PERIOD_NAME, DDP.PERIOD_TYPE,DDP.DATASET_CONTEXT_NAME, DDP.CURRENCY_ISO_CODE, 
    DDP.CONFIDENTIAL_FLAG, DDP.NUMBER_OF_MONTHS_IN_PERIOD, DDP.NUMBER_OF_WEEKS_IN_PERIOD, DDP.AUDIT_STATUS,FDP.SOURCE_DATA_ELEMENT_ID,
    DSDE.UNIQUE_MNEMONIC_TEXT,DSDE.SOURCE_MNEMONIC_TEXT,DSDE.DATA_ELEMENT_NAME,DSDE.DATA_ELEMENT_DESCR,DSDE.DB_DATA_TYPE,DSDE.DATA_UNIT_TYPE,VALUE_TEXT, FDP.CREATE_DTIME as CREATE_DATETIME, FDP.NOT_LATEST_IN_DATASET_DTIME as UPDATE_DATETIME, FDP.LATEST_IN_DATASET_FLAG as LATEST_VALUE_FLAG, EXTRACT(YEAR FROM fdp.PERIOD_END_DATE) as YEAR
    FROM idf_{env}.finmaster.t_dim_DATA_SOURCE_ENTITY DDSE, idf_{env}.finmaster.t_dim_PERIOD_DATASET DPD, idf_{env}.finmaster.t_dim_DATASET_PROFILE DDP,idf_{env}.finmaster.t_FACT_DATA_POINT FDP,idf_{env}.finmaster.t_dim_SOURCE_DATA_ELEMENT DSDE
    WHERE 1=1
    AND DDSE.FM_DATA_SOURCE_ID='6'
    AND DDSE.DATA_SOURCE_ENTITY_ID=DPD.DATA_SOURCE_ENTITY_ID
    AND DPD.FM_DATA_SOURCE_ID='6'
    AND DPD.LATEST_IN_CONTEXT_FLAG='Y'
    AND DPD.PERIOD_END_DATE >=TO_DATE('01/01/2013','MM/dd/yyyy')
    AND DPD.EXPIRY_DTIME=TO_DATE('12/31/9999','MM/dd/yyyy')
    AND DPD.DATASET_PROFILE_ID=DDP.DATASET_PROFILE_ID
    AND FDP.FM_DATA_SOURCE_ID='6'
    AND FDP.AUDIT_ID='6'
    AND DPD.PERIOD_DATASET_ID=FDP.PERIOD_DATASET_ID
    AND DPD.PERIOD_END_DATE=FDP.PERIOD_END_DATE
    AND DSDE.FM_DATA_SOURCE_ID='6'
    AND FDP.SOURCE_DATA_ELEMENT_ID=DSDE.SOURCE_DATA_ELEMENT_ID
    AND ENTITY_ID_TEXT!='00'
    AND 1=1) X,
    (SELECT * FROM idf_{env}.EDS.t_EDS_STATE WHERE 1=1
    AND STATE_FIPS_CODE!='00'
    AND STATE_FIPS_CODE IN
    (SELECT ENTITY_ID_TEXT FROM idf_{env}.finmaster.t_dim_DATA_SOURCE_ENTITY
    WHERE 1=1
    AND FM_DATA_SOURCE_ID=6)) Y
    WHERE 1=1
    AND X.ENTITY_ID_TEXT=Y.STATE_FIPS_CODE
    AND PERIOD_END_DATE >=TO_DATE('01/01/2013','MM/dd/yyyy')
    """)

    # Transform to curated schema
    curated_df = finmaster_df.select(
        col("ENTITY_ID_TEXT").alias("Geography_Unit_Code"),
        lit("STATE").alias("Geography_Type"),
        lit("United States").alias("Country_Name"),
        lit(None).alias("County_FIPS_Code"),
        lit(None).alias("County_Name"),
        col("ENTITY_ID_TEXT").alias("State_FIPS_Code"),
        col("STATE_NAME").alias("State_Name"),
        lit(None).alias("Core_Based_Statistical_Area_Code"),
        lit(None).alias("Core_Based_Statistical_Area_Name"),
        lit(None).alias("Minor_Civil_Division_Code"),
        lit(None).alias("Minor_Civil_Division_Name"),
        lit(None).alias("Place_Code"),
        lit(None).alias("Place_Name"),
        lit(None).alias("School_District_Code"),
        lit(None).alias("School_District_Name"),
        lit(None).alias("Longitude"),
        lit(None).alias("Latitude"),
        lit("Manual").alias("Reference_Data_Source"),
        col("YEAR").cast("string").alias("Data_Point_Year"),
        when(col("PERIOD_NAME") == "A", "0")
            .when(col("PERIOD_NAME") == "Q1", "1")
            .when(col("PERIOD_NAME") == "Q2", "2")
            .when(col("PERIOD_NAME") == "Q3", "3")
            .when(col("PERIOD_NAME") == "Q4", "4")
            .otherwise(None).alias("Data_Point_Quarter"),
        lit("2").alias("Geography_Level"),
        lit(None).alias("Data_Point_Source"),
        col("SOURCE_MNEMONIC_TEXT").alias("Data_Point_Attribute"),
        col("DATA_ELEMENT_NAME").alias("Data_Point_Attribute_Name"),
        col("DATA_ELEMENT_DESCR").alias("Data_Point_Attribute_Short_Description"),
        col("VALUE_TEXT").alias("Data_Point_Value"),
        col("DB_DATA_TYPE").alias("Data_Point_Data_Type"),
        col("PERIOD_TYPE").alias("Data_Point_Period_Type"),
        when(col("PERIOD_NAME") == "A", "Annual")
            .when(col("PERIOD_NAME") == "Q1", "First Quarter")
            .when(col("PERIOD_NAME") == "Q2", "Second Quarter")
            .when(col("PERIOD_NAME") == "Q3", "Third Quarter")
            .when(col("PERIOD_NAME") == "Q4", "Fourth Quarter")
            .otherwise(None).alias("Data_Point_Period_Name"),
        col("PERIOD_END_DATE").cast("string").alias("Data_Point_Period_End_Date"),
        col("CREATE_DATETIME").alias("Start_Dttm"),
        when(col("LATEST_VALUE_FLAG") == "Y", lit("9999-12-31").cast("timestamp"))
            .otherwise(col("UPDATE_DATETIME")).alias("End_Dttm"),
        col("LATEST_VALUE_FLAG").cast("boolean").alias("Current_Ind"),
        lit(user).alias("Create_User_Id"),
        current_timestamp().alias("Create_Dttm"),
        lit(user).alias("Last_Update_User_Id"),
        lit(None).alias("Last_Update_Dttm"),
        lit("zero_day_load").alias("Source_Filename")
    )

    # Repartition for parallelism and write
    curated_df = curated_df.repartition(200)
    curated_df.write.format("delta").mode("append").saveAsTable(f"idf_curated_{env}.eds.t_eds_data_pnt")
    
    logger.info(f"State level data loaded successfully for environment: {env}")


def load_school_district_level_data(env: str, user: str = "dop_user"):
    """
    Load School District level EDS data from FinMaster to curated layer
    
    Args:
        env: Environment (dev, qa, prod)
        user: User ID for audit fields
    """
    logger.info(f"Loading School District level data for environment: {env}")
    spark = get_spark_session()
    
    # Delete existing School District data before loading
    logger.info("Deleting existing School District level data...")
    spark.sql(f"""
        DELETE FROM idf_curated_{env}.eds.t_eds_data_pnt 
        WHERE Geography_Type = 'SCHOOL DISTRICT'
    """)
    logger.info("Existing School District level data deleted successfully")
    
    # Run the FinMaster SQL query
    finmaster_df = spark.sql(f"""
    SELECT ENTITY_ID_TEXT, PERIOD_END_DATE, PERIOD_NAME, PERIOD_TYPE, SOURCE_MNEMONIC_TEXT, DATA_ELEMENT_NAME, DATA_ELEMENT_DESCR, DB_DATA_TYPE, DATA_UNIT_TYPE, VALUE_TEXT, X.CREATE_DATETIME,X.UPDATE_DATETIME, X.LATEST_VALUE_FLAG, YEAR, DOMINANT_COUNTY_FIPS_CODE as COUNTY_FIPS_CODE, DOMINANT_STATE_FIPS_CODE as STATE_FIPS_CODE, DOMINANT_CORE_BASED_SAC as CBS_CODE, SCHOOL_DISTRICT_NAME, county_name, state_name, CBS_AREA_NAME, SOURCE_FILENAME
    FROM
    (SELECT /*+ PARALLEL (10) */ ENTITY_ID_TEXT,DPD.PERIOD_END_DATE,DPD.SUB_SOURCE_NAME,
    DDP.ACCOUNTING_STANDARD_NAME, DDP.ACCOUNTING_BASIS_NAME, 
    DDP.PERIOD_NAME, DDP.PERIOD_TYPE,DDP.DATASET_CONTEXT_NAME, DDP.CURRENCY_ISO_CODE, 
    DDP.CONFIDENTIAL_FLAG, DDP.NUMBER_OF_MONTHS_IN_PERIOD, DDP.NUMBER_OF_WEEKS_IN_PERIOD, DDP.AUDIT_STATUS,FDP.SOURCE_DATA_ELEMENT_ID,
    DSDE.UNIQUE_MNEMONIC_TEXT,DSDE.SOURCE_MNEMONIC_TEXT,DSDE.DATA_ELEMENT_NAME,DSDE.DATA_ELEMENT_DESCR,DSDE.DB_DATA_TYPE,DSDE.DATA_UNIT_TYPE,VALUE_TEXT, FDP.CREATE_DTIME as CREATE_DATETIME, FDP.NOT_LATEST_IN_DATASET_DTIME as UPDATE_DATETIME, FDP.LATEST_IN_DATASET_FLAG as LATEST_VALUE_FLAG, EXTRACT(YEAR FROM fdp.PERIOD_END_DATE) as YEAR
    FROM idf_{env}.finmaster.t_dim_DATA_SOURCE_ENTITY DDSE, idf_{env}.finmaster.t_dim_PERIOD_DATASET DPD, idf_{env}.finmaster.t_dim_DATASET_PROFILE DDP,idf_{env}.finmaster.t_FACT_DATA_POINT FDP,idf_{env}.finmaster.t_dim_SOURCE_DATA_ELEMENT DSDE
    WHERE 1=1
    AND DDSE.FM_DATA_SOURCE_ID='6'
    AND DDSE.DATA_SOURCE_ENTITY_ID=DPD.DATA_SOURCE_ENTITY_ID
    AND DPD.FM_DATA_SOURCE_ID='6'
    AND DPD.LATEST_IN_CONTEXT_FLAG='Y'
    AND DPD.PERIOD_END_DATE >=TO_DATE('01/01/2013','MM/dd/yyyy')
    AND DPD.EXPIRY_DTIME=TO_DATE('12/31/9999','MM/dd/yyyy')
    AND DPD.DATASET_PROFILE_ID=DDP.DATASET_PROFILE_ID
    AND FDP.FM_DATA_SOURCE_ID='6'
    AND FDP.AUDIT_ID='6'
    AND DPD.PERIOD_DATASET_ID=FDP.PERIOD_DATASET_ID
    AND DPD.PERIOD_END_DATE=FDP.PERIOD_END_DATE
    AND DSDE.FM_DATA_SOURCE_ID='6'
    AND FDP.SOURCE_DATA_ELEMENT_ID=DSDE.SOURCE_DATA_ELEMENT_ID
    AND 1=1) X,
    (SELECT
        scd.*,
        county.county_name,
        county.state_name,
        county.CBS_AREA_NAME
    FROM idf_{env}.EDS.t_EDS_SCD scd
    LEFT JOIN idf_{env}.EDS.t_EDS_COUNTY county
        ON scd.DOMINANT_COUNTY_FIPS_CODE = county.FIPS_COUNTY_CODE
        AND county.LATEST_VALUE_FLAG = 'Y'
    WHERE scd.LATEST_VALUE_FLAG = 'Y'
      AND scd.ACTION IN ('INSERT', 'UPDATE')
      AND scd.SCHOOL_DISTRICT_CODE IN (
            SELECT ENTITY_ID_TEXT
            FROM idf_{env}.finmaster.t_dim_DATA_SOURCE_ENTITY
            WHERE FM_DATA_SOURCE_ID = 6)) Y
    WHERE 1=1
    AND X.ENTITY_ID_TEXT=Y.SCHOOL_DISTRICT_CODE
    AND PERIOD_END_DATE >=TO_DATE('12/31/2013','MM/dd/yyyy')
    """)

    # Transform to curated schema
    curated_df = finmaster_df.select(
        col("ENTITY_ID_TEXT").alias("Geography_Unit_Code"),
        lit("SCHOOL DISTRICT").alias("Geography_Type"),
        lit("United States").alias("Country_Name"),
        col("COUNTY_FIPS_CODE").alias("County_FIPS_Code"),
        col("county_name").alias("County_Name"),
        col("STATE_FIPS_CODE").alias("State_FIPS_Code"),
        col("state_name").alias("State_Name"),
        col("CBS_CODE").alias("Core_Based_Statistical_Area_Code"),
        col("CBS_AREA_NAME").alias("Core_Based_Statistical_Area_Name"),
        lit(None).alias("Minor_Civil_Division_Code"),
        lit(None).alias("Minor_Civil_Division_Name"),
        lit(None).alias("Place_Code"),
        lit(None).alias("Place_Name"),
        col("ENTITY_ID_TEXT").alias("School_District_Code"),
        col("SCHOOL_DISTRICT_NAME").alias("School_District_Name"),
        lit(None).alias("Longitude"),
        lit(None).alias("Latitude"),
        col("SOURCE_FILENAME").alias("Reference_Data_Source"),
        col("YEAR").cast("string").alias("Data_Point_Year"),
        when(col("PERIOD_NAME") == "A", "0")
            .when(col("PERIOD_NAME") == "Q1", "1")
            .when(col("PERIOD_NAME") == "Q2", "2")
            .when(col("PERIOD_NAME") == "Q3", "3")
            .when(col("PERIOD_NAME") == "Q4", "4")
            .otherwise(None).alias("Data_Point_Quarter"),
        lit("9").alias("Geography_Level"),
        lit(None).alias("Data_Point_Source"),
        col("SOURCE_MNEMONIC_TEXT").alias("Data_Point_Attribute"),
        col("DATA_ELEMENT_NAME").alias("Data_Point_Attribute_Name"),
        col("DATA_ELEMENT_DESCR").alias("Data_Point_Attribute_Short_Description"),
        col("VALUE_TEXT").alias("Data_Point_Value"),
        col("DB_DATA_TYPE").alias("Data_Point_Data_Type"),
        col("PERIOD_TYPE").alias("Data_Point_Period_Type"),
        when(col("PERIOD_NAME") == "A", "Annual")
            .when(col("PERIOD_NAME") == "Q1", "First Quarter")
            .when(col("PERIOD_NAME") == "Q2", "Second Quarter")
            .when(col("PERIOD_NAME") == "Q3", "Third Quarter")
            .when(col("PERIOD_NAME") == "Q4", "Fourth Quarter")
            .otherwise(None).alias("Data_Point_Period_Name"),
        col("PERIOD_END_DATE").cast("string").alias("Data_Point_Period_End_Date"),
        col("CREATE_DATETIME").alias("Start_Dttm"),
        when(col("LATEST_VALUE_FLAG") == "Y", lit("9999-12-31").cast("timestamp"))
            .otherwise(col("UPDATE_DATETIME")).alias("End_Dttm"),
        col("LATEST_VALUE_FLAG").cast("boolean").alias("Current_Ind"),
        lit(user).alias("Create_User_Id"),
        current_timestamp().alias("Create_Dttm"),
        lit(user).alias("Last_Update_User_Id"),
        lit(None).alias("Last_Update_Dttm"),
        lit("zero_day_load").alias("Source_Filename")
    )

    # Repartition for parallelism and write
    curated_df = curated_df.repartition(200)
    curated_df.write.format("delta").mode("append").saveAsTable(f"idf_curated_{env}.eds.t_eds_data_pnt")
    
    logger.info(f"School District level data loaded successfully for environment: {env}")


def load_place_level_data(env: str, user: str = "dop_user"):
    """
    Load Place level EDS data from FinMaster to curated layer
    
    Args:
        env: Environment (dev, qa, prod)
        user: User ID for audit fields
    """
    logger.info(f"Loading Place level data for environment: {env}")
    spark = get_spark_session()
    
    # Delete existing Place data before loading
    logger.info("Deleting existing Place level data...")
    spark.sql(f"""
        DELETE FROM idf_curated_{env}.eds.t_eds_data_pnt 
        WHERE Geography_Type = 'PLACE'
    """)
    logger.info("Existing Place level data deleted successfully")
    
    # Run the FinMaster SQL query
    finmaster_df = spark.sql(f"""
    SELECT ENTITY_ID_TEXT, PERIOD_END_DATE, PERIOD_NAME, PERIOD_TYPE, SOURCE_MNEMONIC_TEXT, DATA_ELEMENT_NAME, DATA_ELEMENT_DESCR, DB_DATA_TYPE, DATA_UNIT_TYPE, VALUE_TEXT, X.CREATE_DATETIME,X.UPDATE_DATETIME, X.LATEST_VALUE_FLAG, YEAR, FIPS_COUNTY_CODE as COUNTY_FIPS_CODE, county_name, FIPS_STATE_CODE as STATE_FIPS_CODE, state_name, CBS_AREA_CODE as CBS_CODE,CBS_AREA_NAME, PLACE_NAME, SOURCE_FILENAME FROM
    (SELECT /*+ PARALLEL (10) */ ENTITY_ID_TEXT,DPD.PERIOD_END_DATE,DPD.SUB_SOURCE_NAME,
    DDP.ACCOUNTING_STANDARD_NAME, DDP.ACCOUNTING_BASIS_NAME, 
    DDP.PERIOD_NAME, DDP.PERIOD_TYPE,DDP.DATASET_CONTEXT_NAME, DDP.CURRENCY_ISO_CODE, 
    DDP.CONFIDENTIAL_FLAG, DDP.NUMBER_OF_MONTHS_IN_PERIOD, DDP.NUMBER_OF_WEEKS_IN_PERIOD, DDP.AUDIT_STATUS,FDP.SOURCE_DATA_ELEMENT_ID,
    DSDE.UNIQUE_MNEMONIC_TEXT,DSDE.SOURCE_MNEMONIC_TEXT,DSDE.DATA_ELEMENT_NAME,DSDE.DATA_ELEMENT_DESCR,DSDE.DB_DATA_TYPE,DSDE.DATA_UNIT_TYPE,VALUE_TEXT, FDP.CREATE_DTIME as CREATE_DATETIME, FDP.NOT_LATEST_IN_DATASET_DTIME as UPDATE_DATETIME, FDP.LATEST_IN_DATASET_FLAG as LATEST_VALUE_FLAG, EXTRACT(YEAR FROM fdp.PERIOD_END_DATE) as YEAR
    FROM idf_{env}.finmaster.t_dim_DATA_SOURCE_ENTITY DDSE, idf_{env}.finmaster.t_dim_PERIOD_DATASET DPD, idf_{env}.finmaster.t_dim_DATASET_PROFILE DDP,idf_{env}.finmaster.t_FACT_DATA_POINT FDP,idf_{env}.finmaster.t_dim_SOURCE_DATA_ELEMENT DSDE    WHERE 1=1
    AND DDSE.FM_DATA_SOURCE_ID='6'
    AND DDSE.DATA_SOURCE_ENTITY_ID=DPD.DATA_SOURCE_ENTITY_ID
    AND DPD.FM_DATA_SOURCE_ID='6'
    AND DPD.LATEST_IN_CONTEXT_FLAG='Y'
    AND DPD.PERIOD_END_DATE >=TO_DATE('01/01/2013','MM/dd/yyyy')
    AND DPD.EXPIRY_DTIME=TO_DATE('12/31/9999','MM/dd/yyyy')
    AND DPD.DATASET_PROFILE_ID=DDP.DATASET_PROFILE_ID
    AND FDP.FM_DATA_SOURCE_ID='6'
    AND FDP.AUDIT_ID='6'
    AND DPD.PERIOD_DATASET_ID=FDP.PERIOD_DATASET_ID
    AND DPD.PERIOD_END_DATE=FDP.PERIOD_END_DATE
    AND DSDE.FM_DATA_SOURCE_ID='6'
    AND FDP.SOURCE_DATA_ELEMENT_ID=DSDE.SOURCE_DATA_ELEMENT_ID
    AND 1=1) X,
    (SELECT * FROM idf_{env}.EDS.t_EDS_PLACE WHERE 1=1
    AND PLACE_CODE IN
    (SELECT ENTITY_ID_TEXT FROM idf_{env}.finmaster.t_dim_DATA_SOURCE_ENTITY
    WHERE 1=1
    AND FM_DATA_SOURCE_ID=6) 
    AND LATEST_VALUE_FLAG='Y'
    AND ACTION IN ('INSERT','UPDATE')) Y
    WHERE 1=1
    AND X.ENTITY_ID_TEXT=Y.PLACE_CODE
    AND PERIOD_END_DATE >=TO_DATE('01/01/2013','MM/dd/yyyy')
    """)

    # Transform to curated schema
    curated_df = finmaster_df.select(
        col("ENTITY_ID_TEXT").alias("Geography_Unit_Code"),
        lit("PLACE").alias("Geography_Type"),
        lit("United States").alias("Country_Name"),
        col("COUNTY_FIPS_CODE").alias("County_FIPS_Code"),
        col("county_name").alias("County_Name"),
        col("STATE_FIPS_CODE").alias("State_FIPS_Code"),
        col("state_name").alias("State_Name"),
        col("CBS_CODE").alias("Core_Based_Statistical_Area_Code"),
        col("CBS_AREA_NAME").alias("Core_Based_Statistical_Area_Name"),
        lit(None).alias("Minor_Civil_Division_Code"),
        lit(None).alias("Minor_Civil_Division_Name"),
        col("ENTITY_ID_TEXT").alias("Place_Code"),
        col("PLACE_NAME").alias("Place_Name"),
        lit(None).alias("School_District_Code"),
        lit(None).alias("School_District_Name"),
        lit(None).alias("Longitude"),
        lit(None).alias("Latitude"),
        col("SOURCE_FILENAME").alias("Reference_Data_Source"),
        col("YEAR").cast("string").alias("Data_Point_Year"),
        when(col("PERIOD_NAME") == "A", "0")
            .when(col("PERIOD_NAME") == "Q1", "1")
            .when(col("PERIOD_NAME") == "Q2", "2")
            .when(col("PERIOD_NAME") == "Q3", "3")
            .when(col("PERIOD_NAME") == "Q4", "4")
            .otherwise(None).alias("Data_Point_Quarter"),
        lit("5").alias("Geography_Level"),
        lit(None).alias("Data_Point_Source"),
        col("SOURCE_MNEMONIC_TEXT").alias("Data_Point_Attribute"),
        col("DATA_ELEMENT_NAME").alias("Data_Point_Attribute_Name"),
        col("DATA_ELEMENT_DESCR").alias("Data_Point_Attribute_Short_Description"),
        col("VALUE_TEXT").alias("Data_Point_Value"),
        col("DB_DATA_TYPE").alias("Data_Point_Data_Type"),
        col("PERIOD_TYPE").alias("Data_Point_Period_Type"),
        when(col("PERIOD_NAME") == "A", "Annual")
            .when(col("PERIOD_NAME") == "Q1", "First Quarter")
            .when(col("PERIOD_NAME") == "Q2", "Second Quarter")
            .when(col("PERIOD_NAME") == "Q3", "Third Quarter")
            .when(col("PERIOD_NAME") == "Q4", "Fourth Quarter")
            .otherwise(None).alias("Data_Point_Period_Name"),
        col("PERIOD_END_DATE").cast("string").alias("Data_Point_Period_End_Date"),
        col("CREATE_DATETIME").alias("Start_Dttm"),
        when(col("LATEST_VALUE_FLAG") == "Y", lit("9999-12-31").cast("timestamp"))
            .otherwise(col("UPDATE_DATETIME")).alias("End_Dttm"),
        col("LATEST_VALUE_FLAG").cast("boolean").alias("Current_Ind"),
        lit(user).alias("Create_User_Id"),
        current_timestamp().alias("Create_Dttm"),
        lit(user).alias("Last_Update_User_Id"),
        lit(None).alias("Last_Update_Dttm"),
        lit("zero_day_load").alias("Source_Filename")
    )

    # Repartition for parallelism and write
    curated_df = curated_df.repartition(200)
    curated_df.write.format("delta").mode("append").saveAsTable(f"idf_curated_{env}.eds.t_eds_data_pnt")
    
    logger.info(f"Place level data loaded successfully for environment: {env}")


def load_mcd_level_data(env: str, user: str = "dop_user"):
    """
    Load Minor Civil Division (MCD) level EDS data from FinMaster to curated layer
    
    Args:
        env: Environment (dev, qa, prod)
        user: User ID for audit fields
    """
    logger.info(f"Loading Minor Civil Division level data for environment: {env}")
    spark = get_spark_session()
    
    # Delete existing Minor Civil Division data before loading
    logger.info("Deleting existing Minor Civil Division level data...")
    spark.sql(f"""
        DELETE FROM idf_curated_{env}.eds.t_eds_data_pnt 
        WHERE Geography_Type = 'MINOR CIVIL DIVISION'
    """)
    logger.info("Existing Minor Civil Division level data deleted successfully")
    
    # Run the FinMaster SQL query
    finmaster_df = spark.sql(f"""
    SELECT ENTITY_ID_TEXT, PERIOD_END_DATE, PERIOD_NAME, PERIOD_TYPE, SOURCE_MNEMONIC_TEXT, DATA_ELEMENT_NAME, DATA_ELEMENT_DESCR, DB_DATA_TYPE, DATA_UNIT_TYPE, VALUE_TEXT, X.CREATE_DATETIME,X.UPDATE_DATETIME, X.LATEST_VALUE_FLAG, YEAR, FIPS_COUNTY_CODE as COUNTY_FIPS_CODE, county_name, FIPS_STATE_CODE as STATE_FIPS_CODE, state_name, CBS_AREA_CODE as CBS_CODE,CBS_AREA_NAME, PLACE_CODE ,PLACE_NAME, MINOR_CIVIL_DIVISION_NAME, SOURCE_FILENAME FROM
    (SELECT /*+ PARALLEL (10) */ ENTITY_ID_TEXT,DPD.PERIOD_END_DATE,DPD.SUB_SOURCE_NAME,
    DDP.ACCOUNTING_STANDARD_NAME, DDP.ACCOUNTING_BASIS_NAME, 
    DDP.PERIOD_NAME, DDP.PERIOD_TYPE,DDP.DATASET_CONTEXT_NAME, DDP.CURRENCY_ISO_CODE, 
    DDP.CONFIDENTIAL_FLAG, DDP.NUMBER_OF_MONTHS_IN_PERIOD, DDP.NUMBER_OF_WEEKS_IN_PERIOD, DDP.AUDIT_STATUS,FDP.SOURCE_DATA_ELEMENT_ID,
    DSDE.UNIQUE_MNEMONIC_TEXT,DSDE.SOURCE_MNEMONIC_TEXT,DSDE.DATA_ELEMENT_NAME,DSDE.DATA_ELEMENT_DESCR,DSDE.DB_DATA_TYPE,DSDE.DATA_UNIT_TYPE,VALUE_TEXT, FDP.CREATE_DTIME as CREATE_DATETIME, FDP.NOT_LATEST_IN_DATASET_DTIME as UPDATE_DATETIME, FDP.LATEST_IN_DATASET_FLAG as LATEST_VALUE_FLAG, EXTRACT(YEAR FROM fdp.PERIOD_END_DATE) as YEAR
    FROM idf_{env}.finmaster.t_dim_DATA_SOURCE_ENTITY DDSE, idf_{env}.finmaster.t_dim_PERIOD_DATASET DPD, idf_{env}.finmaster.t_dim_DATASET_PROFILE DDP,idf_{env}.finmaster.t_FACT_DATA_POINT FDP,idf_{env}.finmaster.t_dim_SOURCE_DATA_ELEMENT DSDE
    WHERE 1=1
    AND DDSE.FM_DATA_SOURCE_ID='6'
    AND DDSE.DATA_SOURCE_ENTITY_ID=DPD.DATA_SOURCE_ENTITY_ID
    AND DPD.FM_DATA_SOURCE_ID='6'
    AND DPD.LATEST_IN_CONTEXT_FLAG='Y'
    AND DPD.PERIOD_END_DATE >=TO_DATE('01/01/2013','MM/dd/yyyy')
    AND DPD.EXPIRY_DTIME=TO_DATE('12/31/9999','MM/dd/yyyy')
    AND DPD.DATASET_PROFILE_ID=DDP.DATASET_PROFILE_ID
    AND FDP.FM_DATA_SOURCE_ID='6'
    AND FDP.AUDIT_ID='6'
    AND DPD.PERIOD_DATASET_ID=FDP.PERIOD_DATASET_ID
    AND DPD.PERIOD_END_DATE=FDP.PERIOD_END_DATE
    AND DSDE.FM_DATA_SOURCE_ID='6'
    AND FDP.SOURCE_DATA_ELEMENT_ID=DSDE.SOURCE_DATA_ELEMENT_ID
    AND 1=1) X,
    (SELECT * FROM idf_{env}.EDS.t_EDS_MCD WHERE 1=1
    AND MINOR_CIVIL_DIVISION_CODE IN
    (SELECT ENTITY_ID_TEXT FROM idf_{env}.finmaster.t_dim_DATA_SOURCE_ENTITY
    WHERE 1=1
    AND FM_DATA_SOURCE_ID=6) 
    AND LATEST_VALUE_FLAG='Y'
    AND ACTION IN ('INSERT','UPDATE')) Y
    WHERE 1=1
    AND X.ENTITY_ID_TEXT=Y.MINOR_CIVIL_DIVISION_CODE
    AND PERIOD_END_DATE >=TO_DATE('01/01/2013','MM/dd/yyyy')
    """)

    # Transform to curated schema
    curated_df = finmaster_df.select(
        col("ENTITY_ID_TEXT").alias("Geography_Unit_Code"),
        lit("MINOR CIVIL DIVISION").alias("Geography_Type"),
        lit("United States").alias("Country_Name"),
        col("COUNTY_FIPS_CODE").alias("County_FIPS_Code"),
        col("county_name").alias("County_Name"),
        col("STATE_FIPS_CODE").alias("State_FIPS_Code"),
        col("state_name").alias("State_Name"),
        col("CBS_CODE").alias("Core_Based_Statistical_Area_Code"),
        col("CBS_AREA_NAME").alias("Core_Based_Statistical_Area_Name"),
        col("ENTITY_ID_TEXT").alias("Minor_Civil_Division_Code"),
        col("MINOR_CIVIL_DIVISION_NAME").alias("Minor_Civil_Division_Name"),
        col("PLACE_CODE").alias("Place_Code"),
        col("PLACE_NAME").alias("Place_Name"),
        lit(None).alias("School_District_Code"),
        lit(None).alias("School_District_Name"),
        lit(None).alias("Longitude"),
        lit(None).alias("Latitude"),
        col("SOURCE_FILENAME").alias("Reference_Data_Source"),
        col("YEAR").cast("string").alias("Data_Point_Year"),
        when(col("PERIOD_NAME") == "A", "0")
            .when(col("PERIOD_NAME") == "Q1", "1")
            .when(col("PERIOD_NAME") == "Q2", "2")
            .when(col("PERIOD_NAME") == "Q3", "3")
            .when(col("PERIOD_NAME") == "Q4", "4")
            .otherwise(None).alias("Data_Point_Quarter"),
        lit("4").alias("Geography_Level"),
        lit(None).alias("Data_Point_Source"),
        col("SOURCE_MNEMONIC_TEXT").alias("Data_Point_Attribute"),
        col("DATA_ELEMENT_NAME").alias("Data_Point_Attribute_Name"),
        col("DATA_ELEMENT_DESCR").alias("Data_Point_Attribute_Short_Description"),
        col("VALUE_TEXT").alias("Data_Point_Value"),
        col("DB_DATA_TYPE").alias("Data_Point_Data_Type"),
        col("PERIOD_TYPE").alias("Data_Point_Period_Type"),
        when(col("PERIOD_NAME") == "A", "Annual")
            .when(col("PERIOD_NAME") == "Q1", "First Quarter")
            .when(col("PERIOD_NAME") == "Q2", "Second Quarter")
            .when(col("PERIOD_NAME") == "Q3", "Third Quarter")
            .when(col("PERIOD_NAME") == "Q4", "Fourth Quarter")
            .otherwise(None).alias("Data_Point_Period_Name"),
        col("PERIOD_END_DATE").cast("string").alias("Data_Point_Period_End_Date"),
        col("CREATE_DATETIME").alias("Start_Dttm"),
        when(col("LATEST_VALUE_FLAG") == "Y", lit("9999-12-31").cast("timestamp"))
            .otherwise(col("UPDATE_DATETIME")).alias("End_Dttm"),
        col("LATEST_VALUE_FLAG").cast("boolean").alias("Current_Ind"),
        lit(user).alias("Create_User_Id"),
        current_timestamp().alias("Create_Dttm"),
        lit(user).alias("Last_Update_User_Id"),
        lit(None).alias("Last_Update_Dttm"),
        lit("zero_day_load").alias("Source_Filename")
    )

    # Repartition for parallelism and write
    curated_df = curated_df.repartition(200)
    curated_df.write.format("delta").mode("append").saveAsTable(f"idf_curated_{env}.eds.t_eds_data_pnt")
    
    logger.info(f"Minor Civil Division level data loaded successfully for environment: {env}")


def load_cbsa_level_data(env: str, user: str = "dop_user"):
    """
    Load Core Based Statistical Area (CBSA) level EDS data from FinMaster to curated layer

    Args:
        env: Environment (dev, qa, prod)
        user: User ID for audit fields
    """
    logger.info(f"Loading Core Based Statistical Area level data for environment: {env}")
    spark = get_spark_session()
    
    # Delete existing CBSA data before loading
    logger.info("Deleting existing CBSA level data...")
    spark.sql(f"""
        DELETE FROM idf_curated_{env}.eds.t_eds_data_pnt 
        WHERE Geography_Type = 'CBSA'
    """)
    logger.info("Existing CBSA level data deleted successfully")
    
    # Run the FinMaster SQL query
    finmaster_df = spark.sql(f"""
        SELECT ENTITY_ID_TEXT, PERIOD_END_DATE, PERIOD_NAME, PERIOD_TYPE, SOURCE_MNEMONIC_TEXT, DATA_ELEMENT_NAME, DATA_ELEMENT_DESCR, DB_DATA_TYPE, DATA_UNIT_TYPE, VALUE_TEXT, X.CREATE_DATETIME,X.UPDATE_DATETIME, X.LATEST_VALUE_FLAG, YEAR, FIPS_STATE_CODE, state_name, CBSNAME
        FROM
        (SELECT /*+ PARALLEL (10) */ ENTITY_ID_TEXT,DPD.PERIOD_END_DATE,DPD.SUB_SOURCE_NAME,
        DDP.ACCOUNTING_STANDARD_NAME, DDP.ACCOUNTING_BASIS_NAME, 
        DDP.PERIOD_NAME, DDP.PERIOD_TYPE,DDP.DATASET_CONTEXT_NAME, DDP.CURRENCY_ISO_CODE, 
        DDP.CONFIDENTIAL_FLAG, DDP.NUMBER_OF_MONTHS_IN_PERIOD, DDP.NUMBER_OF_WEEKS_IN_PERIOD, DDP.AUDIT_STATUS,FDP.SOURCE_DATA_ELEMENT_ID,
        DSDE.UNIQUE_MNEMONIC_TEXT,DSDE.SOURCE_MNEMONIC_TEXT,DSDE.DATA_ELEMENT_NAME,DSDE.DATA_ELEMENT_DESCR,DSDE.DB_DATA_TYPE,DSDE.DATA_UNIT_TYPE,VALUE_TEXT,
        FDP.CREATE_DTIME as CREATE_DATETIME, FDP.NOT_LATEST_IN_DATASET_DTIME as UPDATE_DATETIME, FDP.LATEST_IN_DATASET_FLAG as LATEST_VALUE_FLAG, EXTRACT(YEAR FROM fdp.PERIOD_END_DATE) as YEAR
        FROM idf_{env}.finmaster.t_dim_DATA_SOURCE_ENTITY DDSE, idf_{env}.finmaster.t_dim_PERIOD_DATASET DPD, idf_{env}.finmaster.t_dim_DATASET_PROFILE DDP,idf_{env}.finmaster.t_FACT_DATA_POINT FDP,idf_{env}.finmaster.t_dim_SOURCE_DATA_ELEMENT DSDE
        WHERE 1=1
        AND DDSE.FM_DATA_SOURCE_ID='6'
        AND DDSE.DATA_SOURCE_ENTITY_ID=DPD.DATA_SOURCE_ENTITY_ID
        AND DPD.FM_DATA_SOURCE_ID='6'
        AND DPD.LATEST_IN_CONTEXT_FLAG='Y'
        AND DPD.PERIOD_END_DATE >=TO_DATE('01/01/2013','MM/dd/yyyy')
        AND DPD.EXPIRY_DTIME=TO_DATE('12/31/9999','MM/dd/yyyy')
        AND DPD.DATASET_PROFILE_ID=DDP.DATASET_PROFILE_ID
        AND FDP.FM_DATA_SOURCE_ID='6'
        AND FDP.AUDIT_ID='6'
        AND DPD.PERIOD_DATASET_ID=FDP.PERIOD_DATASET_ID
        AND DPD.PERIOD_END_DATE=FDP.PERIOD_END_DATE
        AND DSDE.FM_DATA_SOURCE_ID='6'
        AND FDP.SOURCE_DATA_ELEMENT_ID=DSDE.SOURCE_DATA_ELEMENT_ID
        AND 1=1) X, --FM DATA
        (
        WITH raw AS (
            -- Your UNION query without MAX()
            SELECT DISTINCT CBS_AREA_CODE AS CBSID, CBS_AREA_NAME AS CBSNAME, FIPS_STATE_CODE, STATE_NAME
            FROM idf_{env}.EDS.t_EDS_COUNTY
            WHERE CBS_AREA_CODE IN (
                SELECT ENTITY_ID_TEXT FROM idf_{env}.finmaster.t_dim_DATA_SOURCE_ENTITY
                WHERE FM_DATA_SOURCE_ID = 6
            )
            AND LATEST_VALUE_FLAG = 'Y'
            AND ACTION IN ('INSERT','UPDATE')

            UNION

            SELECT DISTINCT CBS_AREA_CODE AS CBSID, CBS_AREA_NAME AS CBSNAME, FIPS_STATE_CODE, STATE_NAME
            FROM idf_{env}.EDS.t_EDS_MCD
            WHERE CBS_AREA_CODE IN (
                SELECT ENTITY_ID_TEXT FROM idf_{env}.finmaster.t_dim_DATA_SOURCE_ENTITY
                WHERE FM_DATA_SOURCE_ID = 6
            )
            AND LATEST_VALUE_FLAG = 'Y'
            AND ACTION IN ('INSERT','UPDATE')

            UNION

            SELECT DISTINCT CBS_AREA_CODE AS CBSID, CBS_AREA_NAME AS CBSNAME, FIPS_STATE_CODE, STATE_NAME
            FROM idf_{env}.EDS.t_EDS_PLACE
            WHERE CBS_AREA_CODE IN (
                SELECT ENTITY_ID_TEXT FROM idf_{env}.finmaster.t_dim_DATA_SOURCE_ENTITY
                WHERE FM_DATA_SOURCE_ID = 6
            )
            AND LATEST_VALUE_FLAG = 'Y'
            AND ACTION IN ('INSERT','UPDATE')

            UNION

            SELECT DISTINCT
                scd.DOMINANT_CORE_BASED_SAC AS CBSID,
                county.CBS_AREA_NAME AS CBSNAME,
                scd.DOMINANT_COUNTY_FIPS_CODE AS FIPS_STATE_CODE,
                county.STATE_NAME
            FROM idf_{env}.EDS.t_EDS_SCD scd
            LEFT JOIN idf_{env}.EDS.t_EDS_COUNTY county
                ON scd.DOMINANT_COUNTY_FIPS_CODE = county.FIPS_COUNTY_CODE
                AND county.LATEST_VALUE_FLAG = 'Y'
            WHERE scd.DOMINANT_CORE_BASED_SAC IN (
                SELECT ENTITY_ID_TEXT FROM idf_{env}.finmaster.t_dim_DATA_SOURCE_ENTITY
                WHERE FM_DATA_SOURCE_ID = 6
            )
            AND scd.LATEST_VALUE_FLAG = 'Y'
            AND scd.ACTION IN ('INSERT','UPDATE')
        ),
        ranked AS (
            SELECT CBSID, CBSNAME, FIPS_STATE_CODE, STATE_NAME,
                COUNT(*) OVER (PARTITION BY CBSID, CBSNAME) AS freq,
                ROW_NUMBER() OVER (PARTITION BY CBSID ORDER BY COUNT(*) OVER (PARTITION BY CBSID, CBSNAME) DESC) AS rn
            FROM raw
        )
        SELECT CBSID, CBSNAME, FIPS_STATE_CODE, STATE_NAME
        FROM ranked
        WHERE rn = 1
        ) Y
        WHERE 1=1
        AND X.ENTITY_ID_TEXT=Y.CBSID
        AND PERIOD_END_DATE >=TO_DATE('01/01/2013','MM/dd/yyyy')
        """)
    # Transform to curated schema
    curated_df = finmaster_df.select(
        concat_ws("_", col("ENTITY_ID_TEXT"), trim(col("FIPS_STATE_CODE"))).alias("Geography_Unit_Code"),
        lit("CBSA").alias("Geography_Type"),
        lit("United States").alias("Country_Name"),
        lit(None).alias("County_FIPS_Code"),
        lit(None).alias("County_Name"),
        col("FIPS_STATE_CODE").alias("State_FIPS_Code"),
        col("state_name").alias("State_Name"),
        col("ENTITY_ID_TEXT").alias("Core_Based_Statistical_Area_Code"),
        col("CBSNAME").alias("Core_Based_Statistical_Area_Name"),
        lit(None).alias("Minor_Civil_Division_Code"),
        lit(None).alias("Minor_Civil_Division_Name"),
        lit(None).alias("Place_Code"),
        lit(None).alias("Place_Name"),
        lit(None).alias("School_District_Code"),
        lit(None).alias("School_District_Name"),
        lit(None).alias("Longitude"),
        lit(None).alias("Latitude"),
        lit(None).alias("Reference_Data_Source"),
        col("YEAR").cast("string").alias("Data_Point_Year"),
        when(col("PERIOD_NAME") == "A", "0")
            .when(col("PERIOD_NAME") == "Q1", "1")
            .when(col("PERIOD_NAME") == "Q2", "2")
            .when(col("PERIOD_NAME") == "Q3", "3")
            .when(col("PERIOD_NAME") == "Q4", "4")
            .otherwise(None).alias("Data_Point_Quarter"),
        lit("6").alias("Geography_Level"),
        lit(None).alias("Data_Point_Source"),
        col("SOURCE_MNEMONIC_TEXT").alias("Data_Point_Attribute"),
        col("DATA_ELEMENT_NAME").alias("Data_Point_Attribute_Name"),
        col("DATA_ELEMENT_DESCR").alias("Data_Point_Attribute_Short_Description"),
        col("VALUE_TEXT").alias("Data_Point_Value"),
        col("DB_DATA_TYPE").alias("Data_Point_Data_Type"),
        col("PERIOD_TYPE").alias("Data_Point_Period_Type"),
        when(col("PERIOD_NAME") == "A", "Annual")
            .when(col("PERIOD_NAME") == "Q1", "First Quarter")
            .when(col("PERIOD_NAME") == "Q2", "Second Quarter")
            .when(col("PERIOD_NAME") == "Q3", "Third Quarter")
            .when(col("PERIOD_NAME") == "Q4", "Fourth Quarter")
            .otherwise(None).alias("Data_Point_Period_Name"),
        col("PERIOD_END_DATE").cast("string").alias("Data_Point_Period_End_Date"),
        col("CREATE_DATETIME").alias("Start_Dttm"),
        when(col("LATEST_VALUE_FLAG") == "Y", lit("9999-12-31").cast("timestamp"))
            .otherwise(col("UPDATE_DATETIME")).alias("End_Dttm"),
        col("LATEST_VALUE_FLAG").cast("boolean").alias("Current_Ind"),
        lit(user).alias("Create_User_Id"),
        current_timestamp().alias("Create_Dttm"),
        lit(user).alias("Last_Update_User_Id"),
        lit(None).alias("Last_Update_Dttm"),
        lit("zero_day_load").alias("Source_Filename")
    )


    # Repartition for parallelism and write
    curated_df = curated_df.repartition(200)
    curated_df.write.format("delta").mode("append").saveAsTable(f"idf_curated_{env}.eds.t_eds_data_pnt")
    
    logger.info(f"Minor Civil Division level data loaded successfully for environment: {env}")

def optimize_and_vacuum_table(env: str):
    spark = get_spark_session()
    table_name = f"idf_curated_{env}.eds.t_eds_data_pnt"
    spark.sql(f"OPTIMIZE {table_name}")
    logger.info(f"OPTIMIZE completed for table: {table_name}")
    spark.sql(f"VACUUM {table_name}")
    logger.info(f"VACUUM completed for table: {table_name}")

def main(env: str = "dev", user: str = "dop_user", load_types: list = None):
    """
    Main function to orchestrate EDS Zero Day data loading for all geography levels
    
    Args:
        env: Environment (dev, qa, prod)
        user: User ID for audit fields
        load_types: List of geography types to load. If None, loads all.
                   Valid values: ['county', 'country', 'state', 'school_district', 'place', 'mcd']
    """
    logger.info(f"=== Starting EDS Zero Day Load for environment: {env} ===")
    
    # If load_types not provided, load all
    if load_types is None:
        load_types = ['county', 'country', 'state', 'school_district', 'place', 'mcd', 'cbsa']
    
    logger.info(f"Geography types to load: {', '.join(load_types)}")
    
    try:
        # Load geography levels based on load_types
        if 'county' in load_types:
            load_county_level_data(env, user)
        
        if 'country' in load_types:
            load_country_level_data(env, user)
        
        if 'state' in load_types:
            load_state_level_data(env, user)
        
        if 'school_district' in load_types:
            load_school_district_level_data(env, user)
        
        if 'place' in load_types:
            load_place_level_data(env, user)
        
        if 'mcd' in load_types:
            load_mcd_level_data(env, user)
            
        if 'cbsa' in load_types:
            load_cbsa_level_data(env, user)
        
        optimize_and_vacuum_table(env)
        
        logger.info(f"=== EDS Zero Day Load completed successfully for environment: {env} ===")
        
    except Exception as e:
        logger.error(f"EDS Zero Day Load failed: {str(e)}")
        raise e


    
    
def load_eds_zero_day(env: str = "dev", 
                      user_name: str = "system", load_types: list = None):

    main(env, user_name, load_types)