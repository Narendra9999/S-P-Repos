import logging
import sys
from pyspark.sql import functions as F
from typing import List

logging.basicConfig(stream=sys.stdout, level=logging.INFO)
logger = logging.getLogger(__name__)
import uuid
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, lit, current_timestamp, when
from apd_ingestion.constants.enum_vars import EdsStatus

class StatusTableUtil:
    def __init__(self, table_name: str):
        self.spark = get_spark_session()
        self.table_name = table_name

    def insert_status(self, FILENAME, SOURCE_FILETYPE, status=EdsStatus.RAW_LOADED.value):
        data = [(FILENAME, SOURCE_FILETYPE, status)]
        columns = [ "FILENAME", "FILETYPE", "status"]
        df = self.spark.createDataFrame(data, columns).withColumn("CREATE_DATETIME", current_timestamp())
        df.write.format("delta").mode("append").saveAsTable(self.table_name)

    def update_status(self, FILENAME, new_status):
        df = self.spark.table(self.table_name)
        updated_df = df.withColumn("status", 
                                   when(col("FILENAME") == FILENAME, lit(new_status)).otherwise(col("status")))
        updated_df.write.format("delta").mode("overwrite").saveAsTable(self.table_name)

    def is_file_loaded(self, FILENAME, status=EdsStatus.RAW_LOADED.value):
        df = self.spark.table(self.table_name)
        return df.filter((col("FILENAME") == FILENAME) & (col("status") == status)).count() > 0

    def get_latest_file(self, file_type: str) -> List[str]:
        """
        Returns the filename with the latest CREATE_DATETIME for the given file_type.
        
        Args:
            file_type: The type of file to search for
            
        Returns:
            List containing one filename (for consistency with other methods),
            or empty list if no files found
        """
        df = self.spark.table(self.table_name)
        
        # Get the row with maximum CREATE_DATETIME for this file type
        result = df.filter(col("FILETYPE") == file_type).orderBy(col("CREATE_DATETIME").desc()).select("FILENAME").first()
        if result is None:
            logger.error(f"No files found for FILETYPE: {file_type}")
            raise ValueError(f"No files found for FILETYPE: {file_type}")
        
        return [result["FILENAME"]]

class ProcessTableUtil:
    def __init__(self, table_name: str, user: str):
        self.spark = get_spark_session()
        self.table_name = table_name
        self.user = user

    def insert_batch_process_status_started(self, process_id, run_type, 
                                          status="STARTED", process_name=None):
        """
        Insert a new batch process status record with STARTED status
        
        Args:
            process_id: Unique process identifier
            run_type: Type of run (BATCH, FINANALYTIC_STREAM, USPF_STREAM)
            status: Process status (default: "STARTED")
            process_name: Optional process name (default: "EDS_{run_type}_PROCESS")
            table_name: Optional table name (default: "eds_tables")
        """
        # Set default values if not provided
        if process_name is None:
            process_name = f"EDS_{run_type}_PROCESS"
            
        self.spark.sql(f"""
            INSERT INTO {self.table_name} (
                PROCESS_ID, TABLE_NAME, RUN_TYPE, FILE_TIMESTAMP, STATUS,
                PROCESS_STARTTIME, PROCESS_ENDTIME, ERROR, THRESHOLD,
                CREATE_DATE, CREATE_BY, UPDATE_DATE, UPDATE_BY, PROCESS_NAME, LAST_PROCESSED_DTTM
            )
            VALUES (
                '{process_id}', 'eds_tables', '{run_type}', current_timestamp(), '{status}',
                current_timestamp(), NULL, NULL, NULL,
                current_timestamp(), '{self.user}', current_timestamp(), '{self.user}', '{process_name}', current_timestamp()
            )
        """)
        
        logger.info(f"Inserted batch process status: {process_name} - {status} for process_id: {process_id} by user: {self.user}")

    def update_batch_process_status(self, process_id, status, run_type, error_message=None):
        """
        Update an existing batch process status record
        
        Args:
            process_id: Unique process identifier to update
            status: New process status (e.g., "COMPLETED", "FAILED", "IN_PROGRESS")
            error_message: Optional error message (default: None)
        """
        if error_message is not None:
            error_message = error_message.replace("'", "''")  # SQL escape: ' becomes ''
            error_field = f"'{error_message}'"
        else:
            error_field = "NULL"        
        # Build the end time update - set current timestamp if status indicates completion
        end_time_field = "current_timestamp()" if status in ["COMPLETED", "FAILED"] else "PROCESS_ENDTIME"
        
        self.spark.sql(f"""
            UPDATE {self.table_name}
            SET STATUS = '{status}',
                PROCESS_ENDTIME = {end_time_field},
                ERROR = {error_field},
                UPDATE_DATE = current_timestamp(),
                UPDATE_BY = '{self.user}',
                LAST_PROCESSED_DTTM = current_timestamp()
            WHERE PROCESS_ID = '{process_id}' and RUN_TYPE = '{run_type}'
        """)
        
        logger.info(f"Updated batch process status: {status} for process_id: {process_id} by user: {self.user}")

def get_spark_session():
    return SparkSession.builder.appName("Load_EDS_APD").getOrCreate()

class EDS_UTILS:
    @staticmethod
    def generate_process_id():
        return str(uuid.uuid4())

