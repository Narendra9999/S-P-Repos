from pyspark.sql import SparkSession
from pyspark.sql.functions import col, when, lit, struct, collect_list, to_json, get_json_object, trim, date_format, first, broadcast
from pyspark.sql import DataFrame
from datetime import datetime
from typing import Dict, Optional
import logging
import sys
from pyspark.sql.types import StructType, StructField, StringType, DoubleType, TimestampType
from apd_ingestion.constants.enum_vars import LoadType, RunType
from apd_ingestion.eds.eds_utils import ProcessTableUtil, EDS_UTILS
from apd_ingestion.database.postgres.adp_postgres_handler import ADPPostgresHandler

# Suppress verbose Py4J logs
logging.getLogger("py4j").setLevel(logging.WARNING)
logging.getLogger("py4j.java_gateway").setLevel(logging.WARNING)
logging.getLogger("py4j.clientserver").setLevel(logging.WARNING)
logging.basicConfig(stream=sys.stdout, level=logging.INFO)
logger = logging.getLogger(__name__)


def build_in_clause(column_name, values):
    """
    Utility to build SQL IN clause string safely for multiple values.
    """
    if not values:
        return ""
    quoted_values = ", ".join(f"'{val}'" for val in values)
    return f"AND {column_name} IN ({quoted_values})"


def get_spark_session():
    """Initialize and return Spark session"""
    return SparkSession.builder.appName("EDS_Data_Processor").getOrCreate()


def load_finorgattr_data(spark: SparkSession, env: str, sector_filter: Optional[list] = None, run_type: str = RunType.BATCH.value) -> DataFrame:
    """
    Load financial organization attributes data
    
    Args:
        spark: SparkSession
        env: Environment name
        sector_filter: Optional list of sectors for USPF optimization
        run_type: Processing mode to determine logging behavior
    
    Returns:
        DataFrame: Financial organization attributes
    """
    # Build sector filter for USPF optimization
    sector_filter_clause = ""
    if sector_filter:
        sector_filter_clause = build_in_clause("fin_sector_name", sector_filter)
        logger.info(f"🎯 USPF Optimization: Pre-filtering FinOrg by {len(sector_filter)} sectors")
    
    finorgattr_sql = f"""
    SELECT 
        finorg_id AS finorg, 
        obligor_re_org_id AS redorgid, 
        finorg_name AS finorgname, 
        fin_sector_name AS sectorname
    FROM idf_{env}.uspf_apr.t_finorg_attr
    WHERE current_ind = 'Y'
    {sector_filter_clause}
    """
    
    finorgattr_df = spark.sql(finorgattr_sql).dropDuplicates()
    
    # Show counts for all modes EXCEPT USPF_STREAM (performance optimization)
    if run_type != RunType.USPF_STREAM.value:
        logger.info(f"FinOrgAttr count: {finorgattr_df.count()}")
    else:
        logger.info("FinOrgAttr loaded (USPF streaming - count skipped)")
    return finorgattr_df

def load_finorggeolink_data(spark: SparkSession, env: str, filter_conditions: Optional[Dict] = None, run_type: str = RunType.BATCH.value) -> DataFrame:
    """
    Load financial organization geo link data with both CSID and PAID records
    Enhanced with finorg_ids filtering
    
    Args:
        spark: SparkSession
        env: Environment name
        filter_conditions: Optional filters including finorg_ids
        run_type: Processing mode to determine logging behavior
    Returns:
        DataFrame: Financial organization geo link data
    """
    # Build geo filter clause (legacy support)
    geo_filter_clause = ""
    finorg_filter = ""
    if filter_conditions and filter_conditions.get("geo_unit_ids"):
        geo_unit_ids = filter_conditions["geo_unit_ids"]
        if isinstance(geo_unit_ids, str):
            geo_unit_ids = [geo_unit_ids]
        geo_filter_clause = build_in_clause("fgr.fips_code", geo_unit_ids)
    
    if filter_conditions and filter_conditions.get("finorg_ids"):
        finorg_ids = filter_conditions["finorg_ids"]
        if isinstance(finorg_ids, str):
            finorg_ids = [finorg_ids]
        
        finorg_filter = build_in_clause("finorgid", finorg_ids)
        
        logger.info(f"🔍 Filtering FinOrgGeoLink for {len(finorg_ids)} finorg_ids: {finorg_ids[:5]}{'...' if len(finorg_ids) > 5 else ''}")
    
    finorggeolink_sql = f"""
    select fgr.finorg_id finorgid, gu.geo_unit_cd gu_id, gu.geo_unit_typ gu_typ, fgr.purpose_type, fgr.fips_code as fipscode, ihs.id_value ihsid, bea.id_value bea, bls.id_value blsid, eds.id_value edsid, fa.fin_sector_name sector
        from idf_{env}.uspf_apr.t_finorg_geo_rel fgr
        join idf_{env}.uspf_apr.t_fips_geo_unit fgu on fgr.fips_code = fgu.fips_code and fgu.cur_ind = 'Y' and fgu.fips_validity_end_date = '9999-12-31'
        join idf_{env}.uspf_apr.t_geographic_unit gu on fgu.geo_unit_id = gu.geo_unit_id
        left join idf_{env}.uspf_apr.t_fips_id_link ihs on ihs.cur_ind = 'Y' and ihs.id_fips_validity_end_date = '9999-12-31' and ihs.id_source = 'IHSID' and fgr.fips_code = ihs.fips_code
        left join idf_{env}.uspf_apr.t_fips_id_link bea on bea.cur_ind = 'Y' and bea.id_fips_validity_end_date = '9999-12-31' and bea.id_source = 'BEA' and fgr.fips_code = bea.fips_code
        left join idf_{env}.uspf_apr.t_fips_id_link eds on eds.cur_ind = 'Y' and eds.id_fips_validity_end_date = '9999-12-31' and eds.id_source = 'EDSID' and fgr.fips_code = eds.fips_code
        left join idf_{env}.uspf_apr.t_fips_id_link bls on bls.cur_ind = 'Y' and bls.id_fips_validity_end_date = '9999-12-31' and bls.id_source = 'BLSID' and fgr.fips_code = bls.fips_code
        join idf_{env}.uspf_apr.t_finorg_attr fa on fa.active_ind = 'Y' and fa.end_dttm = '9999-12-31' and fgr.finorg_id = fa.finorg_id
        where fgr.cur_ind = 'Y'
      {finorg_filter}
      {geo_filter_clause}
    """
    
    finorggeolink_df = spark.sql(finorggeolink_sql).dropDuplicates()
    
    # Show counts for all modes EXCEPT USPF_STREAM (performance optimization)
    if run_type != RunType.USPF_STREAM.value:
        logger.info(f"FinOrgGeoLink count: {finorggeolink_df.count()}")
    else:
        logger.info("FinOrgGeoLink loaded (USPF streaming - count skipped)")
    return finorggeolink_df


def _create_empty_edsdatapoint(spark: SparkSession) -> DataFrame:
    """
    Create empty DataFrames with proper schemas for EDS DATA POINT
    
    Args:
        spark: SparkSession
        
    Returns:
        empty EDS DATA POINT schema
    """
    # Empty metadata DataFrame schema
    schema = StructType([
            StructField("Geography_Unit_Code", StringType(), True),
            StructField("Geography_Type", StringType(), True),
            StructField("Data_Point_Attribute", StringType(), True),
            StructField("Data_Point_Attribute_Name", StringType(), True),
            StructField("Data_Point_Value", DoubleType(), True),
            StructField("Data_Point_Data_Type", StringType(), True),
            StructField("Data_Point_Year", StringType(), True),
            StructField("Data_Point_Quarter", StringType(), True),
            StructField("Data_Point_Source", StringType(), True),
            StructField("Data_Point_Period_Type", StringType(), True),
            StructField("Data_Point_Period_Name", StringType(), True),
            StructField("Data_Point_Period_End_Date", StringType(), True),
            StructField("Longitude", DoubleType(), True),
            StructField("Latitude", DoubleType(), True),
            StructField("Country_Name", StringType(), True),
            StructField("State_Name", StringType(), True),
            StructField("County_Name", StringType(), True),
            StructField("Core_Based_Statistical_Area_Code", StringType(), True),
            StructField("Current_Ind", StringType(), True),
            StructField("Create_User_Id", StringType(), True),
            StructField("Create_Dttm", TimestampType(), True),
            StructField("Last_Update_User_Id", StringType(), True),
            StructField("Last_Update_Dttm", TimestampType(), True)
        ])
    return spark.createDataFrame([], schema)


def load_edsdatapoint_data_uspf_optimized(spark: SparkSession, env: str, mnemonic_df: DataFrame, finorggeo_df: DataFrame) -> DataFrame:
    """
    USPF: Load EDS data points using DataFrame JOIN approach
    Uses clustering advantage with Geography_Unit_Code + Data_Point_Attribute filtering
    
    Args:
        spark: SparkSession
        env: Environment name
        mnemonic_df: Filtered mnemonic DataFrame (from formula_map_ids)
        finorggeo_df: DataFrame containing geography mappings
        
    Returns:
        DataFrame: Highly filtered EDS data points
    """
    logger.info("Loading EDS data points...")
    
    # Create distinct lookup DataFrames for JOIN operations 
    geo_lookup = finorggeo_df.select("edsid").filter(col("edsid").isNotNull()).distinct().alias("geo")
    mnemonic_lookup = mnemonic_df.select("source_mnemonic_text").distinct().alias("mnem")
    
    # Create EDS DataFrame
    eds_df = spark.sql(f"""
        SELECT 
            Geography_Unit_Code, Geography_Type, Data_Point_Attribute, Data_Point_Attribute_Name,
            Data_Point_Value, Data_Point_Data_Type, Data_Point_Year, Data_Point_Quarter,
            Data_Point_Source, Data_Point_Period_Type, Data_Point_Period_Name, Data_Point_Period_End_Date,
            Longitude, Latitude, Country_Name, State_Name, County_Name, Core_Based_Statistical_Area_Code,
            Current_Ind, Create_User_Id, Create_Dttm, Last_Update_User_Id, Last_Update_Dttm
        FROM idf_curated_{env}.eds.t_eds_data_pnt
    """).alias("eds")
    
    filtered_eds = eds_df.join(
        broadcast(geo_lookup), 
        col("eds.Geography_Unit_Code") == col("geo.edsid"), 
        "inner"
    ).join(
        broadcast(mnemonic_lookup), 
        col("eds.Data_Point_Attribute") == col("mnem.source_mnemonic_text"), 
        "inner"
    ).select("eds.*")  # Select only EDS columns
    
    logger.info("EDS DataPoint loaded")
    
    return filtered_eds


def load_edsdatapoint_data(spark: SparkSession, env: str, finorggeo_df: DataFrame) -> DataFrame:
    """
    Load EDS data points by filtering based on geography codes
    derived from specific finorg_ids rather than loading the entire EDS table.
        
    Args:
        spark: SparkSession
        finorggeo_df: DataFrame containing finorg to geography mappings (from load_finorggeolink_data)
        
    Returns:
        DataFrame: Filtered EDS data points
        
    Performance Impact:
        - Filtered EDS data: (based on finorg_ids)
    """
    logger.info("Loading EDS data points...")
    
    # Extract unique geography codes from the finorggeo_df to filter EDS data
    geo_codes = finorggeo_df.select(
        col("edsid")
    ).filter(
        col("edsid").isNotNull()
    ).distinct().collect()
    
    edsid_list = [row["edsid"] for row in geo_codes]
    
    if not edsid_list:
        logger.info(" No valid EDS geography codes found. Returning empty DataFrame.")
        return _create_empty_edsdatapoint(spark)
    
    logger.info(f"Filtering EDS data for {len(edsid_list)} geography codes")
    
    # Build chunked IN clause for large lists
    if len(edsid_list) <= 1000:
        # Simple case - single IN clause
        edsid_filter = build_in_clause_chunked(edsid_list, "eds.Geography_Unit_Code")
        where_clause = f"WHERE eds.Geography_Unit_Code IN ({edsid_filter})"
    else:
        # case - multiple OR conditions already built by function
        where_clause = f"WHERE {build_in_clause_chunked(edsid_list, 'eds.Geography_Unit_Code')}"
    
    edsdatapoint_sql = f"""
    SELECT 
        Geography_Unit_Code,
        Geography_Type,
        Data_Point_Attribute,
        Data_Point_Attribute_Name,
        Data_Point_Value,
        Data_Point_Data_Type,
        Data_Point_Year,
        Data_Point_Quarter,
        Data_Point_Source,
        Data_Point_Period_Type,
        Data_Point_Period_Name,
        Data_Point_Period_End_Date,
        Longitude,
        Latitude,
        Country_Name,
        State_Name,
        County_Name,
        Core_Based_Statistical_Area_Code,
        Current_Ind,
        Create_User_Id,
        Create_Dttm,
        Last_Update_User_Id,
        Last_Update_Dttm
    FROM idf_curated_{env}.eds.t_eds_data_pnt eds
    {where_clause}
    """ 
    edsdatapoint_df = spark.sql(edsdatapoint_sql)
    
    record_count = edsdatapoint_df.count()
    logger.info(f"EDS DataPoint count: {record_count}")

    return edsdatapoint_df


def build_in_clause_chunked(values_list: list, column_name: str, chunk_size: int = 1000) -> str:
    """
    Build chunked IN clause for large lists to avoid SQL query size limits.
    
    Args:
        values_list: List of values for IN clause
        column_name: Column name for the IN clause
        chunk_size: Maximum number of values per chunk
        
    Returns:
        str: Properly quoted values for IN clause
    """
    if not values_list:
        return "''"  # Return empty string that won't match anything
    
    # Clean and quote all values consistently
    clean_values = [str(v).replace("'", "''") for v in values_list if v is not None]
    
    if not clean_values:
        return "''"
    
    if len(clean_values) <= chunk_size:
        # Single IN clause for small lists - return properly quoted values
        return "'" + "', '".join(clean_values) + "'"
    
    # Multiple IN clauses for large lists
    chunks = [clean_values[i:i + chunk_size] for i in range(0, len(clean_values), chunk_size)]
    or_conditions = []
    
    for chunk in chunks:
        values_str = "'" + "', '".join(chunk) + "'"
        or_conditions.append(f"{column_name} IN ({values_str})")
    
    # Return OR-separated conditions for chunked queries
    return f"({' OR '.join(or_conditions)})"


def _create_empty_mnemonic(spark: SparkSession) -> DataFrame:
    """
    Create empty DataFrames with proper schemas for mnemonic
    
    Args:
        spark: SparkSession
        
    Returns:
        empty mnemonic schema
    """
    # Empty metadata DataFrame schema
    schema = StructType([
        StructField("ent_mnem_cd", StringType(), True),
        StructField("source_mnemonic_text", StringType(), True),
        StructField("de_ver_st_frmla_map_id", StringType(), True),
        StructField("cmp_indus_lvl2_clsf_cd", StringType(), True),
        StructField("magnitude", StringType(), True)
    ])
    return spark.createDataFrame([], schema)


def load_mnemonic_data(spark: SparkSession, env: str, formula_map_ids: Optional[list] = None, run_type: str = RunType.BATCH.value) -> DataFrame:
    """
    Load mnemonic data for joining with EDS data points
    
    Args:
        spark: SparkSession
        env: Environment name
        formula_map_ids: Optional list of formula map IDs for USPF streaming optimization
        run_type: Processing mode to determine logging behavior
    
    Returns:
        DataFrame: Mnemonic data
    """
    # Build formula map filter for USPF streaming
    formula_filter = ""
    if formula_map_ids:
        if isinstance(formula_map_ids, (str, int)):
            formula_map_ids = [formula_map_ids]
        formula_filter = build_in_clause("a.de_ver_st_frmla_map_id", formula_map_ids)
        logger.info(f"🎯 USPF Streaming: Filtering mnemonic for {len(formula_map_ids)} formula_map_ids")
    
    mnemonic_sql = f"""
        select dv.ent_mnem_cd, source_mnemonic_text, a.de_ver_st_frmla_map_id, a.cmp_indus_lvl2_clsf_cd,
               mnem_map.ent_mnem_denom_name as magnitude
        from idf_{env}.finanalytic.t_de_ver_st_frmla_map a, idf_{env}.finanalytic.t_de_ver_st dvs, idf_{env}.finanalytic.t_de_ver dv, 
        idf_{env}.finmaster.t_dim_source_data_element elem
        left join idf_{env}.mnem_map.t_ent_mnem mnem_map on dv.ent_mnem_cd = mnem_map.ent_mnem_cd
        where a.fm_data_source_id = 6
        and mnem_map.mnemonic_subtype = 'Reported'
        and a.de_ver_st_id = dvs.de_ver_st_id
        and dvs.de_ver_id = dv.de_ver_id
        and dv.stage_cd = 'FINAL'
        and dv.CUR_IND = 'Y'
        and a.cur_ind = 'Y'
        and dvs.cur_ind = 'Y'
        and a.fm_source_data_element_id = elem.source_data_element_id
        {formula_filter}
    """
    
    try:
        mnemonic_df = spark.sql(mnemonic_sql).dropDuplicates()
        logger.info(f"Mnemonic count: {mnemonic_df.count()}")
        return mnemonic_df
    except Exception as e:
        logger.warning(f"Could not load mnemonic data: {e}")
        return _create_empty_mnemonic(spark)

def join_finorgattr_with_finorggeolink(finorgattr_df: DataFrame, finorggeolink_df: DataFrame) -> DataFrame:
    """
    Join finorgattr and finorggeolink where edsid is not null
    
    Args:
        finorgattr_df: Financial organization attributes DataFrame
        finorggeolink_df: Financial organization geo link DataFrame
    
    Returns:
        DataFrame: Joined finorgattr and finorggeolink data
    """
    logger.info("Joining FinOrgAttr with FinOrgGeoLink...")
    
    # Filter finorggeolink to only records where edsid is not null
    finorggeolink_filtered = finorggeolink_df.filter(col("edsid").isNotNull())
    logger.info("FinOrgGeoLink filtered for non-null edsid")
    
    # Join on finorgid
    joined_df = finorgattr_df.alias("fa").join(
        finorggeolink_filtered.alias("fgl"),
        col("fa.finorg") == col("fgl.finorgid"),
        "inner"
    ).select(
        col("fa.finorg"),
        col("fa.redorgid"),
        col("fa.finorgname"),
        col("fa.sectorname"),
        col("fgl.gu_id"),
        col("fgl.gu_typ"),
        col("fgl.purpose_type"),
        col("fgl.fipscode"),
        col("fgl.ihsid"),
        col("fgl.bea"),
        col("fgl.blsid"),
        col("fgl.edsid"),
        col("fgl.sector")
    ).dropDuplicates() 
    
    logger.info(f"FinOrgAttr + FinOrgGeoLink join completed")
    return joined_df

def join_with_mnemonic(eds_joined_df: DataFrame, mnemonic_df: DataFrame) -> DataFrame:
    """
    Join the EDS result with mnemonic data and select all required columns
    
    Args:
        eds_joined_df: Result from EDS join
        mnemonic_df: Mnemonic DataFrame
    
    Returns:
        DataFrame: Final joined result with all required columns
    """
    logger.info("Joining with Mnemonic data...")
    
    final_df = eds_joined_df.alias("eds").join(
        mnemonic_df.alias("mnem"),
        (col("eds.Data_Point_Attribute") == col("mnem.source_mnemonic_text")) &
        (col("eds.sectorname") == col("mnem.cmp_indus_lvl2_clsf_cd")),
        "inner"
    ).select(
        # All EDS columns
        col("eds.finorg"),
        col("eds.redorgid"),
        col("eds.finorgname"),
        col("eds.sectorname"),
        col("eds.gu_id"),
        col("eds.gu_typ"),
        col("eds.purpose_type"),
        col("eds.fipscode"),
        col("eds.ihsid"),
        col("eds.bea"),
        col("eds.blsid"),
        col("eds.edsid"),
        col("eds.sector"),
        col("eds.Geography_Unit_Code"),
        col("eds.Geography_Type"),
        col("eds.Core_Based_Statistical_Area_Code"),
        col("eds.Data_Point_Attribute"),
        col("eds.Data_Point_Attribute_Name"),
        col("eds.Data_Point_Value"),
        col("eds.Data_Point_Data_Type"),
        col("eds.Data_Point_Year"),
        col("eds.Data_Point_Quarter"),
        col("eds.Data_Point_Source"),
        col("eds.Data_Point_Period_Type"),
        col("eds.Data_Point_Period_Name"),
        col("eds.Data_Point_Period_End_Date"),
        col("eds.Longitude"),
        col("eds.Latitude"),
        col("eds.Country_Name"),
        col("eds.State_Name"),
        col("eds.County_Name"),
        col("eds.Current_Ind"),
        col("eds.Create_User_Id"),
        col("eds.Create_Dttm"),
        col("eds.Last_Update_User_Id"),
        col("eds.Last_Update_Dttm"),
        # All Mnemonic columns - REQUIRED for final JSON
        col("mnem.ent_mnem_cd"),                    # → "mnemonic"
        col("mnem.de_ver_st_frmla_map_id"),         # → "FaDEVerStFrmlaMapId"
        col("mnem.source_mnemonic_text"),           # → "sourceMnemonic" 
        col("mnem.cmp_indus_lvl2_clsf_cd"),         # → sector validation
        col("mnem.magnitude")                       # → "magnitude"
    )
    
    final_df = final_df.dropDuplicates()
    logger.info("Final joined result with all mnemonic columns completed")
    
    return final_df


def create_eds_final_output(final_result_df: DataFrame) -> DataFrame:
    """
    Create the final EDS output in the specified JSON structure with correct 3-level grouping
    
    Args:
        final_result_df: DataFrame with joined data
        
    Returns:
        tuple: (JSON DataFrame, Metadata DataFrame) - Following IHS pattern
    """
    logger.info("Creating EDS final output structure...")
    
    # Ensure nulls are preserved in the JSON output
    final_result_df.sparkSession.conf.set("spark.sql.jsonGenerator.ignoreNullFields", "false")
    
    # First, separate current and historical data for value trail
    current_data = final_result_df.filter(col("Current_Ind") == "Y")
    historical_data = final_result_df.filter(col("Current_Ind") == "N")
    
    # Create value trail for each sourceMnemonic + formula_map_id (historical records)
    value_trail_df = historical_data.groupBy(
        "finorg", 
        "Data_Point_Period_End_Date", 
        "edsid", 
        "purpose_type", 
        "Data_Point_Attribute",
        "de_ver_st_frmla_map_id" 
    ).agg(
        collect_list(
            struct(
                date_format(col("Create_Dttm"), "yyyy-MM-dd'T'HH:mm:ss").alias("valueAsOf"),
                col("Create_User_Id").alias("valueUpdatedBy"),
                col("Data_Point_Value").alias("value")
            )
        ).alias("valueTrail")
    )
    
    # Join current data with value trail
    current_with_trail = current_data.join(
        value_trail_df,
        ["finorg", "Data_Point_Period_End_Date", "edsid", "purpose_type", "Data_Point_Attribute", "de_ver_st_frmla_map_id"],
        "left"
    )
    
    # Create finDataPoints structure (Geography level grouping)
    fin_data_points = current_with_trail.groupBy(
        "finorg", "Data_Point_Period_End_Date",    # Organization + Period
        "edsid", "purpose_type"                    # Geography (econData level)
    ).agg(
        # Get metadata fields (same for all records in group)
        first("redorgid").alias("redorgid"),
        first("finorgname").alias("finorgname"),
        first("sectorname").alias("sectorname"),
        first(trim(col("gu_typ"))).alias("gu_typ"),
        first("fipscode").alias("fipscode"),
        # Create finDataPoints array
        collect_list(
            struct(
                col("Data_Point_Attribute").alias("sourceMnemonic"),
                col("Data_Point_Value").alias("currentValue"),
                lit("Actual").alias("sourceDataMagnitude"),
                lit("").alias("sourcescalemultiplier"),
                col("ent_mnem_cd").alias("mnemonic"),
                col("magnitude").alias("magnitude"),  # From mnemonic lookup
                col("de_ver_st_frmla_map_id").alias("FaDEVerStFrmlaMapId"),
                col("Create_User_Id").alias("valueUpdatedBy"),
                date_format(col("Create_Dttm"), "yyyy-MM-dd'T'HH:mm:ss").alias("valueAsOf"),
                when(col("valueTrail").isNotNull(), col("valueTrail")).otherwise(lit(None)).alias("valueTrail")
            )
        ).alias("finDataPoints")
    )
    
    # Create econData structure (Organization + Period level grouping)
    econ_data = fin_data_points.groupBy(
        "finorg", "Data_Point_Period_End_Date"  # Organization + Period only
    ).agg(
        # Get metadata fields (same for all records in group)
        first("redorgid").alias("redorgid"),
        first("finorgname").alias("finorgname"), 
        first("sectorname").alias("sectorname"),
        # Create econData array
        collect_list(
            struct(
                col("edsid").alias("sourceId"),           # finorggeolink.edsid
                col("purpose_type").alias("purposeType"), # finorggeolink.purpose_type
                trim(col("gu_typ")).alias("guType"),      # finorggeolink.gu_typ (trimmed for consistency)
                col("fipscode").alias("fipsCode"),        # finorggeolink.fipscode
                col("finDataPoints")
            )
        ).alias("econData")
    )
    
    # Create final JSON structure (finOrg+periodEndDate level)
    final_output = econ_data.select(
        struct(
            col("finorg").alias("finOrg"),
            col("redorgid").alias("redOrgId"),
            col("finorgname").alias("finOrgName"),
            col("sectorname").alias("sectorName"),
            date_format(col("Data_Point_Period_End_Date"), "MM-dd-yyyy").alias("periodEndDate"),
            lit("EDS").alias("source"),
            col("econData")
        ).alias("json_output")
    )
    
    # Convert to JSON string
    final_json_df = final_output.select(
        to_json(col("json_output")).alias("eds_output_json")
    )
    logger.info("EDS final output structure created successfully")
    return final_json_df

def join_with_edsdatapoint(spark, finorg_geo_df: DataFrame, edsdatapoint_df: DataFrame) -> DataFrame:
    """
    EDS join using single SQL query
    """
    logger.info("Performing EDS join...")
    
    # Register DataFrames as temporary views for SQL optimization
    finorg_geo_df.createOrReplaceTempView("finorg_geo")
    edsdatapoint_df.createOrReplaceTempView("eds_data")
    
    # Single SQL query instead of multiple DataFrame operations
    optimized_join_sql = """
    SELECT DISTINCT
        -- FinOrg columns
        fg.finorg,
        fg.redorgid,
        fg.finorgname,
        fg.sectorname,
        fg.gu_id,
        fg.gu_typ,
        fg.purpose_type,
        fg.fipscode,
        fg.ihsid,
        fg.bea,
        fg.blsid,
        fg.edsid,
        fg.sector,
        -- EDS columns
        eds.Geography_Unit_Code,
        eds.Geography_Type,
        eds.Core_Based_Statistical_Area_Code,
        eds.Data_Point_Attribute,
        eds.Data_Point_Attribute_Name,
        eds.Data_Point_Value,
        eds.Data_Point_Data_Type,
        eds.Data_Point_Year,
        eds.Data_Point_Quarter,
        eds.Data_Point_Source,
        eds.Data_Point_Period_Type,
        eds.Data_Point_Period_Name,
        eds.Data_Point_Period_End_Date,
        eds.Longitude,
        eds.Latitude,
        eds.Country_Name,
        eds.State_Name,
        eds.County_Name,
        eds.Current_Ind,
        eds.Create_User_Id,
        eds.Create_Dttm,
        eds.Last_Update_User_Id,
        eds.Last_Update_Dttm
    FROM finorg_geo fg
    INNER JOIN eds_data eds ON (
        -- All possible join conditions in single query
        (TRIM(fg.gu_typ) = 'STATE' AND TRIM(eds.Geography_Type) = 'STATE' AND fg.edsid = eds.Geography_Unit_Code)
        OR 
        (TRIM(fg.gu_typ) = 'CITY' AND fg.edsid = eds.Geography_Unit_Code)
        OR
        (TRIM(fg.gu_typ) = 'MCD' AND TRIM(eds.Geography_Type) = 'MINOR CIVIL DIVISION' AND fg.edsid = eds.Geography_Unit_Code)
        OR
        (TRIM(fg.gu_typ) = 'COUNTY' AND TRIM(eds.Geography_Type) = 'COUNTY' AND fg.edsid = eds.Geography_Unit_Code)
        OR 
        (TRIM(fg.gu_typ) = 'SCD' AND TRIM(eds.Geography_Type) = 'SCHOOL DISTRICT' AND fg.edsid = eds.Geography_Unit_Code)
        OR
        (TRIM(fg.gu_typ) = 'SCD' AND TRIM(eds.Geography_Type) = 'CBSA' AND fg.edsid = eds.Core_Based_Statistical_Area_Code)
    )
    """
    
    result_df = spark.sql(optimized_join_sql)
    
    logger.info("EDS join completed")
    return result_df

def _create_empty_eds_dataframes(spark: SparkSession) -> tuple:
    """
    Create empty DataFrames with proper schemas for EDS pipeline
    
    Args:
        spark: SparkSession
        
    Returns:
        Empty Metadata DataFrame
    """
    
    # Empty metadata DataFrame schema
    empty_metadata_schema = StructType([
        StructField("sp_org_id", StringType(), True),
        StructField("org_name", StringType(), True),
        StructField("fin_entity_id", StringType(), True),
        StructField("period_end_date", StringType(), True),
        StructField("dataset", StringType(), True),
        StructField("dataset_source", StringType(), True)
    ])
    
    empty_metadata_df = spark.createDataFrame([], empty_metadata_schema)
    
    return empty_metadata_df


def parse_eds_json_to_metadata(json_str_df: DataFrame, run_type: str = RunType.BATCH.value) -> DataFrame:
    """
    Parses metadata fields from EDS JSON strings for database storage
    
    Args:
        json_str_df: DataFrame with 'eds_output_json' column
    
    Returns:
        DataFrame: Metadata with dataset column
    """
    logger.info("Parsing EDS JSON to metadata...")
    
    # Get input count efficiently
    if run_type != RunType.USPF_STREAM.value:
        input_count = json_str_df.count()
        logger.info(f"Input JSON records: {input_count}")
    
    # Extract metadata first
    metadata_raw = json_str_df.select(
        get_json_object(col("eds_output_json"), "$.redOrgId").alias("re_org_id"),
        get_json_object(col("eds_output_json"), "$.finOrgName").alias("org_name"),
        get_json_object(col("eds_output_json"), "$.finOrg").alias("fin_entity_id"),
        get_json_object(col("eds_output_json"), "$.periodEndDate").alias("period_end_date"),
        col("eds_output_json").alias("dataset")
    ).withColumn("dataset_source", lit("EDS"))
    
    # Cache for count verification
    metadata_raw.cache()
    before_count = metadata_raw.count()
    logger.info(f"Metadata records before deduplication: {before_count}")
    
    # Deduplicate based on business keys
    metadata_df = metadata_raw.dropDuplicates([
        "fin_entity_id", "re_org_id", "period_end_date"
    ])
    
    # Final count for verification
    final_count = metadata_df.count()
    logger.info(f"Metadata records after deduplication: {final_count}")
    logger.info(f"Records removed by deduplication: {before_count - final_count}")
    
    # Unpersist cached DataFrame
    metadata_raw.unpersist()
        
    return metadata_df


def process_eds_data_pipeline(env: str, filter_conditions: Optional[Dict], run_type: str = RunType.BATCH.value) -> DataFrame:
    """
    Args:
        filter_conditions: Optional filtering conditions
        env: Environment (dev, qa, prod)
        
    Returns:
        DataFrame: JSON output with EDS data for specified finorg_ids
        
    """
    start_time = datetime.now()
    logger.info(f"Starting EDS pipeline with filters: {filter_conditions}")

    finorg_ids = None
    if filter_conditions and "finorg_ids" in filter_conditions:
        finorg_ids = filter_conditions["finorg_ids"]
    
    spark = get_spark_session()    
    
    try:
        # Step 1: Load and filter finorg attributes
        logger.info("Loading finorg attributes...")
        finorgattr_df = load_finorgattr_data(spark, env, run_type=run_type)
        finorgattr_filtered = broadcast(finorgattr_df.filter(col("finorg").isin(finorg_ids))) if finorg_ids else finorgattr_df
        
        # Step 2: Load finorggeolink data
        logger.info("Loading finorggeolink data...")
        finorggeolink_df = load_finorggeolink_data(spark, env, filter_conditions, run_type)
        
        # Step 3: Load EDS data 
        edsdatapoint_df = load_edsdatapoint_data(spark, env, finorggeolink_df)
        
        # Step 4: Load mnemonic data 
        logger.info("Loading mnemonic data...")
        mnemonic_df = broadcast(load_mnemonic_data(spark, env, run_type=run_type))
        
        # Step 5: First join finorgattr with finorggeolink
        finorg_geo_df = join_finorgattr_with_finorggeolink(finorgattr_filtered, finorggeolink_df)

        # Step 6: Perform join with EDS data
        final_result_df = join_with_edsdatapoint(spark,
            finorg_geo_df, edsdatapoint_df
        )
        
        # Early validation - check join results  
        join_count = final_result_df.count()
        logger.info(f"Record count after EDS joins: {join_count}")
        if join_count == 0:
            logger.info("No data after joins. Exiting early.")
            return _create_empty_eds_dataframes(spark)
        
        # Step 7: Join with mnemonic data
        enriched_result_df = join_with_mnemonic(final_result_df, mnemonic_df)
        
        # Step 8: Create final JSON output and metadata
        final_json_df = create_eds_final_output(enriched_result_df)
        
        # Create metadata DataFrame
        metadata_df = parse_eds_json_to_metadata(final_json_df, run_type)
            
        # Force immediate garbage collection for streaming
        #spark.sparkContext._jvm.System.gc()
        
        end_time = datetime.now()
        duration = (end_time - start_time).total_seconds()
        
        logger.info(f"EDS pipeline completed!")
        logger.info(f"Processing time: {duration:.2f} seconds")
        
        return metadata_df
        
    except Exception as e:
        logger.info(f"EDS pipeline failed: {str(e)}")
        raise e
    finally:
        logger.info("Done!")


def process_eds_uspf_stream(env: str, filter_conditions: Optional[Dict], run_type: str = RunType.USPF_STREAM.value) -> DataFrame:
    """
    USPF Streaming Pipeline with Reverse Optimization
    
    Optimization Strategy: Mnemonic → Sector → EDS → Geography → FinOrg
    
    Args:
        filter_conditions: Must contain formula_map_ids for USPF processing
        env: Environment (dev, qa, prod)
        run_type: Processing mode to determine logging behavior
        
    Returns:
        DataFrame: Metadata DataFrame
    """
    start_time = datetime.now()
    logger.info(f"🚀 Starting USPF STREAMING pipeline with filters: {filter_conditions}")
    
    # Extract formula_map_ids (required for USPF)
    formula_map_ids = filter_conditions.get("formula_map_ids") if filter_conditions else None
    if not formula_map_ids:
        logger.error("USPF Streaming requires formula_map_ids in filter_conditions")
        raise ValueError("Missing required formula_map_ids for USPF streaming")
    
    spark = get_spark_session()
    
    try:
        # Step 1: Load FILTERED mnemonic data first (reverse optimization)
        logger.info("Step 1: Loading filtered mnemonic data...")
        mnemonic_df = broadcast(load_mnemonic_data(spark, env, formula_map_ids, run_type))
        
        # Step 2: Extract sectors from mnemonic for pre-filtering
        logger.info("Step 2: Extracting sectors for optimization...")
        sectors = mnemonic_df.select("cmp_indus_lvl2_clsf_cd").distinct().collect()
        sector_list = [row["cmp_indus_lvl2_clsf_cd"] for row in sectors if row["cmp_indus_lvl2_clsf_cd"]]
        
        # Step 3: Load finorg attributes (sector pre-filtered)
        logger.info("Step 3: Loading finorg attributes by sectors...")
        finorgattr_df = load_finorgattr_data(spark, env, sector_list, run_type)
        
        # Step 4: Load geo link data
        logger.info("Step 4: Loading geo link data by finorg id's...")
        finorg_ids = finorgattr_df.select("finorg").distinct().collect()
        finorg_id_list = [row["finorg"] for row in finorg_ids]
        filter_conditions_internal = {"finorg_ids": finorg_id_list}
        finorggeolink_df = load_finorggeolink_data(spark, env, filter_conditions_internal, run_type)
        
        # Step 5: Load EDS data (mnemonic + geography filtered)
        logger.info("Step 5: Loading EDS data...")
        edsdatapoint_df = load_edsdatapoint_data_uspf_optimized(spark, env, mnemonic_df, finorggeolink_df)
        
        # Step 6: Join finorgattr with finorggeolink
        logger.info("Step 6: Joining finorgattr with geo link...")
        finorg_geo_df = join_finorgattr_with_finorggeolink(finorgattr_df, finorggeolink_df)
        
        # Step 7: EDS join
        logger.info("Step 7: Performing EDS join...")
        final_result_df = join_with_edsdatapoint(spark, finorg_geo_df, edsdatapoint_df)
        
        # Step 8: Join with pre-filtered mnemonic data
        logger.info("Step 8: Joining with pre-filtered mnemonic data...")
        enriched_result_df = join_with_mnemonic(final_result_df, mnemonic_df)
        
        # Step 9: Create final JSON output
        logger.info("Step 9: Creating JSON output...")
        final_json_df = create_eds_final_output(enriched_result_df)
        
        # Step 10: Create metadata (no count operations for streaming)
        logger.info("Step 10: Creating metadata...")
        metadata_df = parse_eds_json_to_metadata(final_json_df, run_type)
        
        end_time = datetime.now()
        duration = (end_time - start_time).total_seconds()
        
        logger.info(f"✅ USPF STREAMING pipeline completed in {duration:.2f} seconds!")        
        return metadata_df
        
    except Exception as e:
        logger.error(f"USPF streaming pipeline failed: {str(e)}")
        raise e
    finally:
        logger.info("USPF streaming done!")


def load_eds_pipeline(env: str = "dev", filter_conditions: Optional[Dict] = None, run_type: str = RunType.BATCH.value, 
                      user_name: str = "system", table_name: str = "required") -> DataFrame:
    """
    Entry point for EDS data processing with pipeline selection
    
    Args:
        env: Environment name (default: "dev")
        filter_conditions: Optional filtering conditions
        run_type: Processing mode (BATCH, FINANALYTIC_STREAM, USPF_STREAM)
        
    Returns:
        DataFrame: Metadata DataFrame
    """
    try:
        process_id = EDS_UTILS.generate_process_id()
        logger.info(f"Running EDS Run Type: {run_type} for new process {process_id}")
        process_table_util = ProcessTableUtil(table_name, user_name)
        process_table_util.insert_batch_process_status_started(process_id, run_type)
        output_df = None
        
        # Pipeline selection based on run_type
        # TODO: Need to chage the input defination for USPF_STREAM filter will be on fips code
        if run_type == RunType.USPF_STREAM.value:
            # USPF Streaming: Full reverse optimization pipeline
            output_df = process_eds_uspf_stream(env, filter_conditions, run_type)
        else:
            # BATCH + FINANALTIC_STREAM: Existing pipeline (no changes)
            output_df = process_eds_data_pipeline(env, filter_conditions, run_type)

        logger.info(f"EDS processing completed, updating {run_type} process {process_id} with status as COMPLETED...")
        process_table_util.update_batch_process_status(process_id, "COMPLETED", run_type)
        
        if output_df is not None and not output_df.rdd.isEmpty():
            adpHandler = ADPPostgresHandler()
            if run_type != RunType.BATCH.value:
                logger.info("Writing incremental data to APD DB for streaming run type ...")
                adpHandler.write_into_db(output_df,load_type=LoadType.INCREMENTAL)
            else:
                logger.info("Writing incremental data to APD DB for batch/zero day run type ...")
                adpHandler.write_into_db(output_df)
        else:
            logger.warning("No new records")
    except Exception as e:
        logger.info(f"EDS processing completed, updating {run_type} process {process_id} with status as FAILED...")
        process_table_util.update_batch_process_status(process_id, "FAILED", run_type, str(e))
        logger.error(f"Pipeline failed with error: {str(e)}")
        raise e