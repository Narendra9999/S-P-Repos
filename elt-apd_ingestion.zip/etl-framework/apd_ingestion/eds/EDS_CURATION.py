# Databricks notebook source
from pyspark.sql import SparkSession
from pyspark.sql.functions import (
    lit, col, when, concat_ws, to_date, current_timestamp, sha2, concat
)

from pyspark.sql import DataFrame

from typing import List
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import col, concat_ws, sha2, current_timestamp, lit
from apd_ingestion.constants.enum_vars import EdsStatus
from apd_ingestion.eds.eds_incremental_process import StatusTableUtil,EDSFileRegistry
import logging
import sys
logging.basicConfig(stream=sys.stdout, level=logging.INFO)
logger = logging.getLogger(__name__)

def get_spark_session():
    return SparkSession.builder.appName("Load_EDS_APD").getOrCreate()

spark = SparkSession.getActiveSession()

def apply_scd_type_2(
    source_df: DataFrame,
    target_table: str,
    business_keys: List[str],
    created_by: str,
    hash_columns: List[str]
) -> None:
    spark = SparkSession.getActiveSession()

    # Compute hash for change detection in source
    source_hashed = source_df.withColumn("hash", sha2(
        concat_ws("||", *[col(c).cast("string") for c in hash_columns]),
        256
    ))

    # Load current records from target and compute hash
    target_df = spark.table(target_table).filter(col("Current_Ind") == "Y")
    target_hashed = target_df.withColumn("hash", sha2(
        concat_ws("||", *[col(c).cast("string") for c in hash_columns]),
        256
    ))

    # Join on business keys
    join_condition = [source_hashed[f] == target_hashed[f] for f in business_keys]
    joined_df = source_hashed.alias("src").join(target_hashed.alias("tgt"), join_condition, "left")

    # Identify new or changed records
    new_or_changed = joined_df.filter(
        col("tgt.hash").isNull() | (col("src.hash") != col("tgt.hash"))
    ).select("src.*")

    # Identify records to expire
    to_expire = joined_df.filter(
        col("tgt.hash").isNotNull() & (col("src.hash") != col("tgt.hash"))
    ).select("tgt.*")

    # Mark old records as expired
    expired_df = to_expire \
        .withColumn("End_Dttm", current_timestamp()) \
        .withColumn("Current_Ind", lit("N")) \
        .withColumn("Last_Update_User_Id", lit(created_by)) \
        .withColumn("Last_Update_Dttm", current_timestamp())

    # Prepare inserts
    final_inserts_df = new_or_changed.drop("hash")
    expired_df = expired_df.drop("hash")

    # Define columns to write (ensure order matches target schema)
    final_columns = [
        "Geography_Unit_Code", "Geography_Type", "Country_Name",
        "County_FIPS_Code", "County_Name", "State_FIPS_Code", "State_Name",
        "Core_Based_Statistical_Area_Code", "Core_Based_Statistical_Area_Name",
        "Minor_Civil_Division_Code", "Minor_Civil_Division_Name",
        "Place_Code", "Place_Name", "School_District_Code", "School_District_Name",
        "Longitude", "Latitude", "Reference_Data_Source", "Data_Point_Year",
        "Data_Point_Quarter", "Geography_Level", "Data_Point_Source",
        "Data_Point_Attribute", "Data_Point_Attribute_Name",
        "Data_Point_Attribute_Short_Description", "Data_Point_Value",
        "Data_Point_Data_Type", "Data_Point_Period_Type", "Data_Point_Period_Name",
        "Data_Point_Period_End_Date", "Start_Dttm", "End_Dttm", "Current_Ind",
        "Create_User_Id", "Create_Dttm", "Last_Update_User_Id", "Last_Update_Dttm",
        "Source_Filename"
    ]

    final_df = expired_df.select(final_columns).unionByName(final_inserts_df.select(final_columns))
    insert_count = final_inserts_df.count()
    logger.info(f"Inserted {insert_count} new/changed rows into {target_table}.")
    expire_count = expired_df.count()
    logger.info(f"Expired {expire_count} rows in {target_table}.")
    # Write to target
    final_df.write.mode("append").insertInto(target_table)

    logger.info(f"SCD Type 2 applied. {final_inserts_df.count()} new/changed rows inserted into {target_table}.")



def curate_country_level_data(
    dpfile_table: str,
    dataelement_table: str,
    target_table: str,
    created_by: str,
    data_filenames: List[str]
):

    # Load and filter data point table
    dp_df = spark.table(dpfile_table).filter(col("Source_Filename").isin(data_filenames))
    de_df = spark.table(dataelement_table)

    # Skip if no data to process
    if dp_df.rdd.isEmpty():
        logger.info(f"Skipping COUNTRY curation due to empty input. Data files: {data_filenames}")
        return
    de_df_renamed = de_df.withColumnRenamed("Source_Filename", "de_Source_Filename")
    # Join with DataElement to get descriptions
    joined_df = dp_df.alias("dp").join(
    de_df_renamed.alias("de"),
    col("dp.MNEMONIC") == col("de.VAR_CODE"),
    "left"
    )
    joined_df = joined_df.drop("de.de_Source_Filename")
    # Transform the data
    result_df = joined_df \
    .withColumn("Geography_Unit_Code", lit("00")) \
    .withColumn("Geography_Type", lit("COUNTRY")) \
    .withColumn("Country_Name", lit("United States")) \
    .withColumn("County_FIPS_Code", lit(None)) \
    .withColumn("County_Name", lit(None)) \
    .withColumn("State_FIPS_Code", lit(None)) \
    .withColumn("State_Name", lit(None)) \
    .withColumn("Core_Based_Statistical_Area_Code", lit(None)) \
    .withColumn("Core_Based_Statistical_Area_Name", lit(None)) \
    .withColumn("Minor_Civil_Division_Code", lit(None)) \
    .withColumn("Minor_Civil_Division_Name", lit(None)) \
    .withColumn("Place_Code", lit(None)) \
    .withColumn("Place_Name", lit(None)) \
    .withColumn("School_District_Code", lit(None)) \
    .withColumn("School_District_Name", lit(None)) \
    .withColumn("Longitude", lit(None)) \
    .withColumn("Latitude", lit(None)) \
    .withColumn("Reference_Data_Source", lit("Manual")) \
    .withColumn("Data_Point_Year", col("year")) \
    .withColumn("Data_Point_Quarter", col("quarter")) \
    .withColumn("Geography_Level", col("geo_level")) \
    .withColumn("Data_Point_Source", lit(dpfile_table)) \
    .withColumn("Data_Point_Attribute", col("mnemonic")) \
    .withColumn("Data_Point_Attribute_Name", col("Variable_Desc")) \
    .withColumn("Data_Point_Attribute_Short_Description", col("Short_Variable_Desc")) \
    .withColumn("Data_Point_Value", col("value")) \
    .withColumn("Data_Point_Data_Type", col("DE_Data_Type")) \
    .withColumn("Data_Point_Period_Type", when(col("quarter") == 0, "Annual").otherwise("Quarterly")) \
    .withColumn("Data_Point_Period_Name",
                when(col("quarter") == 0, "Annual")
                .when(col("quarter") == 1, "First Quarter")
                .when(col("quarter") == 2, "Second Quarter")
                .when(col("quarter") == 3, "Third Quarter")
                .when(col("quarter") == 4, "Fourth Quarter")) \
    .withColumn("Data_Point_Period_End_Date",
                to_date(concat_ws("-",
                                  when(col("quarter") == 0, "12").when(col("quarter") == 1, "03")
                                  .when(col("quarter") == 2, "06").when(col("quarter") == 3, "09")
                                  .otherwise("12"),
                                  when(col("quarter") == 0, "31").when(col("quarter") == 1, "31")
                                  .when(col("quarter") == 2, "30").when(col("quarter") == 3, "30")
                                  .otherwise("31"),
                                  col("year").cast("string")
                                  ), "MM-dd-yyyy")) \
    .withColumn("Start_Dttm", current_timestamp()) \
    .withColumn("End_Dttm", to_date(lit("9999-12-31"))) \
    .withColumn("Current_Ind", lit("Y")) \
    .withColumn("Create_User_Id", lit(created_by)) \
    .withColumn("Create_Dttm", current_timestamp()) \
    .withColumn("Last_Update_User_Id", lit(None)) \
    .withColumn("Last_Update_Dttm", lit(None)) \
    .withColumn("Source_Filename", col("dp.Source_Filename"))



    apply_scd_type_2(
    source_df=result_df,
    target_table=target_table,
    business_keys=[
        "Geography_Unit_Code",
        "Geography_Type",
        "Data_Point_Year",
        "Data_Point_Quarter",
        "Data_Point_Attribute"
    ],
    created_by=created_by,
    hash_columns=[
        "Data_Point_Value",
        "Data_Point_Attribute_Name",
        "Data_Point_Data_Type",
        "Geography_Level",
        "Data_Point_Attribute_Short_Description"
    ]
)



def curate_state_level_data(dpfile_table: str, dataelement_table: str, reffile_table: str, 
                            target_table: str, created_by: str, 
                            data_filenames: List[str], ref_filenames: List[str]):

    # Load source and lookup tables
    dp_df = spark.table(dpfile_table).filter(col("Source_Filename").isin(data_filenames))
    ref_df = spark.table(reffile_table).filter(col("Source_Filename").isin(ref_filenames))
    de_df = spark.table(dataelement_table)

    if dp_df.rdd.isEmpty() or ref_df.rdd.isEmpty():
        logger.info(f"No records to process in {dpfile_table} or {reffile_table} for data files: {data_filenames} and ref files: {ref_filenames}")
        return

    # Rename to avoid duplicate Source_Filename column
    de_df_renamed = de_df.withColumnRenamed("Source_Filename", "de_Source_Filename")

    # Join dp_df with de_df to enrich with data element descriptions
    joined_df = dp_df.alias("dp").join(
        de_df_renamed.alias("de"),
        col("dp.MNEMONIC") == col("de.VAR_CODE"),
        "left"
    ).drop("de.de_Source_Filename")

    # Join with reference file to get State_Name using State_FIPS_Code
    joined_df = joined_df.join(
        ref_df.select("State_FIPS_Code", "State_Name").dropDuplicates(),
        on="State_FIPS_Code",
        how="left"
    )

    # Transform for state-level geography
    result_df = joined_df \
        .withColumn("Geography_Unit_Code", col("State_FIPS_Code")) \
        .withColumn("Geography_Type", lit("STATE")) \
        .withColumn("Country_Name", lit("United States")) \
        .withColumn("County_FIPS_Code", lit(None)) \
        .withColumn("County_Name", lit(None)) \
        .withColumn("State_FIPS_Code", col("State_FIPS_Code")) \
        .withColumn("State_Name", col("State_Name")) \
        .withColumn("Core_Based_Statistical_Area_Code", lit(None)) \
        .withColumn("Core_Based_Statistical_Area_Name", lit(None)) \
        .withColumn("Minor_Civil_Division_Code", lit(None)) \
        .withColumn("Minor_Civil_Division_Name", lit(None)) \
        .withColumn("Place_Code", lit(None)) \
        .withColumn("Place_Name", lit(None)) \
        .withColumn("School_District_Code", lit(None)) \
        .withColumn("School_District_Name", lit(None)) \
        .withColumn("Longitude", lit(None)) \
        .withColumn("Latitude", lit(None)) \
        .withColumn("Reference_Data_Source", lit("Manual")) \
        .withColumn("Data_Point_Year", col("year")) \
        .withColumn("Data_Point_Quarter", col("quarter")) \
        .withColumn("Geography_Level", col("geo_level")) \
        .withColumn("Data_Point_Source", lit(dpfile_table)) \
        .withColumn("Data_Point_Attribute", col("mnemonic")) \
        .withColumn("Data_Point_Attribute_Name", col("Variable_Desc")) \
        .withColumn("Data_Point_Attribute_Short_Description", col("Short_Variable_Desc")) \
        .withColumn("Data_Point_Value", col("value")) \
        .withColumn("Data_Point_Data_Type", col("DE_Data_Type")) \
        .withColumn("Data_Point_Period_Type", when(col("quarter") == 0, "Annual").otherwise("Quarterly")) \
        .withColumn("Data_Point_Period_Name",
                    when(col("quarter") == 0, "Annual")
                    .when(col("quarter") == 1, "First Quarter")
                    .when(col("quarter") == 2, "Second Quarter")
                    .when(col("quarter") == 3, "Third Quarter")
                    .when(col("quarter") == 4, "Fourth Quarter")) \
        .withColumn("Data_Point_Period_End_Date",
                    to_date(concat_ws("-",
                                      when(col("quarter") == 0, "12").when(col("quarter") == 1, "03")
                                      .when(col("quarter") == 2, "06").when(col("quarter") == 3, "09")
                                      .otherwise("12"),
                                      when(col("quarter") == 0, "31").when(col("quarter") == 1, "31")
                                      .when(col("quarter") == 2, "30").when(col("quarter") == 3, "30")
                                      .otherwise("31"),
                                      col("year").cast("string")
                                      ), "MM-dd-yyyy")) \
        .withColumn("Start_Dttm", current_timestamp()) \
        .withColumn("End_Dttm", to_date(lit("9999-12-31"))) \
        .withColumn("Current_Ind", lit("Y")) \
        .withColumn("Create_User_Id", lit(created_by)) \
        .withColumn("Create_Dttm", current_timestamp()) \
        .withColumn("Last_Update_User_Id", lit(None)) \
        .withColumn("Last_Update_Dttm", lit(None)) \
        .withColumn("Source_Filename", col("dp.Source_Filename"))

    # Apply SCD Type 2 merge to target table
    apply_scd_type_2(
        source_df=result_df,
        target_table=target_table,
        business_keys=[
            "Geography_Unit_Code", "Geography_Type",
            "Data_Point_Year", "Data_Point_Quarter",
            "Data_Point_Attribute"
        ],
        hash_columns=[
        "Data_Point_Value",
        "Data_Point_Attribute_Name",
        "Data_Point_Data_Type",
        "Geography_Level",
        "Data_Point_Attribute_Short_Description",
        "State_FIPS_Code",
        "State_Name"
    ],
        created_by=created_by
    )



def curate_school_district_level_data(
    dpfile_table: str,
    dataelement_table: str,
    school_xref_table: str,
    county_xref_table: str,
    target_table: str,
    created_by: str,
    data_filenames: List[str],
    school_ref_filenames: List[str],
    county_ref_filenames: List[str]
):

    # Filtered source data
    dp_df = spark.table(dpfile_table).filter(col("Source_Filename").isin(data_filenames))
    de_df = spark.table(dataelement_table)
    sch_xref_df = spark.table(school_xref_table).filter(col("Source_Filename").isin(school_ref_filenames))
    cty_xref_df = spark.table(county_xref_table).filter(col("Source_Filename").isin(county_ref_filenames))

    if dp_df.rdd.isEmpty() or sch_xref_df.rdd.isEmpty() or cty_xref_df.rdd.isEmpty():
        logger.info(f"Skipping school district curation due to empty input. "
                    f"Data: {data_filenames}, School XREF: {school_ref_filenames}, County XREF: {county_ref_filenames}")
        return

    # Rename to avoid column conflicts
    de_df_renamed = de_df.withColumnRenamed("Source_Filename", "de_Source_Filename")

    # Enrich with data element descriptions
    joined_df = dp_df.alias("dp").join(
        de_df_renamed.alias("de"),
        col("dp.MNEMONIC") == col("de.VAR_CODE"),
        "left"
    ).drop("de.de_Source_Filename")

    # Enrich with school district info (school_xref)
    # Alias school_xref select block
    sch_xref_select = sch_xref_df.selectExpr(
        "SCHOOL_DISTRICT_CODE as School_District_Code",
        "SCHOOL_DISTRICT_NAME as School_District_Name",
        "CBS_AREA_CODE as CBSA_Code",
        "LONGITUDE as Longitude",
        "LATITUDE as Latitude"
    ).alias("sx")

    # Join with alias and qualified column names
    joined_df = joined_df.join(
        sch_xref_select,
        col("dp.School_District_Code") == col("sx.School_District_Code"),
        "left"
    ).drop(col("sx.School_District_Code"))
    

    # Enrich with county/state info (county_xref)
    # Alias county_xref select block
    cty_xref_select = cty_xref_df.selectExpr(
        "COUNTY_FIPS_CODE as County_FIPS_Code",
        "COUNTY_NAME as County_Name",
        "STATE_FIPS_CODE as State_FIPS_Code_Lookup",
        "STATE_NAME as State_Name",
        "CBS_AREA_CODE as CBSA_Code_Lookup",
        "CBS_AREA_NAME as Core_Based_Statistical_Area_Name"
    ).dropDuplicates(["County_FIPS_Code"]).alias("cx")

    # Join with alias and qualified column names
    joined_df = joined_df.join(
        cty_xref_select,
        col("dp.County_FIPS_Code") == col("cx.County_FIPS_Code"),
        "left"
    ).drop(col("cx.County_FIPS_Code"))

    # Derive final DataFrame
    result_df = joined_df \
    .withColumn("Geography_Unit_Code", col("dp.School_District_Code")) \
    .withColumn("Geography_Type", lit("SCHOOL DISTRICT")) \
    .withColumn("Country_Name", lit("United States")) \
    .withColumn("County_FIPS_Code", col("dp.County_FIPS_Code")) \
    .withColumn("County_Name", col("cx.County_Name")) \
    .withColumn("State_FIPS_Code", col("dp.State_FIPS_Code")) \
    .withColumn("State_Name", col("cx.State_Name")) \
    .withColumn("Core_Based_Statistical_Area_Code", col("sx.CBSA_Code")) \
    .withColumn("Core_Based_Statistical_Area_Name", col("cx.Core_Based_Statistical_Area_Name")) \
    .withColumn("Minor_Civil_Division_Code", lit(None)) \
    .withColumn("Minor_Civil_Division_Name", lit(None)) \
    .withColumn("Place_Code", lit(None)) \
    .withColumn("Place_Name", lit(None)) \
    .withColumn("School_District_Code", col("dp.School_District_Code")) \
    .withColumn("School_District_Name", col("sx.School_District_Name")) \
    .withColumn("Longitude", col("sx.Longitude")) \
    .withColumn("Latitude", col("sx.Latitude")) \
    .withColumn("Reference_Data_Source", lit(f"{school_xref_table} - {county_xref_table}")) \
    .withColumn("Data_Point_Year", col("dp.year")) \
    .withColumn("Data_Point_Quarter", col("dp.quarter")) \
    .withColumn("Geography_Level", col("dp.geo_level")) \
    .withColumn("Data_Point_Source", lit(dpfile_table)) \
    .withColumn("Data_Point_Attribute", col("dp.mnemonic")) \
    .withColumn("Data_Point_Attribute_Name", col("de.Variable_Desc")) \
    .withColumn("Data_Point_Attribute_Short_Description", col("de.Short_Variable_Desc")) \
    .withColumn("Data_Point_Value", col("dp.value")) \
    .withColumn("Data_Point_Data_Type", col("de.DE_Data_Type")) \
    .withColumn("Data_Point_Period_Type", when(col("dp.quarter") == 0, "Annual").otherwise("Quarterly")) \
    .withColumn("Data_Point_Period_Name",
                when(col("dp.quarter") == 0, "Annual")
                .when(col("dp.quarter") == 1, "First Quarter")
                .when(col("dp.quarter") == 2, "Second Quarter")
                .when(col("dp.quarter") == 3, "Third Quarter")
                .when(col("dp.quarter") == 4, "Fourth Quarter")) \
    .withColumn("Data_Point_Period_End_Date",
                to_date(concat_ws("-",
                                  when(col("dp.quarter") == 0, "12").when(col("dp.quarter") == 1, "03")
                                  .when(col("dp.quarter") == 2, "06").when(col("dp.quarter") == 3, "09")
                                  .otherwise("12"),
                                  when(col("dp.quarter") == 0, "31").when(col("dp.quarter") == 1, "31")
                                  .when(col("dp.quarter") == 2, "30").when(col("dp.quarter") == 3, "30")
                                  .otherwise("31"),
                                  col("dp.year").cast("string")
                                  ), "MM-dd-yyyy")) \
    .withColumn("Start_Dttm", current_timestamp()) \
    .withColumn("End_Dttm", to_date(lit("9999-12-31"))) \
    .withColumn("Current_Ind", lit("Y")) \
    .withColumn("Create_User_Id", lit(created_by)) \
    .withColumn("Create_Dttm", current_timestamp()) \
    .withColumn("Last_Update_User_Id", lit(None)) \
    .withColumn("Last_Update_Dttm", lit(None)) \
    .withColumn("Source_Filename", col("dp.Source_Filename"))


    # Apply SCD Type 2 Merge
    apply_scd_type_2(
        source_df=result_df,
        target_table=target_table,
        business_keys=[
            "Geography_Unit_Code", "Geography_Type",
            "Data_Point_Year", "Data_Point_Quarter",
            "Data_Point_Attribute"
        ],
        hash_columns=[
            "Data_Point_Value",
            "Data_Point_Attribute_Name",
            "Data_Point_Data_Type",
            "Geography_Level",
            "Data_Point_Attribute_Short_Description",
            "State_FIPS_Code",
            "State_Name",
            "County_FIPS_Code",
            "County_Name",
            "School_District_Name",
            "Longitude",
            "Latitude"
        ],
        created_by=created_by
    )






def curate_mcd_level_data(
    dpfile_table: str,
    dataelement_table: str,
    mcd_xref_table: str,
    target_table: str,
    created_by: str,
    data_filenames: List[str],
    xref_filenames: List[str]
):

    # Load and filter source and reference tables
    dp_df = spark.table(dpfile_table).filter(col("Source_Filename").isin(data_filenames))
    de_df = spark.table(dataelement_table)
    mcd_ref_df = spark.table(mcd_xref_table).filter(col("Source_Filename").isin(xref_filenames))

    if dp_df.rdd.isEmpty() or mcd_ref_df.rdd.isEmpty():
        logger.info(f"Skipping MCD-level curation due to empty input. "
                    f"Data files: {data_filenames}, XREF files: {xref_filenames}")
        return

    # Rename to avoid duplicate Source_Filename column in data element table
    de_df_renamed = de_df.withColumnRenamed("Source_Filename", "de_Source_Filename")


    # Enrich with data element descriptions
    joined_df = dp_df.alias("dp").join(
        de_df_renamed.alias("de"),
        col("dp.MNEMONIC") == col("de.VAR_CODE"),
        "left"
    ).drop("de.de_Source_Filename")

    # Join with MCD reference data using provided column names
    joined_df = joined_df.join(
        mcd_ref_df.selectExpr(
            "MCD_CODE as ref_mcd_code",
            "COUNTY_FIPS_CODE as ref_county_fips",
            "COUNTY_NAME as County_Name",
            "STATE_FIPS_CODE as ref_state_fips",
            "STATE_NAME as State_Name",
            "CBS_AREA_CODE as Core_Based_Statistical_Area_Code",
            "CBS_AREA_NAME as Core_Based_Statistical_Area_Name",
            "MCD_NAME as Minor_Civil_Division_Name",
            "PLACE_CODE as Place_Code",
            "PLACE_NAME as Place_Name"
        ),
        (col("dp.MCD_CODE") == col("ref_mcd_code")) &
        (col("dp.COUNTY_FIPS_CODE") == col("ref_county_fips")) &
        (col("dp.STATE_FIPS_CODE") == col("ref_state_fips")),
        "left"
    )

    # Build the final DataFrame
    result_df = joined_df \
        .withColumn("Geography_Unit_Code", col("dp.MCD_CODE")) \
        .withColumn("Geography_Type", lit("MINOR CIVIL DIVISION")) \
        .withColumn("Country_Name", lit("United States")) \
        .withColumn("County_FIPS_Code", col("dp.COUNTY_FIPS_CODE")) \
        .withColumn("County_Name", col("County_Name")) \
        .withColumn("State_FIPS_Code", col("dp.STATE_FIPS_CODE")) \
        .withColumn("State_Name", col("State_Name")) \
        .withColumn("Core_Based_Statistical_Area_Code", col("Core_Based_Statistical_Area_Code")) \
        .withColumn("Core_Based_Statistical_Area_Name", col("Core_Based_Statistical_Area_Name")) \
        .withColumn("Minor_Civil_Division_Code", col("dp.MCD_CODE")) \
        .withColumn("Minor_Civil_Division_Name", col("Minor_Civil_Division_Name")) \
        .withColumn("Place_Code", col("Place_Code")) \
        .withColumn("Place_Name", col("Place_Name")) \
        .withColumn("School_District_Code", lit(None)) \
        .withColumn("School_District_Name", lit(None)) \
        .withColumn("Longitude", lit(None)) \
        .withColumn("Latitude", lit(None)) \
        .withColumn("Reference_Data_Source", lit(mcd_xref_table)) \
        .withColumn("Data_Point_Year", col("dp.YEAR").cast("int")) \
        .withColumn("Data_Point_Quarter", col("dp.QUARTER").cast("int")) \
        .withColumn("Geography_Level", col("dp.GEO_LEVEL")) \
        .withColumn("Data_Point_Source", lit(dpfile_table)) \
        .withColumn("Data_Point_Attribute", col("dp.MNEMONIC")) \
        .withColumn("Data_Point_Attribute_Name", col("Variable_Desc")) \
        .withColumn("Data_Point_Attribute_Short_Description", col("Short_Variable_Desc")) \
        .withColumn("Data_Point_Value", col("dp.VALUE")) \
        .withColumn("Data_Point_Data_Type", col("DE_Data_Type")) \
        .withColumn("Data_Point_Period_Type", when(col("dp.QUARTER") == 0, "Annual").otherwise("Quarterly")) \
        .withColumn("Data_Point_Period_Name",
                    when(col("dp.QUARTER") == 0, "Annual")
                    .when(col("dp.QUARTER") == 1, "First Quarter")
                    .when(col("dp.QUARTER") == 2, "Second Quarter")
                    .when(col("dp.QUARTER") == 3, "Third Quarter")
                    .when(col("dp.QUARTER") == 4, "Fourth Quarter")) \
        .withColumn("Data_Point_Period_End_Date",
                    to_date(concat_ws("-",
                                      when(col("dp.QUARTER") == 0, "12").when(col("dp.QUARTER") == 1, "03")
                                      .when(col("dp.QUARTER") == 2, "06").when(col("dp.QUARTER") == 3, "09")
                                      .otherwise("12"),
                                      when(col("dp.QUARTER") == 0, "31").when(col("dp.QUARTER") == 1, "31")
                                      .when(col("dp.QUARTER") == 2, "30").when(col("dp.QUARTER") == 3, "30")
                                      .otherwise("31"),
                                      col("dp.YEAR").cast("string")
                                      ), "MM-dd-yyyy")) \
        .withColumn("Start_Dttm", current_timestamp()) \
        .withColumn("End_Dttm", to_date(lit("9999-12-31"))) \
        .withColumn("Current_Ind", lit("Y")) \
        .withColumn("Create_User_Id", lit(created_by)) \
        .withColumn("Create_Dttm", current_timestamp()) \
        .withColumn("Last_Update_User_Id", lit(None)) \
        .withColumn("Last_Update_Dttm", lit(None)) \
        .withColumn("Source_Filename", col("dp.SOURCE_FILENAME"))

    # Apply SCD Type 2 merge
    apply_scd_type_2(
        source_df=result_df,
        target_table=target_table,
        business_keys=[
            "Geography_Unit_Code", "Geography_Type",
            "Data_Point_Year", "Data_Point_Quarter",
            "Data_Point_Attribute"
        ],
        hash_columns=[
            "Data_Point_Value",
            "Data_Point_Attribute_Name",
            "Data_Point_Data_Type",
            "Geography_Level",
            "Data_Point_Attribute_Short_Description",
            "State_FIPS_Code",
            "State_Name",
            "County_FIPS_Code",
            "County_Name",
            "Minor_Civil_Division_Name",
            "Core_Based_Statistical_Area_Code",
            "Core_Based_Statistical_Area_Name",
            "Place_Code",
            "Place_Name"
        ],
        created_by=created_by
    )



def curate_county_level_data(
    dpfile_table: str,
    dataelement_table: str,
    county_xref_table: str,
    target_table: str,
    created_by: str,
    data_filenames: list,
    ref_filenames: list
):

    # Load and filter source tables
    dp_df = spark.table(dpfile_table).filter(col("Source_Filename").isin(data_filenames))
    de_df = spark.table(dataelement_table)
    cty_ref_df = spark.table(county_xref_table).filter(col("Source_Filename").isin(ref_filenames))

    # Rename to avoid column name conflicts
    de_df_renamed = de_df.withColumnRenamed("Source_Filename", "de_Source_Filename")

    # Join with data element descriptions
    joined_df = dp_df.alias("dp").join(
        de_df_renamed.alias("de"),
        col("dp.MNEMONIC") == col("de.VAR_CODE"),
        "left"
    ).drop("de.de_Source_Filename")

    # Join with county reference data using updated columns
    joined_df = joined_df.join(
        cty_ref_df.selectExpr(
            "COUNTY_FIPS_CODE as ref_county_fips",
            "STATE_FIPS_CODE as ref_state_fips",
            "COUNTY_NAME as County_Name",
            "STATE_NAME as State_Name",
            "CBS_AREA_CODE as Core_Based_Statistical_Area_Code",
            "CBS_AREA_NAME as Core_Based_Statistical_Area_Name"
        ),
        (col("dp.COUNTY_FIPS_CODE") == col("ref_county_fips")) &
        (col("dp.STATE_FIPS_CODE") == col("ref_state_fips")),
        "left"
    )

    # Build final DataFrame
    result_df = joined_df \
        .withColumn("Geography_Unit_Code", col("dp.COUNTY_FIPS_CODE")) \
        .withColumn("Geography_Type", lit("COUNTY")) \
        .withColumn("Country_Name", lit("United States")) \
        .withColumn("County_FIPS_Code", col("dp.COUNTY_FIPS_CODE")) \
        .withColumn("County_Name", col("County_Name")) \
        .withColumn("State_FIPS_Code", col("dp.STATE_FIPS_CODE")) \
        .withColumn("State_Name", col("State_Name")) \
        .withColumn("Core_Based_Statistical_Area_Code", col("Core_Based_Statistical_Area_Code")) \
        .withColumn("Core_Based_Statistical_Area_Name", col("Core_Based_Statistical_Area_Name")) \
        .withColumn("Minor_Civil_Division_Code", lit(None)) \
        .withColumn("Minor_Civil_Division_Name", lit(None)) \
        .withColumn("Place_Code", lit(None)) \
        .withColumn("Place_Name", lit(None)) \
        .withColumn("School_District_Code", lit(None)) \
        .withColumn("School_District_Name", lit(None)) \
        .withColumn("Longitude", lit(None)) \
        .withColumn("Latitude", lit(None)) \
        .withColumn("Reference_Data_Source", lit(county_xref_table)) \
        .withColumn("Data_Point_Year", col("dp.YEAR").cast("int")) \
        .withColumn("Data_Point_Quarter", col("dp.QUARTER").cast("int")) \
        .withColumn("Geography_Level", col("dp.GEO_LEVEL")) \
        .withColumn("Data_Point_Source", lit(dpfile_table)) \
        .withColumn("Data_Point_Attribute", col("dp.MNEMONIC")) \
        .withColumn("Data_Point_Attribute_Name", col("Variable_Desc")) \
        .withColumn("Data_Point_Attribute_Short_Description", col("Short_Variable_Desc")) \
        .withColumn("Data_Point_Value", col("dp.VALUE")) \
        .withColumn("Data_Point_Data_Type", col("DE_Data_Type")) \
        .withColumn("Data_Point_Period_Type", when(col("dp.QUARTER") == 0, "Annual").otherwise("Quarterly")) \
        .withColumn("Data_Point_Period_Name",
                    when(col("dp.QUARTER") == 0, "Annual")
                    .when(col("dp.QUARTER") == 1, "First Quarter")
                    .when(col("dp.QUARTER") == 2, "Second Quarter")
                    .when(col("dp.QUARTER") == 3, "Third Quarter")
                    .when(col("dp.QUARTER") == 4, "Fourth Quarter")) \
        .withColumn("Data_Point_Period_End_Date",
                    to_date(concat_ws("-",
                                      when(col("dp.QUARTER") == 0, "12").when(col("dp.QUARTER") == 1, "03")
                                      .when(col("dp.QUARTER") == 2, "06").when(col("dp.QUARTER") == 3, "09")
                                      .otherwise("12"),
                                      when(col("dp.QUARTER") == 0, "31").when(col("dp.QUARTER") == 1, "31")
                                      .when(col("dp.QUARTER") == 2, "30").when(col("dp.QUARTER") == 3, "30")
                                      .otherwise("31"),
                                      col("dp.YEAR").cast("string")
                                      ), "MM-dd-yyyy")) \
        .withColumn("Start_Dttm", current_timestamp()) \
        .withColumn("End_Dttm", to_date(lit("9999-12-31"))) \
        .withColumn("Current_Ind", lit("Y")) \
        .withColumn("Create_User_Id", lit(created_by)) \
        .withColumn("Create_Dttm", current_timestamp()) \
        .withColumn("Last_Update_User_Id", lit(None)) \
        .withColumn("Last_Update_Dttm", lit(None)) \
        .withColumn("Source_Filename", col("dp.SOURCE_FILENAME"))

    # Apply SCD Type 2 merge
    apply_scd_type_2(
        source_df=result_df,
        target_table=target_table,
        business_keys=[
            "Geography_Unit_Code", "Geography_Type",
            "Data_Point_Year", "Data_Point_Quarter",
            "Data_Point_Attribute"
        ],
        hash_columns=[
            "Data_Point_Value",
            "Data_Point_Attribute_Name",
            "Data_Point_Data_Type",
            "Geography_Level",
            "Data_Point_Attribute_Short_Description",
            "State_FIPS_Code",
            "State_Name",
            "County_FIPS_Code",
            "County_Name",
            "Core_Based_Statistical_Area_Code",
            "Core_Based_Statistical_Area_Name"
        ],
        created_by=created_by
    )





def curate_cbsa_level_data(
    dpfile_table: str,
    dataelement_table: str,
    cbsa_xref_table: str,
    target_table: str,
    created_by: str,
    data_filenames: List[str],
    cbsa_ref_filenames: List[str]
):


    dp_df = spark.table(dpfile_table).filter(col("Source_Filename").isin(data_filenames))
    de_df = spark.table(dataelement_table)
    cbsa_ref_df = spark.table(cbsa_xref_table).filter(col("Source_Filename").isin(cbsa_ref_filenames))

    if dp_df.rdd.isEmpty() or cbsa_ref_df.rdd.isEmpty():
        logger.info(f"Skipping CBSA curation due to empty input. Data: {data_filenames}, XREF: {cbsa_ref_filenames}")
        return


    # Rename to avoid column conflicts
    de_df_renamed = de_df.withColumnRenamed("SOURCE_FILENAME", "de_SOURCE_FILENAME")

    # Join with data element descriptions
    joined_df = dp_df.alias("dp").join(
        de_df_renamed.alias("de"),
        col("dp.MNEMONIC") == col("de.VAR_CODE"),
        "left"
    ).drop("de.de_SOURCE_FILENAME")

    # Join with CBSA reference data
    joined_df = joined_df.join(
        cbsa_ref_df.selectExpr(
            "CBS_AREA_CODE as ref_cbsa_code",
            "STATE_FIPS_CODE as ref_state_fips",
            "STATE_NAME as State_Name",
            "CBS_AREA_NAME as Core_Based_Statistical_Area_Name"
        ),
        (col("dp.GEO_CODE") == col("ref_cbsa_code")) &
        (col("dp.STATE_FIPS_CODE") == col("ref_state_fips")),
        "left"
    )

    # Create Geography Unit Code (geo code + "_" + state fips)
    joined_df = joined_df.withColumn(
        "Geography_Unit_Code", concat(col("dp.GEO_CODE"), lit("_"), col("dp.STATE_FIPS_CODE"))
    )

    # Build the final DataFrame
    result_df = joined_df \
        .withColumn("Geography_Type", lit("CBSA")) \
        .withColumn("Country_Name", lit("United States")) \
        .withColumn("County_FIPS_Code", lit(None)) \
        .withColumn("County_Name", lit(None)) \
        .withColumn("State_FIPS_Code", col("dp.STATE_FIPS_CODE")) \
        .withColumn("State_Name", col("State_Name")) \
        .withColumn("Core_Based_Statistical_Area_Code", col("dp.GEO_CODE")) \
        .withColumn("Core_Based_Statistical_Area_Name", col("Core_Based_Statistical_Area_Name")) \
        .withColumn("Minor_Civil_Division_Code", lit(None)) \
        .withColumn("Minor_Civil_Division_Name", lit(None)) \
        .withColumn("Place_Code", lit(None)) \
        .withColumn("Place_Name", lit(None)) \
        .withColumn("School_District_Code", lit(None)) \
        .withColumn("School_District_Name", lit(None)) \
        .withColumn("Longitude", lit(None)) \
        .withColumn("Latitude", lit(None)) \
        .withColumn("Reference_Data_Source", lit(cbsa_xref_table)) \
        .withColumn("Data_Point_Year", col("dp.YEAR").cast("int")) \
        .withColumn("Data_Point_Quarter", col("dp.QUARTER").cast("int")) \
        .withColumn("Geography_Level", col("dp.GEO_LEVEL")) \
        .withColumn("Data_Point_Source", lit(dpfile_table)) \
        .withColumn("Data_Point_Attribute", col("dp.MNEMONIC")) \
        .withColumn("Data_Point_Attribute_Name", col("Variable_Desc")) \
        .withColumn("Data_Point_Attribute_Short_Description", col("Short_Variable_Desc")) \
        .withColumn("Data_Point_Value", col("dp.VALUE")) \
        .withColumn("Data_Point_Data_Type", col("DE_Data_Type")) \
        .withColumn("Data_Point_Period_Type", when(col("dp.QUARTER") == 0, "Annual").otherwise("Quarterly")) \
        .withColumn("Data_Point_Period_Name",
                    when(col("dp.QUARTER") == 0, "Annual")
                    .when(col("dp.QUARTER") == 1, "First Quarter")
                    .when(col("dp.QUARTER") == 2, "Second Quarter")
                    .when(col("dp.QUARTER") == 3, "Third Quarter")
                    .when(col("dp.QUARTER") == 4, "Fourth Quarter")) \
        .withColumn("Data_Point_Period_End_Date",
                    to_date(concat_ws("-",
                                      when(col("dp.QUARTER") == 0, "12").when(col("dp.QUARTER") == 1, "03")
                                      .when(col("dp.QUARTER") == 2, "06").when(col("dp.QUARTER") == 3, "09")
                                      .otherwise("12"),
                                      when(col("dp.QUARTER") == 0, "31").when(col("dp.QUARTER") == 1, "31")
                                      .when(col("dp.QUARTER") == 2, "30").when(col("dp.QUARTER") == 3, "30")
                                      .otherwise("31"),
                                      col("dp.YEAR").cast("string")
                                      ), "MM-dd-yyyy")) \
        .withColumn("Start_Dttm", current_timestamp()) \
        .withColumn("End_Dttm", to_date(lit("9999-12-31"))) \
        .withColumn("Current_Ind", lit("Y")) \
        .withColumn("Create_User_Id", lit(created_by)) \
        .withColumn("Create_Dttm", current_timestamp()) \
        .withColumn("Last_Update_User_Id", lit(None)) \
        .withColumn("Last_Update_Dttm", lit(None)) \
        .withColumn("Source_Filename", col("dp.SOURCE_FILENAME"))

    # Apply SCD Type 2 merge
    apply_scd_type_2(
        source_df=result_df,
        target_table=target_table,
        business_keys=[
            "Geography_Unit_Code", "Geography_Type",
            "Data_Point_Year", "Data_Point_Quarter",
            "Data_Point_Attribute"
        ],
        hash_columns=[
            "Data_Point_Value",
            "Data_Point_Attribute_Name",
            "Data_Point_Data_Type",
            "Geography_Level",
            "Data_Point_Attribute_Short_Description",
            "State_FIPS_Code",
            "State_Name",
            "Core_Based_Statistical_Area_Code",
            "Core_Based_Statistical_Area_Name"
        ],
        created_by=created_by
    )

def curate_places_level_data(
    dpfile_table: str,
    dataelement_table: str,
    place_xref_table: str,
    target_table: str,
    created_by: str,
    data_filenames: List[str],
    place_ref_filenames: List[str]
):

    # Filter input data based on source filenames
    dp_df = spark.table(dpfile_table).filter(col("Source_Filename").isin(data_filenames))
    de_df = spark.table(dataelement_table)
    place_ref_df = spark.table(place_xref_table).filter(col("Source_Filename").isin(place_ref_filenames))

    # Skip if either DataFrame is empty
    if dp_df.rdd.isEmpty() or place_ref_df.rdd.isEmpty():
        logger.info(f"Skipping PLACES curation due to empty input. "
                    f"Data files: {data_filenames}, Place XREF files: {place_ref_filenames}")
        return

       
    de_df_renamed = de_df.withColumnRenamed("SOURCE_FILENAME", "de_SOURCE_FILENAME")

    # Join with data element descriptions
    joined_df = dp_df.alias("dp").join(
            de_df_renamed.alias("de"),
            col("dp.MNEMONIC") == col("de.VAR_CODE"),
            "left"
        ).drop("de.de_SOURCE_FILENAME")

    # Join with place reference data
    joined_df = joined_df.join(
            place_ref_df.selectExpr(
                "PLACE_CODE as ref_place_code",
                "COUNTY_FIPS_CODE as ref_county_fips",
                "STATE_FIPS_CODE as ref_state_fips",
                "CBS_AREA_CODE as ref_cbs_area_code",
                "CBS_AREA_NAME as ref_cbs_area_name",
                "COUNTY_NAME as ref_County_Name",
                "STATE_NAME as ref_state_name",
                "PLACE_NAME as ref_place_name"
            ),
            (col("dp.PLACE_CODE") == col("ref_place_code")) &
            (col("dp.COUNTY_FIPS_CODE") == col("ref_county_fips")) &
            (col("dp.STATE_FIPS_CODE") == col("ref_state_fips")),
            "left"
        )
        # Build the final DataFrame
    result_df = joined_df \
            .withColumn("Geography_Unit_Code", col("PLACE_CODE")) \
            .withColumn("Geography_Type", lit("PLACE")) \
            .withColumn("Country_Name", lit("United States")) \
            .withColumn("County_FIPS_Code", col("COUNTY_FIPS_CODE")) \
            .withColumn("County_Name", col("ref_County_Name")) \
            .withColumn("State_FIPS_Code", col("STATE_FIPS_CODE")) \
            .withColumn("State_Name", col("ref_state_name")) \
            .withColumn("Core_Based_Statistical_Area_Code", col("ref_cbs_area_code")) \
            .withColumn("Core_Based_Statistical_Area_Name", col("ref_cbs_area_name")) \
            .withColumn("Minor_Civil_Division_Code", lit(None)) \
            .withColumn("Minor_Civil_Division_Name", lit(None)) \
            .withColumn("Place_Code", col("PLACE_CODE")) \
            .withColumn("Place_Name", col("ref_place_name")) \
            .withColumn("School_District_Code", lit(None)) \
            .withColumn("School_District_Name", lit(None)) \
            .withColumn("Longitude", lit(None)) \
            .withColumn("Latitude", lit(None)) \
            .withColumn("Reference_Data_Source", lit(place_xref_table)) \
            .withColumn("Data_Point_Year", col("dp.YEAR").cast("int")) \
            .withColumn("Data_Point_Quarter", col("dp.QUARTER").cast("int")) \
            .withColumn("Geography_Level", col("dp.GEO_LEVEL")) \
            .withColumn("Data_Point_Source", lit(dpfile_table)) \
            .withColumn("Data_Point_Attribute", col("dp.MNEMONIC")) \
            .withColumn("Data_Point_Attribute_Name", col("de.Variable_Desc")) \
            .withColumn("Data_Point_Attribute_Short_Description", col("de.Short_Variable_Desc")) \
            .withColumn("Data_Point_Value", col("dp.VALUE")) \
            .withColumn("Data_Point_Data_Type", col("de.DE_Data_Type")) \
            .withColumn("Data_Point_Period_Type", when(col("dp.QUARTER") == 0, "Annual").otherwise("Quarterly")) \
            .withColumn("Data_Point_Period_Name",
                        when(col("dp.QUARTER") == 0, "Annual")
                        .when(col("dp.QUARTER") == 1, "First Quarter")
                        .when(col("dp.QUARTER") == 2, "Second Quarter")
                        .when(col("dp.QUARTER") == 3, "Third Quarter")
                        .when(col("dp.QUARTER") == 4, "Fourth Quarter")) \
            .withColumn("Data_Point_Period_End_Date",
                        to_date(concat_ws("-",
                                          when(col("dp.QUARTER") == 0, "12").when(col("dp.QUARTER") == 1, "03")
                                          .when(col("dp.QUARTER") == 2, "06").when(col("dp.QUARTER") == 3, "09")
                                          .otherwise("12"),
                                          when(col("dp.QUARTER") == 0, "31").when(col("dp.QUARTER") == 1, "31")
                                          .when(col("dp.QUARTER") == 2, "30").when(col("dp.QUARTER") == 3, "30")
                                          .otherwise("31"),
                                          col("dp.YEAR").cast("string")
                                          ), "MM-dd-yyyy")) \
            .withColumn("Start_Dttm", current_timestamp()) \
            .withColumn("End_Dttm", to_date(lit("9999-12-31"))) \
            .withColumn("Current_Ind", lit("Y")) \
            .withColumn("Create_User_Id", lit(created_by)) \
            .withColumn("Create_Dttm", current_timestamp()) \
            .withColumn("Last_Update_User_Id", lit(None)) \
            .withColumn("Last_Update_Dttm", lit(None)) \
            .withColumn("Source_Filename", col("dp.SOURCE_FILENAME"))


    apply_scd_type_2(
            source_df=result_df,
            target_table=target_table,
            business_keys=[
                "Geography_Unit_Code", "Geography_Type",
                "Data_Point_Year", "Data_Point_Quarter",
                "Data_Point_Attribute"
            ],
            hash_columns=[
                "Data_Point_Value",
                "Data_Point_Attribute_Name",
                "Data_Point_Data_Type",
                "Geography_Level",
                "Data_Point_Attribute_Short_Description",
                "State_FIPS_Code",
                "State_Name",
                "Core_Based_Statistical_Area_Code",
                "Core_Based_Statistical_Area_Name"
            ],
            created_by=created_by
    )

def get_filenames(file_type: str, status_table: str) -> List[str]:
    """
    Returns a list of distinct filenames for a given file_type with RAW_LOADED status.
    """
    status_util = StatusTableUtil(status_table)
    if file_type.endswith("_REFERENCE"):
        # Special handling for Reference Files
        return status_util.get_latest_file(file_type)
    
    df_status = status_util.spark.table(status_table)

    return [row["FILENAME"] for row in df_status
            .filter((col("FILETYPE") == file_type) & (col("status") == EdsStatus.RAW_LOADED.value))
            .select("FILENAME").distinct().collect()]

def raw_to_curation(env, user):
    dataelement_table = f"idf_curated_{env}.eds.t_eds_data_element"
    target_table = f"idf_curated_{env}.eds.t_eds_data_pnt"
    status_table = f"idf_raw_{env}.eds.t_eds_load_status"
    status_util = StatusTableUtil(status_table)
    registry = EDSFileRegistry(f"idf_raw_{env}") 


    for _, config in registry._registry.items():
        file_type = config.file_type
        raw_table = config.raw_table

        if not config.is_data_point:
            continue  # Skip reference files

        data_filenames = get_filenames(file_type, status_table)
        if not data_filenames:
            logger.info(f"No RAW_LOADED files found for {file_type}, skipping.")
            continue

        logger.info(f"Processing file_type={file_type} for files: {data_filenames}")
        ref_filenames = []  # default to avoid UnboundLocalError

        try:
            # COUNTRY
            if file_type == "USA_DATA_POINT":
                curate_country_level_data(raw_table, dataelement_table, target_table, user, data_filenames)

            # STATE
            elif file_type == "STATE_DATA_POINT":
                ref_file_type = registry._registry["CTY_XREF"].file_type
                ref_table = registry._registry["CTY_XREF"].raw_table
                ref_filenames = get_filenames(ref_file_type, status_table)
                logger.info(f"State-level curation will use reference files: {ref_filenames} and file_type: {ref_file_type}")
                curate_state_level_data(raw_table, dataelement_table, ref_table, target_table, user, data_filenames, ref_filenames)

            # SCHOOL DISTRICT
            elif file_type == "SCHOOL_DATA_POINT":
                school_ref_type = registry._registry["SCH_XREF"].file_type
                county_ref_type = registry._registry["CTY_XREF"].file_type
                school_ref_table = registry._registry["SCH_XREF"].raw_table
                county_ref_table = registry._registry["CTY_XREF"].raw_table
                school_ref_filenames = get_filenames(school_ref_type, status_table)
                county_ref_filenames = get_filenames(county_ref_type, status_table)
                ref_filenames = school_ref_filenames + county_ref_filenames
                logger.info(f"School District-level curation will use school reference files: {school_ref_filenames} and county reference files: {county_ref_filenames}")
                curate_school_district_level_data(
                    raw_table, dataelement_table, school_ref_table, county_ref_table,
                    target_table, user, data_filenames, school_ref_filenames, county_ref_filenames
                )

            # MCD
            elif file_type == "MCD_DATA_POINT":
                ref_type = registry._registry["MCD_XREF"].file_type
                ref_table = registry._registry["MCD_XREF"].raw_table
                ref_filenames = get_filenames(ref_type, status_table)
                logger.info(f"MCD-level curation will use reference files: {ref_filenames} and file_type: {ref_type}")
                curate_mcd_level_data(raw_table, dataelement_table, ref_table, target_table, user, data_filenames, ref_filenames)

            # COUNTY
            elif file_type == "COUNTY_DATA_POINT":
                ref_type = registry._registry["CTY_XREF"].file_type
                ref_table = registry._registry["CTY_XREF"].raw_table
                ref_filenames = get_filenames(ref_type, status_table)
                logger.info(f"County-level curation will use reference files: {ref_filenames} and file_type: {ref_type}")
                curate_county_level_data(raw_table, dataelement_table, ref_table, target_table, user, data_filenames, ref_filenames)

            # CBSA
            elif file_type == "CBS_DATA_POINT":
                ref_type = registry._registry["CTY_XREF"].file_type
                ref_table = registry._registry["CTY_XREF"].raw_table
                ref_filenames = get_filenames(ref_type, status_table)
                logger.info(f"CBSA-level curation will use reference files: {ref_filenames} and file_type: {ref_type}")
                curate_cbsa_level_data(raw_table, dataelement_table, ref_table, target_table, user, data_filenames, ref_filenames)

            # PLACES
            elif file_type == "PLACE_DATA_POINT":
                ref_type = registry._registry["PLA_XREF"].file_type
                ref_table = registry._registry["PLA_XREF"].raw_table
                ref_filenames = get_filenames(ref_type, status_table)
                logger.info(f"Places-level curation will use reference files: {ref_filenames} and file_type: {ref_type}")
                curate_places_level_data(raw_table, dataelement_table, ref_table, target_table, user, data_filenames, ref_filenames)

            else:
                logger.warning(f"No handler implemented for file type: {file_type}")
                continue

            # ✅ Update all involved files as CURATED_SUCCESS
            for fname in data_filenames + ref_filenames:
                status_util.update_status(fname, EdsStatus.CURATED_LOADED.value)

        except Exception as e:
            logger.error(f"❌ Error processing file type {file_type}: {str(e)}", exc_info=True)
            