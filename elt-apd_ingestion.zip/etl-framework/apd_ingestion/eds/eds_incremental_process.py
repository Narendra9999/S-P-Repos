import pandas as pd
from datetime import datetime
import chardet
import os
from typing import Dict, List, Optional
from dataclasses import dataclass
import logging
from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.types import DecimalType, TimestampType
from contextlib import contextmanager
from apd_ingestion.utils.s3_utils import S3Utils
from apd_ingestion.eds.eds_utils import StatusTableUtil

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class EDSFileConfig:
    """Configuration for EDS file processing"""
    file_type: str
    widths: List[int]
    columns: List[str]
    raw_table: str
    is_data_point: bool = False

@dataclass
class EDSConfig:
    """Configuration for EDS ingestion processor"""
    aws_env: str = "dev"
    bucket_name: Optional[str] = None
    folder_prefix: str = 'streaming_checkpoint/eds-apd/'
    archive_prefix: str = 'archive'
    spark_app_name: str = "EDS_Ingestion_Processor"
    spark_config: Optional[Dict[str, str]] = None

@dataclass
class EDSProcessingResult:
    """Result of EDS file processing"""
    success: bool
    file_name: str
    file_type: str
    records_processed: int = 0
    error_message: Optional[str] = None
    processing_time_seconds: float = 0.0

class EDSFileRegistry:
    """Registry for EDS file configurations"""
    
    def __init__(self, raw_schema: str):
        self.raw_schema = raw_schema
        self._registry = self._build_registry()
    
    def _build_registry(self) -> Dict[str, EDSFileConfig]:
        """Build the EDS file registry with configurations"""
        return {
            "sch_data_": EDSFileConfig(
                file_type="SCHOOL_DATA_POINT",
                widths=[3, 4, 1, 1, 2, 5, 10, 31],
                columns=["MNEMONIC", "YEAR", "QUARTER", "GEO_LEVEL", "STATE_FIPS_CODE", 
                        "COUNTY_FIPS_CODE", "SCHOOL_DISTRICT_CODE", "VALUE"],
                raw_table=f"{self.raw_schema}.eds.t_eds_sch_data_point",
                is_data_point=True,
            ),
            "usa_data_": EDSFileConfig(
                file_type="USA_DATA_POINT",
                widths=[3, 4, 1, 18, 31],
                columns=["MNEMONIC", "YEAR", "QUARTER", "GEO_LEVEL", "VALUE"],
                raw_table=f"{self.raw_schema}.eds.t_eds_country_data_point",
                is_data_point=True,
            ),
            "sta_data_": EDSFileConfig(
                file_type="STATE_DATA_POINT",
                widths=[3, 4, 1, 1, 17, 31],
                columns=["MNEMONIC", "YEAR", "QUARTER", "GEO_LEVEL", "STATE_FIPS_CODE", "VALUE"],
                raw_table=f"{self.raw_schema}.eds.t_eds_state_data_point",
                is_data_point=True,
            ),
            "CTY_XREF": EDSFileConfig(
                file_type="COUNTY_REFERENCE",
                widths=[5, 32, 2, 32, 5, 32],
                columns=["COUNTY_FIPS_CODE", "COUNTY_NAME", "STATE_FIPS_CODE", 
                        "STATE_NAME", "CBS_AREA_CODE", "CBS_AREA_NAME"],
                raw_table=f"{self.raw_schema}.eds.t_eds_county_reference",
            ),
            "SCH_XREF": EDSFileConfig(
                file_type="SCHOOL_DISTRICT_REFERENCE",
                widths=[9, 90, 2, 5, 5, 10, 10],
                columns=["SCHOOL_DISTRICT_CODE", "SCHOOL_DISTRICT_NAME", "STATE_FIPS_CODE",
                        "COUNTY_FIPS_CODE", "CBS_AREA_CODE", "LONGITUDE", "LATITUDE"],
                raw_table=f"{self.raw_schema}.eds.t_eds_sch_reference",
            ),
            "pla_data_": EDSFileConfig(
                file_type="PLACE_DATA_POINT",
                widths=[3, 4, 1, 1, 2, 5, 10, 31],
                columns=["MNEMONIC", "YEAR", "QUARTER", "GEO_LEVEL", "STATE_FIPS_CODE",
                        "COUNTY_FIPS_CODE", "PLACE_CODE", "VALUE"],
                raw_table=f"{self.raw_schema}.eds.t_eds_place_data_point",
                is_data_point=True,
            ),
            "PLA_XREF": EDSFileConfig(
                file_type="PLACE_REFERENCE",
                widths=[7, 32, 5, 32, 2, 32, 5, 32],
                columns=["PLACE_CODE", "PLACE_NAME", "COUNTY_FIPS_CODE", "COUNTY_NAME",
                        "STATE_FIPS_CODE", "STATE_NAME", "CBS_AREA_CODE", "CBS_AREA_NAME"],
                raw_table=f"{self.raw_schema}.eds.t_eds_place_reference",
            ),
            "mcd_data_": EDSFileConfig(
                file_type="MCD_DATA_POINT",
                widths=[3, 4, 1, 1, 2, 5, 10, 31],
                columns=["MNEMONIC", "YEAR", "QUARTER", "GEO_LEVEL", "STATE_FIPS_CODE",
                        "COUNTY_FIPS_CODE", "MCD_CODE", "VALUE"],
                raw_table=f"{self.raw_schema}.eds.t_eds_mcd_data_point",
                is_data_point=True,
            ),
            "MCD_XREF": EDSFileConfig(
                file_type="MCD_REFERENCE",
                widths=[10, 32, 7, 32, 5, 32, 2, 32, 5, 32],
                columns=["MCD_CODE", "MCD_NAME", "PLACE_CODE", "PLACE_NAME", "COUNTY_FIPS_CODE",
                        "COUNTY_NAME", "STATE_FIPS_CODE", "STATE_NAME", "CBS_AREA_CODE", "CBS_AREA_NAME"],
                raw_table=f"{self.raw_schema}.eds.t_eds_mcd_reference",
            ),
            "cbs_data_": EDSFileConfig(
                file_type="CBS_DATA_POINT",
                widths=[3, 4, 1, 1, 2, 15, 31],
                columns=["MNEMONIC", "YEAR", "QUARTER", "GEO_LEVEL", "STATE_FIPS_CODE", "GEO_CODE", "VALUE"],
                raw_table=f"{self.raw_schema}.eds.t_eds_cbs_data_point",
                is_data_point=True,
            ),
            "cty_data_": EDSFileConfig(
                file_type="COUNTY_DATA_POINT",
                widths=[3, 4, 1, 1, 2, 15, 31],
                columns=["MNEMONIC", "YEAR", "QUARTER", "GEO_LEVEL", "STATE_FIPS_CODE", "COUNTY_FIPS_CODE", "VALUE"],
                raw_table=f"{self.raw_schema}.eds.t_eds_county_data_point",
                is_data_point=True,
            ),
        }
    
    def get_config(self, prefix: str) -> Optional[EDSFileConfig]:
        """Get configuration for a given file prefix"""
        return self._registry.get(prefix)
    
    def get_all_prefixes(self) -> List[str]:
        """Get all registered file prefixes"""
        return list(self._registry.keys())
    
    def detect_prefix(self, filename: str) -> Optional[str]:
        """Detect file prefix from filename"""
        for prefix in self._registry.keys():
            if filename.startswith(prefix):
                return prefix
        return None

class EDSFileUtils:
    """Utility functions for EDS file processing"""
    
    @staticmethod
    def detect_encoding(file_path: str) -> str:
        """Detect file encoding"""
        try:
            with open(file_path, 'rb') as f:
                result = chardet.detect(f.read())
                encoding = result.get('encoding', 'utf-8')
                logger.info(f"Detected encoding for {file_path}: {encoding}")
                return encoding
        except Exception as e:
            logger.warning(f"Error detecting encoding for {file_path}: {str(e)}, using utf-8")
            return 'utf-8'
    
    @staticmethod
    def parse_fixed_width_file(
        file_path: str, 
        field_widths: List[int], 
        column_names: List[str], 
        create_datetime: str, 
        source_filename: str
    ) -> pd.DataFrame:
        """Parse fixed-width file into pandas DataFrame"""
        try:
            encoding = EDSFileUtils.detect_encoding(file_path)
            
            # Try detected encoding first
            try:
                with open(file_path, 'r', encoding=encoding) as file:
                    lines = file.readlines()
            except UnicodeDecodeError:
                logger.warning(f"Failed with {encoding}, trying latin1 encoding")
                with open(file_path, 'r', encoding='latin1') as file:
                    lines = file.readlines()
            
            parsed_rows = []
            for line_num, line in enumerate(lines, 1):
                try:
                    pos = 0
                    row = []
                    for width in field_widths:
                        field = line[pos:pos+width].strip()
                        row.append(field)
                        pos += width
                    
                    # Add metadata columns
                    row.extend([create_datetime, source_filename])
                    parsed_rows.append(row)
                    
                except Exception as e:
                    logger.warning(f"Error parsing line {line_num} in {file_path}: {str(e)}")
                    continue
            
            # Create DataFrame
            all_columns = column_names + ["CREATE_DATETIME", "SOURCE_FILENAME"]
            df = pd.DataFrame(parsed_rows, columns=all_columns)
            
            logger.info(f"Successfully parsed {len(parsed_rows)} rows from {file_path}")
            return df
            
        except Exception as e:
            logger.error(f"Error parsing fixed width file {file_path}: {str(e)}")
            raise
    
    @staticmethod
    def apply_data_transformations(spark_df: DataFrame, is_data_point: bool = False) -> DataFrame:
        """Apply data type transformations to Spark DataFrame"""
        try:
            # Apply transformations based on file type
            if is_data_point:
                spark_df = spark_df.withColumn("VALUE", spark_df["VALUE"].cast(DecimalType(31, 14)))
            
            # Apply timestamp transformation
            spark_df = spark_df.withColumn("CREATE_DATETIME", spark_df["CREATE_DATETIME"].cast(TimestampType()))
            
            return spark_df
            
        except Exception as e:
            logger.error(f"Error applying data transformations: {str(e)}")
            raise



class EDSIngestionProcessor:
    """Main processor for EDS file ingestion"""
    
    def __init__(
        self, 
        config: EDSConfig
    ):
        self.config = config
        
        # Extract fields from config
        self.aws_env = config.aws_env
        self.bucket_name = config.bucket_name
        self.folder_prefix = config.folder_prefix
        self.archive_prefix = config.archive_prefix
        
        # Create Spark session internally
        self.spark = self._create_spark_session()
        
        # Initialize components
        self.raw_schema = f"idf_raw_{self.aws_env}"
        self.file_registry = EDSFileRegistry(self.raw_schema)
        self.s3_manager = EDSS3Manager(self.bucket_name, self.folder_prefix, self.archive_prefix)
        
        # Status utility for tracking loaded files
        status_table = f"{self.raw_schema}.eds.t_eds_load_status"
        self.status_util = StatusTableUtil(status_table)
    
    def _create_spark_session(self) -> SparkSession:
        """Create and configure Spark session based on config"""
        builder = SparkSession.builder.appName(self.config.spark_app_name)
        spark = builder.getOrCreate()

        return spark
    
    @contextmanager
    def temporary_file(self, filename: str):
        """Context manager for temporary file handling"""
        try:
            yield filename
        finally:
            if os.path.exists(filename):
                os.remove(filename)
                logger.info(f"Cleaned up temporary file: {filename}")
    
    def process_single_file(self, file_key: str) -> EDSProcessingResult:
        """Process a single EDS file"""
        start_time = datetime.now()
        local_filename = os.path.basename(file_key)
        
        try:
            # Check if file already loaded (if status utility is available)
            if self.status_util and self.status_util.is_file_loaded(local_filename):
                logger.info(f"File {local_filename} already loaded, skipping")
                return EDSProcessingResult(
                    success=True,
                    file_name=local_filename,
                    file_type="ALREADY_LOADED",
                    processing_time_seconds=0.0
                )
            
            # Detect file configuration
            prefix = self.file_registry.detect_prefix(local_filename)
            config = self.file_registry.get_config(prefix)
            
            if not config:
                error_msg = f"Unknown file prefix: {prefix}"
                logger.error(error_msg)
                return EDSProcessingResult(
                    success=False,
                    file_name=local_filename,
                    file_type="UNKNOWN",
                    error_message=error_msg
                )
            
            with self.temporary_file(local_filename):
                # Download file
                self.s3_manager.download_file(file_key, local_filename)
                
                # Parse file
                create_datetime = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                df = EDSFileUtils.parse_fixed_width_file(
                    local_filename,
                    config.widths,
                    config.columns,
                    create_datetime,
                    local_filename
                )
                
                # Load to raw table
                records_processed = self._load_to_raw_table(df, config)
                
                # Move to archive
                self.s3_manager.move_to_archive(file_key)
                
                processing_time = (datetime.now() - start_time).total_seconds()
                
                logger.info(f"✅ Successfully processed: {local_filename}")
                return EDSProcessingResult(
                    success=True,
                    file_name=local_filename,
                    file_type=config.file_type,
                    records_processed=records_processed,
                    processing_time_seconds=processing_time
                )
                
        except Exception as e:
            processing_time = (datetime.now() - start_time).total_seconds()
            error_msg = f"Error processing {file_key}: {str(e)}"
            logger.error(error_msg)
            
            return EDSProcessingResult(
                success=False,
                file_name=local_filename,
                file_type="ERROR",
                error_message=error_msg,
                processing_time_seconds=processing_time
            )
    
    def _load_to_raw_table(self, df: pd.DataFrame, config: EDSFileConfig) -> int:
        """Load DataFrame to raw table"""
        try:
            file_name = df["SOURCE_FILENAME"].iloc[0]
            
            # Convert to Spark DataFrame
            spark_df = self.spark.createDataFrame(df)
            
            # Apply transformations
            spark_df = EDSFileUtils.apply_data_transformations(spark_df, config.is_data_point)
            
            # Write to Delta table
            spark_df.write.format("delta").mode("append").saveAsTable(config.raw_table)
            
            # Update status (if status utility is available)
            if self.status_util:
                self.status_util.insert_status(file_name, config.file_type)
            
            records_count = len(df)
            logger.info(f"Loaded {records_count} records to {config.raw_table}")
            
            return records_count
            
        except Exception as e:
            logger.error(f"Error loading to raw table: {str(e)}")
            raise
    
    def process_all_files(self) -> List[EDSProcessingResult]:
        """Process all EDS files in S3 bucket"""
        try:
            # Get list of files to process
            file_prefixes = self.file_registry.get_all_prefixes()
            files_to_process = self.s3_manager.list_files(file_prefixes)
            
            logger.info(f"Processing {len(files_to_process)} files")
            
            results = []
            for file_key in files_to_process:
                result = self.process_single_file(file_key)
                results.append(result)
            
            # Summary
            successful = sum(1 for r in results if r.success)
            failed = len(results) - successful
            total_records = sum(r.records_processed for r in results if r.success)
            
            logger.info(f"Processing complete: {successful} successful, {failed} failed, {total_records} total records")
            
            return results
            
        except Exception as e:
            logger.error(f"Error in process_all_files: {str(e)}")
            raise

class EDSS3Manager:
    """EDS-specific S3 manager that wraps S3Utils for backward compatibility"""
    
    def __init__(self, bucket_name: str, folder_prefix: str, archive_prefix: str = 'archive'):
        self.bucket_name = bucket_name
        self.folder_prefix = folder_prefix
        self.archive_prefix = archive_prefix
        self.s3_utils = S3Utils(bucket_name)
    
    def list_files(self, file_prefixes: List[str]) -> List[str]:
        """List all .DAT files in S3 bucket that match given prefixes"""
        return self.s3_utils.list_files(
            folder_prefix=self.folder_prefix,
            file_extensions=['.DAT'],
            file_prefixes=file_prefixes
        )
    
    def download_file(self, file_key: str, local_filename: str) -> None:
        """Download file from S3 to local filesystem"""
        return self.s3_utils.download_file(file_key, local_filename)
    
    def move_to_archive(self, source_key: str) -> None:
        """Move file to archive folder in S3"""
        self.s3_utils.move_to_archive(source_key, self.archive_prefix)
