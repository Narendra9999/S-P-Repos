"""
Job processor for non-streaming ETL jobs.
"""

import logging
from typing import Dict, Any, Optional
from apd_ingestion.config.config_manager import get_config_value
import importlib

class JobProcessor:
    """
    Processor for batch/non-streaming ETL jobs.
    """
    
    def __init__(self, job_name: str, environment: str):
        """Initialize job processor for the given job."""
        self.job_name = job_name
        self.environment = environment
        self.logger = logging.getLogger(f"JobProcessor.{job_name}")
        
        # Load job configuration
        self.job_config = self._load_job_config()
        self._validate_job_configuration()
        
        self.logger.info(f"Initialized {job_name} job for {environment}")
    
    def _load_job_config(self) -> Dict[str, Any]:
        """Load job configuration from YAML files."""
        self.logger.info(f"Loading job config for '{self.job_name}'")
        
        job_config = get_config_value(f'jobs.{self.job_name}', {})
        if not job_config:
            self.logger.error(f"No configuration found for job '{self.job_name}'")
            raise ValueError(f"No configuration found for job '{self.job_name}'. Please add it to jobs.{self.job_name} in application.yaml")
        
        # Merge with defaults if available
        defaults = get_config_value('jobs.defaults', {})
        merged = defaults.copy()
        merged.update(job_config)
        
        self.logger.info(f"Job config loaded for '{self.job_name}': {merged}")
        return merged
    
    def _validate_job_configuration(self):
        """Validate that all required configuration is present."""
        self.logger.info(f"Validating configuration for job '{self.job_name}'")
        
        # Validate handler class exists
        handler_class_name = self.job_config.get('handler_class')
        if not handler_class_name:
            self.logger.error("'handler_class' must be specified in job config.")
            raise ValueError("'handler_class' must be specified in job config.")
        
        self.logger.info("Job configuration validation passed")
    
    def run(self, **kwargs):
        """
        Run the job.
        
        Args:
            **kwargs: Additional arguments for the job
        """
        try:
            self.logger.info(f"Starting job: {self.job_name}")
            handler_class_name = self.job_config.get('handler_class')
            self.logger.info(f"Loading handler: {handler_class_name}")

            
            handler_module = importlib.import_module("apd_ingestion.jobs.handlers")
            handler_class = getattr(handler_module, handler_class_name)
            handler_instance = handler_class(self.job_config, self.environment)

            # Call the handler's handle method
            handler_instance.handle(**kwargs)

            self.logger.info(f"Job {self.job_name} completed successfully")
        except Exception as e:
            self.logger.error(f"Job {self.job_name} failed: {e}")
            raise
    
    def _process_job(self, **kwargs):
        """Process the job with provided arguments."""
        self.logger.info(f"Processing job with args: {kwargs}")
        # Implement job processing logic here
        # This is where you would call your specific job handler
