"""
Jobs module for non-streaming ETL processes.
"""

from .job_processor import JobProcessor

__all__ = ['JobProcessor']
