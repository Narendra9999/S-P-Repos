from .base_handler import BaseJobHandler
from apd_ingestion.ihs.IHS_MAIN import run_etl
from apd_ingestion.ihs.IHS_MNEMONICMAPPING import run_load_ecr_mnemonicmapping
from apd_ingestion.ihs.IHS_PROC_LOG import run_proc_log
from apd_ingestion.ihs.IHS_JSON_TO_APD import main
from datetime import datetime
class IhsBatchJobHandler(BaseJobHandler):
    """
    Handler for the IHS batch job pipeline.
    """
    def handle(self, **kwargs):
        process_name = kwargs.get("process_name")
        run_type=kwargs.get("run_type")
        start_date= kwargs.get("start_date")

        if start_date:
            if "T" not in start_date:
                start_date = f"{start_date}T00:00:00.000"
            else:
                print(" No start date is passed as an argument")

                
        user_name = self.config.get("user_name")
        self.logger.info(f"Handling job for pipeline: {self.config} with args: {kwargs}")

        process_map = {
            "IHS_MAIN": lambda: run_etl(user_name, self.environment,run_type,start_date),
            "IHS_MNEMONICMAPPING": lambda: run_load_ecr_mnemonicmapping(self.environment, user_name,run_type,start_date),
            "IHS_PROC_LOG": lambda: run_proc_log(self.environment, user_name,run_type,start_date),
            "IHS_JSON_TO_APD": lambda: main(self.environment, user_name,run_type,start_date),
        }

        func = process_map.get(process_name)
        if func:
            self.logger.info(f"Running {process_name} logic in {self.environment} for user {user_name}...")
            func()
        else:
            self.logger.warning(f"Unknown PROCESS_NAME: {process_name}")

        return f"Job {self.config.get('name')} handled by IhsBatchJobHandler"
