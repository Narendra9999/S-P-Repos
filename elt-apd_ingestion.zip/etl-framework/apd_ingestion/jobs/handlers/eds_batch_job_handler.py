from .base_handler import BaseJobHandler
from apd_ingestion.eds.EDS_CURATION import raw_to_curation
from apd_ingestion.eds.EDS_DATA_PROCESSOR import load_eds_pipeline
from apd_ingestion.eds.EDS_ZERO_DAY import load_eds_zero_day
from apd_ingestion.eds.eds_incremental_process import EDSIngestionProcessor, EDSConfig

class EdsBatchJobHandler(BaseJobHandler):
    """
    Handler for the IHS batch job pipeline.
    """
    def handle(self, **kwargs):
        process_name = kwargs.get("process_name")
        run_type=kwargs.get("run_type")
        filter_conditions= kwargs.get("filter_conditions")
        load_types= kwargs.get("load_types")
        # start_date= kwargs.get("start_date")
        #
        # if start_date:
        #     if "T" not in start_date:
        #         start_date = f"{start_date}T00:00:00.000"
        #     else:
        #         print(" No start date is passed as an argument")

        user_name = self.config.get("user_name")
        self.logger.info(f"Handling job for pipeline: {self.config} with args: {kwargs}")

        def run_eds_incremental_raw():
            eds_config = EDSConfig(
                aws_env=self.environment,
                bucket_name=self.config.get("bucket_name"),
                folder_prefix=self.config.get("folder_prefix"),
                archive_prefix=self.config.get("archive_prefix"),
            )
            self.logger.info(f"EDS Configs are: {eds_config}")
            processor = EDSIngestionProcessor(eds_config)
            results = processor.process_all_files()
            successful = sum(1 for r in results if r.success)
            failed = len(results) - successful
            total_records = sum(r.records_processed for r in results if r.success)
            self.logger.info(f"EDS Raw processing completed: {successful} successful, {failed} failed, {total_records} total records")
        
        def run_eds_pipeline():
            process_table_name = self.config.get("process_table_name")
            load_eds_pipeline(self.environment, filter_conditions, run_type, user_name, process_table_name)

        process_map = {
            "EDS_JSON_TO_APD": run_eds_pipeline,
            "EDS_INCREMENTAL_CURATION": lambda: raw_to_curation(self.environment, user_name),
            "EDS_INCREMENTAL_RAW": run_eds_incremental_raw,
            "EDS_ZERO_DAY": lambda: load_eds_zero_day(self.environment, user_name, load_types),
        }

        func = process_map.get(process_name)
        if func:
            self.logger.info(f"Running {process_name} logic in {self.environment} for user {user_name}...")
            func()
        else:
            self.logger.warning(f"Unknown PROCESS_NAME: {process_name}")

        return f"Job {self.config.get('name')} handled by EdsBatchJobHandler"
