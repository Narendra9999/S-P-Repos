class BaseJobHandler:
    """
    Base handler for job processing. Inherit this and override the handle method for specific pipelines.
    Accepts job config and environment for flexible handler setup.
    """
    def __init__(self, config, environment):
        self.config = config
        self.environment = environment
        import logging
        self.logger = logging.getLogger(f"{self.__class__.__name__}")

    def handle(self, **kwargs):
        """Override this method in pipeline-specific handlers."""
        raise NotImplementedError("handle() must be implemented by the pipeline handler.")
