from typing import Dict, Any
from pyspark.sql import DataFrame
from .postgres_writer import PostgreSQLWriter, PostgreSQLTableConfig
from ...constants.enum_vars import LoadType, DataSetStatus, DataSetType, RunType
import logging
import pyspark.sql.functions as F
from pyspark.sql.types import StringType, TimestampType
from apd_ingestion.config.config_manager import get_config_value
from pyspark import StorageLevel
from apd_ingestion.models.apd_kafka_response import create_kafka_messages
from apd_ingestion.utils.kafka_producer import send_kafka_batch
from apd_ingestion.constants.table_columns import ADPTableColumns
import threading
from concurrent.futures import ThreadPoolExecutor

logger = logging.getLogger(__name__)

class ADPPostgresHandler:
    """
    SCD2 handler for ADP dataset table using PostgreSQLWriter utilities.
    Implements SCD2 upsert logic for the ADP table schema using set-based SQL.
    """
    def __init__(self, writer: PostgreSQLWriter = None, batch_size: int = 25000):
        if writer is None:
            connection_details = get_config_value("database.apd_schema")
            self.connection_details = connection_details
            self.writer = PostgreSQLWriter(
                host = connection_details.get("host"),
                port = connection_details.get("port"),  
                database = connection_details.get("database"),
                username = connection_details.get("username"),
                password = connection_details.get("password"),
                batch_size = batch_size
            )
        else:
            self.writer = writer

    def write_into_db(
        self,
        df: DataFrame,
        table_config: PostgreSQLTableConfig = None,
        load_type: LoadType = LoadType.ZERO_DAY.value,
        run_type: RunType = RunType.BATCH.value
    ) -> Dict[str, Any]:
        """
        Perform SCD2 upsert for ADP dataset table using set-based SQL only.
        Handles both Zero Day (initial) and Incremental loads with static parameters.
        """
        version_col = ADPTableColumns.DATASET_VERSION
        user_id = None

        # Set static/default values based on load type
        default_user = user_id or get_config_value("databricks_user", "svcp_nonprod_idf_dop")
        topic_name = get_config_value("kafka.topics.aero_response_topic")
        now = F.current_timestamp()
        if not table_config:
            table_config = PostgreSQLTableConfig(
                schema=self.connection_details["schema_name"],
                table_name=self.connection_details["final_json_table"]
            )
        logger.info(f"Table config is {table_config}")

        if load_type == LoadType.ZERO_DAY.value:
            logger.info("Starting Zero Day load for ADP dataset table")

            # Set static columns for initial load
            df = df.withColumn(ADPTableColumns.DATASET_STATUS, F.lit(DataSetStatus.FINAL.value))
            df = df.withColumn(version_col, F.lit(1))
            df = df.withColumn(ADPTableColumns.CREATE_USER_ID, F.lit(default_user))
            df = df.withColumn(ADPTableColumns.CREATE_DATETIME, now)
            df = df.withColumn(ADPTableColumns.DATASET_TYPE, F.lit(DataSetType.ECONOMIC_FINANCIAL.value))
            delete_condition = f"dataset_type = '{DataSetType.ECONOMIC_FINANCIAL.value}' AND dataset_status = '{DataSetStatus.FINAL.value}'"
            logger.info(f"Zero Day load delete condition: {delete_condition} and business keys: {ADPTableColumns.BUSINESS_KEYS}")
            writer_output = self.writer.write_execute_batch(df, table_config, business_key_columns=ADPTableColumns.BUSINESS_KEYS,
                    delete_condition=delete_condition)
            if writer_output.get("success"):
                logger.info(f"Zero Day load successful: {writer_output}")
                return writer_output
            else:
                raise ValueError(f"Zero Day load failed: {writer_output}")
        else:
            logger.info("Starting Incremental load for ADP dataset table")

            # Prepare DataFrame with required columns
            df = df.withColumn(ADPTableColumns.DATASET_STATUS, F.lit(DataSetStatus.PROVISIONAL.value))
            df = df.withColumn(ADPTableColumns.CREATE_USER_ID, F.lit(default_user))
            df = df.withColumn(ADPTableColumns.CREATE_DATETIME, now)
            df = df.withColumn(ADPTableColumns.DATASET_TYPE, F.lit(DataSetType.ECONOMIC_FINANCIAL.value))
            df = df.withColumn(version_col, F.lit(1))
            # Cast period_end_date to date for correct matching
            if ADPTableColumns.PERIOD_END_DATE in df.columns:
                df = df.withColumn(ADPTableColumns.PERIOD_END_DATE, 
                                 F.col(ADPTableColumns.PERIOD_END_DATE).cast("date"))

            try:
                # Use optimized incremental batch processing
                logger.info(f"Executing incremental load with delete-insert batch processing")
                delete_condition = f"dataset_type = '{DataSetType.ECONOMIC_FINANCIAL.value}' AND dataset_status = '{DataSetStatus.PROVISIONAL.value}'"

                # Cache the DF so it is not recomputed multiple times
                storage_level = getattr(StorageLevel, "DISK_ONLY", StorageLevel.DISK_ONLY)
                cached_df = df.persist(storage_level)
            
                writer_output = self.writer.write_incremental_batch(
                    cached_df, 
                    table_config,
                    business_key_columns=ADPTableColumns.BUSINESS_KEYS,
                    delete_condition=delete_condition
                )
                
                if writer_output.get("success"):
                    logger.info(f"Incremental load successful: {writer_output}")
                    # if run_type == RunType.BATCH.value:
                    #     send_incremental_data_to_kafka(cached_df, topic_name, async_send=False)
                    # else:
                    #     send_incremental_data_to_kafka(cached_df, topic_name)
                    # In Most cases for both Realtime whole program runs atmost once so sending synchronously
                    send_incremental_data_to_kafka(cached_df, topic_name, async_send=False)
                    return writer_output
                else:
                    raise ValueError(f"Incremental load failed: {writer_output}")
            except Exception as e:
                logger.error(f"Error in incremental load: {str(e)}")
                raise

def _send_kafka_worker(
    cached_df, 
    topic: str, 
    dataset_column: str = "dataset",
    connection_name: str = "confluent_kafka"
) -> int:
    """
    Worker function that actually sends data to Kafka (runs in background thread).
    """
    try:
        # Extract event_source from dataset_source column
        first_row = cached_df.select(ADPTableColumns.DATASET_SOURCE).first()
        event_source = first_row[ADPTableColumns.DATASET_SOURCE] if first_row else "UNKNOWN_SOURCE"
        
        # Convert DataFrame to APD Kafka response messages
        logger.info(f"[Background] Converting cached DataFrame to Kafka messages for topic '{topic}' with event_source '{event_source}'")
        kafka_messages, header_list = create_kafka_messages(
            df=cached_df,
            event_source=event_source
        )
        
        logger.info(f"[Background] Generated {len(kafka_messages)} Kafka messages and {len(header_list)} headers from cached DataFrame")
        
        if not kafka_messages:
            logger.warning("[Background] No messages generated from cached DataFrame")
            return 0
        
        # Send messages to Kafka using batch method
        messages_sent = send_kafka_batch(
            topic=topic,
            messages=kafka_messages,
            connection_name=connection_name,
            headers_list=header_list
        )
        
        logger.info(f"[Background] Successfully sent {messages_sent}/{len(kafka_messages)} messages to Kafka topic '{topic}'")
        return messages_sent
        
    except Exception as e:
        logger.error(f"[Background] Failed to send incremental data to Kafka: {e}")
        return 0


def send_incremental_data_to_kafka_async(
    cached_df, 
    topic: str, 
    dataset_column: str = "dataset",
    connection_name: str = "confluent_kafka"
) -> threading.Thread:
    """
    Send cached DataFrame to Kafka in background thread (non-blocking).
    
    Args:
        cached_df: Cached DataFrame from incremental processing (must have dataset_source column)
        topic: Kafka topic to send messages to
        dataset_column: Column name containing dataset JSON information
        connection_name: Kafka connection name to use
        
    Returns:
        threading.Thread: Background thread handle (can be used to wait for completion)
    """
    logger.info(f"Starting background Kafka send to topic '{topic}'")
    
    # Create and start background thread
    thread = threading.Thread(
        target=_send_kafka_worker,
        args=(cached_df, topic, dataset_column, connection_name),
        name=f"KafkaSender-{topic}",
        daemon=True  # Dies when main process dies
    )
    
    thread.start()
    logger.info(f"Background Kafka send thread started for topic '{topic}'")
    return thread


def send_incremental_data_to_kafka(
    cached_df, 
    topic: str, 
    dataset_column: str = "dataset",
    connection_name: str = "confluent_kafka",
    async_send: bool = True
) -> int:
    """
    Convert cached DataFrame from incremental process to APD Kafka response messages and send to Kafka.
    
    Args:
        cached_df: Cached DataFrame from incremental processing (must have dataset_source column)
        topic: Kafka topic to send messages to
        dataset_column: Column name containing dataset JSON information
        connection_name: Kafka connection name to use
        async_send: If True, send in background (non-blocking). If False, send synchronously.
        
    Returns:
        int: Number of messages sent (0 if async_send=True, since it returns immediately)
    """
    if async_send:
        # Send in background - returns immediately
        send_incremental_data_to_kafka_async(
            cached_df, topic, dataset_column, connection_name
        )
        return 0  # Can't return count since it's async
    else:
        # Send synchronously - blocks until complete
        return _send_kafka_worker(
            cached_df, topic, dataset_column, connection_name
        )
