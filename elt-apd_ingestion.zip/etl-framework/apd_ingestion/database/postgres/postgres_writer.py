import logging
import time
import traceback
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass, field
from pyspark.sql import DataFrame
from apd_ingestion.utils.decorators import retry_decorator
import psycopg2
from psycopg2.extras import RealDictCursor
import psycopg2.pool
from pyspark.sql import SparkSession
import time
from psycopg2.extras import execute_values, Json
from pyspark import StorageLevel

logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# SQL Query Constants for PostgreSQL operations
class SQLQueries:
    """Centralized SQL query constants with optimized reusability"""
    
    # Base table information query - can be extended dynamically
    _BASE_TABLE_COLUMNS_QUERY = """
        SELECT 
            column_name, 
            data_type, 
            is_nullable,
            column_default
            {extra_columns}
        FROM information_schema.columns
        WHERE table_schema = %s AND table_name = %s
        ORDER BY ordinal_position;
    """
    
    # Table existence queries
    CHECK_TABLE_EXISTS = """
        SELECT EXISTS (
            SELECT FROM information_schema.tables 
            WHERE table_schema = %s AND table_name = %s
        ) as table_exists;
    """
    
    COUNT_TABLES = """
        SELECT COUNT(*) as count
        FROM information_schema.tables
        WHERE table_schema = %s AND table_name = %s;
    """
    
    # Dynamic column selection methods
    @classmethod
    def get_table_columns_query(cls, include_udt_name: bool = False) -> str:
        """
        Generate table columns query with optional additional columns
        
        Args:
            include_udt_name: Whether to include PostgreSQL-specific udt_name column
            
        Returns:
            SQL query string for retrieving table columns
        """
        extra_columns = ""
        if include_udt_name:
            extra_columns = ", udt_name"
        
        return cls._BASE_TABLE_COLUMNS_QUERY.format(extra_columns=extra_columns)
    
    # Legacy named queries for backward compatibility
    @property
    def GET_TABLE_COLUMNS_BASIC(self) -> str:
        """Basic table columns query without PostgreSQL-specific fields"""
        return self.get_table_columns_query(include_udt_name=False)
    
    @property  
    def GET_TABLE_COLUMNS_FULL(self) -> str:
        """Full table columns query with PostgreSQL-specific fields"""
        return self.get_table_columns_query(include_udt_name=True)
    
@dataclass
class PostgreSQLTableConfig:
    """
    Configuration for table-specific PostgreSQL operations
    
    This class contains all table-specific settings like primary keys, upsert strategies,
    and incremental loading configurations that vary per table.
    """
    
    # Table identification
    table_name: str
    schema: str = 'public'
    
    # Table-specific operation settings
    primary_key_columns: List[str] = field(default_factory=list)
    upsert_strategy: str = 'none'  # 'none', 'update', 'ignore'
    conflict_columns: List[str] = field(default_factory=list)
    update_columns: List[str] = field(default_factory=list)
    
    # Auto-increment/sequence column handling
    exclude_auto_increment_columns: bool = True  # Automatically exclude nextval columns from INSERT
    auto_increment_columns: List[str] = field(default_factory=list)  # Manual override for auto-increment columns
    
    # Incremental loading settings
    incremental_column: Optional[str] = None
    incremental_strategy: str = 'timestamp'  # 'timestamp', 'version', 'delete_insert'
    
    def __post_init__(self):
        """Post-initialization validation and defaults"""
        # Set intelligent defaults
        if not self.conflict_columns and self.primary_key_columns:
            self.conflict_columns = self.primary_key_columns.copy()
        
        # Validate table name
        if not self.table_name.strip():
            raise ValueError("Table name is required and cannot be empty")
    
    def validate(self) -> Tuple[bool, List[str]]:
        """
        Validate table configuration
        
        Returns:
            Tuple of (is_valid, list_of_issues)
        """
        issues = []
        
        # Table name validation
        if not self.table_name.strip():
            issues.append("Table name is required and cannot be empty")
        
        # Schema validation
        if not self.schema.strip():
            issues.append("Schema cannot be empty")
        
        # Upsert strategy validation
        if self.upsert_strategy not in ['none', 'update', 'ignore']:
            issues.append(f"Invalid upsert strategy: {self.upsert_strategy}. Must be 'none', 'update', or 'ignore'")
        
        if self.upsert_strategy != 'none' and not self.conflict_columns:
            issues.append("Conflict columns are required when upsert strategy is not 'none'")
        
        # Incremental strategy validation
        if self.incremental_strategy not in ['timestamp', 'version', 'delete_insert']:
            issues.append(f"Invalid incremental strategy: {self.incremental_strategy}. Must be 'timestamp', 'version', or 'delete_insert'")
        
        return len(issues) == 0, issues
    
    @property
    def full_table_name(self) -> str:
        """Get fully qualified table name"""
        return f"{self.schema}.{self.table_name}"
    
@dataclass
class PostgreSQLWriter:
    """
    Production-ready PostgreSQL writer for Spark DataFrames with connection-level configuration
    
    This class handles the database connection and provides methods to write to different tables
    with their own specific configurations (primary keys, upsert strategies, etc.)
    """
    
    # Required connection properties
    host: str
    port: int
    database: str
    username: str
    password: str
    
    # Optional connection properties with defaults
    ssl_mode: str = 'prefer'
    connection_timeout: int = 1200
    application_name: str = 'apd_ingestion_databricks'
    max_pool_size: int = 12  # Max connections in the pool
    
    # Performance properties (connection-level)
    batch_size: int = 1000
    num_partitions: Optional[int] = None
    isolation_level: str = 'READ_COMMITTED'
    enable_metrics: bool = True  # Whether to collect performance metrics (records written, time taken, etc.)
    
    # JSONB/JSON handling configuration
    use_postgresql_auto_casting: bool = True  # Use stringtype=unspecified for automatic PostgreSQL type casting

    #NOTE Batch processing configuration, exercise caution when changing these
    default_rows_per_commit: int = 500  # Number of rows per transaction commit
    default_values_per_statement: int = 600  # Number of rows per SQL statement (execute_values page_size)
    
    # Additional JDBC properties
    additional_jdbc_properties: Dict[str, str] = field(default_factory=dict)
    
    def __post_init__(self):
        """Post-initialization setup"""
        # Initialize Spark session with optimized configurations for JDBC operations and large JSON processing
    
        self.spark = SparkSession.builder \
        .config("spark.executor.heartbeatInterval", "120s") \
        .config("spark.task.maxFailures", "6") \
        .config("spark.speculation", "false") \
        .getOrCreate()
            
        # Log actual configuration (which may differ if session already existed)
        logger.info(f"Using Spark session with configurations: " +
                f"spark.task.maxFailures={self.spark.conf.get('spark.task.maxFailures', 'default')}, " +
                f"spark.executor.heartbeatInterval={self.spark.conf.get('spark.executor.heartbeatInterval', 'default')}, " +
                f"spark.executor.memory={self.spark.conf.get('spark.executor.memory', 'default')}, " +
                f"spark.dynamicAllocation.enabled={self.spark.conf.get('spark.dynamicAllocation.enabled', 'default')}")
            
        # Performance metrics (only if enabled)
        if self.enable_metrics:
            self.metrics = {
                'total_records_written': 0,
                'total_write_time_seconds': 0,
                'batches_processed': 0,
                'errors_encountered': 0
            }
        else:
            self.metrics = None
        
        # Initialize table schema cache to avoid multiple calls
        self._table_schema_cache = {}
        
        # Initialize SQL queries instance for reuse
        self.sql_queries = SQLQueries()
        
        # Initialize connection pool
        self._init_connection_pool()
        
    @property
    def jdbc_url(self) -> str:
        """Generate JDBC URL for Spark PostgreSQL connector"""
        return f"jdbc:postgresql://{self.host}:{self.port}/{self.database}"
    
    @property
    def connection_properties_dict(self) -> Dict[str, str]:
        """Generate connection properties dictionary for Spark JDBC"""
        properties = {
            ## Authentication & Connection
            "user": self.username,
            "password": self.password,
            "driver": "org.postgresql.Driver",
            "sslmode": self.ssl_mode,
            
            # Connection Pool & Timeouts
            "maxPoolSize": str(self.max_pool_size),
            "tcpKeepAlive": "true",                  # Keep this - prevents connection drops
            "connectionTestQuery": "SELECT 1",       # Keep this - validates connections

            # PostgreSQL Write Optimization
            "reWriteBatchedInserts": "true", 
            "prepareThreshold": "0",  # Don't prepare statements with large data
            "isolationLevel": self.isolation_level,
            
            # Application Identification
            "ApplicationName": self.application_name
        }
        
        # Add PostgreSQL auto-casting for JSONB if enabled
        if self.use_postgresql_auto_casting:
            properties["stringtype"] = "unspecified"
        
        # Add any additional JDBC properties
        properties.update(self.additional_jdbc_properties)
        
        return properties
    
    @property
    def psycopg2_dsn(self) -> str:
        """Generate DSN string for psycopg2 connections"""
        return (f"host={self.host} port={self.port} dbname={self.database} "
                f"user={self.username} password={self.password} sslmode={self.ssl_mode} "
                f"keepalives=1 keepalives_idle=60 keepalives_interval=30 keepalives_count=6 "
                f"connect_timeout={self.connection_timeout} application_name={self.application_name}")
    
    def validate(self) -> tuple[bool, List[str]]:
        """
        Validate connection properties
        
        Returns:
            Tuple of (is_valid, list_of_issues)
        """
        issues = []
        
        # Required fields validation
        if not self.host.strip():
            issues.append("Host is required and cannot be empty")
        if not self.database.strip():
            issues.append("Database is required and cannot be empty")
        if not self.username.strip():
            issues.append("Username is required and cannot be empty")
        if not self.password:
            issues.append("Password is required")
        
        # Port validation
        if not (1 <= self.port <= 65535):
            issues.append("Port must be between 1 and 65535")
        
        # Performance validation
        if self.batch_size <= 0:
            issues.append("Batch size must be positive")
        
        if self.num_partitions is not None and self.num_partitions <= 0:
            issues.append("Number of partitions must be positive")
        
        if self.connection_timeout <= 0:
            issues.append("Connection timeout must be positive")
        
        return len(issues) == 0, issues
    
    def _init_connection_pool(self):
        """Initialize PostgreSQL connection pool"""
        try:
            self.connection_pool = psycopg2.pool.ThreadedConnectionPool(
                minconn=1,
                maxconn=self.max_pool_size,
                dsn=self.psycopg2_dsn
            )
            logger.info(f"PostgreSQL connection pool initialized successfully (min=1, max={self.max_pool_size})")
        except Exception as e:
            logger.error(f"Failed to initialize connection pool: {str(e)}")
            raise
    
    @retry_decorator(max_retries=3)
    def _test_connection(self) -> bool:
        """Test PostgreSQL connection"""
        conn = None
        try:
            conn = self.connection_pool.getconn()
            with conn.cursor() as cursor:
                cursor.execute("SELECT 1")
                result = cursor.fetchone()
                logger.info("PostgreSQL connection test successful")
                return result[0] == 1
        except Exception as e:
            logger.error(f"Connection test failed: {str(e)}")
            raise
        finally:
            if conn:
                self.connection_pool.putconn(conn)
    
    def _validate_dataframe(self, df: DataFrame) -> Tuple[bool, List[str]]:
        """Validate DataFrame for writing"""
        issues = []
        
        # Check if DataFrame is empty
        if df.count() == 0:
            issues.append("DataFrame is empty")
        
        # Check for duplicate column names
        column_names = df.columns
        if len(column_names) != len(set(column_names)):
            issues.append("DataFrame contains duplicate column names")
        
        # Check for invalid column names (PostgreSQL restrictions)
        for col_name in column_names:
            if not col_name.replace('_', '').replace('-', '').isalnum():
                if not col_name.startswith('_') or len(col_name) > 63:
                    issues.append(f"Invalid column name: {col_name}")
        
        return len(issues) == 0, issues
    
    @retry_decorator(max_retries=3)
    def _check_table_exists(self, schema: str, table_name: str) -> bool:
        """Check if table exists in PostgreSQL"""
        conn = None
        try:
            conn = self.connection_pool.getconn()
            logger.debug(f"Connection acquired from pool for table existence check: {schema}.{table_name}")
            with conn.cursor(cursor_factory=RealDictCursor) as cursor:
                cursor.execute(SQLQueries.CHECK_TABLE_EXISTS, (schema, table_name))
                return cursor.fetchone()['table_exists']
        except Exception as e:
            logger.error(f"Error checking table existence: {str(e)}")
            raise
        finally:
            if conn:
                self.connection_pool.putconn(conn)
    
    def _process_column_info(self, row: Dict[str, Any], include_jsonb: bool = False) -> Dict[str, Any]:
        """
        Process column information from database query results
        
        Args:
            row: Row from database query containing column information
            include_jsonb: Whether to include JSONB-specific processing
            
        Returns:
            Processed column information dictionary
        """
        column_info = {
            'data_type': row['data_type'],
            'is_nullable': row['is_nullable'] == 'YES',
            'column_default': row['column_default'],
            'is_auto_increment': False,
            'is_jsonb': False
        }
        
        # Detect auto-increment columns
        if row['column_default'] and 'nextval(' in str(row['column_default']):
            column_info['is_auto_increment'] = True
        
        # JSONB detection (only if include_jsonb is True and udt_name is available)
        if include_jsonb and 'udt_name' in row:
            column_info['udt_name'] = row['udt_name']
            column_info['is_jsonb'] = row['udt_name'] in ['json', 'jsonb']
        
        return column_info
    
    @retry_decorator(max_retries=3)
    def _get_table_schema(self, schema: str, table_name: str, include_jsonb: bool = True) -> Dict[str, Dict[str, Any]]:
        """
        Get table schema from PostgreSQL with caching and optimized queries
        
        Args:
            schema: Database schema name
            table_name: Table name
            include_jsonb: Whether to include JSONB-specific information
            
        Returns:
            Dictionary mapping column names to column information
        """
        # Check cache first
        cache_key = f"{schema}.{table_name}.{include_jsonb}"
        if cache_key in self._table_schema_cache:
            logger.debug(f"Using cached schema for {cache_key}")
            return self._table_schema_cache[cache_key]
        
        conn = None
        try:
            conn = self.connection_pool.getconn()
            logger.debug(f"Connection acquired from pool for schema retrieval: {schema}.{table_name}")
            with conn.cursor(cursor_factory=RealDictCursor) as cursor:
                # First, check if table exists
                cursor.execute(SQLQueries.COUNT_TABLES, (schema, table_name))
                
                table_result = cursor.fetchone()
                if not table_result:
                    raise ValueError(f"No result returned when checking table existence for {schema}.{table_name}")
                
                table_count = table_result['count']
                if table_count == 0:
                    raise ValueError(f"Table {schema}.{table_name} does not exist")
                
                logger.info(f"Table {schema}.{table_name} exists, retrieving schema...")
                
                # Use optimized query selection based on requirements
                query = self.sql_queries.get_table_columns_query(include_udt_name=include_jsonb)
                cursor.execute(query, (schema, table_name))
                
                rows = cursor.fetchall()
                if not rows:
                    raise ValueError(f"No columns found for table {schema}.{table_name}")
                
                logger.info(f"Retrieved {len(rows)} columns for table {schema}.{table_name}")
                
                table_schema = {}
                for row in rows:
                    try:
                        column_info = self._process_column_info(row, include_jsonb=include_jsonb)
                        table_schema[row['column_name']] = column_info
                    except (KeyError, TypeError, ValueError) as e:
                        logger.error(f"Error processing column row {row}: {str(e)}")
                        raise ValueError(f"Invalid column data structure: {row}")
                
                logger.info(f"Retrieved schema for {schema}.{table_name}: {len(table_schema)} columns")
                
                # Cache the result
                self._table_schema_cache[cache_key] = table_schema
                
                return table_schema
                
        except Exception as e:
            logger.error(f"Error getting table schema for {schema}.{table_name}: {str(e)}")
            logger.error(f"Exception type: {type(e).__name__}")
            raise
        finally:
            if conn:
                self.connection_pool.putconn(conn)

    @retry_decorator(max_retries=3)
    def _execute_sql_command(self, sql: str, params: Tuple = None) -> int:
        """
        Execute SQL command with retry logic and log affected row count
        Returns the number of affected rows for DML statements
        """
        conn = None
        affected_rows = -1
        try:
            conn = self.connection_pool.getconn()
            with conn.cursor() as cursor:
                cursor.execute(sql, params)
                affected_rows = cursor.rowcount
                conn.commit()
                logger.info(f"SQL executed: {sql[:100]}... Rows affected: {affected_rows}")
        except Exception as e:
            if conn:
                conn.rollback()
            logger.error(f"SQL execution failed: {sql[:100]}... Error: {str(e)}")
            raise
        finally:
            if conn:
                self.connection_pool.putconn(conn)
        return affected_rows
    
    def write_execute_batch(
        self,
        df: DataFrame,
        table_config: 'PostgreSQLTableConfig',
        on_conflict: str = None,
        business_key_columns: List[str] = None,
        delete_condition: str = None,
        cache_storage_level: str = "DISK_ONLY"
    ) -> dict:
        """
        Write DataFrame to PostgreSQL using optimized psycopg2 per-batch commit method.
        This method is fast, memory-efficient, and natively handles JSON/timestamp columns.
        Args:
            df: Spark DataFrame to write
            table_config: Table-specific configuration
            on_conflict: Optional ON CONFLICT clause (e.g., 'ON CONFLICT (pk) DO NOTHING')
            business_key_columns: Optional list of columns for DELETE operations (enables DELETE-first strategy)
            delete_condition: Optional additional WHERE condition for DELETE operations
            cache_storage_level: StorageLevel for caching (MEMORY_AND_DISK recommended)
        Returns:
            Dictionary containing write operation metrics and results including:
            - total_deleted, total_inserted, total_committed counts
            - total_batches, total_commits, failed_commits
            - all_logs from the operation
        """
        import time
        # Ensure StorageLevel is imported correctly
        from pyspark import StorageLevel
        
        start_time = time.time()
        try:
            # Validate DataFrame
            is_valid, issues = self._validate_dataframe(df)
            if not is_valid:
                raise ValueError(f"DataFrame validation failed: {', '.join(issues)}")

            # Validate table configuration
            is_valid, issues = table_config.validate()
            if not is_valid:
                raise ValueError(f"Table configuration validation failed: {', '.join(issues)}")

            is_valid, issues = self._validate_column_compatibility(df, table_config.schema, table_config.table_name)
            if not is_valid:
                raise ValueError(f"Column compatibility validation failed: {', '.join(issues)}")
                
            # Cache the DataFrame to memory and disk to avoid recomputing transformations
            storage_level = getattr(StorageLevel, cache_storage_level, StorageLevel.MEMORY_AND_DISK)
            logger.info(f"Caching DataFrame using storage level: {cache_storage_level}")
            
            # Cache and trigger materialization
            cached_df = df.persist(storage_level)
            
            # Trigger an action to materialize the cache
            row_count = cached_df.count()
            logger.info(f"DataFrame cached with {row_count} rows")
            # Use unified batch worker with optional DELETE-first capability
            if business_key_columns:
                logger.info(f"Using DELETE-first strategy with business key columns: {business_key_columns}")
            
            # Prepare columns for the unified worker
            #columns = [col for col in cached_df.columns if col != 'dataset']
            columns= cached_df.columns
            
            rows_per_commit = self.default_rows_per_commit
            values_per_statement = self.default_values_per_statement
            target_partitions = min(self.max_pool_size, max(1, self._calculate_optimal_partitions(row_count)))
            df_optimized = cached_df.repartition(target_partitions)
            logger.info(f"Processing {row_count} rows using {target_partitions} partitions")
            
            dsn = self.psycopg2_dsn
            # Use unified worker via mapPartitions
            results = df_optimized.rdd.mapPartitions(
                lambda partition: PostgreSQLWriter._unified_batch_worker(
                    partition,
                    dsn=dsn,
                    columns=columns,
                    rows_per_commit=rows_per_commit,
                    values_per_statement=values_per_statement,
                    full_table_name=table_config.full_table_name,
                    business_key_columns=business_key_columns,
                    delete_condition=delete_condition,
                    on_conflict=on_conflict
                )
            ).collect()

            # Process results from unified worker
            total_deleted = 0
            total_inserted = 0
            total_committed = 0
            total_batches = 0
            total_commits = 0
            failed_commits = 0
            all_logs = []
            partition_failures = []
            
            for i, result_tuple in enumerate(results):
                if len(result_tuple) >= 7:
                    deleted, inserted, committed, batches, commits, fails, logs = result_tuple[:7]
                    total_deleted += deleted
                    total_inserted += inserted
                    total_committed += committed
                    total_batches += batches
                    total_commits += commits
                    failed_commits += fails
                    all_logs.extend(logs)
                    
                    # Check for failures
                    if deleted == -1 or inserted == -1:
                        partition_failures.append(i)
                else:
                    logger.error(f"Unexpected result format from partition {i}: {result_tuple}")
                    partition_failures.append(i)
            
            # Display all executor logs in driver
            logger.info("=== EXECUTOR LOGS START ===")
            for log_entry in sorted(all_logs):  # Sort by timestamp
                logger.info(log_entry)
            logger.info("=== EXECUTOR LOGS END ===")
            
            # Check for partition failures
            if partition_failures:
                raise Exception(f"Partitions {partition_failures} failed during processing")
            
            # Create result dictionary matching expected format
            result = {
                'total_deleted': total_deleted,
                'total_inserted': total_inserted,
                'total_committed': total_committed,
                'total_batches': total_batches, 
                'total_commits': total_commits,
                'failed_commits': failed_commits,
                'rows_written': total_inserted,
                'elapsed_seconds': time.time() - start_time
            }

            # Unpersist the DataFrame to free up resources
            try:
                cached_df.unpersist()
                logger.info("DataFrame unpersisted after batch write complete")
            except Exception as unpersist_error:
                logger.warning(f"Error unpersisting DataFrame: {str(unpersist_error)}")

            if self.enable_metrics:
                self.metrics['total_records_written'] += result.get('rows_written', 0)
                self.metrics['total_write_time_seconds'] += result.get('elapsed_seconds', 0)
                self.metrics['batches_processed'] += 1

            self.close()

            result.update({
                'success': True,
                'table_name': table_config.full_table_name,
                'write_time_seconds': time.time() - start_time,
                'upsert_strategy': table_config.upsert_strategy,
                'row_count': row_count
            })
            return result

        except Exception as e:
            if self.enable_metrics:
                self.metrics['errors_encountered'] += 1
            
            # Make sure to unpersist even on error
            try:
                if 'cached_df' in locals():
                    cached_df.unpersist()
                    logger.info("DataFrame unpersisted after error")
            except:
                pass
                
            # Using the module-level logger that's already defined
            logger.error(f"Failed to write DataFrame to {table_config.full_table_name} (batch method): {str(e)}")
            return {
                'success': False,
                'error': str(e),
                'table_name': table_config.full_table_name,
                'write_time_seconds': time.time() - start_time
            }

    def write_incremental_batch(
        self,
        cached_df: DataFrame,
        table_config: 'PostgreSQLTableConfig',
        business_key_columns: List[str],
        delete_condition: str = None,
    ) -> dict:
        """
        Optimized incremental write using delete-then-insert with parallel batch processing.
        
        Args:
            df: Spark DataFrame to write
            table_config: Table-specific configuration
            business_key_columns: List of column names that form the business key
            delete_condition: Optional additional WHERE condition for deletion
        Returns:
            Dictionary containing write operation metrics and results
        """
        
        
        start_time = time.time()
        logger.info(f"Starting incremental batch write for {table_config.full_table_name}")

        try:
            # Basic validations
            is_valid, issues = self._validate_dataframe(cached_df)
            if not is_valid:
                raise ValueError(f"DataFrame validation failed: {', '.join(issues)}")

            missing_keys = [col for col in business_key_columns if col not in cached_df.columns]
            if missing_keys:
                raise ValueError(f"Missing business key columns: {', '.join(missing_keys)}")

            row_count = cached_df.count()
            target_partitions = min(self.max_pool_size, max(1, self._calculate_optimal_partitions(row_count)))
            df_optimized = cached_df.repartition(target_partitions)

            logger.info(f"Processing {row_count} rows using {target_partitions} partitions")

            # Capture configuration for worker functions
            dsn = self.psycopg2_dsn
            columns = df_optimized.columns
            rows_per_commit = self.default_rows_per_commit
            values_per_statement = self.default_values_per_statement
            full_table = table_config.full_table_name

            # Use unified worker function
            results = df_optimized.rdd.mapPartitions(
                lambda iterator: PostgreSQLWriter._unified_batch_worker(
                    iterator=iterator,
                    dsn=dsn,
                    columns=columns,
                    rows_per_commit=rows_per_commit,
                    values_per_statement=values_per_statement,
                    full_table_name=full_table,
                    business_key_columns=business_key_columns,
                    delete_condition=delete_condition,
                    on_conflict=None
                )
            ).collect()

            # Process results and display executor logs
            all_executor_logs = []
            partition_failures = []
            
            for i, result in enumerate(results):
                if len(result) >= 7:  # Now expecting 7 values including logs
                    deleted, inserted, committed, batches, commits, failed_commits, executor_logs = result[:7]
                    
                    # Collect all executor logs
                    all_executor_logs.extend(executor_logs)
                    
                    # Check for failures
                    if deleted == -1 or inserted == -1:
                        partition_failures.append(i)
                else:
                    logger.error(f"Unexpected result format from partition {i}: {result}")
                    partition_failures.append(i)
            
            # Display all executor logs in driver
            logger.info("=== EXECUTOR LOGS START ===")
            for log_entry in sorted(all_executor_logs):  # Sort by timestamp
                logger.info(log_entry)
            logger.info("=== EXECUTOR LOGS END ===")
            
            # Check for partition failures
            if partition_failures:
                raise Exception(f"Partitions {partition_failures} failed during processing")
            
            # Aggregate detailed results (now expects 7 values, use first 6 for metrics)
            valid_results = [r[:6] for r in results if isinstance(r, tuple) and len(r) >= 6]
            total_deleted = sum(r[0] for r in valid_results)
            total_inserted = sum(r[1] for r in valid_results)
            total_committed = sum(r[2] for r in valid_results)
            total_batches = sum(r[3] for r in valid_results)
            total_commits = sum(r[4] for r in valid_results)
            total_failed_commits = sum(r[5] for r in valid_results)

            # Comprehensive data integrity validation
            if total_committed != row_count:
                raise Exception(f"COMMIT INTEGRITY CHECK FAILED: Expected {row_count} committed rows, got {total_committed}")
            
            if total_inserted != row_count:
                raise Exception(f"INSERT INTEGRITY CHECK FAILED: Expected {row_count} inserted rows, got {total_inserted}")
            
            if total_failed_commits > 0:
                logger.warning(f"WARNING: {total_failed_commits} failed commits occurred but were recovered")

            # Cleanup
            cached_df.unpersist()
            if self.enable_metrics:
                self.metrics['total_records_written'] += total_committed  # Use committed count
                self.metrics['total_write_time_seconds'] += time.time() - start_time
                self.metrics['batches_processed'] += 1
            self.close()

            execution_time = time.time() - start_time
            logger.info(f"Incremental batch completed successfully:")
            logger.info(f"   - {total_deleted} rows deleted")
            logger.info(f"   - {total_inserted} rows inserted") 
            logger.info(f"   - {total_committed} rows actually committed")
            logger.info(f"   - {total_batches} batches processed")
            logger.info(f"   - {total_commits} successful commits")
            logger.info(f"   - {total_failed_commits} failed commits")
            logger.info(f"   - {execution_time:.2f} seconds")

            return {
                "success": True,
                "deleted_rows": total_deleted,
                "inserted_rows": total_inserted,
                "committed_rows": total_committed,  # NEW: Actual committed count
                "total_affected": total_deleted + total_committed,
                "execution_time": execution_time,
                "partitions_used": target_partitions,
                "batches_processed": total_batches,
                "successful_commits": total_commits,
                "failed_commits": total_failed_commits,
                "commit_success_rate": (total_commits / (total_commits + total_failed_commits)) if (total_commits + total_failed_commits) > 0 else 1.0,
                "method": "optimized_incremental_batch_with_commit_tracking",
                "table_name": table_config.full_table_name
            }

        except Exception as e:
            if self.enable_metrics:
                self.metrics['errors_encountered'] += 1

            # Ensure DataFrame is unpersisted even on error
            try:
                if 'cached_df' in locals():
                    cached_df.unpersist()
                    logger.info("DataFrame unpersisted after error")
            except:
                pass

            logger.error(f"Incremental batch write failed: {str(e)}")
            return {
                "success": False,
                "error": str(e),
                "execution_time": time.time() - start_time,
                "table_name": table_config.full_table_name,
                "write_time_seconds": time.time() - start_time
            }
        
    def _calculate_optimal_partitions(self, row_count: int) -> int:
        """
        Calculate optimal number of partitions based on row count
        
        Args:
            row_count: Total number of rows
            
        Returns:
            Optimal number of partitions
        """
        if row_count <= 100000:
            return 10
        elif row_count <= 250000:
            return 10
        elif row_count <= 500000:
            return 10
        else:
            return 12

    @staticmethod
    def _unified_batch_worker(
        iterator,
        dsn: str,
        columns: List[str],
        rows_per_commit: int,
        values_per_statement: int,
        full_table_name: str,
        business_key_columns: List[str] = None,
        delete_condition: str = None,
        on_conflict: str = None
    ):
        """
        Unified worker function for both incremental and regular batch processing.
        
        Args:
            iterator: Partition iterator
            dsn: Database connection string
            columns: DataFrame columns
            rows_per_commit: Batch size for commits
            values_per_statement: Page size for execute_values
            full_table_name: Target table name
            business_key_columns: Optional business keys for DELETE operations
            delete_condition: Optional additional DELETE condition
            on_conflict: Optional ON CONFLICT clause
        
        Yields:
            Tuple of metrics (deleted_count, inserted_count, committed_count, batch_count, commit_count, failed_commits, log_messages)
        """
        import psycopg2
        import datetime
        import secrets
        import traceback
        from psycopg2.extras import execute_values, Json
        
        # Create log collector
        log_messages = []
        partition_id = secrets.randbelow(9000) + 1000
        
        def log_message(level, message):
            """Helper to collect log messages with timestamps"""
            timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
            log_entry = f"[Worker-{partition_id}] [{timestamp}] [{level}] {message}"
            log_messages.append(log_entry)
        
        conn = None
        
        # Detailed tracking variables
        deleted_count = 0
        inserted_count = 0
        actual_committed_count = 0
        batch_count = 0
        commit_count = 0
        failed_commits = 0

        # Helper function to adapt Row to tuple with JSON handling
        def _adapt_row(row):
            return tuple(Json(row[c]) if isinstance(row[c], (dict, list)) and row[c] is not None 
                       else row[c] for c in columns)

        try:
            log_message("INFO", f"Starting processing")
            
            conn = psycopg2.connect(dsn)
            conn.autocommit = False
            log_message("INFO", "Database connection established")

            with conn.cursor() as cur:
                cur.execute("SET synchronous_commit = off")
                cur.execute("SET statement_timeout = '1800000'")
                log_message("INFO", "PostgreSQL parameters configured")

                rows = list(iterator)
                if not rows:
                    log_message("INFO", "No rows to process")
                    yield (0, 0, 0, 0, 0, 0, log_messages)
                    return

                log_message("INFO", f"Processing {len(rows)} rows")

                # DELETE logic - only if business_key_columns provided
                if business_key_columns:
                    # Extract unique business keys for deletion
                    unique_keys = list(set(tuple(getattr(row, col) for col in business_key_columns) for row in rows))

                    if unique_keys:
                        log_message("INFO", f"Deleting {len(unique_keys)} unique business keys in batches")
                        
                        # Process deletes in batches to avoid massive SQL statements
                        delete_batch_size = 600  # Process 600 keys at a time to prevent timeouts
                        total_deleted = 0
                        
                        for batch_start in range(0, len(unique_keys), delete_batch_size):
                            batch_end = min(batch_start + delete_batch_size, len(unique_keys))
                            batch_keys = unique_keys[batch_start:batch_end]
                            
                            log_message("INFO", f"Processing DELETE batch {batch_start//delete_batch_size + 1}: keys {batch_start+1}-{batch_end}")
                            
                            # Build dynamic DELETE query for this batch
                            delete_conditions = []
                            delete_params = []
                            
                            for key_tuple in batch_keys:
                                # Build condition for this specific key combination
                                key_conditions = []
                                for col, value in zip(business_key_columns, key_tuple):
                                    if value is None:
                                        key_conditions.append(f"{col} IS NULL")
                                    else:
                                        key_conditions.append(f"{col} = %s")
                                        delete_params.append(value)
                                
                                # Combine conditions for this key with AND
                                delete_conditions.append(f"({' AND '.join(key_conditions)})")
                            
                            # Combine all key conditions with OR
                            where_clause = f"({' OR '.join(delete_conditions)})"
                            
                            # Add additional delete condition if provided
                            if delete_condition:
                                where_clause = f"({where_clause}) AND ({delete_condition})"
                            
                            delete_sql = f"DELETE FROM {full_table_name} WHERE {where_clause}"
                            
                            try:
                                cur.execute(delete_sql, delete_params)
                                batch_deleted = cur.rowcount
                                total_deleted += batch_deleted
                                log_message("INFO", f"Batch DELETE completed: {batch_deleted} records deleted")
                            except Exception as e:
                                log_message("ERROR", f"Batch DELETE operation failed: {str(e)}")
                                conn.rollback()
                                raise
                        
                        log_message("INFO", f"Total deleted records: {total_deleted}")
                        deleted_count = total_deleted

                # INSERT logic - common for both modes
                base_sql = f"INSERT INTO {full_table_name} ({', '.join(columns)}) VALUES %s"
                insert_sql = base_sql if not on_conflict else f"{base_sql} {on_conflict}"
                adapted_rows = [_adapt_row(row) for row in rows]
                
                batch = []
                rows_staged_for_commit = 0
                
                for row_data in adapted_rows:
                    batch.append(row_data)
                    rows_staged_for_commit += 1
                    
                    if len(batch) >= rows_per_commit:
                        batch_count += 1
                        batch_size = len(batch)
                        
                        try:
                            log_message("INFO", f"Inserting batch #{batch_count} with {batch_size} rows")
                            
                            # Execute the insert
                            execute_values(cur, insert_sql, batch, page_size=values_per_statement)
                            
                            # Verify rows were staged
                            rows_affected = cur.rowcount
                            if rows_affected != batch_size:
                                log_message("WARNING", f"Batch #{batch_count}: Expected {batch_size} rows, got {rows_affected} affected")
                            
                            # Attempt commit
                            conn.commit()
                            commit_count += 1
                            actual_committed_count += rows_affected
                            inserted_count += rows_affected
                            
                            log_message("INFO", f"Batch #{batch_count} committed successfully: {rows_affected} rows")
                            
                            # Reset counters
                            rows_staged_for_commit = 0
                            
                        except Exception as e:
                            failed_commits += 1
                            log_message("ERROR", f"Batch #{batch_count} failed: {str(e)}")
                            log_message("ERROR", "Rolling back transaction")
                            
                            try:
                                conn.rollback()
                                rows_staged_for_commit = 0
                            except Exception as rollback_error:
                                log_message("ERROR", f"Rollback failed: {str(rollback_error)}")
                            
                            raise
                        finally:
                            batch.clear()

                # Process remaining rows
                if batch:
                    batch_count += 1
                    batch_size = len(batch)
                    
                    try:
                        log_message("INFO", f"Inserting final batch #{batch_count} with {batch_size} rows")
                        
                        # Execute the insert
                        execute_values(cur, insert_sql, batch, page_size=values_per_statement)
                        
                        # Verify rows were staged
                        rows_affected = cur.rowcount
                        if rows_affected != batch_size:
                            log_message("WARNING", f"Final batch: Expected {batch_size} rows, got {rows_affected} affected")
                        
                        # Attempt commit
                        conn.commit()
                        commit_count += 1
                        actual_committed_count += rows_affected
                        inserted_count += rows_affected
                        
                        log_message("INFO", f"Final batch committed successfully: {rows_affected} rows")
                        
                    except Exception as e:
                        failed_commits += 1
                        log_message("ERROR", f"Final batch failed: {str(e)}")
                        
                        try:
                            conn.rollback()
                        except Exception as rollback_error:
                            log_message("ERROR", f"Rollback failed: {str(rollback_error)}")
                        
                        raise

                # Final verification for incremental mode
                if business_key_columns and actual_committed_count != len(rows):
                    error_msg = f"COMMIT VERIFICATION FAILED: Expected {len(rows)} committed, actually committed {actual_committed_count}"
                    log_message("ERROR", error_msg)
                    raise Exception(f"Commit verification failed: {len(rows)} expected vs {actual_committed_count} committed")
                
                log_message("INFO", f"SUCCESS: {deleted_count} deleted, {inserted_count} inserted, {actual_committed_count} committed, {commit_count} commits, {failed_commits} failed commits")

                yield (deleted_count, inserted_count, actual_committed_count, batch_count, commit_count, failed_commits, log_messages)

        except Exception as e:
            log_message("ERROR", f"Critical error: {str(e)}")
            log_message("ERROR", f"Traceback: {traceback.format_exc()}")
            
            if conn and not conn.closed:
                try:
                    conn.rollback()
                    log_message("INFO", "Final rollback completed")
                except:
                    log_message("ERROR", "Final rollback failed")
            
            # Return error indicator with logs
            yield (-1, -1, actual_committed_count, batch_count, commit_count, failed_commits + 1, log_messages)
            
        finally:
            if conn and not getattr(conn, 'closed', True):
                try:
                    conn.close()
                    log_message("INFO", "Connection closed")
                except Exception as e:
                    log_message("ERROR", f"Error closing connection: {str(e)}")

    def _validate_column_compatibility(self, df: DataFrame, schema: str, table_name: str) -> Tuple[bool, List[str]]:
        """Validate DataFrame columns against existing table schema"""
        issues = []
        warnings = []
        
        try:
            logger.info(f"Validating column compatibility for {schema}.{table_name}")
            
            # Get existing table schema
            table_schema = self._get_table_schema(schema, table_name)
            
            if not table_schema:
                issues.append(f"Could not retrieve schema for table {schema}.{table_name}")
                return False, issues
            
            df_columns = set(df.columns)
            table_columns = set(table_schema.keys())
            
            logger.info(f"DataFrame columns: {sorted(df_columns)}")
            logger.info(f"Table columns: {sorted(table_columns)}")
            
            # Check for missing columns in DataFrame
            missing_in_df = table_columns - df_columns
            if missing_in_df:
                logger.info(f"Missing columns in DataFrame: {sorted(missing_in_df)}")
                
                # Categorize missing columns
                auto_increment_missing = []
                nullable_missing = []
                nullable_with_default_missing = []
                non_nullable_missing = []
                
                for col in missing_in_df:
                    try:
                        col_info = table_schema.get(col, {})
                        
                        if not col_info:
                            logger.warning(f"No schema info found for column: {col}")
                            continue
                        
                        if col_info.get('is_auto_increment', False):
                            auto_increment_missing.append(col)
                        elif col_info.get('is_nullable', True):
                            if col_info.get('column_default', False):
                                nullable_with_default_missing.append(col)
                            else:
                                nullable_missing.append(col)
                        elif col_info.get('column_default', False):
                            # Non-nullable with default (should be fine)
                            pass
                        else:
                            non_nullable_missing.append(col)
                            
                    except Exception as e:
                        logger.error(f"Error processing column {col}: {str(e)}")
                        issues.append(f"Error processing column {col}: {str(e)}")
                
                # Report issues and warnings
                if non_nullable_missing:
                    issues.append(f"DataFrame missing non-nullable columns without defaults: {non_nullable_missing}")
                
                if auto_increment_missing:
                    warnings.append(f"DataFrame missing auto-increment columns (will be generated): {auto_increment_missing}")
                
                if nullable_with_default_missing:
                    warnings.append(f"DataFrame missing nullable columns with defaults: {nullable_with_default_missing}")
                
                if nullable_missing:
                    warnings.append(f"DataFrame missing nullable columns (will be NULL): {nullable_missing}")

            # Check for extra columns in DataFrame
            extra_in_df = df_columns - table_columns
            if extra_in_df:
                issues.append(f"DataFrame contains columns not in target table: {sorted(extra_in_df)}")
            
            # Log warnings
            for warning in warnings:
                logger.warning(warning)
            
            for issue in issues:
                logger.error(issue)
            
            logger.info(f"Column validation completed. Issues: {len(issues)}, Warnings: {len(warnings)}")
            return len(issues) == 0, issues
            
        except Exception as e:
            error_msg = f"Error validating column compatibility for {schema}.{table_name}: {str(e)}"
            logger.error(error_msg)
            return False, [error_msg]
    
    def close(self):
        """Close connection pool and cleanup resources"""
        try:
            if hasattr(self, 'connection_pool'):
                self.connection_pool.closeall()
                logger.info("Connection pool closed successfully")
            
            # Clear schema cache
            if hasattr(self, '_table_schema_cache'):
                self._table_schema_cache.clear()
                logger.info("Schema cache cleared")
                
        except Exception as e:
            logger.error(f"Error closing connection pool: {str(e)}")
    
    def clear_schema_cache(self, schema: str = None, table_name: str = None):
        """
        Clear cached table schema information
        
        Args:
            schema: If provided, clear cache only for this schema
            table_name: If provided (along with schema), clear cache only for this specific table
        """
        if not hasattr(self, '_table_schema_cache'):
            return
            
        if schema and table_name:
            # Clear specific table
            cache_key = f"{schema}.{table_name}"
            if cache_key in self._table_schema_cache:
                del self._table_schema_cache[cache_key]
                logger.info(f"Cleared schema cache for {cache_key}")
        elif schema:
            # Clear all tables in schema
            keys_to_remove = [key for key in self._table_schema_cache.keys() if key.startswith(f"{schema}.")]
            for key in keys_to_remove:
                del self._table_schema_cache[key]
            logger.info(f"Cleared schema cache for schema {schema}: {len(keys_to_remove)} tables")
        else:
            # Clear all cache
            self._table_schema_cache.clear()
            logger.info("Cleared all schema cache")
    
