"""
Main entry point for the ETL Framework CLI.
"""

import sys
import os
import argparse
from .config.config_manager import ConfigManager, get_config_value
from .streaming.cdf_stream_processor import CDFStreamProcessor
from .jobs.job_processor import JobProcessor
from apd_ingestion.constants.env_vars import GeneralEnvVars, VaultEnvVars
import logging

logger = logging.getLogger("apd_framework_main")


def parse_arguments():
    """Parse command line arguments and return known and unknown args."""
    parser = argparse.ArgumentParser(description="Run ETL Framework pipeline")
    parser.add_argument("--pipeline_name", required=True, help="Pipeline/Job name to execute")
    parser.add_argument("--env", required=True, help="Environment name (dev, qa, uat, prod, dr, local)")
    parser.add_argument("--streaming", action="store_true", help="Run as streaming pipeline")
    return parser.parse_known_args()


def parse_extra_args(unknown_args):
    """Convert extra CLI args (e.g. --foo bar --baz qux) to a dict."""
    extra = {}
    key = None
    for item in unknown_args:
        if item.startswith("--"):
            key = item.lstrip("-")
            extra[key] = True  # Default to True for flags
        else:
            if key:
                extra[key] = item
                key = None
    return extra


def determine_pipeline_type(pipeline_name: str) -> str:
    """
    Determine if pipeline is streaming (kafka/cdf) or batch based on configuration.
    """
    # Check if pipeline exists in streaming.pipelines
    streaming_config = get_config_value(f'streaming.pipelines.{pipeline_name}')
    if streaming_config:
        stream_type = streaming_config.get('type')
        return f"streaming_{stream_type}"
    
    # Check if pipeline exists in jobs
    job_config = get_config_value(f'jobs.{pipeline_name}')
    if job_config:
        return "job"
    
    # Default fallback - could also raise error
    return "unknown"


def run_streaming_pipeline(pipeline_name: str, env: str, **extra_args):
    """Run streaming pipeline (Kafka or CDF)."""
    logger.info(f"Starting streaming pipeline: {pipeline_name}")
    logger.info(f"Extra arguments: {extra_args}")
    
    # Get pipeline configuration
    pipeline_config = get_config_value(f'streaming.pipelines.{pipeline_name}')
    pipeline_type = pipeline_config.get('type', 'kafka')
    
    if pipeline_type == 'cdf':
        processor = CDFStreamProcessor(
            name=pipeline_name,
            environment=env,
            checkpoint_version=extra_args.get('checkpoint_version', 'v1'),
            skip_vacuum_files=extra_args.get('skip_vacuum_files', 'false').lower() == 'true'
        )
    else:
        raise ValueError(f"Unknown streaming type: {pipeline_type}")
        
    processor.run(await_termination=True)


def run_job_pipeline(pipeline_name: str, env: str, **kwargs):
    """Run batch job pipeline."""
    logger.info(f"Starting job: {pipeline_name}")
    processor = JobProcessor(
        job_name=pipeline_name,
        environment=env
    )
    processor.run(**kwargs)

def setup_local_testing_profile():
    """
    Set up environment variables for local testing.
    This is only used when LOCAL_TESTING environment variable is set to 'true'.
    In production/Databricks, these should be set externally.
    
    Usage:
    - For local development: set LOCAL_TESTING=true before running
    - For production/Databricks: ensure environment variables are configured externally
    """
    # Only apply local testing profile if explicitly enabled
    if os.getenv('LOCAL_TESTING', '').lower() == 'true':
        logger.info("LOCAL_TESTING mode enabled - setting up test environment variables")
        
        # Set default environment if not already set
        if not os.getenv(GeneralEnvVars.APP_ENV.value):
            os.environ[GeneralEnvVars.APP_ENV.value] = "local"
            logger.info(f"  Set {GeneralEnvVars.APP_ENV.value} = local")
        
        # Check if required vault token is provided
        if not os.getenv(VaultEnvVars.VAULT_TOKEN.value):
            logger.error(f"ERROR: {VaultEnvVars.VAULT_TOKEN.value} environment variable is required for local testing.")
            logger.error(f"Please set it before running: $env:{VaultEnvVars.VAULT_TOKEN.value}='your-token-here'")
            sys.exit(1)
            
        # Set other test environment variables (only if not already set)
        test_env_vars = {
            "IDF_GRDP_DOP_SHELF_ID": "grdp-dop/dev",
        }
        
        for key, value in test_env_vars.items():
            if not os.getenv(key):
                os.environ[key] = value
        
        logger.info("Local testing environment configured")
    else:
        logger.info("Non-Local mode - Using externally configured environment variables")


def main():
    """
    Main entry point for the ETL Framework.
    """
    # Set up local testing profile if enabled
    setup_local_testing_profile()

    # Initialize ConfigManager singleton early
    # Don't pass resource_root - let ConfigManager use its default (apd_ingestion directory)
    config_manager = ConfigManager()
    
    try:
        # Parse command line arguments
        args, unknown = parse_arguments()
        extra_args = parse_extra_args(unknown)
        
        logger.info(f"Pipeline: {args.pipeline_name}")
        logger.info(f"Environment: {args.env}")
        logger.info(f"Extar Arguments are : {extra_args}")
        # Load configuration to validate setup
        config_manager.get_config()
        
        # Determine pipeline type if not explicitly specified
        if args.streaming:
            pipeline_type = "streaming"
        else:
            pipeline_type = determine_pipeline_type(args.pipeline_name)
        
        logger.info(f"Pipeline type: {pipeline_type}")
        
        # Route to appropriate processor
        if pipeline_type.startswith("streaming"):
            run_streaming_pipeline(
                pipeline_name=args.pipeline_name,
                env=args.env,
                **extra_args  # Pass extra arguments to streaming pipeline
            )
        elif pipeline_type == "job":
            run_job_pipeline(
                pipeline_name=args.pipeline_name,
                env=args.env,
                **extra_args  # <-- pass extra args here
            )
        else:
            raise ValueError(f"Unknown pipeline '{args.pipeline_name}'. Please check your configuration.")
            
        logger.info(f"Pipeline {args.pipeline_name} completed successfully")
            
    except Exception as e:
        logger.error(f"Error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
