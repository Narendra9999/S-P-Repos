"""
ETL Framework Package

A comprehensive framework for ETL operations in Databricks environment.
"""

__version__ = "0.1.0"
__author__ = "sunil_swarna"