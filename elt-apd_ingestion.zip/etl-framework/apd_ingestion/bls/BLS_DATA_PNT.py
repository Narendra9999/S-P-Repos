# Databricks notebook source
import os
import uuid
import logging
from datetime import datetime
from typing import Tuple, Optional, Dict, Any
from pyspark.sql import SparkSession, DataFrame
from pyspark.sql import functions as F
from pyspark.sql.functions import row_number, monotonically_increasing_id, col, lit, current_timestamp, regexp_replace, sum, desc, trim, length, expr, List
from pyspark.sql.window import Window
from apd_ingestion.constants.enum_vars import RunType
from apd_ingestion.bls.bls_utils import insert_batch_process_status_started, insert_process_status_started,update_process_status,get_last_processed_date



# COMMAND ----------

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
spark = SparkSession.builder.appName("Load_BLS_Data_Pnt").getOrCreate()

def generate_process_id():
    return str(uuid.uuid4())

# COMMAND ----------

def process_non_current_records(env, bls_last_date, process_id, user):
    """Process non-current records."""
    try:
        # Get non-current records
        non_current_query = f"""
        SELECT dp.SERIES_ID, INT(dp.YR) AS YR, dp.PER_CD, dp.VAL_TEXT, dp.FOOTNOTE_CD, 
              NVL(dp.FOOTNOTE_TEXT, ' ') AS FOOTNOTE_TEXT, dp.AREA_TYP_CD, dp.AREA_TYP_DESC,
              dp.AREA_CD, dp.AREA_DESC, dp.MEASURE_CD, dp.MEASURE_DESC, dp.SEASONAL_CD, dp.SEASONAL_DESC,
              dp.ST_REGN_DIV_CD, dp.ST_REGN_DIV_NAME, dp.SERIES_TITLE, dp.START_DTTM, dp.END_DTTM,
              dp.CUR_IND, dp.DEL_FROM_SRC_IND, dp.ACTV_IND, dp.CREATE_USR_ID, dp.LAST_UPD_USR_ID,
              dp.CREATE_DTTM, dp.LAST_UPD_DTTM, dp.START_DATE, dp.END_DATE, dp.SRC_FILE_NAME
        FROM idf_curated_{env}.bls.v_data_pnt dp
        WHERE cur_ind = 'N'
        AND (dp.create_dttm >= cast('{bls_last_date}' as TIMESTAMP)
            OR dp.last_upd_dttm >= cast('{bls_last_date}' as TIMESTAMP))
        """
        non_current_df = spark.sql(non_current_query).dropDuplicates()

        print(f"Non-current records count: {non_current_df.count()}")

        non_current_data = non_current_df \
            .withColumn("LAST_UPD_USR_ID", lit(user)) \
            .withColumn("LAST_UPD_DTTM", current_timestamp())

        # Update the target table
        non_current_data.createOrReplaceTempView("non_current_updates")

        spark.sql(f"""
            MERGE INTO idf_raw_{env}.BLS_ECON.T_DATA_PNT target
            USING non_current_updates source
            ON target.SERIES_ID = source.SERIES_ID
                AND target.YR = source.YR
                AND target.PER_CD = source.PER_CD
                AND target.CUR_IND = 'Y'
            WHEN MATCHED THEN
                UPDATE SET
                    target.BLS_END_DTTM = source.END_DTTM,
                    target.CUR_IND = 'N',
                    target.LAST_UPD_USR_ID = source.LAST_UPD_USR_ID,
                    target.LAST_UPD_DTTM = source.LAST_UPD_DTTM
        """)

        return True
    except Exception as e:
        error_message = f"❌ Merge failed: {str(e)}"
        logger.error(error_message)
        update_process_status(env, user, process_id, status="FAILED", error_message=error_message)
        raise


# COMMAND ----------

def process_current_records(env, bls_last_date, process_id, user, filter_ids=None):
    """Process current records."""
    try:
        frmla_map_filter = "1=1"
        if filter_ids and filter_ids.get("formula_map_ids"):
            # Ensure values are properly escaped and comma-separated
            formatted_ids = ",".join(f"'{str(id)}'" for id in filter_ids["formula_map_ids"])
            frmla_map_filter = f"frml.DE_VER_ST_FRMLA_MAP_ID IN ({formatted_ids})"

        current_query = f"""
        WITH fin AS (
            SELECT vend.bls_measure_cd,vend.bls_seasonal_ind, dv.create_dttm dv_create_dttm, dv.LAST_UPD_DTTM dv_last_upd_dttm,
                   dvs.CREATE_DTTM dvs_create_dttm, dvs.LAST_UPD_DTTM dvs_last_upd_dttm, frml.CREATE_DTTM frml_create_dttm,
                   frml.LAST_UPD_DTTM frml_last_upd_dttm, vend.CREATE_DTTM vend_create_dttm, vend.LAST_UPD_DTTM vend_last_upd_dttm
              FROM idf_{env}.finanalytic.v_de_ver dv
              JOIN idf_{env}.finanalytic.v_de_ver_st dvs ON dv.de_ver_id = dvs.de_ver_id AND dvs.CUR_IND = 'Y'
              JOIN idf_{env}.finanalytic.v_de_ver_st_frmla_map frml ON dvs.DE_VER_ST_ID = frml.de_ver_st_id AND frml.cur_ind = 'Y'
              JOIN idf_{env}.finanalytic.v_de_frmla_map_vendor_attr vend ON frml.DE_VER_ST_FRMLA_MAP_ID = vend.de_ver_st_frmla_map_id AND vend.ACTV_IND = 'Y'
             WHERE dv.CUR_IND = 'Y' and dv.stage_cd='FINAL'
             AND ({frmla_map_filter})
        )
        SELECT dp.SERIES_ID, INT(dp.YR) AS YR, NVL(dp.PER_CD, ' ') AS PER_CD, dp.END_DTTM AS BLS_END_DTTM, 
               dp.VAL_TEXT, dp.FOOTNOTE_CD, NVL(dp.FOOTNOTE_TEXT, ' ') AS FOOTNOTE_TEXT, 
               dp.START_DTTM AS BLS_START_DTTM, NVL(dp.CUR_IND, ' ') AS CUR_IND, 
               NVL(dp.DEL_FROM_SRC_IND, ' ') AS DEL_FROM_SRC_IND, NVL(dp.ACTV_IND, ' ') AS ACTV_IND, 
               NVL(dp.AREA_TYP_CD, ' ') AS AREA_TYP_CD, NVL(dp.AREA_TYP_DESC, ' ') AS AREA_TYP_DESC, 
               NVL(dp.AREA_CD, ' ') AS AREA_CD, NVL(dp.AREA_DESC, ' ') AS AREA_DESC, 
               NVL(dp.MEASURE_CD, ' ') AS MEASURE_CD, NVL(dp.MEASURE_DESC, ' ') AS MEASURE_DESC, 
               NVL(dp.SEASONAL_CD, ' ') AS SEASONAL_CD, NVL(dp.SEASONAL_DESC, ' ') AS SEASONAL_DESC, 
               NVL(dp.ST_REGN_DIV_CD, ' ') AS ST_REGN_DIV_CD, NVL(dp.ST_REGN_DIV_NAME, ' ') AS ST_REGN_DIV_NAME, 
               NVL(dp.SERIES_TITLE, ' ') AS SERIES_TITLE, dp.CREATE_USR_ID, dp.CREATE_DTTM, 
               dp.LAST_UPD_USR_ID, dp.LAST_UPD_DTTM, NVL(dp.SRC_FILE_NAME, ' ') AS SRC_FILE_NAME
        FROM idf_curated_{env}.bls.v_data_pnt dp
        JOIN fin ON fin.bls_measure_cd = dp.measure_cd
           AND fin.bls_seasonal_ind=dp.seasonal_cd
        WHERE cur_ind = 'Y'
        AND (dp.create_dttm >= cast('{bls_last_date}' as TIMESTAMP)
             OR dp.last_upd_dttm >= cast('{bls_last_date}' as TIMESTAMP)
             OR fin.dv_create_dttm >= cast('{bls_last_date}' as TIMESTAMP)
             OR fin.dv_last_upd_dttm >= cast('{bls_last_date}' as TIMESTAMP)
             OR fin.dvs_create_dttm >= cast('{bls_last_date}' as TIMESTAMP)
             OR fin.dvs_last_upd_dttm >= cast('{bls_last_date}' as TIMESTAMP)
             OR fin.frml_create_dttm >= cast('{bls_last_date}' as TIMESTAMP)
             OR fin.frml_last_upd_dttm >= cast('{bls_last_date}' as TIMESTAMP)
             OR fin.vend_create_dttm >= cast('{bls_last_date}' as TIMESTAMP)
             OR fin.vend_last_upd_dttm >= cast('{bls_last_date}' as TIMESTAMP))
                """

        current_df = spark.sql(current_query).dropDuplicates()
        print(f"Current records count: {current_df.count()}")
        # Get the current max DATA_PNT_ID from the target table
        max_id_row = spark.sql(f"SELECT MAX(DATA_PNT_ID) as max_id FROM idf_raw_{env}.BLS_ECON.T_DATA_PNT").collect()
        max_id = max_id_row[0]['max_id'] if max_id_row[0]['max_id'] is not None else 0
        window_spec = Window.orderBy(lit(1))

        current_data = current_df \
            .withColumn("CREATE_USR_ID", lit(user)) \
            .withColumn("CREATE_DTTM", current_timestamp()) \
            .withColumn("LAST_UPD_USR_ID", lit(user)) \
            .withColumn("LAST_UPD_DTTM", current_timestamp())  \
            .withColumn("DATA_PNT_ID", row_number().over(window_spec) + max_id)


        # Create a temporary view for the merge operation
        current_data.createOrReplaceTempView("current_updates")

        # Execute the merge operation
        spark.sql(f"""
            MERGE INTO idf_raw_{env}.BLS_ECON.T_DATA_PNT target
            USING current_updates source
            ON target.SERIES_ID = source.SERIES_ID
                AND target.YR = source.YR
                AND target.PER_CD = source.PER_CD
                AND target.CUR_IND = 'Y'
            WHEN MATCHED THEN
                UPDATE SET
                    target.SEASONAL_CD = source.SEASONAL_CD,
                    target.SEASONAL_DESC = source.SEASONAL_DESC,
                    target.AREA_CD = source.AREA_CD,
                    target.AREA_DESC = source.AREA_DESC,
                    target.MEASURE_CD = source.MEASURE_CD,
                    target.VAL_TEXT = source.VAL_TEXT,
                    target.BLS_START_DTTM = source.BLS_START_DTTM,
                    target.BLS_END_DTTM = source.BLS_END_DTTM,
                    target.DEL_FROM_SRC_IND = source.DEL_FROM_SRC_IND,
                    target.ACTV_IND = source.ACTV_IND,
                    target.MEASURE_DESC = source.MEASURE_DESC,
                    target.FOOTNOTE_CD = source.FOOTNOTE_CD,
                    target.FOOTNOTE_TEXT = source.FOOTNOTE_TEXT,
                    target.AREA_TYP_CD = source.AREA_TYP_CD,
                    target.AREA_TYP_DESC = source.AREA_TYP_DESC,
                    target.ST_REGN_DIV_CD = source.ST_REGN_DIV_CD,
                    target.ST_REGN_DIV_NAME = source.ST_REGN_DIV_NAME,
                    target.SERIES_TITLE = source.SERIES_TITLE,
                    target.LAST_UPD_USR_ID = source.LAST_UPD_USR_ID,
                    target.LAST_UPD_DTTM = current_timestamp(),
                    target.SRC_FILE_NAME = source.SRC_FILE_NAME
            WHEN NOT MATCHED THEN
                INSERT (
                    DATA_PNT_ID, SERIES_ID, YR, PER_CD, SEASONAL_CD, SEASONAL_DESC,
                    AREA_CD, AREA_DESC, MEASURE_CD, VAL_TEXT,
                    BLS_START_DTTM, BLS_END_DTTM, CUR_IND,
                    DEL_FROM_SRC_IND, ACTV_IND, MEASURE_DESC,
                    FOOTNOTE_CD, FOOTNOTE_TEXT, AREA_TYP_CD,
                    AREA_TYP_DESC, ST_REGN_DIV_CD, ST_REGN_DIV_NAME,
                    SERIES_TITLE, CREATE_USR_ID, CREATE_DTTM,
                    LAST_UPD_USR_ID, LAST_UPD_DTTM, SRC_FILE_NAME
                )
                VALUES (
                    source.DATA_PNT_ID, source.SERIES_ID, source.YR, source.PER_CD,
                    source.SEASONAL_CD, source.SEASONAL_DESC,
                    source.AREA_CD, source.AREA_DESC, source.MEASURE_CD,
                    source.VAL_TEXT, source.BLS_START_DTTM,
                    source.BLS_END_DTTM, source.CUR_IND,
                    source.DEL_FROM_SRC_IND, source.ACTV_IND,
                    source.MEASURE_DESC, source.FOOTNOTE_CD,
                    source.FOOTNOTE_TEXT, source.AREA_TYP_CD,
                    source.AREA_TYP_DESC, source.ST_REGN_DIV_CD,
                    source.ST_REGN_DIV_NAME, source.SERIES_TITLE,
                    source.CREATE_USR_ID, current_timestamp(),
                    source.LAST_UPD_USR_ID, current_timestamp(),
                    source.SRC_FILE_NAME
                )
        """)

        return True
    except Exception as e:
        error_message = f"❌ Merge failed: {str(e)}"
        logger.error(error_message)
        update_process_status(env, user, process_id, status="FAILED", error_message=error_message)
        raise


# COMMAND ----------

def calculate_bls_ttm(env, bls_last_date):
    """Calculate TTM (Trailing Twelve Months) values for BLS data."""
    try:
        if bls_last_date == "1900-01-01":
            # Fetch data for initial load
            try:
                data_n_query = f"""
                SELECT dp.SERIES_ID, dp.YR, dp.PER_CD, dp.SEASONAL_CD, dp.SEASONAL_DESC, dp.AREA_CD, dp.AREA_DESC, dp.MEASURE_CD, dp.VAL_TEXT,
                    AVG(CASE WHEN NOT REGEXP_LIKE(dp.VAL_TEXT, '^-?[0-9.]+$') THEN 0 ELSE CAST(dp.VAL_TEXT AS DOUBLE) END)
                    OVER (PARTITION BY dp.SERIES_ID ORDER BY dp.YR, dp.PER_CD ROWS BETWEEN 11 PRECEDING AND CURRENT ROW) AS TTM_VAL_TEXT,
                    CURRENT_TIMESTAMP() AS TTM_VAL_ASOF_DTTM, dp.BLS_START_DTTM, dp.BLS_END_DTTM, dp.CUR_IND, dp.DEL_FROM_SRC_IND, dp.ACTV_IND,
                    dp.MEASURE_DESC, dp.FOOTNOTE_CD, dp.FOOTNOTE_TEXT, dp.AREA_TYP_CD, dp.AREA_TYP_DESC, dp.ST_REGN_DIV_CD, dp.ST_REGN_DIV_NAME,
                    dp.SERIES_TITLE, dp.CREATE_USR_ID, dp.CREATE_DTTM, dp.LAST_UPD_USR_ID, dp.LAST_UPD_DTTM, dp.SRC_FILE_NAME
                FROM idf_raw_{env}.BLS_ECON.T_DATA_PNT dp
                WHERE PER_CD != 'M13' AND DEL_FROM_SRC_IND = 'N' AND CUR_IND = 'Y'
                AND (dp.create_dttm >= cast('{bls_last_date}' as TIMESTAMP)
                    OR dp.last_upd_dttm >= cast('{bls_last_date}' as TIMESTAMP))"""
                data_n = spark.sql(data_n_query).dropDuplicates()
                data_y_query = f"""
                SELECT dp.SERIES_ID, dp.YR, dp.PER_CD, dp.SEASONAL_CD, dp.SEASONAL_DESC, dp.AREA_CD, dp.AREA_DESC, dp.MEASURE_CD, dp.VAL_TEXT,
                    dp.TTM_VAL_TEXT, dp.TTM_VAL_ASOF_DTTM, dp.BLS_START_DTTM, dp.BLS_END_DTTM, dp.CUR_IND, dp.DEL_FROM_SRC_IND, dp.ACTV_IND,
                    dp.MEASURE_DESC, dp.FOOTNOTE_CD, dp.FOOTNOTE_TEXT, dp.AREA_TYP_CD, dp.AREA_TYP_DESC, dp.ST_REGN_DIV_CD, dp.ST_REGN_DIV_NAME,
                    dp.SERIES_TITLE, dp.CREATE_USR_ID, dp.CREATE_DTTM, dp.LAST_UPD_USR_ID, dp.LAST_UPD_DTTM, dp.SRC_FILE_NAME
                FROM idf_raw_{env}.BLS_ECON.T_DATA_PNT dp
                WHERE PER_CD = 'M13' OR DEL_FROM_SRC_IND = 'Y'
                AND (dp.create_dttm >= cast('{bls_last_date}' as TIMESTAMP)
                    OR dp.last_upd_dttm >= cast('{bls_last_date}' as TIMESTAMP))"""

                data_y = spark.sql(data_y_query).dropDuplicates()

                # Combine the results and write to the main table
                combined_data = data_n.union(data_y)
                combined_data.write.insertInto(f"idf_raw_{env}.BLS_ECON.T_DATA_PNT", overwrite=False)
            except Exception as e:
                logger.warning(f"Error merging current data: {e}")
                return False
        else:
            # Fetch data for incremental load
            try:
                data_query = f"""
                SELECT dp.DATA_PNT_ID, dp.SERIES_ID, dp.YR, dp.PER_CD, dp.SEASONAL_CD, dp.SEASONAL_DESC, dp.AREA_CD, dp.AREA_DESC, dp.MEASURE_CD, dp.VAL_TEXT,
                    AVG(CASE WHEN NOT REGEXP_LIKE(dp.VAL_TEXT, '^-?[0-9.]+$') THEN 0 ELSE CAST(dp.VAL_TEXT AS DOUBLE) END)
                    OVER (PARTITION BY dp.SERIES_ID ORDER BY YR, dp.PER_CD ROWS BETWEEN 11 PRECEDING AND CURRENT ROW) AS TTM_VAL_TEXT,
                    CURRENT_TIMESTAMP() AS TTM_VAL_ASOF_DTTM, dp.BLS_START_DTTM, dp.BLS_END_DTTM, dp.CUR_IND, dp.DEL_FROM_SRC_IND, dp.ACTV_IND,
                    dp.MEASURE_DESC, dp.FOOTNOTE_CD, dp.FOOTNOTE_TEXT, dp.AREA_TYP_CD, dp.AREA_TYP_DESC, dp.ST_REGN_DIV_CD, dp.ST_REGN_DIV_NAME,
                    dp.SERIES_TITLE, dp.CREATE_USR_ID, dp.CREATE_DTTM, dp.LAST_UPD_USR_ID, dp.LAST_UPD_DTTM, dp.SRC_FILE_NAME
                FROM idf_raw_{env}.BLS_ECON.T_DATA_PNT dp
                WHERE PER_CD != 'M13' AND DEL_FROM_SRC_IND = 'N' AND CUR_IND = 'Y'
                AND SERIES_ID IN (
                    SELECT SERIES_ID
                    FROM idf_raw_{env}.BLS_ECON.T_DATA_PNT
                    WHERE LAST_UPD_DTTM >= cast('{bls_last_date}' as TIMESTAMP)
                       OR CREATE_DTTM >= cast('{bls_last_date}' as TIMESTAMP)
                )
                AND (dp.create_dttm >= cast('{bls_last_date}' as TIMESTAMP)
                    OR dp.last_upd_dttm >= cast('{bls_last_date}' as TIMESTAMP))"""
                data = spark.sql(data_query).dropDuplicates()

                # Create a temp view for the data
                data.createOrReplaceTempView("ttm_data")

                # Update existing records
                spark.sql(f"""
                    MERGE INTO idf_raw_{env}.BLS_ECON.T_DATA_PNT target
                    USING ttm_data source
                    ON (target.SERIES_ID = source.SERIES_ID AND target.YR = source.YR AND target.PER_CD = source.PER_CD)
                    WHEN MATCHED AND target.TTM_VAL_TEXT IS NULL AND target.PER_CD != 'M13' AND target.CUR_IND = 'Y' THEN
                        UPDATE SET
                            target.TTM_VAL_TEXT = source.TTM_VAL_TEXT,
                            target.TTM_VAL_ASOF_DTTM = source.TTM_VAL_ASOF_DTTM
                """)

                # Mark records as non-current if TTM_VAL_TEXT has changed
                spark.sql(f"""
                    MERGE INTO idf_raw_{env}.BLS_ECON.T_DATA_PNT target
                    USING ttm_data source
                    ON (target.SERIES_ID = source.SERIES_ID AND target.YR = source.YR AND target.PER_CD = source.PER_CD)
                    WHEN MATCHED AND NVL(target.TTM_VAL_TEXT, 'na') != NVL(source.TTM_VAL_TEXT, 'na') AND target.TTM_VAL_TEXT IS NOT NULL AND target.CUR_IND = 'Y' THEN
                        UPDATE SET
                            target.CUR_IND = 'N'
                """)

                # Insert new records
                spark.sql(f"""
                    MERGE INTO idf_raw_{env}.BLS_ECON.T_DATA_PNT target
                    USING ttm_data source
                    ON (target.SERIES_ID = source.SERIES_ID AND target.YR = source.YR AND target.PER_CD = source.PER_CD AND NVL(target.TTM_VAL_TEXT, 'na') = NVL(source.TTM_VAL_TEXT, 'na') AND target.CUR_IND = 'Y')
                    WHEN NOT MATCHED THEN
                        INSERT (
                            DATA_PNT_ID, SERIES_ID, YR, PER_CD, SEASONAL_CD, SEASONAL_DESC, AREA_CD, AREA_DESC, MEASURE_CD, VAL_TEXT,
                            TTM_VAL_TEXT, TTM_VAL_ASOF_DTTM, BLS_START_DTTM, BLS_END_DTTM, CUR_IND, DEL_FROM_SRC_IND, ACTV_IND,
                            MEASURE_DESC, FOOTNOTE_CD, FOOTNOTE_TEXT, AREA_TYP_CD, AREA_TYP_DESC, ST_REGN_DIV_CD, ST_REGN_DIV_NAME,
                            SERIES_TITLE, CREATE_USR_ID, CREATE_DTTM, LAST_UPD_USR_ID, LAST_UPD_DTTM, SRC_FILE_NAME
                        )
                        VALUES (
                            source.DATA_PNT_ID, source.SERIES_ID, source.YR, source.PER_CD, source.SEASONAL_CD, source.SEASONAL_DESC,
                            source.AREA_CD, source.AREA_DESC, source.MEASURE_CD, source.VAL_TEXT, source.TTM_VAL_TEXT, source.TTM_VAL_ASOF_DTTM,
                            source.BLS_START_DTTM, source.BLS_END_DTTM, source.CUR_IND, source.DEL_FROM_SRC_IND, source.ACTV_IND,
                            source.MEASURE_DESC, source.FOOTNOTE_CD, source.FOOTNOTE_TEXT, source.AREA_TYP_CD, source.AREA_TYP_DESC,
                            source.ST_REGN_DIV_CD, source.ST_REGN_DIV_NAME, source.SERIES_TITLE, source.CREATE_USR_ID,
                            current_timestamp(), source.LAST_UPD_USR_ID, source.LAST_UPD_DTTM, source.SRC_FILE_NAME
                        )
                """)
            except Exception as e:
                logger.warning(f"Error merging current data: {e}")
                return False

        logger.info("BLS TTM calculation completed successfully.")
        return True
    except Exception as e:
        error_message = f"❌ Merge failed: {str(e)}"
        logger.error(error_message)
        update_process_status(env, user, process_id, status="FAILED", error_message=error_message)
        raise


def run_bls_data_pnt(env, user,run_type, start_date=None, filters=None):
    """Main function to coordinate the data ingestion process."""
    if start_date:
        bls_last_date=start_date
    else:
        bls_last_date = get_last_processed_date(env,run_type,start_date)
    print(f"Processing data since: {bls_last_date}")
    print(run_type)
    batch_process_id = generate_process_id()
    insert_batch_process_status_started(env, user, batch_process_id,run_type, status="STARTED")
    print(f"Batch process ID: {batch_process_id}")
    process_id = generate_process_id()
    print(f"Task Process ID: {process_id}")
    insert_process_status_started(env, user, process_id, batch_process_id,run_type,table_name="BLS_DATA_PNT")
    print(f"Starting BLS data ingestion process with ID: {process_id}")
    bls_last_date_first = datetime.now().strftime("%Y-%m-%d") if bls_last_date == "1900-01-01" else bls_last_date
    print(f"Using last processed date: {bls_last_date_first}")
    process_non_current_records(env, bls_last_date_first, process_id, user)
    if run_type in (RunType.FINANALYTIC_STREAM.value, RunType.USPF_STREAM.value):
        process_current_records(env, bls_last_date_first, process_id, user, filter_ids=filters)
    else:
        process_current_records(env, bls_last_date_first, process_id, user)
    calculate_bls_ttm(env, bls_last_date_first)
    update_process_status(env, user, process_id, status="COMPLETED")
    print("🎉 load_bls_data_pnt task completed successfully.")





