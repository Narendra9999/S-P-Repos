from pyspark.sql import functions as F
from pyspark.sql.functions import col, when, struct, lit, udf, to_json, from_json, to_timestamp, \
    monotonically_increasing_id, lit, current_timestamp
from pyspark.sql.types import DoubleType, StructType, StructField, StringType
import time
from typing import  Dict,List, Optional
from pyspark.sql import SparkSession
from pyspark.sql import DataFrame
from datetime import datetime
from apd_ingestion.constants.enum_vars import RunType,LoadType
from apd_ingestion.database.postgres.adp_postgres_handler import ADPPostgresHandler
from apd_ingestion.bls.bls_utils import get_last_processed_date,get_main_process_id, is_bls_batch_completed


def get_spark_session():
    return SparkSession.builder.appName("Load_BLS_into_APD").getOrCreate()

def build_in_clause(column_name, values):
    """
    Utility to build SQL IN clause string safely for multiple values.
    """
    if not values:
        return ""
    quoted_values = ", ".join(f"'{val}'" for val in values)
    return f"AND {column_name} IN ({quoted_values})"

def load_input_dataframes(spark,is_incremental,env,run_type,bls_last_date, filter_ids=None):

    fips_code = filter_ids.get("fips_code") if filter_ids else None
    org_ids = filter_ids.get("org_ids") if filter_ids else None
    # Handle strings passed instead of lists
    if isinstance(fips_code, str):
        fips_code = [fips_code]
    if isinstance(org_ids, str):
        org_ids = [org_ids]

    geo_filter_clause = build_in_clause("fgr.fips_code", fips_code)
    org_filter_clause = build_in_clause("fa.finorg_id", org_ids)

    print("🔍 Applying filters:")
    print(f" - geo_filter_clause: {geo_filter_clause}")
    print(f" - org_filter_clause: {org_filter_clause}")

    finOrg = f"""
    select 
    fa.state_code state,
    fa.finorg_id finOrg,
    fsem.source_entity_id entityid,
    fa.finorg_name finorgname,
    fa.obligor_re_org_id red_org_id, 
    reo.legal_name re_org_name,
    fa.country_code countrycd,
    fa.fin_sector_name sectorname,
    fa.fye_day_mth_text as fye
    from idf_{env}.uspf_apr.t_finorg_attr fa
    join idf_{env}.uspf_apr.t_finorg_source_entity_map fsem on fa.finorg_id = fsem.finorg_id and source_code = 'PHOENIXUSPF' and fsem.active_ind = 'Y'
    left join idf_{env}.uspf_apr.t_ratings_entity_org reo on fa.obligor_re_org_id = reo.re_org_id and reo.END_DTTM = '31-dec-9999'
    where 1=1
    {org_filter_clause}
    """

    # # COMMAND ----------
    #
    # spid = f"""select a.sp_org_id, a.id_type, a.id_value, b.primary_name from idf_{env}.org.v_org_linking a, idf_{env}.org.v_enterprise_org_reference b
    #     where a.id_type = 'CORE' and a.active_flag = 'Y'
    #     and a.end_date is null
    #     and a.sp_org_id = b.sp_org_id
    #     and b.end_date is null"""


    # COMMAND ----------

    finOrgGeoLink = f"""
        select fgr.finorg_id finorgid, gu.geo_unit_cd gu_id, gu.geo_unit_typ gu_typ, fgr.purpose_type, fgr.fips_code as fipscode, ihs.id_value ihsid, bea.id_value bea, bls.id_value blsid, eds.id_value edsid, fa.fin_sector_name sector
        from idf_{env}.uspf_apr.t_finorg_geo_rel fgr
        join idf_{env}.uspf_apr.t_fips_geo_unit fgu on fgr.fips_code = fgu.fips_code and fgu.cur_ind = 'Y' and fgu.fips_validity_end_date >= current_date()
        join idf_{env}.uspf_apr.t_geographic_unit gu on fgu.geo_unit_id = gu.geo_unit_id
        left join idf_{env}.uspf_apr.t_fips_id_link ihs on ihs.cur_ind = 'Y' and ihs.id_fips_validity_end_date = '9999-12-31' and ihs.id_source = 'IHSID' and fgr.fips_code = ihs.fips_code
        left join idf_{env}.uspf_apr.t_fips_id_link bea on bea.cur_ind = 'Y' and bea.id_fips_validity_end_date = '9999-12-31' and bea.id_source = 'BEA' and fgr.fips_code = bea.fips_code
        left join idf_{env}.uspf_apr.t_fips_id_link eds on eds.cur_ind = 'Y' and eds.id_fips_validity_end_date = '9999-12-31' and eds.id_source = 'EDSID' and fgr.fips_code = eds.fips_code
        left join idf_{env}.uspf_apr.t_fips_id_link bls on bls.cur_ind = 'Y' and bls.id_fips_validity_end_date = '9999-12-31' and bls.id_source = 'BLSID' and fgr.fips_code = bls.fips_code
        join idf_{env}.uspf_apr.t_finorg_attr fa on fa.active_ind = 'Y' and fa.end_dttm = '9999-12-31' and fgr.finorg_id = fa.finorg_id
        where fgr.cur_ind = 'Y'
        {geo_filter_clause}
"""

    # COMMAND ----------
    blsDataPnt = f"""select c.cmp_indus_lvl2_clsf_cd, dv.ent_mnem_cd, c.de_ver_st_frmla_map_id,
    a.DATA_PNT_ID,a.SERIES_ID,a.YR,a.PER_CD,a.SEASONAL_CD,a.SEASONAL_DESC,a.AREA_CD,a.AREA_DESC,
    a.MEASURE_CD,a.VAL_TEXT,a.TTM_VAL_TEXT,a.TTM_VAL_ASOF_DTTM,a.BLS_START_DTTM,a.BLS_END_DTTM,
    a.CUR_IND,a.DEL_FROM_SRC_IND,a.ACTV_IND,a.MEASURE_DESC,a.FOOTNOTE_CD,a.FOOTNOTE_TEXT,
    a.AREA_TYP_CD,a.AREA_TYP_DESC,a.ST_REGN_DIV_CD,a.ST_REGN_DIV_NAME,a.SERIES_TITLE,
    a.CREATE_USR_ID,a.CREATE_DTTM,a.LAST_UPD_USR_ID,a.LAST_UPD_DTTM,a.SRC_FILE_NAME 
    from idf_raw_{env}.bls_econ.t_data_pnt a, idf_{env}.finanalytic.t_de_frmla_map_vendor_attr b, 
    idf_{env}.finanalytic.t_de_ver_st_frmla_map c, idf_{env}.finanalytic.t_de_ver_st dvs, idf_{env}.finanalytic.t_de_ver dv
    where dv.cur_ind = 'Y'
    and dv.stage_cd = 'FINAL'
    and dv.de_ver_id = dvs.de_ver_id
    and dvs.cur_ind = 'Y'
    and dvs.de_ver_st_id = c.de_ver_st_id
    and b.de_ver_st_frmla_map_id = c.de_ver_st_frmla_map_id
    and  a.measure_cd = b.bls_measure_cd
    and a.seasonal_cd = b.bls_seasonal_ind
    """

    # COMMAND ----------

    ent_mnem = f"""select * from idf_{env}.mnem_map.t_ent_mnem where mnemonic_type = 'Financial' and is_deleted = 'N'"""

    # reo=f"""select legacy_core_org_id, sp_org_id, re_org_id, published_name
    # from idf_{env}.uspf_apr.t_ratings_entity_org
    # where end_date is null or end_date = '31-dec-9999'"""

    filters = []

    if is_incremental:
        print("updating query for incremental")
        print(bls_last_date)
        blsDataPnt += f""" and a.LAST_UPD_DTTM >= TIMESTAMP('{bls_last_date}')"""

    if filter_ids and filter_ids.get("formula_map_ids"):
        formatted_ids = ",".join(f"'{str(id)}'" for id in filter_ids["formula_map_ids"])
        filters.append(f"edp.fa_de_ver_st_frmla_map_id IN ({formatted_ids})")

    if filters:
        blsDataPnt += f""" and frml.DE_VER_ST_FRMLA_MAP_ID IN ({final_ids})"""

    # Run queries
    finorg_df = spark.sql(finOrg).dropDuplicates()
    # spid_df = spark.sql(spid).dropDuplicates()
    finorggeolink_df = spark.sql(finOrgGeoLink).dropDuplicates()
    blsdatapnt_df = spark.sql(blsDataPnt).dropDuplicates()
    ent_mnem_df = spark.sql(ent_mnem).dropDuplicates()
    # reo_df = spark.sql(reo).dropDuplicates()

    print(f"✅ FinOrg count:        {finorg_df.count()}")
    # print(f"✅ SPID count:          {spid_df.count()}")
    print(f"✅ ent_mnem_df count:    {ent_mnem_df.count()}")
    print(f"✅ FinOrgGeoLink count: {finorggeolink_df.count()}")
    print(f"✅ blsData count:   {blsdatapnt_df.count()}")
    # print(f"✅ REO count:           {reo_df.count()}")

    return finorg_df, finorggeolink_df, blsdatapnt_df, ent_mnem_df

def filter_input_dataframes(finorg_df, finorggeolink_df, blsdatapnt_df):
    """
    Filters all input DataFrames based on finorg_ids and geo_ids.

    :param finorg_df: Spark DataFrame for finOrg
    :param spid_df: Spark DataFrame for SPID
    :param finorggeolink_df: Spark DataFrame for finOrgGeoLink
    :param econ_df: Spark DataFrame for econDataPnt
    :param entfinfndl_df: Spark DataFrame for EntFinFndl
    :param finorg_ids: List of finorgids to filter
    :param geo_ids: List of geo_unit_ids to filter
    :return: Tuple of filtered DataFrames
    """

    # if finorg_ids:
    #     finorg_df = finorg_df.filter(F.col("finorg").isin(finorg_ids))
    #     spid_df = spid_df.filter(F.col("id_value").isin(finorg_ids))
    #     finorggeolink_df = finorggeolink_df.filter(F.col("finorgid").isin(finorg_ids))
    #     entfinfndl_df = entfinfndl_df.filter(F.col("finorgid").isin(finorg_ids))

    # if geo_ids:
    #     econ_df = econ_df.filter(F.col("vendorgeographiclocationid").isin(geo_ids))
    #     finorggeolink_df = finorggeolink_df.filter(F.col("ihsid").isin(geo_ids))
    # core_org_ids = [row['core_org_id'] for row in finorg_df.select("core_org_id").distinct().collect()]

    # Step 2: Filter SPID to only relevant core_org_ids
    # spid_df_filtered = spid_df.filter(F.col("id_value").isin(core_org_ids))
    finorg_ids = [row['finOrg'] for row in finorg_df.select("finOrg").distinct().collect()]

    print("\n🔄 Filtering finorggeolink_df by finorg_ids...")
    finorggeolink_filtered = finorggeolink_df.filter(F.col("finorgid").isin(finorg_ids))
    print(f"finorggeolink_df count after filter: {finorggeolink_filtered.count()}")

    print("\n🔄 Filtering blsdatapnt_df by area_cd in finorggeolink_filtered...")
    geo_ids = [row['blsid'] for row in finorggeolink_filtered.select("blsid").distinct().collect()]
    bls_filtered = blsdatapnt_df.filter(F.col("area_cd").isin(geo_ids))
    print(f"blsdatapnt_df count after filter: {bls_filtered.count()}")

    # Drop duplicates after filtering (optional but recommended)
    print("📦 Deduplicating after filtering...")
    finorg_df = finorg_df.dropDuplicates()
    # spid_df = spid_df_filtered.dropDuplicates()
    finorggeolink_df = finorggeolink_filtered.dropDuplicates()
    blsdatapnt_df = bls_filtered.dropDuplicates()

    print("✅ Filtered + Deduplicated Counts:")
    print(f" - finorg_df:         {finorg_df.count()}")
    # print(f" - spid_df:           {spid_df.count()}")
    print(f" - finorggeolink_df:  {finorggeolink_df.count()}")
    print(f" - blsdatapnt_df:           {blsdatapnt_df.count()}")

    return finorg_df, finorggeolink_df, blsdatapnt_df

# COMMAND ----------

# def join_finorg_with_spid(finorg_df, spid_df):
#     """
#     Join FinOrg with SPID on core_org_id = id_value.
#     Returns deduplicated joined DataFrame.
#     """
#
#     finorg_df = finorg_df.withColumn("fye", F.lpad(col("fye"), 4, "0")) \
#         .withColumn("fym", F.expr("substr(fye, 0,2)")) \
#         .withColumn("fyd", F.expr("substr(fye,3,4)"))
#
#     finorg_spid_df = finorg_df.alias("fo") \
#         .join(spid_df.alias("sp"),
#               F.col("fo.core_org_id") == F.col("sp.id_value"),
#               "left") \
#         .select(
#         F.col("fo.finOrg"),
#         F.col("fo.core_org_id"),
#         F.col("fye"),
#         F.col("fym").alias("fym"),
#         F.col("fyd").alias("fyd"),
#         F.col("fo.sectorname").alias("sectorName"),
#         F.col("sp.sp_org_id").alias("org_sp_id"),
#         F.col("sp.primary_name").alias("org_name")
#     )
#
#     # Step 4: Print sample and count before and after deduplication
#     print("\n--- FinOrg + SPID Join (Before Deduplication) ---")
#     # finorg_spid_df.show(5)
#     print(f"Count before dedup: {finorg_spid_df.count()}")
#
#     # Step 5: Drop duplicates
#     finorg_spid_df = finorg_spid_df.dropDuplicates()
#
#     print(f"Count after dedup:  {finorg_spid_df.count()}")
#     return finorg_spid_df


# COMMAND ----------

def join_bls_with_finorggeolink(blsdatapnt_df, finorggeolink_df):
    blsdatapnt_df = blsdatapnt_df.withColumn("per_cd_month", F.col("PER_CD")) \
        .withColumn("per_cd_month", F.expr("substr(per_cd, -2)"))

    bls_data_fingeo_df = blsdatapnt_df.alias("bls") \
        .join(
        finorggeolink_df.alias("fog"),
        on=(
                (F.col("bls.area_cd") == F.col("fog.blsid")) &
                (F.col("bls.cmp_indus_lvl2_clsf_cd") == F.col("fog.sector"))
        ),
        how="inner"
    ) \
        .select(F.col("fog.finorgid"),
                F.col("fog.sector"),
                F.col("fog.purpose_type"),
                F.col("fog.gu_typ"),
                F.col("bls.*")
                )

    print(f"Count before dedup bls_data_fingeo_df: {bls_data_fingeo_df.count()}")
    bls_data_fingeo_df = bls_data_fingeo_df.dropDuplicates()

    print(f"Count after dedup bls_data_fingeo_df:  {bls_data_fingeo_df.count()}")
    return bls_data_fingeo_df


# COMMAND ----------

def join_bls_with_ent_mnem(bls_data_fingeo_df, ent_mnem_df):
    ent_mnem_df = ent_mnem_df.select("ent_mnem_cd", "ent_mnem_denom_name")
    ent_mnem_df = ent_mnem_df.dropDuplicates()
    bls_data_fingeo_ent_mnem_df = bls_data_fingeo_df.alias("bls") \
        .join(ent_mnem_df.alias("em"), F.col("bls.ent_mnem_cd") == F.col("em.ent_mnem_cd"), "left") \
        .select(
        F.col("bls.*"),
        F.col("em.ent_mnem_denom_name").alias("magnitude")
    )

    print(f"Count before dedup bls_data_fingeo_ent_mnem_df: {bls_data_fingeo_ent_mnem_df.count()}")
    bls_data_fingeo_ent_mnem_df = bls_data_fingeo_ent_mnem_df.dropDuplicates()

    print(f"Count after dedup bls_data_ent_mnem_df:  {bls_data_fingeo_ent_mnem_df.count()}")
    return bls_data_fingeo_ent_mnem_df


# COMMAND ----------

def join_bls_fingelink_with_finorg(bls_data_fingeo_ent_mnem_df, finorg_df):
    finorg_df = finorg_df.withColumn("fye", F.lpad(col("fye"), 4, "0")) \
                .withColumn("fym", F.expr("substr(fye, 0,2)")) \
                .withColumn("fyd", F.expr("substr(fye,3,4)"))
    bls_data_per_fye_df = bls_data_fingeo_ent_mnem_df.alias("blsfingeo") \
        .join(finorg_df.alias("fsp"), F.col("blsfingeo.finorgid") == F.col("fsp.finOrg"), "inner") \
        .select(
        F.col("fsp.finOrg"),
        F.col("fsp.re_org_name"),
        F.col("fsp.red_org_id"),
        F.col("fsp.finorgname"),
        F.col("fsp.fym"),
        F.col("fsp.fyd"),
        F.col("blsfingeo.*")
    )
    bls_data_fingeo_annual_df = bls_data_fingeo_ent_mnem_df.filter(F.col("PER_CD") == "M13")
    bls_data_per_annual_df = bls_data_fingeo_annual_df.alias("blsfingeo_annual") \
        .join(finorg_df.alias("fsp"), (F.col("blsfingeo_annual.finorgid") == F.col("fsp.finOrg")), "inner") \
        .select(
        F.col("fsp.finOrg"),
        F.col("fsp.re_org_name"),
        F.col("fsp.red_org_id"),
        F.col("fsp.finorgname"),
        F.col("fsp.fym"),
        F.col("fsp.fyd"),
        F.col("blsfingeo_annual.*")
    )
    print(f"Count before dedup bls_data_per_fye_df: {bls_data_per_fye_df.count()}")
    bls_data_per_fye_df = bls_data_per_fye_df.dropDuplicates()

    print(f"Count after dedup bls_data_per_fye_df:  {bls_data_per_fye_df.count()}")

    print(f"Count before dedup bls_data_per_annual_df: {bls_data_per_annual_df.count()}")
    bls_data_per_annual_df = bls_data_per_annual_df.dropDuplicates()

    print(f"Count after dedup bls_data_per_annual_df:  {bls_data_per_annual_df.count()}")

    return bls_data_per_fye_df, bls_data_per_annual_df


# COMMAND ----------

def monthly_value_trail(bls_noncur_df):
    monthly_value_trail_df = bls_noncur_df \
        .select(
        "finOrg", "AREA_CD", "YR", "PER_CD", "measure_cd", "de_ver_st_frmla_map_id", "seasonal_cd", "sector",
        F.col("bls_start_dttm").alias("valueAsOf"),
        F.coalesce("last_upd_usr_id", "create_usr_id").alias("valueUpdatedBy"),
        F.col("val_text").alias("value")
    ) \
        .withColumn("monthlyTrailItem", F.struct("valueAsOf", "valueUpdatedBy", "value")) \
        .groupBy("finOrg", "AREA_CD", "YR", "PER_CD", "measure_cd", "de_ver_st_frmla_map_id", "seasonal_cd") \
        .agg(F.collect_list("monthlyTrailItem").alias("MonthlyTrail"))

    print(f"Count before dedup monthly_value_trail_df: {monthly_value_trail_df.count()}")
    monthly_value_trail_df = monthly_value_trail_df.dropDuplicates()

    print(f"Count after dedup monthly_value_trail_df:  {monthly_value_trail_df.count()}")
    return monthly_value_trail_df


# COMMAND ----------

def ttm_value_trail(bls_noncur_df):
    ttm_value_trail_df = bls_noncur_df \
        .filter(F.col("ttm_val_text").isNotNull()) \
        .select(
        "finOrg", "AREA_CD", "YR", "PER_CD", "measure_cd", "de_ver_st_frmla_map_id", "seasonal_cd", "sector",
        F.col("ttm_val_asof_dttm").alias("valueAsOf"),
        F.coalesce("last_upd_usr_id", "create_usr_id").alias("valueUpdatedBy"),
        F.col("ttm_val_text").alias("value")
    ) \
        .withColumn("ttmTrailItem", F.struct("valueAsOf", "valueUpdatedBy", "value")) \
        .groupBy("finOrg", "AREA_CD", "YR", "PER_CD", "measure_cd", "de_ver_st_frmla_map_id", "seasonal_cd", "sector") \
        .agg(F.collect_list("ttmTrailItem").alias("TTMTrail"))

    print(f"Count before dedup ttm_value_trail_df: {ttm_value_trail_df.count()}")
    ttm_value_trail_df = ttm_value_trail_df.dropDuplicates()

    print(f"Count after dedup ttm_value_trail_df:  {ttm_value_trail_df.count()}")
    return ttm_value_trail_df


# COMMAND ----------

def annual_value_trail(bls_noncur_annual_df):
    annual_value_trail_df = bls_noncur_annual_df \
        .select(
        "finOrg", "AREA_CD", "YR", "PER_CD", "measure_cd", "de_ver_st_frmla_map_id", "seasonal_cd", "sector",
        F.col("bls_start_dttm").alias("valueAsOf"),
        F.coalesce("last_upd_usr_id", "create_usr_id").alias("valueUpdatedBy"),
        F.col("val_text").alias("value")
    ) \
        .withColumn("annualTrailItem", F.struct("valueAsOf", "valueUpdatedBy", "value")) \
        .groupBy("finOrg", "AREA_CD", "YR", "PER_CD", "measure_cd", "de_ver_st_frmla_map_id", "seasonal_cd", "sector") \
        .agg(F.collect_list("annualTrailItem").alias("annualValueTrail"))

    print(f"Count before dedup annual_value_trail_df: {annual_value_trail_df.count()}")
    annual_value_trail_df = annual_value_trail_df.dropDuplicates()

    print(f"Count after dedup annual_value_trail_df:  {annual_value_trail_df.count()}")
    return annual_value_trail_df


# COMMAND ----------

def current_month(bls_cur_df):
    current_month_df = bls_cur_df \
        .select(
        "finOrg", "fym", "fyd", "AREA_CD", "YR", "PER_CD", "measure_cd", "de_ver_st_frmla_map_id", "seasonal_cd",
        "sector", "ent_mnem_cd", "series_id", "magnitude",
        F.col("val_text").alias("currentMonthValue"),
        F.col("bls_start_dttm").alias("currentMonthValueAsOf"),
        F.col("ttm_val_text").alias("ttmValue"),
        F.col("ttm_val_asof_dttm").alias("ttmValueAsOf")
    )
    print(f"Count before dedup current_month_df: {current_month_df.count()}")
    current_month_df = current_month_df.dropDuplicates()

    print(f"Count after dedup current_month_df:  {current_month_df.count()}")
    return current_month_df


# COMMAND ----------

def annual_cur(bls_cur_annual_df):
    annual_cur_df = bls_cur_annual_df \
        .select(
        "finOrg", "fym", "fyd", "AREA_CD", "YR", "PER_CD", "measure_cd", "seasonal_cd", "sector", "ent_mnem_cd",
        "series_id", "de_ver_st_frmla_map_id", "magnitude",
        F.col("bls_start_dttm").alias("valueAsOf"),
        F.coalesce("last_upd_usr_id", "create_usr_id").alias("valueUpdatedBy"),
        F.col("val_text").alias("value")
    ) \
        .withColumnRenamed("valueAsOf", "annualValueAsOf") \
        .withColumnRenamed("valueUpdatedBy", "annualValueUpdatedBy") \
        .withColumnRenamed("value", "annualValue")
    print(f"Count before dedup annual_cur_df: {annual_cur_df.count()}")
    annual_cur_df = annual_cur_df.dropDuplicates()

    print(f"Count after dedup annual_cur_df:  {annual_cur_df.count()}")
    return annual_cur_df


# COMMAND ----------

def monthly_annual_data(current_month_df, monthly_value_trail_df, ttm_value_trail_df, annual_value_trail_df,
                        annual_cur_df):
    monthly_data_df = current_month_df.alias("current_month") \
        .join(monthly_value_trail_df.alias("monthly_value_trail"),
              ["finOrg", "AREA_CD", "YR", "PER_CD", "measure_cd", "de_ver_st_frmla_map_id", "seasonal_cd"],
              "left") \
        .select(F.col("current_month.*"),
                "monthly_value_trail.MonthlyTrail")
    ttm_data_df = monthly_data_df.alias("monthly_data") \
        .join(ttm_value_trail_df.alias("ttm_value_trail"),
              ["finOrg", "AREA_CD", "YR", "PER_CD", "measure_cd", "de_ver_st_frmla_map_id", "seasonal_cd"],
              "left") \
        .select(F.col("monthly_data.*"),
                "ttm_value_trail.TTMTrail")
    annual_data_df = ttm_data_df.alias("ttm_data") \
        .join(annual_cur_df.alias("annual_cur"),
              ["finOrg", "AREA_CD", "YR", "PER_CD", "measure_cd", "de_ver_st_frmla_map_id", "seasonal_cd"],
              "left") \
        .select(
        F.col("ttm_data.*"),
        "annual_cur.annualValue",
        "annual_cur.annualValueAsOf",
        "annual_cur.annualValueUpdatedBy")
    full_data_df = annual_data_df.alias("annual_data") \
        .join(annual_value_trail_df.alias("annual_value_trail"),
              ["finOrg", "AREA_CD", "YR", "PER_CD", "measure_cd", "de_ver_st_frmla_map_id", "seasonal_cd"],
              "left") \
        .select(F.col("annual_data.*"),
                "annual_value_trail.annualValueTrail")

    print(f"Count before dedup full_data_df: {full_data_df.count()}")
    full_data_df = full_data_df.dropDuplicates()

    print(f"Count after dedup full_data_df:  {full_data_df.count()}")

    return full_data_df


# COMMAND ----------

def seasonal_unseason_datapoint(full_data_df):
    data_point_struct = struct(
        col("measure_cd").alias("sourceMnemonic"),
        col("ent_mnem_cd").alias("mnemonic"),
        col("magnitude"),
        col("de_ver_st_frmla_map_id").alias("FaDEVerStFrmlaMapId"),
        col("series_id").alias("sourceSeriesId"),
        col("currentMonthValue"),
        col("currentMonthValueAsOf"),
        col("MonthlyTrail"),
        col("ttmValue"),
        col("ttmValueAsOf"),
        col("TTMTrail"),
        col("annualValue"),
        col("annualValueAsOf"),
        col("annualValueTrail")
    )
    data_by_location_seasonal_df = (full_data_df.withColumn("dataPoint", data_point_struct) \
                                    .groupBy("finOrg", "fym", "fyd", "AREA_CD", "YR", "PER_CD", "measure_cd",
                                             "de_ver_st_frmla_map_id", "seasonal_cd", "sector") \
                                    .agg(F.collect_list("dataPoint").alias("dataPoints")))
    print(f"Count before dedup data_by_location_seasonal_df: {data_by_location_seasonal_df.count()}")
    data_by_location_seasonal_df = data_by_location_seasonal_df.dropDuplicates()

    print(f"Count after dedup data_by_location_seasonal_df:  {data_by_location_seasonal_df.count()}")
    return data_by_location_seasonal_df


# COMMAND ----------

def econ_data(data_by_location_seasonal_df, bls_data_per_fye_df):
    location_data_df = data_by_location_seasonal_df.alias("dls") \
        .join(
        bls_data_per_fye_df.alias("fog"),
        on=(
                (F.col("dls.finOrg") == F.col("fog.finorg")) &
                (F.col("dls.area_cd") == F.col("fog.AREA_CD")) &
                (F.col("dls.sector") == F.col("fog.sector")) &
                (F.col("dls.yr") == F.col("fog.yr")) &
                (F.col("dls.per_cd") == F.col("fog.per_cd"))
        ),
        how="inner"
    ) \
        .select(
        F.col("fog.finorg"),
        F.col("fog.AREA_CD"),
        F.col("fog.purpose_type"),
        F.col("fog.gu_typ"),
        F.col("fog.YR"),
        F.col("fog.PER_CD"),
        F.col("fog.seasonal_cd"),
        F.col("fog.fym"),
        F.col("fog.fyd"),
        F.col("dls.dataPoints")
    )
    location_data_with_seasonal = location_data_df.withColumn(
        "seasonal_group",
        F.when(F.col("seasonal_cd") == "S", "seasonal")
        .when(F.col("seasonal_cd") == "U", "unseasonal")
        .otherwise("other")
    )
    print(f"Count before dedup location_data_with_seasonal: {location_data_with_seasonal.count()}")
    location_data_with_seasonal = location_data_with_seasonal.dropDuplicates()

    print(f"Count after dedup location_data_with_seasonal:  {location_data_with_seasonal.count()}")

    econ_data_df = location_data_with_seasonal.groupBy( \
        "finOrg", "fym", "fyd", "AREA_CD", "purpose_type", "gu_typ", "YR", "PER_CD" \
        ).pivot("seasonal_group").agg(
        F.first("dataPoints")
    ).withColumn(
        "sourceId", col("area_cd")
    ).withColumn(
        "purposeType", col("purpose_type")
    ).withColumn(
        "guType", col("gu_typ")
    ).withColumn(
        "sourceYr", col("yr")
    ).withColumn(
        "sourcePeriod", col("per_cd")
    )

    columns = econ_data_df.columns
    if "seasonal" not in columns:
        econ_data_df = econ_data_df.withColumn("seasonal", F.lit(None))
    if "unseasonal" not in columns:
        econ_data_df = econ_data_df.withColumn("unseasonal", F.lit(None))

    econ_data_df = econ_data_df.withColumn(
        "seasonal", F.when(F.col("seasonal").isNull(), F.array()).otherwise(F.col("seasonal"))
    ).withColumn(
        "unseasonal", F.when(F.col("unseasonal").isNull(), F.lit(None)).otherwise(F.col("unseasonal"))
    )

    print(f"Count before dedup econ_data_df: {econ_data_df.count()}")
    econ_data_df = econ_data_df.dropDuplicates()

    print(f"Count after dedup econ_data_df:  {econ_data_df.count()}")
    return econ_data_df


# COMMAND ----------

def org_econ(econ_data_df):
    econData_struct = struct(
        col("sourceId"),
        col("purposeType"),
        col("guType"),
        col("sourceYr"),
        col("sourcePeriod"),
        col("seasonal"),
        col("unseasonal")
    )
    org_econ_data_df = econ_data_df.select(
        "finOrg", "sourceId", "purposeType", "guType", "sourceYr", "sourcePeriod",
        "seasonal", "unseasonal", "fym", "fyd"
    ).withColumn(
        "EconData", econData_struct
    ).withColumn(
        "periodEndDate", F.concat(
            col("sourceYr"),
            F.lit("-"),
            col("fym"),
            F.lit("-"),
            col("fyd")
        )
    ).groupBy("finOrg", "periodEndDate").agg(
        F.collect_list("EconData").alias("EconData")
    )
    print(f"Count before dedup org_econ_data_df: {org_econ_data_df.count()}")
    org_econ_data_df = org_econ_data_df.dropDuplicates()

    print(f"Count after dedup org_econ_data_df:  {org_econ_data_df.count()}")
    return org_econ_data_df

# COMMAND ----------

def final_data_df(org_econ_data_df, finorg_df):
    org_econ_data_df_alias = org_econ_data_df.alias("o")
    finorg_df_alias = finorg_df.alias("f")

    final_data_df = org_econ_data_df_alias \
        .join(
        finorg_df_alias,
        org_econ_data_df_alias.finOrg == finorg_df_alias.finOrg,
        "inner"
    ) \
        .withColumnRenamed("countrycd", "countryCd") \
        .withColumnRenamed("f.finorgid", "finOrgId") \
        .withColumn("source", lit("BLS")) \
        .select(
        "o.finOrg",
        col("f.finorgname").alias("finOrgname"),
        "f.sectorName",
        "periodEndDate",
        "source",
        "EconData",
        col("f.red_org_id").alias("redOrgId"),
        "f.re_org_name"
    )
    print(f"Count before dedup org_econ_data_df: {final_data_df.count()}")
    final_data_df = final_data_df.dropDuplicates()

    print(f"Count after dedup org_econ_data_df:  {final_data_df.count()}")
    return final_data_df


# COMMAND ----------


def final_json(spark, final_data_df, start_time):
    spark.conf.set("spark.sql.jsonGenerator.ignoreNullFields", "false")
    json_str_df = final_data_df.select(
        to_json(
            struct(
                "finOrg", "redOrgId", "finOrgName", "sectorName", "periodEndDate", "source", "EconData"
            )
        ).alias("json_string")
    )
    json_schema = StructType([
        StructField("finOrg", StringType(), True),
        StructField("redOrgId", StringType(), True),
        StructField("finorgname", StringType(), True),
        StructField("periodEndDate", StringType(), True),
        StructField("source", StringType(), True),
        StructField("re_org_name", StringType(), True),
    ])
    print(f"Count before dedup json_str_df: {json_str_df.count()}")
    json_str_df = json_str_df.dropDuplicates()

    print(f"Count after dedup json_str_df:  {json_str_df.count()}")

    metadata_df = json_str_df.withColumn(
        "parsed", from_json(col("json_string"), json_schema),
    ).select(
        col("parsed.finorgname").alias("org_name"),
        col("parsed.finOrg").alias("fin_entity_id"),
        col("parsed.periodEndDate").alias("period_end_date"),
        col("json_string").alias("dataset"),
        lit("BLS").alias("dataset_source"),
        col("parsed.redOrgId").alias("re_org_id"),
        col("parsed.re_org_name").alias("re_org_name")
    )
    print(f"Count before dedup metadata_df: {metadata_df.count()}")
    metadata_df = metadata_df.dropDuplicates()

    print(f"Count after dedup metadata_df:  {metadata_df.count()}")

    end_time = time.time()
    total_time = end_time - start_time

    print(f"✅ Pipeline completed at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"⏱️ Total runtime: {total_time:.2f} seconds ({total_time / 60:.2f} minutes)")

    return metadata_df

def run_bls_pipeline(is_incremental,env,run_type,bls_last_date,filter_ids=None):
    # 🕓 Start timer
    start_time = time.time()
    print(f"🚀 Pipeline started at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    # Extract org_ids and geo_ids from filter_ids dict
    org_ids = filter_ids.get("org_ids") if filter_ids else None
    geo_ids = filter_ids.get("fips_code") if filter_ids else None

    print(f"Org IDs: {org_ids}")
    print(f"Geo IDs: {geo_ids}")

    spark = get_spark_session()
    # 🔹 Step 1: Load data
    finorg_df,finorggeolink_df,blsdatapnt_df,ent_mnem_df = load_input_dataframes(spark,is_incremental,env,run_type,bls_last_date, filter_ids=filter_ids)
    if org_ids or geo_ids:
        print(f"🔍 Filtering input data for selected orgs and geos")
        if org_ids:
            print(f"   • Selected org_ids: {org_ids}")
        if geo_ids:
            print(f"   • Selected geo_ids: {geo_ids}")
        #print("Running selected orgs")
        finorg_df, finorggeolink_df, blsdatapnt_df= filter_input_dataframes(
        finorg_df, finorggeolink_df, blsdatapnt_df
        )
    if blsdatapnt_df.count() == 0:
        print("⚠️ No data found in blsdatapnt during initial load. Skipping pipeline execution.")

        end_time = time.time()
        total_time = end_time - start_time
        print(f"✅ Pipeline exited early at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"⏱️ Total runtime: {total_time:.2f} seconds ({total_time / 60:.2f} minutes)")
        return None

    # Step 3: Join BLS with FinOrgGeoLink
    bls_data_fingeo_df = join_bls_with_finorggeolink(blsdatapnt_df, finorggeolink_df)
    print(f"✅ BLS+FinGeo data point count: {bls_data_fingeo_df.count()}")

    # Step 4: Join BLSFinGeo with EntMnem
    bls_data_fingeo_ent_mnem_df = join_bls_with_ent_mnem(bls_data_fingeo_df, ent_mnem_df)
    print(f"✅ BLS+FinGeo+EntMnem data point count: {bls_data_fingeo_ent_mnem_df.count()}")

    # Step 5: Join BLSFinGeoEntMnem with FinOrg
    bls_data_per_fye_df, bls_data_per_annual_df=join_bls_fingelink_with_finorg(bls_data_fingeo_ent_mnem_df, finorg_df)
    print(f"✅ BLS+FinGeo+EntMnem+FinOrg data point count (FYE): {bls_data_per_fye_df.count()}")
    print(f"✅ BLS+FinGeo+EntMnem+FinOrg data point count (Annual): {bls_data_per_annual_df.count()}")

    # Step 6: Process Current and Non-Current Data
    bls_noncur_df = bls_data_per_fye_df.filter(F.col("cur_ind") == "N")
    print(f"✅ Non-current BLS data point count: {bls_noncur_df.count()}")
    bls_cur_df = bls_data_per_fye_df.filter(F.col("cur_ind") == "Y")
    print(f"✅ Current BLS data point count: {bls_cur_df.count()}")
    bls_noncur_annual_df = bls_data_per_annual_df.filter(F.col("cur_ind") == "N")
    print(f"✅ Non-current Annual BLS data point count: {bls_noncur_annual_df.count()}")
    bls_cur_annual_df = bls_data_per_annual_df.filter(F.col("cur_ind") == "Y")
    print(f"✅ Current Annual BLS data point count: {bls_cur_annual_df.count()}")

    # Step 7: Generate Value Monthly Trails
    monthly_value_trail_df=monthly_value_trail(bls_noncur_df)
    print(f"✅ Monthly Value Trail data point count: {monthly_value_trail_df.count()}")

    # Step 8: Generate TTM Value Trails
    ttm_value_trail_df=ttm_value_trail(bls_noncur_df)
    print(f"✅ TTM Value Trail data point count: {ttm_value_trail_df.count()}")

    # Step 9: Generate Annual Value Trails
    annual_value_trail_df=annual_value_trail(bls_noncur_annual_df)
    print(f"✅ Annual Value Trail data point count: {annual_value_trail_df.count()}")

    # Step 10: Get Current Month Data
    current_month_df=current_month(bls_cur_df)
    print(f"✅ Current Month data point count: {current_month_df.count()}")

    # Step 11: Get Annual Current Data
    annual_cur_df=annual_cur(bls_cur_annual_df)
    print(f"✅ Annual Current data point count: {annual_cur_df.count()}")

    # Step 12: Combine Monthly, TTM, and Annual Data
    monthly_annual_data_df = monthly_annual_data(current_month_df, monthly_value_trail_df, ttm_value_trail_df,
                                                 annual_value_trail_df,
                                                 annual_cur_df)
    print(f"✅ Monthly + TTM + Annual data point count: {monthly_annual_data_df.count()}")
    data_by_location_seasonal_df=seasonal_unseason_datapoint(monthly_annual_data_df)

    # Step 13: Structure EconData
    econ_data_df=econ_data(data_by_location_seasonal_df,bls_data_per_fye_df)
    print(f"✅ Econ Data point count: {econ_data_df.count()}")

    # Step 14: Structure OrgEcon
    org_econ_data_df=org_econ(econ_data_df)
    print(f"✅ Org Econ Data point count: {org_econ_data_df.count()}")

    # Step 15: Final DataFrame with FinOrg+SPID
    final_df = final_data_df(org_econ_data_df, finorg_df)
    print(f"✅ Final Data point count: {final_df.count()}")

    # Step 16: Convert to JSON and prepare metadata
    metadata_df=final_json(spark,final_df,start_time)
    print(f"✅ Metadata Data point count: {metadata_df.count()}")

    end_time = time.time()
    total_time = end_time - start_time

    print(f"✅ Pipeline completed at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"⏱️ Total runtime: {total_time:.2f} seconds ({total_time / 60:.2f} minutes)")
    return metadata_df

def main(
    env: str,
    user: str,
    run_type:str,
    start_date: str = None,
    filter_ids: Optional[Dict[str, List[str]]] = None
):

    # Ensure filter_ids is at least an empty dict
    filter_ids = filter_ids or {}

    print(f"Run Type is {run_type}")
    if run_type in (RunType.BATCH.value, RunType.FINANALYTIC_STREAM.value, RunType.USPF_STREAM.value):
        print("debugging Runtype")
        if is_bls_batch_completed(env,run_type):
            is_incremental=True
            if start_date:
                bls_last_date=start_date
            else:
                main_process_id=get_main_process_id(env,run_type)
                bls_last_date = get_last_processed_date(env,run_type, exclude_process_id=main_process_id)
            output_bls_df=run_bls_pipeline(is_incremental, env,run_type, bls_last_date,filter_ids=filter_ids)
            print("Pipeline run complete.")
            if output_bls_df is not None and not output_bls_df.rdd.isEmpty():
                adpHandler = ADPPostgresHandler()
                adpHandler.write_into_db(output_bls_df,load_type=LoadType.INCREMENTAL)
            #updates the last processed timestamp
            else:
                print("No new records")

        else:
            print("Latest BLS_BATCH_PROCESS has not completed. main() will not run.")
    else:
        print("Non batch run type")
        is_incremental=False
        output_bls_df = run_bls_pipeline(is_incremental, env,run_type,start_date,filter_ids=filter_ids)
        print("Pipeline run complete.")
        adpHandler = ADPPostgresHandler()
        adpHandler.write_into_db(output_bls_df)