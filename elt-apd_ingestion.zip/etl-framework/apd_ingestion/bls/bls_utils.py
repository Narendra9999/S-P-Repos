from pyspark.sql import SparkSession
import logging
import sys
from pyspark.sql import functions as F

logging.basicConfig(stream=sys.stdout, level=logging.INFO)
logger = logging.getLogger(__name__)
spark = SparkSession.builder.appName("Load_BLS_Data_Pnt").getOrCreate()


def insert_process_status_started(env_name, user, process_id, batch_process_id, run_type, table_name,
                                  error_message=None):
    spark.sql(f"""
        INSERT INTO idf_raw_{env_name}.apd_control.t_process_status (
            PROCESS_ID,
            TABLE_NAME,
            RUN_TYPE,
            FILE_TIMESTAMP,
            STATUS,
            PROCESS_STARTTIME,
            PROCESS_ENDTIME,
            ERROR,
            THRESHOLD,
            CREATE_DATE,
            CREATE_BY,
            UPDATE_DATE,
            UPDATE_BY,
            PROCESS_NAME
        )
        VALUES (
            '{process_id}',
            'bls_econ.{table_name}',
            '{run_type}',
            current_timestamp(),
            'STARTED',
            current_timestamp(),
            NULL,
            '{error_message}',
            NULL,
            current_timestamp(),
            '{user}',
            current_timestamp(),
            '{user}',
            'BLS_{table_name}_{batch_process_id}'
        )
    """)


def update_process_status(env_name, user, process_id, status, error_message=None):
    if error_message is not None:
            error_message = error_message.replace("'", "''")  # SQL escape: ' becomes ''
            error_field = f"'{error_message}'"
    else:
            error_field = "NULL" 

    spark.sql(f"""
        UPDATE idf_raw_{env_name}.apd_control.t_process_status
        SET
            STATUS = '{status}',
            PROCESS_ENDTIME = current_timestamp(),
            ERROR = {error_field},
            UPDATE_DATE = current_timestamp(),
            UPDATE_BY = '{user}'
        WHERE PROCESS_ID = '{process_id}'
    """)


def insert_batch_process_status_started(env_name, user, process_id, run_type, status="STARTED"):
    spark.sql(f"""
        INSERT INTO idf_raw_{env_name}.apd_control.t_process_status (
            PROCESS_ID, TABLE_NAME, RUN_TYPE, FILE_TIMESTAMP, STATUS,
            PROCESS_STARTTIME, PROCESS_ENDTIME, ERROR, THRESHOLD,
            CREATE_DATE, CREATE_BY, UPDATE_DATE, UPDATE_BY,PROCESS_NAME,LAST_PROCESSED_DTTM
        )
        VALUES (
            '{process_id}', 'bls_tables', '{run_type}', current_timestamp(), '{status}',
            current_timestamp(), NULL, NULL, NULL,
            current_timestamp(), '{user}', current_timestamp(), '{user}','BLS_{run_type}_PROCESS',current_timestamp()
        )
    """)


def get_last_processed_date(env_name: str, run_type: str, fallback_date: str = "2025-01-01",
                            exclude_process_id: str = None):
    try:
        process_name = f"BLS_{run_type}_PROCESS"
        df = spark.read.table(f"idf_raw_{env_name}.apd_control.t_process_status")

        filtered_df = df.filter((F.col("PROCESS_NAME") == process_name) & (F.col("status") == "COMPLETED"))
        if exclude_process_id:
            filtered_df = filtered_df.filter(F.col("PROCESS_ID") != exclude_process_id)
        latest_row = filtered_df.orderBy(F.col("LAST_PROCESSED_DTTM").desc()).limit(1)
        rows = latest_row.selectExpr(
            "CAST(LAST_PROCESSED_DTTM AS STRING) AS LAST_PROCESSED_DTTM"
        ).collect()
        return rows[0]['LAST_PROCESSED_DTTM'] if rows and rows[0]['LAST_PROCESSED_DTTM'] else fallback_date

    except Exception as e:
        logger.warning(f"Using fallback date due to error: {e}")
        return fallback_date


def get_main_process_id(env_name, run_type):
    query = f"""
        SELECT PROCESS_ID,PROCESS_NAME
        FROM idf_raw_{env_name}.apd_control.t_process_status
        WHERE PROCESS_NAME = 'BLS_{run_type}_PROCESS'
        AND FILE_TIMESTAMP = (
            SELECT MAX(FILE_TIMESTAMP)
            FROM idf_raw_{env_name}.apd_control.t_process_status
            WHERE PROCESS_NAME = 'BLS_{run_type}_PROCESS'
        )
        AND run_type='{run_type}'
        ORDER BY PROCESS_STARTTIME DESC
        LIMIT 1
    """
    result_df = spark.sql(query)
    result = result_df.collect()
    print(result)
    if result:
        print("Available keys in Row:", result[0].asDict().keys())
        print("Row content:", result[0])
        return result[0]['PROCESS_ID']


def is_bls_batch_completed(env_name: str, run_type) -> bool:
    """
    Checks if the latest BLS_BATCH_PROCESS has completed successfully.
    """
    query = f"""
        SELECT STATUS
        FROM idf_raw_{env_name}.apd_control.t_process_status
        WHERE PROCESS_NAME = 'BLS_{run_type}_PROCESS'
        AND FILE_TIMESTAMP = (
            SELECT MAX(FILE_TIMESTAMP)
            FROM idf_raw_{env_name}.apd_control.t_process_status
            WHERE PROCESS_NAME = 'BLS_{run_type}_PROCESS'
        )
        ORDER BY PROCESS_STARTTIME DESC
        LIMIT 1
    """
    result_df = spark.sql(query)
    result = result_df.collect()

    if result:
        status = result[0]["STATUS"]
        print(f"Latest BLS_{run_type}_PROCESS status: {status}")
        return status.upper() == "COMPLETED"

    print(f"No BLS_{run_type}_PROCESS status found.")
    return False