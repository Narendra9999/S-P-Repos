# Databricks notebook source
import os
import uuid
import logging
import sys
from datetime import datetime
from typing import Tuple, Optional, Dict, Any
from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.functions import col, lit, current_timestamp, regexp_replace, sum, desc, trim, length, expr
from pyspark.sql.window import Window
from apd_ingestion.bls.bls_utils import insert_batch_process_status_started, insert_process_status_started,update_process_status,get_last_processed_date,get_main_process_id
import traceback


# Configure Logging
logging.basicConfig(stream=sys.stdout, level=logging.INFO)
logger = logging.getLogger(__name__)
spark = SparkSession.builder.appName("Load_BLS_Series").getOrCreate()

# COMMAND ----------
def generate_process_id():
    return str(uuid.uuid4())

# COMMAND ----------


def process_non_current_records(env, bls_last_date, user):
    """Process records that are not current (CUR_IND = 'N')"""
    non_current_query = f"""
    SELECT bs.* FROM idf_curated_{env}.bls.v_series bs
    WHERE cur_ind = 'N'
    AND (bs.create_dttm >= cast('{bls_last_date}' as TIMESTAMP)
        OR bs.last_upd_dttm >= cast('{bls_last_date}' as TIMESTAMP))"""
    non_current_df = spark.sql(non_current_query).dropDuplicates()
    print("non_current_df count:", non_current_df.count())
    # Transform the data
    non_current_data = non_current_df \
        .withColumn("LAST_UPD_USR_ID", lit(user)) \
        .withColumn("LAST_UPD_DTTM", current_timestamp()) \
        .select(
        "SERIES_ID",
        "AREA_TYP_CD",
        "AREA_TYP_DESC",
        "AREA_CD",
        "AREA_DESC",
        "MEASURE_CD",
        "MEASURE_DESC",
        "SEASONAL_CD",
        "SEASONAL_DESC",
        "ST_REGN_DIV_CD",
        "ST_REGN_DIV_NAME",
        "SERIES_TITLE",
        "FOOTNOTE_CD",
        "FOOTNOTE_TEXT",
        "BEGIN_YR",
        "BEGIN_PER",
        "BEGIN_PER_ABBR",
        "BEGIN_PER_NAME",
        "END_YR",
        "END_PER",
        "END_PER_ABBR",
        "END_PER_NAME",
        "CUR_IND",
        "ACTV_IND",
        "START_DTTM",
        "END_DTTM",
        "LAST_UPD_USR_ID",
        "LAST_UPD_DTTM"
    )
    try:
        # Create temp view for SQL update
        non_current_data.createOrReplaceTempView("non_current_series")

        # Update deactivated series (set CUR_IND = 'N')
        spark.sql(f"""
                  MERGE INTO idf_raw_{env}.bls_econ.t_series target
                  using non_current_series source
                  on target.SERIES_ID = source.SERIES_ID
                  AND target.CUR_IND = 'Y'
                  WHEN MATCHED THEN
                  UPDATE set target.END_DTTM = source.END_DTTM,
                      target.CUR_IND = 'N',
                      target.LAST_UPD_USR_ID = source.LAST_UPD_USR_ID,
                      target.LAST_UPD_DTTM = source.LAST_UPD_DTTM
                  """)
        return True
    except Exception as e:
        error_message = f"❌ Merge failed: {str(e)}"
        logger.error(error_message)
        update_process_status(env, user, process_id, status="FAILED", error_message=error_message)
        raise


# COMMAND ----------

def process_current_records(env, bls_last_date, user):
    """Process current records (CUR_IND = 'Y')"""
    current_query = f"""
    WITH fin AS (
    SELECT vend.bls_measure_cd,vend.bls_seasonal_ind, dv.create_dttm dv_create_dttm, dv.LAST_UPD_DTTM dv_last_upd_dttm,
          dvs.CREATE_DTTM dvs_create_dttm, dvs.LAST_UPD_DTTM dvs_last_upd_dttm, frml.CREATE_DTTM frml_create_dttm,
          frml.LAST_UPD_DTTM frml_last_upd_dttm, vend.CREATE_DTTM vend_create_dttm, vend.LAST_UPD_DTTM vend_last_upd_dttm
     FROM idf_{env}.finanalytic.v_de_ver dv
     JOIN idf_{env}.finanalytic.v_de_ver_st dvs ON dv.de_ver_id = dvs.de_ver_id AND dvs.CUR_IND = 'Y'
     JOIN idf_{env}.finanalytic.v_de_ver_st_frmla_map frml ON dvs.DE_VER_ST_ID = frml.de_ver_st_id AND frml.cur_ind = 'Y'
     JOIN idf_{env}.finanalytic.v_de_frmla_map_vendor_attr vend ON frml.DE_VER_ST_FRMLA_MAP_ID = vend.de_ver_st_frmla_map_id AND vend.ACTV_IND = 'Y'
    WHERE dv.CUR_IND = 'Y' and dv.stage_cd='FINAL'
    )
    SELECT bs.* FROM idf_curated_{env}.bls.v_series bs
    JOIN fin ON fin.bls_measure_cd = bs.measure_cd
    AND fin.bls_seasonal_ind=bs.seasonal_cd
    WHERE cur_ind = 'Y'
    AND (bs.create_dttm >= cast('{bls_last_date}' as TIMESTAMP)
        OR bs.last_upd_dttm >= cast('{bls_last_date}' as TIMESTAMP)
    	OR fin.dv_create_dttm >= cast('{bls_last_date}' as TIMESTAMP)
        OR fin.dv_last_upd_dttm >= cast('{bls_last_date}' as TIMESTAMP)
    	OR fin.dvs_create_dttm >= cast('{bls_last_date}' as TIMESTAMP)
        OR fin.dvs_last_upd_dttm >= cast('{bls_last_date}' as TIMESTAMP)
    	OR fin.frml_create_dttm >= cast('{bls_last_date}' as TIMESTAMP)
        OR fin.frml_last_upd_dttm >= cast('{bls_last_date}' as TIMESTAMP)
    	OR fin.vend_create_dttm >= cast('{bls_last_date}' as TIMESTAMP)
        OR fin.vend_last_upd_dttm >= cast('{bls_last_date}' as TIMESTAMP))"""
    current_df = spark.sql(current_query).dropDuplicates()
    print("current_df count:", current_df.count())

    # Transform the data
    current_data = current_df \
        .withColumn("CREATE_USR_ID", lit(user)) \
        .withColumn("CREATE_DTTM", current_timestamp()) \
        .withColumn("LAST_UPD_USR_ID", lit(user)) \
        .withColumn("LAST_UPD_DTTM", current_timestamp()) \
        .select(
        "SERIES_ID",
        expr("NVL(AREA_TYP_CD, ' ') AS AREA_TYP_CD"),
        expr("NVL(AREA_TYP_DESC, ' ') AS AREA_TYP_DESC"),
        expr("NVL(AREA_CD, ' ') AS AREA_CD"),
        expr("NVL(AREA_DESC, ' ') AS AREA_DESC"),
        expr("NVL(MEASURE_CD, ' ') AS MEASURE_CD"),
        expr("NVL(MEASURE_DESC, ' ') AS MEASURE_DESC"),
        expr("NVL(SEASONAL_CD, ' ') AS SEASONAL_CD"),
        expr("NVL(SEASONAL_DESC, ' ') AS SEASONAL_DESC"),
        expr("NVL(ST_REGN_DIV_CD, ' ') AS ST_REGN_DIV_CD"),
        expr("NVL(ST_REGN_DIV_NAME, ' ') AS ST_REGN_DIV_NAME"),
        expr("NVL(SERIES_TITLE, ' ') AS SERIES_TITLE"),
        "FOOTNOTE_CD",
        "FOOTNOTE_TEXT",
        expr("INT(BEGIN_YR) AS BEGIN_YR"),
        "BEGIN_PER",
        "BEGIN_PER_ABBR",
        "BEGIN_PER_NAME",
        expr("INT(END_YR) AS END_YR"),
        "END_PER",
        "END_PER_ABBR",
        "END_PER_NAME",
        "CUR_IND",
        "ACTV_IND",
        "START_DTTM",
        "END_DTTM",
        "CREATE_USR_ID",
        "CREATE_DTTM",
        "LAST_UPD_USR_ID",
        "LAST_UPD_DTTM"
    )
    try:
        # Create temp view for SQL merge
        current_data.createOrReplaceTempView("current_series")

        # Merge into target table using Delta Lake merge
        spark.sql(f"""
            MERGE INTO idf_raw_{env}.bls_econ.t_series target
            USING current_series source
            ON target.SERIES_ID = source.SERIES_ID
            AND target.CUR_IND = 'Y'
            WHEN MATCHED THEN
            UPDATE SET
                target.AREA_TYP_CD = source.AREA_TYP_CD,
                target.AREA_TYP_DESC = source.AREA_TYP_DESC,
                target.AREA_CD = source.AREA_CD,
                target.AREA_DESC = source.AREA_DESC,
                target.MEASURE_CD = source.MEASURE_CD,
                target.MEASURE_DESC = source.MEASURE_DESC,
                target.SEASONAL_CD = source.SEASONAL_CD,
                target.SEASONAL_DESC = source.SEASONAL_DESC,
                target.ST_REGN_DIV_CD = source.ST_REGN_DIV_CD,
                target.ST_REGN_DIV_NAME = source.ST_REGN_DIV_NAME,
                target.SERIES_TITLE = source.SERIES_TITLE,
                target.FOOTNOTE_CD = source.FOOTNOTE_CD,
                target.FOOTNOTE_TEXT = source.FOOTNOTE_TEXT,
                target.BEGIN_YR = source.BEGIN_YR,
                target.BEGIN_PER = source.BEGIN_PER,
                target.BEGIN_PER_ABBR = source.BEGIN_PER_ABBR,
                target.BEGIN_PER_NAME = source.BEGIN_PER_NAME,
                target.END_YR = source.END_YR,
                target.END_PER = source.END_PER,
                target.END_PER_ABBR = source.END_PER_ABBR,
                target.END_PER_NAME = source.END_PER_NAME,
                target.ACTV_IND = source.ACTV_IND,
                target.START_DTTM = source.START_DTTM,
                target.END_DTTM = source.END_DTTM,
                target.LAST_UPD_USR_ID = source.LAST_UPD_USR_ID,
                target.LAST_UPD_DTTM = source.LAST_UPD_DTTM
            WHEN NOT MATCHED THEN
            INSERT (
                SERIES_ID, AREA_TYP_CD, AREA_TYP_DESC, AREA_CD, AREA_DESC,
                MEASURE_CD, MEASURE_DESC, SEASONAL_CD, SEASONAL_DESC,
                ST_REGN_DIV_CD, ST_REGN_DIV_NAME, SERIES_TITLE,
                FOOTNOTE_CD, FOOTNOTE_TEXT, BEGIN_YR, BEGIN_PER,
                BEGIN_PER_ABBR, BEGIN_PER_NAME, END_YR, END_PER,
                END_PER_ABBR, END_PER_NAME, CUR_IND, ACTV_IND,
                START_DTTM, END_DTTM, CREATE_USR_ID, CREATE_DTTM,
                LAST_UPD_USR_ID, LAST_UPD_DTTM
            )
            VALUES (
                source.SERIES_ID, source.AREA_TYP_CD, source.AREA_TYP_DESC,
                source.AREA_CD, source.AREA_DESC, source.MEASURE_CD,
                source.MEASURE_DESC, source.SEASONAL_CD, source.SEASONAL_DESC,
                source.ST_REGN_DIV_CD, source.ST_REGN_DIV_NAME, source.SERIES_TITLE,
                source.FOOTNOTE_CD, source.FOOTNOTE_TEXT, source.BEGIN_YR,
                source.BEGIN_PER, source.BEGIN_PER_ABBR, source.BEGIN_PER_NAME,
                source.END_YR, source.END_PER, source.END_PER_ABBR,
                source.END_PER_NAME, source.CUR_IND, source.ACTV_IND,
                source.START_DTTM, source.END_DTTM, source.CREATE_USR_ID,
                source.CREATE_DTTM, NULL, NULL
            )
        """)
        return True
    except Exception as e:
        error_message = f"❌ Merge failed: {str(e)}"
        logger.error(error_message)
        update_process_status(env, user, process_id, status="FAILED", error_message=error_message)
        raise


# COMMAND ----------

def run_bls_series(env: str, user:str,run_type:str, start_date=None):
    """Main function to coordinate the data ingestion process."""
    print(run_type)
    main_process_id = get_main_process_id(env, run_type)
    if start_date:
        bls_last_date = start_date
    else:
        bls_last_date = get_last_processed_date(env, run_type,start_date, main_process_id)
    print(bls_last_date)
    process_id = generate_process_id()

    try:
        # Start the process and mark as running
        print(f"🚀 Starting BLS data ingestion process ID: {process_id}")
        insert_process_status_started(env, user, process_id, main_process_id, run_type, table_name='BLS_SERIES')
        print("✅ Process status updated to STARTED.")
        process_non_current_records(env, bls_last_date, user)
        process_current_records(env, bls_last_date, user)
        update_process_status(env, user, process_id, status="COMPLETED")
        update_process_status(env, user, main_process_id, status="COMPLETED")
        print("🎉 load_bls_series task completed successfully.")

        return True

    except Exception as e:
        error_message = traceback.format_exc()
        logger.error(error_message)
        update_process_status(env, user, process_id, status="FAILED", error_message=error_message)
        raise