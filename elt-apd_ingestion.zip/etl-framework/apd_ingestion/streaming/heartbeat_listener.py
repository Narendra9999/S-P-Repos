"""
Enhanced StreamingQueryListener for comprehensive monitoring.
Handles heartbeats, performance monitoring, and health alerts.
"""

import time
import threading
from pyspark.sql.streaming import StreamingQueryListener
import logging
from datetime import datetime

class HeartbeatStreamingListener(StreamingQueryListener):
    """
    Comprehensive streaming monitor that handles:
    1. Automatic heartbeat updates
    2. Performance monitoring and alerts
    3. Health status tracking
    4. Error rate monitoring
    5. Background heartbeat checker
    """
    
    def __init__(self, pipeline_name: str, monitor_config: dict = None):
        super().__init__()
        self.pipeline_name = pipeline_name
        self.logger = logging.getLogger(f"StreamingMonitor.{pipeline_name}")
        
        # Health tracking
        self.last_heartbeat = datetime.now()
        self.health_status = "HEALTHY"
        self.consecutive_failures = 0
        self.consecutive_slow_batches = 0
        self.total_processed_records = 0
        self.total_error_count = 0
        
        # Use provided config or fallback to defaults
        if monitor_config is None:
            monitor_config = {}
        
        # Configuration with proper fallback hierarchy
        self.slow_batch_threshold_ms = monitor_config.get('slow_batch_threshold_ms', 30000)
        self.max_consecutive_failures = monitor_config.get('max_consecutive_failures', 3)
        self.error_rate_alert_threshold = monitor_config.get('error_rate_alert', 0.05)
        
        # Heartbeat config with nested fallback
        heartbeat_config = monitor_config.get('heartbeat', {})
        self.heartbeat_max_stale_seconds = heartbeat_config.get('max_stale_seconds', 240)
        self.heartbeat_check_interval = heartbeat_config.get('check_interval', 120)
        
        # Start background heartbeat checker
        self._start_heartbeat_checker()
        
        # Log all monitoring settings for visibility
        self.logger.info(f"Enhanced streaming monitor initialized for: {pipeline_name}")
        self.logger.info(f"Monitoring settings:")
        self.logger.info(f"  - slow_batch_threshold_ms: {self.slow_batch_threshold_ms}")
        self.logger.info(f"  - max_consecutive_failures: {self.max_consecutive_failures}")
        self.logger.info(f"  - error_rate_alert_threshold: {self.error_rate_alert_threshold}")
        self.logger.info(f"  - heartbeat.max_stale_seconds: {self.heartbeat_max_stale_seconds}")
        self.logger.info(f"  - heartbeat.check_interval: {self.heartbeat_check_interval}")

    def onQueryProgress(self, event):
        """Called automatically by Spark when a batch completes."""
        try:
            # Update heartbeat automatically
            self.last_heartbeat = datetime.now()
            
            progress = event.progress
            
            # Extract key metrics with safe access
            batch_id = getattr(progress, 'batchId', '?')
            input_rows = getattr(progress, 'numInputRows', 0)
            batch_duration = getattr(progress, 'batchDuration', 0)
            input_rate = getattr(progress, 'inputRowsPerSecond', 0)
            processed_rate = getattr(progress, 'processedRowsPerSecond', 0)
            
            # Update totals for error rate calculation
            self.total_processed_records += input_rows
            
            # Log heartbeat every batch (since you have low volume)
            self.logger.info(
                f"HEARTBEAT | Batch={batch_id} | Input={input_rows} rows | "
                f"Duration={batch_duration}ms | Rate={processed_rate:.1f} rows/sec"
            )
            
            # Performance lag detection
            if input_rate > 0 and processed_rate > 0 and processed_rate < input_rate * 0.8:
                self.logger.warning(
                    f"PERFORMANCE LAG | Input={input_rate:.1f} vs Processed={processed_rate:.1f} rows/sec"
                )
            
            # Slow batch detection
            if batch_duration > self.slow_batch_threshold_ms:
                self.consecutive_slow_batches += 1
                self.logger.warning(f"SLOW BATCH | Batch {batch_id} took {batch_duration}ms")
                
                if self.consecutive_slow_batches >= 3:
                    self._update_health_status("DEGRADED", f"3+ consecutive slow batches")
            else:
                self.consecutive_slow_batches = 0
                if self.health_status == "DEGRADED":
                    self._update_health_status("HEALTHY", "Performance recovered")
            
            # Reset failure count on successful batch
            self.consecutive_failures = 0
            if self.health_status == "CRITICAL":
                self._update_health_status("HEALTHY", "Batch processing recovered")
                
        except Exception as e:
            self.logger.warning(f"Exception in onQueryProgress (likely during shutdown): {e}")

    def onQueryTerminated(self, event):
        """Called when the streaming query terminates."""
        try:
            if hasattr(event, 'exception') and event.exception:
                self.logger.error(f"Stream terminated with exception: {event.exception}")
                self._update_health_status("CRITICAL", f"Stream terminated: {event.exception}")
            else:
                self.logger.info("Stream terminated normally")
                self._update_health_status("STOPPED", "Stream terminated")
        except Exception as e:
            self.logger.warning(f"Exception in onQueryTerminated: {e}")

    def onQueryStarted(self, event):
        """Called when the streaming query starts."""
        try:
            self.logger.info(f"Streaming query started: {event.name if hasattr(event, 'name') else 'unknown'}")
            self._update_health_status("HEALTHY", "Stream started")
        except Exception as e:
            self.logger.warning(f"Exception in onQueryStarted: {e}")

    def track_batch_failure(self, batch_id: int, error_msg: str):
        """Call this when a batch fails to update failure tracking."""
        self.consecutive_failures += 1
        self.total_error_count += 1
        
        self.logger.error(f"Batch {batch_id} failed: {error_msg}")
        
        if self.consecutive_failures >= self.max_consecutive_failures:
            self._update_health_status("CRITICAL", f"{self.consecutive_failures} consecutive failures")
    
    def _update_health_status(self, status: str, reason: str = ""):
        """Update health status with logging if it changed."""
        if self.health_status != status:
            self.logger.info(f"Health status: {self.health_status} -> {status}. {reason}")
            self.health_status = status

    def get_recent_error_rate(self) -> float:
        """Get overall error rate."""
        if self.total_processed_records == 0:
            return 0.0
        return self.total_error_count / self.total_processed_records

    def _start_heartbeat_checker(self):
        """Start background thread to check for stale heartbeats."""
        try:
            def heartbeat_watcher():
                try:
                    while True:
                        now = datetime.now()
                        if (now - self.last_heartbeat).total_seconds() > self.heartbeat_max_stale_seconds:
                            self.logger.error(
                                f"ALERT: No heartbeat in the last {self.heartbeat_max_stale_seconds} seconds! "
                                f"Last heartbeat at {self.last_heartbeat.isoformat()}"
                            )
                        time.sleep(self.heartbeat_check_interval)
                except Exception as e:
                    self.logger.error(f"Heartbeat watcher thread failed: {e}")
                    
            t = threading.Thread(target=heartbeat_watcher, daemon=True, name=f"HeartbeatWatcher-{self.pipeline_name}")
            t.start()
            self.logger.info(f"Heartbeat checker started with {self.heartbeat_max_stale_seconds}s threshold")
        except Exception as e:
            self.logger.warning(f"Failed to start heartbeat checker: {e}")