"""
S3 checkpoint manager for Databricks streaming pipelines.
"""

import logging
from typing import Optional

from apd_ingestion.config.config_manager import get_config_value


class CheckpointManager:
    """Simple checkpoint path manager for Spark Structured Streaming (S3 + local file testing)."""
    
    def __init__(self, base_s3_path: Optional[str] = None):
        """Initialize with S3 base path or local file path for testing."""
        self.logger = logging.getLogger(self.__class__.__name__)
        
        self.base_s3_path = base_s3_path or get_config_value('streaming.checkpoint.base_s3_path')
        if not self.base_s3_path:
            raise ValueError("No checkpoint base path configured")
        
        # Handle local file:// paths for testing
        if self.base_s3_path.startswith('file://'):
            if not self.base_s3_path.endswith('/'):
                self.base_s3_path += '/'
        else:
            # Handle S3 paths - ensure s3a:// protocol and trailing slash
            if self.base_s3_path.startswith('s3://'):
                self.base_s3_path = self.base_s3_path.replace('s3://', 's3a://', 1)
            elif not self.base_s3_path.startswith('s3a://'):
                self.base_s3_path = f's3a://{self.base_s3_path.lstrip("/")}'
                
            if not self.base_s3_path.endswith('/'):
                self.base_s3_path += '/'
        
        self.logger.info(f"Checkpoint base: {self.base_s3_path}")
    
    def get_checkpoint_location(self, pipeline_name: str, kafka_group_id: Optional[str] = None, version: str = "v1") -> str:
        """Get S3 checkpoint path for pipeline."""
        safe_pipeline = pipeline_name.lower().replace('_', '-').replace(' ', '-')
        
        # Use kafka_group_id if provided, otherwise use 'default'
        group_identifier = kafka_group_id.lower().replace('_', '-').replace(' ', '-') if kafka_group_id else 'default'
        
        return f"{self.base_s3_path}{safe_pipeline}/{group_identifier}/{version}/"
