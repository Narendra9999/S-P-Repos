from apd_ingestion.ihs.IHS_MAIN import run_etl
from apd_ingestion.ihs.IHS_MNEMONICMAPPING import run_load_ecr_mnemonicmapping
from apd_ingestion.ihs.IHS_PROC_LOG import run_proc_log
from apd_ingestion.ihs.IHS_JSON_TO_APD import main as ihs_main

from apd_ingestion.bls.BLS_DATA_PNT import run_bls_data_pnt
from apd_ingestion.bls.BLS_SERIES import run_bls_series
from apd_ingestion.bls.BLS_JSON_TO_APD import main

from apd_ingestion.eds.EDS_DATA_PROCESSOR import load_eds_pipeline
from typing import Any
from datetime import datetime
from apd_ingestion.config.config_manager import get_config_value

import logging

logger = logging.getLogger("streaming_utils")

class StreamingUtils:
    """
    Utility class for executing data processing pipelines triggered by streaming events.
    
    This class provides orchestration for various data vendor pipelines (IHS, BLS, EDS)
    that can be triggered by both finanalytic and UPSF monitoring streams.
    """
    @staticmethod
    def finanalytic_ihs_records(timestamp: datetime, filters: dict[Any], run_type) -> None:
        """
        Execute IHS finanalytics processing pipeline in sequence.
        
        This method orchestrates the complete IHS data processing workflow for finanalytics:
        1. IHS_MAIN: Core IHS data extraction and transformation
        2. IHS_PROC_LOG: Process logging and metadata updates
        3. IHS_MNEMONICMAPPING: Mnemonic mapping and standardization
        4. IHS_JSON_TO_APD: Final transformation to APD format
        
        All processes are executed sequentially to ensure proper data dependencies.
        If any process fails, the entire pipeline stops and raises an exception.
        
        Args:
            timestamp: EST timezone timestamp representing the earliest change time
                      Used by each process to determine the data processing window
            filters: which will contain formula map id's 
                      
        Raises:
            Exception: If any IHS process fails, with details about which step failed
        """
        logger.info(f"Processing IHS finanalytic records for timestamp: {timestamp}")
        
        user_name = get_config_value('databricks_user')
        environment = get_config_value('environment')
        
        # Define IHS processes in execution order
        processes = [
            ("IHS_MAIN", lambda: run_etl(user_name, environment, run_type, timestamp, filters)),
            ("IHS_PROC_LOG", lambda: run_proc_log(environment, user_name, run_type, timestamp, filters)),
            ("IHS_MNEMONICMAPPING", lambda: run_load_ecr_mnemonicmapping(environment, user_name, run_type, timestamp)),
            ("IHS_JSON_TO_APD", lambda: ihs_main(environment, user_name, run_type, timestamp, filters)),
        ]
        
        StreamingUtils.execute_processes_sequentially(processes, "IHS", timestamp)

    @staticmethod
    def finanalytic_bls_records(timestamp: datetime, filters: dict[Any], run_type) -> None:
        """
        Execute BLS finanalytics processing pipeline in sequence.
        
        This method orchestrates the complete BLS data processing workflow for finanalytics:
        1. BLS_DATA_PNT: BLS data point extraction and processing
        2. BLS_SERIES: BLS series data processing and transformation
        3. BLS_JSON_TO_APD: Final transformation to APD format
        
        All processes are executed sequentially to ensure proper data dependencies.
        If any process fails, the entire pipeline stops and raises an exception.
        
        Args:
            timestamp: EST timezone timestamp representing the earliest change time
                      Used by each process to determine the data processing window
            frml_map_id: List of unique formula map IDs to process
        Raises:
            Exception: If any BLS process fails, with details about which step failed
        """
        logger.info(f"Processing BLS finanalytic records for timestamp: {timestamp}")
        
        user_name = get_config_value('databricks_user')
        environment = get_config_value('environment')
        
        
        # Define BLS processes in execution order  
        processes = [
            ("BLS_DATA_PNT", lambda: run_bls_data_pnt(environment, user_name, run_type, timestamp, filters)),
            ("BLS_SERIES", lambda: run_bls_series(environment, user_name, run_type, timestamp)),
            ("BLS_JSON_TO_APD", lambda: main(environment, user_name, run_type, filters=filters)),
        ]

        StreamingUtils.execute_processes_sequentially(processes, "BLS", timestamp)

    @staticmethod
    def execute_processes_sequentially(processes: list, process_type: str, timestamp: datetime) -> None:
        """
        Execute a list of processing functions sequentially with comprehensive error handling.
        
        This helper method provides:
        1. Sequential execution ensuring proper data pipeline dependencies
        2. Detailed logging for each process start/completion
        3. Error handling with process-specific failure information
        4. Fail-fast behavior - stops on first error to prevent data corruption
        
        Args:
            processes: List of tuples (process_name, process_function)
                      Each process_function should be a callable that takes no arguments
            process_type: String identifier for the process type (e.g., "IHS", "BLS")
                         Used in error messages and logging
            timestamp: Timestamp passed to the original calling method
                      Used for logging context only
                      
        Raises:
            Exception: If any process fails, includes process name and original error details
        """
        for process_name, process_func in processes:
            try:
                logger.info(f"Starting {process_name} for timestamp {timestamp}")
                process_func()
                logger.info(f"Completed {process_name} successfully")
            except Exception as e:
                logger.error(f"Failed to execute {process_name}: {str(e)}")
                raise Exception(f"{process_type} finanalytic processing failed at {process_name}: {str(e)}")
        
        logger.info(f"All {process_type} finanalytic processes completed successfully for timestamp: {timestamp}")
