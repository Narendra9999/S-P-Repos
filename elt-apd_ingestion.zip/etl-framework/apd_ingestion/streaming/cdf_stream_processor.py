"""
Main processor for Change Data Feed (CDF) monitoring streams.

This module provides a configurable framework for monitoring Delta table changes 
using Change Data Feed. It supports multiple monitoring patterns through different
handlers while providing common infrastructure for checkpointing and status tracking.
"""

import logging
import os
from datetime import datetime
from typing import Optional, Dict, Any
import importlib
import signal

# PySpark imports
from pyspark.sql import SparkSession, DataFrame
from pyspark.sql import functions as F

# APD imports
from apd_ingestion.config.config_manager import get_config_value
from apd_ingestion.constants.env_vars import GeneralEnvVars
from apd_ingestion.streaming.checkpoint_manager import CheckpointManager
from apd_ingestion.utils.job_monitor import JobMonitorUtility


class CDFStreamProcessor:
    """
    Main processor for Change Data Feed (CDF) monitoring streams.
    
    This class handles setting up and running streams that monitor Delta table
    changes using Change Data Feed. It's designed to be configuration-driven
    and work with different monitoring handlers for different use cases.
    """
    
    def __init__(self, name: str, environment: str = None, checkpoint_version: str = "v1", skip_vacuum_files: bool = False):
        """Initialize a new CDF stream processor."""
        self.name = name
        self.logger = logging.getLogger(f"CDFStreamProcessor.{name}")
        
        # Set environment
        self.environment = environment or os.getenv(GeneralEnvVars.APP_ENV.value)
        if not self.environment:
            raise ValueError("Environment must be specified either through parameter or APP_ENV")
            
        # Initialize core attributes
        self.spark: Optional[SparkSession] = None
        self.handler = None
        self.checkpoint_manager: Optional[CheckpointManager] = None
        self.checkpoint_dir: Optional[str] = None
        self.job_monitor: Optional[JobMonitorUtility] = None
        self.skip_vacuum_files = skip_vacuum_files
        # Load and validate configuration
        self.config = self._load_pipeline_config()
        self._validate_all_configuration()
        
        # Initialize job coordinator after config is loaded
        self._initialize_job_monitor()     
        
        # Initialize components after validation
        self.handler_class = self.config.get('handler_class')
        self._setup_checkpoint_manager(checkpoint_version)
        self.status_table = self.config['tables'].get('status_table')
        self.source_name = self.config.get('source_name')
        self.update_by = get_config_value('databricks_user')
        self.logger.info(f"Status Table {self.status_table} will be Updated by {self.update_by} for Source {self.source_name}")
        # Load the handler using the class name we determined above
        self.handler = self._init_handler(self.handler_class)
        self.handler.job_monitor = self.job_monitor
        self.spark = self._create_spark_session()
        self._register_signal_handlers()
        self.logger.info(f"Initialized {self.name} pipeline")
        
    def _setup_checkpoint_manager(self, checkpoint_version: str):
        """Set up checkpoint management for fault tolerance.
        
        Args:
            checkpoint_version: Version tag for checkpointing (e.g. 'v1', 'v2' or custom versioning).
                              This allows for checkpoint version management through job configuration.
        """
        self.logger.info("Setting up checkpoint manager")
        
        base_s3_path = get_config_value('streaming.checkpoint.base_s3_path')
        if not base_s3_path:
            raise ValueError("streaming.checkpoint.base_s3_path must be configured")
            
        # Use configured version or fallback to parameter
        config_version = self.config.get('checkpoint_version', checkpoint_version)
        
        self.checkpoint_manager = CheckpointManager(base_s3_path=base_s3_path)
        self.checkpoint_dir = self.checkpoint_manager.get_checkpoint_location(
            pipeline_name=self.name,
            version=config_version
        )
        self.logger.info(f"Using checkpoint location: {self.checkpoint_dir} (version: {config_version})")
        
    def _load_pipeline_config(self) -> Dict[str, Any]:
        """Load and merge pipeline configuration from YAML files."""
        self.logger.info(f"Loading pipeline config for '{self.name}'")
        
        # Load pipeline-specific config
        pipeline_config = get_config_value(f'streaming.pipelines.{self.name}', {})
        if not pipeline_config:
            self.logger.error(f"No configuration found for pipeline '{self.name}'")
            raise ValueError(f"No configuration found for pipeline '{self.name}'. Please add it to streaming.pipelines.{self.name} in application.yaml")
            
        # Load and merge with defaults
        defaults = get_config_value('streaming.defaults', {})
        self.logger.debug(f"Defaults loaded: {defaults}")
        self.logger.debug(f"Pipeline config loaded: {pipeline_config}")
        
        merged = defaults.copy()
        for k, v in pipeline_config.items():
            if isinstance(v, dict) and k in merged and isinstance(merged[k], dict):
                self.logger.debug(f"Deep merging dict for key '{k}': {merged[k]} <- {v}")
                merged[k] = {**merged[k], **v}
            else:
                self.logger.debug(f"Setting key '{k}' to value: {v}")
                merged[k] = v
                
        self.logger.info(f"Final merged config for '{self.name}': {merged}")
        return merged

    def _validate_all_configuration(self):
        """Validate that all required configuration is present."""
        self.logger.info(f"Validating all configuration for pipeline '{self.name}'")
        
        # Validate handler class exists
        handler_class = self.config.get('handler_class')
        if not handler_class:
            self.logger.error("'handler_class' must be specified in pipeline config or constructor")
            raise ValueError("'handler_class' must be specified in pipeline config or constructor")
            
        try:
            handler_module = importlib.import_module('apd_ingestion.streaming.handlers')
            if not hasattr(handler_module, handler_class):
                self.logger.error(f"Handler class '{handler_class}' not found in module 'apd_ingestion.streaming.handlers'")
                raise ValueError(f"Handler class '{handler_class}' not found in handlers module")
        except ImportError as e:
            self.logger.error(f"Could not import handlers module: {e}")
            raise ValueError(f"Could not import handlers module: {e}")
            
        # Validate checkpoint configuration
        base_s3_path = get_config_value('streaming.checkpoint.base_s3_path')
        if not base_s3_path:
            self.logger.error("No checkpoint base S3 path configured")
            raise ValueError("streaming.checkpoint.base_s3_path must be configured")
            
        # Validate basic CDF configuration
        if not self.config.get('source_name'):
            self.logger.error(f"No source_name specified for pipeline '{self.name}'")
            raise ValueError(f"source_name is required in pipeline config")
            
        # Note: Specific table configuration validation is handled by the specialized handlers
        self.logger.info("All configuration validation passed")
    
    def _initialize_job_monitor(self):
        """Initialize job coordinator from control table configuration."""
        try:
            # Extract control table configuration from defaults or pipeline-specific config
            control_config = self.config.get('control_table', {})
            table_name = control_config.get('table_name')
 
            # Extract process and table name filters for coordination
            process_name_filter = control_config.get("process_name")
            table_name_filter = control_config.get("table_name_filter")
            
            # Initialize job coordinator
            self.job_monitor = JobMonitorUtility(
                coordination_table = table_name,
                process_name_filter = process_name_filter,
                table_name_filter = table_name_filter,
                job_name = self.name
            )
            
            self.logger.info(f"Job coordinator initialized with table: {table_name}")
            self.logger.info(f"Process filter: {process_name_filter}, Table filter: {table_name_filter}")
        except Exception as e:
            self.logger.error(f"Failed to initialize job coordinator: {str(e)}")
            self.job_monitor = None

    def _create_spark_session(self) -> SparkSession:
        """Create and configure a Spark session."""
        self.logger.info(f"Creating Spark session for pipeline '{self.name}'...")
        app_name = f"CDF_Monitor_{self.name}"
        is_local = os.getenv('LOCAL_TESTING', '').lower() == 'true'
        if is_local:
            self.logger.info("Creating local Spark session for testing")
            builder = SparkSession.builder \
                .appName(app_name) \
                .master("local[*]") \
                .config("spark.sql.warehouse.dir", "/tmp/spark-warehouse") 
        else:
            self.logger.info("Creating Databricks Spark session")
            builder = SparkSession.builder.appName(app_name)
        builder = builder \
            .config("spark.sql.streaming.checkpointLocation.deleteSourceMetadataFiles", "false") \
            .config("spark.sql.streaming.stopGracefullyOnShutdown", "true") \
            .config("spark.sql.legacy.timeParserPolicy", "LEGACY")
        spark_config = get_config_value('streaming.spark_config', {})
        for key, value in spark_config.items():
            self.logger.info(f"Applied Spark config: {key}={value}")
            builder = builder.config(key, value)
        spark = builder.getOrCreate()
        self.logger.info(f"Spark session created: {spark}")
        return spark
    
    def _init_handler(self, handler_class: str):
        """Initialize the CDF monitor handler."""
        try:
            self.logger.info(f"Loading handler class: {handler_class}")
            module = importlib.import_module('apd_ingestion.streaming.handlers')
            handler_cls = getattr(module, handler_class)
            return handler_cls(self.config)
        except (ImportError, AttributeError) as e:
            raise ValueError(f"Could not load handler class {handler_class}: {e}")
    
    def _get_trigger(self) -> Dict[str, Any]:
        """Figure out how often we should process batches."""
        self.logger.info(f"Getting trigger configuration for pipeline '{self.name}'")
        trigger_config = self.config.get('trigger', {})
        self.logger.debug(f"Trigger config: {trigger_config}")
        trigger_type = trigger_config.get('type', 'processing_time')
        if trigger_type == 'processing_time':
            interval = trigger_config.get('processing_time', '30 seconds')
            self.logger.info(f"Using processingTime trigger: {interval}")
            return {'processingTime': interval}
        elif trigger_type == 'available_now':
            self.logger.info("Using availableNow trigger")
            return {'availableNow': True}
        elif trigger_type == 'once':
            self.logger.info("Using once trigger")
            return {'once': True}
        elif trigger_type == 'continuous':
            interval = trigger_config.get('continuous', '1 second')
            self.logger.info(f"Using continuous trigger: {interval}")
            return {'continuous': interval}
        else:
            self.logger.warning(f"Unknown trigger type {trigger_type}, using default")
            return {'processingTime': '60 seconds'}
        
    def _register_signal_handlers(self):
        """Set up graceful shutdown on SIGTERM/SIGINT."""
        def handle_signal(signum, frame):
            self.logger.info(f"Received signal {signum}, initiating shutdown...")
            # Query will be stopped in start() method's try/finally
            
        signal.signal(signal.SIGTERM, handle_signal)
        signal.signal(signal.SIGINT, handle_signal)
    
    def _path_exists(self, path: str) -> bool:
        """Check if a path exists in the filesystem."""
        jvm = self.spark.sparkContext._jvm
        fs = jvm.org.apache.hadoop.fs.FileSystem.get(
            jvm.java.net.URI.create(path),
            self.spark._jsc.hadoopConfiguration()
        )
        return fs.exists(jvm.org.apache.hadoop.fs.Path(path))
    
    def _latest_delta_version(self, table_name: str) -> int:
        """Get the latest version of a Delta table."""
        v = (self.spark.sql(f"DESCRIBE HISTORY {table_name}")
             .select("version")
             .orderBy("version", ascending=False)
             .first()["version"])
        return int(v if v is not None else 0)
    
    def _get_cdf_reader(self, first_run: bool, latest_ver: Optional[int]):
        """Create a CDF reader for the given table."""
        max_files = self.config.get('max_files_per_trigger', 1000)
        reader = (self.spark.readStream
                 .format("delta")
                 .option("readChangeFeed", "true")
                 .option("maxFilesPerTrigger", max_files))
        
        if first_run and latest_ver is not None:
            reader = reader.option("startingVersion", latest_ver)
        return reader
    
    def _ensure_status_row(self):
        """Ensure status row exists for this pipeline."""
        exists = (self.spark.table(self.status_table)
                 .where(f"SOURCE_NAME = '{self.source_name}'")
                 .limit(1).count() > 0)
        if not exists:
            self.spark.sql(f"""
                INSERT INTO {self.status_table}
                SELECT 
                    '{self.source_name}' AS SOURCE_NAME,
                    current_timestamp()  AS LAST_PROCESSED_DTTM,
                    'INIT'              AS STATUS,
                    current_timestamp()  AS UPDATE_DATE,
                    '{self.update_by}'   AS UPDATE_BY
            """)
        
    def _get_last_business_ts(self) -> datetime:
        """Get the last processed business timestamp."""
        row = self.spark.sql(f"""
            SELECT LAST_PROCESSED_DTTM 
            FROM {self.status_table}
            WHERE SOURCE_NAME = '{self.source_name}'
        """).collect()[0]
        return row["LAST_PROCESSED_DTTM"]
    
    def _upsert_status(self, new_last_ts: datetime, changed: bool):
        """Update the status table with latest processing information."""
        status_str = "CHANGED" if changed else "NO_CHANGE"
        self.logger.info(f"Updating status: {status_str}, new_last_ts={new_last_ts}")
        
        # Handle timestamp consistently with current_timestamp()
        ts_lit = ("current_timestamp()" if new_last_ts is None 
                else f"CAST(from_utc_timestamp(to_timestamp('{new_last_ts}'), 'America/New_York') AS TIMESTAMP)")
        
        self.spark.sql(f"""
            MERGE INTO {self.status_table} t
            USING (
            SELECT
                '{self.source_name}' AS SOURCE_NAME,
                {ts_lit}             AS LAST_PROCESSED_DTTM,
                '{status_str}'       AS STATUS,
                current_timestamp()  AS UPDATE_DATE,
                '{self.update_by}'   AS UPDATE_BY
            ) s
            ON t.SOURCE_NAME = s.SOURCE_NAME
            WHEN MATCHED THEN UPDATE SET
            t.LAST_PROCESSED_DTTM = s.LAST_PROCESSED_DTTM,
            t.STATUS              = s.STATUS,
            t.UPDATE_DATE         = s.UPDATE_DATE,
            t.UPDATE_BY           = s.UPDATE_BY
            WHEN NOT MATCHED THEN INSERT *
        """)
    
    def _monitor_batch(self, df: DataFrame, batch_id: int):
        """Process a micro-batch of CDF changes."""
        self._ensure_status_row()
        last_business_ts = self._get_last_business_ts()
        
        self.logger.info(f"Processing batch_id={batch_id}")
        self.logger.info(f"Current business timestamp before start of the process: {last_business_ts}")
        
        # Let handler process the batch
        max_business_ts, changed = self.handler.process_batch(df, last_business_ts)
        
        # Update status
        self._upsert_status(max_business_ts, changed)
        if changed:
            self.logger.info(f"Advanced watermark to {max_business_ts}")
    
    def _reset_checkpoint(self):
        """Reset checkpoint directory."""
        self.logger.error("Need to Handle the delete logic for checkpoint reset")
        pass
    
    def run(self, await_termination: bool = True):
        """Start the CDF monitoring stream."""
        query = None
        try:
            first_run = not self._path_exists(self.checkpoint_dir)
            
            # If skip_vacuum_files is True and checkpoint exists, delete it
            if self.skip_vacuum_files and not first_run:
                self.logger.warning("skip_vacuum_files=True: Deleting existing checkpoint...")
                self._reset_checkpoint()
                first_run = True
                self.logger.warning("Checkpoint deleted. Starting fresh from latest version.")
            
            self.logger.info(f"Starting CDF monitor (first_run={first_run})")
            self.handler.can_job_start()
            # Build unified stream using handler
            unified_stream = self.handler.build_stream(
                self._get_cdf_reader,
                first_run,
                self._latest_delta_version,
                self.spark
            )
            
            self.logger.info(f"Unified Stream schema: {unified_stream.schema}")
            self.logger.info(f"Unified Stream isStreaming: {unified_stream.isStreaming}")
            self.logger.info("Unified Stream explain:")
            self.logger.info(unified_stream.explain(True))  # Will show the logical and physical plans
            
            # Configure and start the streaming query
            trigger_options = self._get_trigger()
            self.logger.info(f"Starting streaming query for {self.name}")
            self.logger.info(f"Trigger: {trigger_options}")
            
            writer = (unified_stream.writeStream
                    .queryName(f"{self.name}_cdf_monitor")
                    .foreachBatch(self._monitor_batch)
                    .option("checkpointLocation", self.checkpoint_dir)
                    .trigger(**trigger_options))
            
            query = writer.start()
            
            return query.awaitTermination()
            
        except Exception as e:
            self.logger.error(f"Error in CDF monitor: {e}")
            raise
        finally:
            if query:
                try:
                    query.stop()
                except Exception as e:
                    self.logger.error(f"Error stopping query: {e}")