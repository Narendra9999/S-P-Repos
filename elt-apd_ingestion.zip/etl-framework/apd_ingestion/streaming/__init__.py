"""
Streaming module for Kafka-based data processing.
"""

from .checkpoint_manager import CheckpointManager

__all__ = ['CheckpointManager']