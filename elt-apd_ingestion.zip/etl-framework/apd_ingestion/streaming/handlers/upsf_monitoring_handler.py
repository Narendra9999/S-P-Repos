from datetime import datetime
from typing import Any, Tuple, Set, Callable, Optional
from pyspark.sql import DataFrame, functions as F
import logging
from apd_ingestion.constants.enum_vars import RunType, StreamType
from apd_ingestion.streaming.streaming_utils import StreamingUtils
from pytz import timezone
import pytz

class USPFMonitoringHandler:
    """
    Handler to monitor changes in t_fips_id_link and t_finorg_geo_rel tables.
    Logs all unique FIPS_CODEs that changed based on CREATE_DTTM or LAST_UPD_DTTM.
    """
    def __init__(self, config: dict):
        self.logger = logging.getLogger(f"{self.__class__.__name__}")
        self.logger.info("Initializing USPFMonitoringHandler")
        
        # Validate configuration
        self._validate_config(config)
        
        # Required configuration
        self.id_source = config['id_source']
        self.source_name = config['source_name']
        
        # Get tables from the nested 'tables' config
        tables = config.get('tables', {})
        self.fips_id_link_table = tables.get('fips_id_link_table')
        self.finorg_geo_rel_table = tables.get('finorg_geo_rel_table')
        
        # Get options from the nested 'options' config
        options = config.get('options', {})
        self.skip_latest_on_day1 = options.get('skip_latest_on_day1', True)
        self.include_deletes = options.get('include_deletes', False)
        
        # Define CDF types to monitor
        self.cdf_types = ["insert", "update_postimage"]
        if self.include_deletes:
            self.cdf_types.append("delete")
            
        self.process_status_table = config.get('control_table').get('table_name')
        self.run_type = RunType.USPF_STREAM.value

    def can_job_start(self):
        if not self.job_monitor.wait_with_alerting(self.run_type):
            raise Exception(f"Timeout waiting for job coordination slot for pipeline '{self.run_type}'")
            
    def _validate_config(self, config: dict):
        """Validate USPF-specific configuration."""
        # Check id_source
        if 'id_source' not in config:
            raise ValueError("Missing required configuration field: id_source")
            
        # Check tables configuration
        tables = config.get('tables', {})
        if not tables:
            raise ValueError("Missing 'tables' configuration section")
            
        # Validate required table names
        for table_key in ['fips_id_link_table', 'finorg_geo_rel_table']:
            table_name = tables.get(table_key)
            if not table_name:
                raise ValueError(f"Missing required table configuration: tables.{table_key}")
            if not isinstance(table_name, str) or '.' not in table_name:
                raise ValueError(f"{table_key} must be a fully qualified table name (e.g., 'schema.table')")

    def _get_fips_id_link_stream(self, get_reader: Callable, first_run: bool, latest_ver: Optional[int]) -> DataFrame:
        """
        Extract and transform changes from the t_fips_id_link table using Change Data Feed (CDF).
        
        This method:
        1. Reads CDF data from the fips_id_link table
        2. Filters for relevant change types (insert, update_postimage, optionally delete)
        3. Filters by ID_SOURCE to get only records for this specific data source
        4. Creates unified business timestamps from CREATE_DTTM and LAST_UPD_DTTM
        5. Returns standardized change records with FIPS_CODE as the key
        
        Args:
            get_reader: Function to create CDF reader with version constraints
            first_run: If True, this is initial run (no checkpoint exists)
            latest_ver: Latest table version to use as starting point for first run
            
        Returns:
            DataFrame with columns:
            - fips_code: Business key identifier 
            - origin: 'fips_id_link' to identify source table
            - business_ts: Change detection timestamp (when record actually changed)
            - commit_ts: Delta table commit timestamp
            - commit_version: Delta table version number
            - change_type: Type of change (insert/update_postimage/delete)
        """
        self.logger.info(f"Getting fips_id_link changes from {self.fips_id_link_table} (first_run={first_run}, latest_ver={latest_ver})")
        
        fips_reader = get_reader(first_run, latest_ver)
        fips_cdf = (fips_reader.table(self.fips_id_link_table)
                   .filter(F.col("_change_type").isin(self.cdf_types))
                   .filter(F.col("ID_SOURCE") == self.id_source))
        
        self.logger.info(f"Filtering fips_id_link changes for id_source={self.id_source} and change_types={self.cdf_types}")
                  
        if first_run and self.skip_latest_on_day1:
            fips_cdf = fips_cdf.filter(F.col("_commit_version") > F.lit(latest_ver))
            
        # Use change detection timestamp logic
        # If LAST_UPD_DTTM > CREATE_DTTM: record was updated, use LAST_UPD_DTTM
        # Otherwise: record was created or created==updated, use CREATE_DTTM
        business_ts = F.when(
            F.col("LAST_UPD_DTTM") > F.col("CREATE_DTTM"),
            F.col("LAST_UPD_DTTM")  # Record was updated
        ).otherwise(F.col("CREATE_DTTM"))  # Record was created or created==updated
        
        
        return (fips_cdf
            .select(
                F.col("FIPS_CODE").alias("fips_code"),
                F.lit("fips_id_link").alias("origin"),
                business_ts.alias("business_ts"),  # Change detection timestamp
                F.col("_commit_timestamp").alias("commit_ts"),
                F.col("_commit_version").alias("commit_version"),
                F.col("_change_type").alias("change_type")
            ))

    def _get_finorg_geo_rel_stream(self, get_reader: Callable, first_run: bool, latest_ver: Optional[int], spark) -> DataFrame:
        """
        Extract and transform changes from the t_finorg_geo_rel table using Change Data Feed (CDF).
        
        This method:
        1. Reads CDF data from the finorg_geo_rel table
        2. Filters for relevant change types (insert, update_postimage, optionally delete)
        3. Joins with fips_id_link table snapshot to filter by ID_SOURCE (since finorg_geo_rel doesn't have ID_SOURCE directly)
        4. Creates unified business timestamps from CREATE_DTTM and LAST_UPD_DTTM
        5. Returns standardized change records matching the fips_id_link stream format
        
        Args:
            get_reader: Function to create CDF reader with version constraints
            first_run: If True, this is initial run (no checkpoint exists)
            latest_ver: Latest table version to use as starting point for first run
            spark: Spark session for reading fips_id_link table snapshot
            
        Returns:
            DataFrame with columns:
            - fips_code: Business key identifier
            - origin: 'finorg_geo_rel' to identify source table
            - business_ts: Change detection timestamp (when record actually changed)
            - commit_ts: Delta table commit timestamp
            - commit_version: Delta table version number
            - change_type: Type of change (insert/update_postimage/delete)
        """
        self.logger.info(f"Getting finorg_geo_rel changes from {self.finorg_geo_rel_table} (first_run={first_run}, latest_ver={latest_ver})")
        
        finorg_reader = get_reader(first_run, latest_ver)        
        finorg_cdf = (finorg_reader.table(self.finorg_geo_rel_table)
                     .filter(F.col("_change_type").isin(self.cdf_types)))
        
        self.logger.info(f"Filtering finorg_geo_rel changes for change_types={self.cdf_types}")
                   
        if first_run and self.skip_latest_on_day1:
            finorg_cdf = finorg_cdf.filter(F.col("_commit_version") > F.lit(latest_ver))
            
        # Use change detection timestamp logic
        # If LAST_UPD_DTTM > CREATE_DTTM: record was updated, use LAST_UPD_DTTM
        # Otherwise: record was created or created==updated, use CREATE_DTTM
        business_ts = F.when(
            F.col("LAST_UPD_DTTM") > F.col("CREATE_DTTM"),
            F.col("LAST_UPD_DTTM")  # Record was updated
        ).otherwise(F.col("CREATE_DTTM"))  # Record was created or created==updated
            
        finorg_base = finorg_cdf.select(
            F.col("FIPS_CODE").alias("fips_code"),
            business_ts.alias("business_ts"),  # Change detection timestamp
            F.col("_commit_timestamp").alias("commit_ts"),
            F.col("_commit_version").alias("commit_version"),
            F.col("_change_type").alias("change_type")
        )
        
        # Join with fips_id_link table to filter by ID_SOURCE
        fips_snapshot = (spark.table(self.fips_id_link_table)
                        .select(
                            F.col("FIPS_CODE").alias("fips_code"),
                            F.col("ID_SOURCE").alias("id_source")))

        return (finorg_base.join(fips_snapshot, on="fips_code", how="inner")
                .filter(F.col("id_source") == self.id_source)
                .select(
                    F.col("fips_code"),
                    F.lit("finorg_geo_rel").alias("origin"),
                    F.col("business_ts"),
                    F.col("commit_ts"),
                    F.col("commit_version"),
                    F.col("change_type")))

    def build_stream(self, get_reader: Callable, first_run: bool, get_latest_version: Callable, spark) -> DataFrame:
        """
        Build the unified Change Data Feed (CDF) stream for USPF monitoring.
        
        This is the main orchestration method that:
        1. Gets latest table versions for first-run initialization
        2. Creates separate CDF streams from fips_id_link and finorg_geo_rel tables
        3. Unions the streams into a single monitoring DataFrame
        4. Ensures consistent schema across both tables for unified processing
        
        The unified stream enables monitoring changes across both tables
        with a single checkpoint, providing comprehensive change detection for USPF data.
        
        Args:
            get_reader: Function to create CDF reader with version constraints
                       Signature: get_reader(first_run: bool, latest_ver: Optional[int]) -> CDF_Reader
            first_run: If True, this is initial run (no checkpoint exists)
                      Controls whether to skip latest version on day 1
            get_latest_version: Function to get latest version of a table
                               Signature: get_latest_version(table_name: str) -> int
            spark: Spark session for reading table snapshots
            
        Returns:
            DataFrame: Unified stream with standardized schema containing:
            - fips_code: Business key for tracking changes
            - origin: 'fips_id_link' or 'finorg_geo_rel' to identify source table
            - business_ts: Change detection timestamp (when record actually changed)
            - commit_ts: Delta table commit timestamp
            - commit_version: Delta table version number
            - change_type: Type of change (insert/update_postimage/delete)
        """
        self.logger.info(f"Building unified CDF stream (first_run={first_run})")
        
        # Get latest versions if needed
        latest_fips_ver = get_latest_version(self.fips_id_link_table) if first_run else None
        latest_finorg_ver = get_latest_version(self.finorg_geo_rel_table) if first_run else None
        self.logger.info(f"Latest versions - FIPS ID Link: {latest_fips_ver}, FINORG Geo Rel: {latest_finorg_ver}")
        
        # Get changes from both tables
        self.logger.info("Starting to fetch changes from both tables")
        fips_stream = self._get_fips_id_link_stream(get_reader, first_run, latest_fips_ver)
        finorg_stream = self._get_finorg_geo_rel_stream(get_reader, first_run, latest_finorg_ver, spark)
        
        # Union the streams
        return fips_stream.unionByName(finorg_stream, allowMissingColumns=False)


    def process_batch(self, df: DataFrame, last_business_ts: datetime) -> Tuple[datetime, bool]:
        """
        Process a batch of CDF changes and log changed FIPS_CODEs.
        
        This method processes the unified CDF stream and:
        1. Filters changes newer than the last processed business timestamp
        2. Deduplicates records by fips_code, origin, and commit_version
        3. Collects all unique FIPS_CODEs that changed
        4. Logs the changed FIPS_CODEs for monitoring
        5. Returns the maximum business timestamp for checkpoint advancement
        
        Args:
            df: DataFrame containing CDF changes from build_stream()
                Must have columns: fips_code, origin, business_ts, commit_version
            last_business_ts: Last processed business timestamp from checkpoint
                             Used to filter for only new changes since last run
                             Can be None for first run (processes all data)
        
        Returns:
            Tuple[datetime, bool]: 
            - datetime: Maximum business_ts from this batch (for checkpoint update)
            - bool: True if changes were found and processed, False if no new changes
        """
        self.logger.info(f"Processing USPF batch with last_business_ts={last_business_ts}")
        
        # Filter by business_ts
        filtered = df if last_business_ts is None else df.filter(F.col("business_ts") > F.lit(last_business_ts))
        
        if filtered.rdd.isEmpty():
            self.logger.info("No new changes found in this batch")
            return last_business_ts, False
            
        # Deduplicate and aggregate
        filtered_dedup = filtered.dropDuplicates(["fips_code", "origin", "commit_version"])
        
        # Collect all unique FIPS_CODEs that changed
        unique_fips_codes = [row.fips_code for row in filtered_dedup.select("fips_code").distinct().collect()]
        
        # Get aggregation results
        agg = (filtered_dedup.agg(
            F.countDistinct("fips_code").alias("changed_keys"),
            F.max("business_ts").alias("max_business_ts"),
            F.min("business_ts").alias("min_business_ts_earliest"))
            .collect()[0])
            
        changed_keys = agg["changed_keys"]
        max_business_ts = agg["max_business_ts"]
        min_business_ts_earliest = agg["min_business_ts_earliest"]

        self.logger.info(f"Changed FIPS_CODEs ({changed_keys} total): {unique_fips_codes}")
        self.logger.info(f"Batch aggregation results: min_business_ts_earliest={min_business_ts_earliest}")
        
        # Convert earliest business timestamp to EST timezone for downstream processing
        est_tz = timezone('US/Eastern')
        
        # Handle timezone conversion properly for the earliest timestamp
        if min_business_ts_earliest.tzinfo is None:
            # Assume naive datetime is in UTC and convert to EST
            utc_tz = pytz.UTC
            min_business_ts_earliest_utc = utc_tz.localize(min_business_ts_earliest)
            min_business_ts_earliest_est = min_business_ts_earliest_utc.astimezone(est_tz)
            self.logger.info(f"Converted naive earliest timestamp (assumed UTC) to EST: {min_business_ts_earliest} -> {min_business_ts_earliest_est}")
        else:
            # Already timezone-aware, convert to EST
            min_business_ts_earliest_est = min_business_ts_earliest.astimezone(est_tz)
            self.logger.info(f"Converted timezone-aware earliest timestamp to EST: {min_business_ts_earliest} -> {min_business_ts_earliest_est}")
        
        self.logger.info(f"Triggering processing for {changed_keys} changed keys with earliest timestamp: {min_business_ts_earliest_est}")
        filters = {"fips_code": unique_fips_codes}
        if self.source_name == StreamType.IHS_USPF.value:
            StreamingUtils.finanalytic_ihs_records(min_business_ts_earliest_est, filters, self.run_type)
        elif self.source_name == StreamType.BLS_USPF.value:
            StreamingUtils.finanalytic_bls_records(min_business_ts_earliest_est, filters, self.run_type)
        else:
            self.logger.error(f"Unknown source_name: {self.source_name}. Skipping processing.")

        self.logger.info(f"Processed batch: {changed_keys} changed keys, max_business_ts={max_business_ts}")

        return max_business_ts, True

    