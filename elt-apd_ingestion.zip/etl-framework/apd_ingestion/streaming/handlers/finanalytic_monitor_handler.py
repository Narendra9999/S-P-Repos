import logging
from pyspark.sql import DataFrame, functions as F
from datetime import datetime
from typing import Any, List, Tuple, Callable, Optional

from apd_ingestion.ihs.IHS_MAIN import run_etl
from apd_ingestion.ihs.IHS_MNEMONICMAPPING import run_load_ecr_mnemonicmapping
from apd_ingestion.ihs.IHS_PROC_LOG import run_proc_log
from apd_ingestion.ihs.IHS_JSON_TO_APD import main as ihs_main

from apd_ingestion.bls.BLS_DATA_PNT import run_bls_data_pnt
from apd_ingestion.bls.BLS_SERIES import run_bls_series
from apd_ingestion.bls.BLS_JSON_TO_APD import main

from apd_ingestion.eds.EDS_DATA_PROCESSOR import load_eds_pipeline

from apd_ingestion.config.config_manager import get_config_value
from apd_ingestion.constants.enum_vars import RunType, StreamType

from pytz import timezone
import pytz
class FinanalyticMonitorHandler:
    """
    Handler for finanalytics-specific CDF monitoring.
    Monitors changes in map and attribute tables for finanalytics data.
    """
    
    def __init__(self, config: dict):
        self.logger = logging.getLogger(f"{self.__class__.__name__}")
        self.logger.info("Initializing FinanalyticMonitorHandler")
        # Validate finanalytics configuration
        self._validate_config(config)
        
        # Required configuration
        self.source_id = config['source_id']
        self.source_name = config['source_name']
        
        # Get tables from the nested 'tables' config
        tables = config.get('tables', {})
        self.map_table = tables.get('map_table')
        self.attr_table = tables.get('attr_table')
        
        # Get options from the nested 'options' config
        options = config.get('options', {})
        self.skip_latest_on_day1 = options.get('skip_latest_on_day1', True)
        self.include_deletes = options.get('include_deletes', False)
        self.source_id_column = config.get('source_id_column', 'fm_data_source_id')
        self.map_id_column = config.get('map_id_column', 'de_ver_st_frmla_map_id')
        self.timestamp_columns = config.get('timestamp_columns', ['create_dttm', 'last_upd_dttm'])
        
        self.process_status_table = config.get('control_table').get('table_name')
        
        # Define CDF types to monitor
        self.cdf_types = ["insert", "update_postimage"]
        if self.include_deletes:
            self.cdf_types.append("delete")
        self.run_type = RunType.FINANALYTIC_STREAM.value
        
    def can_job_start(self):
        if not self.job_monitor.wait_with_alerting(self.run_type):
            raise Exception(f"Timeout waiting for job coordination slot for pipeline '{self.run_type}'")
            
    def _validate_config(self, config: dict):
        """Validate finanalytics-specific configuration."""
        # Check source_id
        if 'source_id' not in config:
            raise ValueError("Missing required configuration field: source_id")
            
        if not isinstance(config.get('source_id'), (int, str)):
            raise ValueError("source_id must be an integer or string")
            
        # Check tables configuration
        tables = config.get('tables', {})
        if not tables:
            raise ValueError("Missing 'tables' configuration section")
            
        # Validate required table names, map table is mandatory for all sources
        for table_key in ['map_table']:
            table_name = tables.get(table_key)
            if not table_name:
                raise ValueError(f"Missing required table configuration: tables.{table_key}")
            if not isinstance(table_name, str) or '.' not in table_name:
                raise ValueError(f"{table_key} must be a fully qualified table name (e.g., 'schema.table')")
            
    def _get_map_stream(self, get_reader: Callable, first_run: bool, latest_ver: Optional[int]) -> DataFrame:
        """
        Extract and transform changes from the finanalytics map table using Change Data Feed (CDF).
        
        This method:
        1. Reads CDF data from the map table
        2. Filters for relevant change types (insert, update_postimage, optionally delete)
        3. Filters by source_id to get only records for this specific data source
        4. Creates unified business timestamps from create_dttm and last_upd_dttm
        5. Returns standardized change records with both earliest and latest timestamps
        
        Args:
            get_reader: Function to create CDF reader with version constraints
            first_run: If True, this is initial run (no checkpoint exists)
            latest_ver: Latest table version to use as starting point for first run
            
        Returns:
            DataFrame with columns:
            - map_id: Business key identifier 
            - origin: 'map' to identify source table
            - business_ts: Change detection timestamp (when record actually changed)
            - commit_ts: Delta table commit timestamp
            - commit_version: Delta table version number
            - change_type: Type of change (insert/update_postimage/delete)
        """
        self.logger.info(f"Getting map changes from {self.map_table} (first_run={first_run}, latest_ver={latest_ver})")
        
        map_reader = get_reader(first_run, latest_ver)
        map_cdf = (map_reader.table(self.map_table)
                  .filter(F.col("_change_type").isin(self.cdf_types))
                  .filter(F.col(self.source_id_column) == self.source_id))
        
        self.logger.info(f"Filtering map changes for source_id={self.source_id} and change_types={self.cdf_types}")
                  
        if first_run and self.skip_latest_on_day1:
            map_cdf = map_cdf.filter(F.col("_commit_version") > F.lit(latest_ver))
            
        # Use change detection timestamp logic
        # If last_upd_dttm > create_dttm: record was updated, use last_upd_dttm
        # Otherwise: record was created or created==updated, use create_dttm
        business_ts = F.when(
            F.col("last_upd_dttm") > F.col("create_dttm"),
            F.col("last_upd_dttm")  # Record was updated
        ).otherwise(F.col("create_dttm"))  # Record was created or created==updated
        
        return (map_cdf
            .select(
                F.col(self.map_id_column).alias("map_id"),
                F.lit("map").alias("origin"),
                business_ts.alias("business_ts"),  # Change detection timestamp
                F.col("_commit_timestamp").alias("commit_ts"),
                F.col("_commit_version").alias("commit_version"),
                F.col("_change_type").alias("change_type")
            ))

    def _get_attr_stream(self, get_reader: Callable, first_run: bool, latest_ver: Optional[int], spark) -> DataFrame:
        """
        Extract and transform changes from the finanalytics attribute table using Change Data Feed (CDF).
        
        This method:
        1. Reads CDF data from the attribute table
        2. Filters for relevant change types (insert, update_postimage, optionally delete)
        3. Joins with map table snapshot to filter by source_id (since attr table doesn't have source_id directly)
        4. Creates unified business timestamps from create_dttm and last_upd_dttm
        5. Returns standardized change records matching the map stream format
        
        Args:
            get_reader: Function to create CDF reader with version constraints
            first_run: If True, this is initial run (no checkpoint exists)
            latest_ver: Latest table version to use as starting point for first run
            spark: Spark session for reading map table snapshot
            
        Returns:
            DataFrame with columns:
            - map_id: Business key identifier
            - origin: 'attr' to identify source table
            - business_ts: Change detection timestamp (when record actually changed)
            - commit_ts: Delta table commit timestamp
            - commit_version: Delta table version number
            - change_type: Type of change (insert/update_postimage/delete)
        """
        self.logger.info(f"Getting attribute changes from {self.attr_table} (first_run={first_run}, latest_ver={latest_ver})")
        
        attr_reader = get_reader(first_run, latest_ver)        
        attr_cdf = (attr_reader.table(self.attr_table)
                   .filter(F.col("_change_type").isin(self.cdf_types)))
        
        self.logger.info(f"Filtering attribute changes for change_types={self.cdf_types}")
                   
        if first_run and self.skip_latest_on_day1:
            attr_cdf = attr_cdf.filter(F.col("_commit_version") > F.lit(latest_ver))
            
        # Use change detection timestamp logic
        # If last_upd_dttm > create_dttm: record was updated, use last_upd_dttm
        # Otherwise: record was created or created==updated, use create_dttm
        business_ts = F.when(
            F.col("last_upd_dttm") > F.col("create_dttm"),
            F.col("last_upd_dttm")  # Record was updated
        ).otherwise(F.col("create_dttm"))  # Record was created or created==updated
            
        attr_base = attr_cdf.select(
            F.col(self.map_id_column).alias("map_id"),
            business_ts.alias("business_ts"),  # Change detection timestamp
            F.col("_commit_timestamp").alias("commit_ts"),
            F.col("_commit_version").alias("commit_version"),
            F.col("_change_type").alias("change_type")
        )
        
        # Join with map table to filter by source_id
        map_snapshot = (spark.table(self.map_table)
                       .select(
                           F.col(self.map_id_column).alias("map_id"),
                           F.col(self.source_id_column).alias("source_id")))

        return (attr_base.join(map_snapshot, on="map_id", how="inner")
                .filter(F.col("source_id") == self.source_id)
                .select(
                    F.col("map_id"),
                    F.lit("attr").alias("origin"),
                    F.col("business_ts"),
                    F.col("commit_ts"),
                    F.col("commit_version"),
                    F.col("change_type")))

    def build_stream(self, get_reader: Callable, first_run: bool, get_latest_version: Callable, spark) -> DataFrame:
        """
        Build the unified Change Data Feed (CDF) stream for finanalytics monitoring.
        
        This is the main orchestration method that:
        1. Gets latest table versions for first-run initialization
        2. Creates separate CDF streams from map and attribute tables
        3. Unions the streams into a single monitoring DataFrame
        4. Ensures consistent schema across both tables for unified processing
        
        The unified stream enables monitoring changes across both map and attribute tables
        with a single checkpoint, providing comprehensive change detection for finanalytics data.
        
        Args:
            get_reader: Function to create CDF reader with version constraints
                       Signature: get_reader(first_run: bool, latest_ver: Optional[int]) -> CDF_Reader
            first_run: If True, this is initial run (no checkpoint exists)
                      Controls whether to skip latest version on day 1
            get_latest_version: Function to get latest version of a table
                               Signature: get_latest_version(table_name: str) -> int
            spark: Spark session for reading table snapshots
            
        Returns:
            DataFrame: Unified stream with standardized schema containing:
            - map_id: Business key for tracking changes
            - origin: 'map' or 'attr' to identify source table
            - business_ts: Change detection timestamp (when record actually changed)
            - commit_ts: Delta table commit timestamp
            - commit_version: Delta table version number
            - change_type: Type of change (insert/update_postimage/delete)
        """
        self.logger.info(f"Building unified CDF stream (first_run={first_run})")
        
        latest_map_ver = get_latest_version(self.map_table) if first_run else None
        self.logger.info(f"Latest versions - Map: {latest_map_ver}")
        
        # Get changes from map table
        map_stream = self._get_map_stream(get_reader, first_run, latest_map_ver)
        
        # EDS only monitors map table changes, other sources monitor both tables
        if self.source_name == StreamType.EDS_FINANALYTIC.value:
            self.logger.info(f"{self.source_name}: Monitoring map table changes only")
            return map_stream
        else:
            latest_attr_ver = get_latest_version(self.attr_table) if first_run else None
            self.logger.info(f"Latest versions - Attr: {latest_attr_ver}")
            self.logger.info("Starting to fetch changes from both map and attr tables")
            attr_stream = self._get_attr_stream(get_reader, first_run, latest_attr_ver, spark)
            
            # Union the streams
            return map_stream.unionByName(attr_stream, allowMissingColumns=False)

    def process_batch(self, df: DataFrame, last_business_ts: datetime) -> Tuple[datetime, bool]:
        """
        Process a batch of CDF changes and trigger downstream finanalytics processing.
        
        This method is the main batch processing logic that:
        1. Filters changes newer than the last processed business timestamp
        2. Deduplicates records by map_id, origin, and commit_version
        3. Aggregates to find changed keys count and timestamp ranges
        4. Converts the earliest timestamp to EST timezone
        5. Triggers appropriate downstream processing (IHS or BLS) based on source_id
        6. Returns the maximum business timestamp for checkpoint advancement
        
        The method ensures idempotent processing by filtering on business_ts and
        provides comprehensive change statistics for monitoring and debugging.
        
        Args:
            df: DataFrame containing CDF changes from build_stream()
                Must have columns: map_id, origin, business_ts, commit_version
            last_business_ts: Last processed business timestamp from checkpoint
                             Used to filter for only new changes since last run
                             Can be None for first run (processes all data)
        
        Returns:
            Tuple[datetime, bool]: 
            - datetime: Maximum business_ts from this batch (for checkpoint update)
            - bool: True if changes were found and processed, False if no new changes
            
        Raises:
            Exception: If downstream processing (IHS/BLS) fails during execution
        """
        self.logger.info(f"Processing batch with last_business_ts={last_business_ts}")
        # Filter by business_ts
        filtered = df if last_business_ts is None else df.filter(F.col("business_ts") > F.lit(last_business_ts))
        
        if filtered.rdd.isEmpty():
            self.logger.info("No new changes found in this batch")
            return last_business_ts, False
            
        # Deduplicate and aggregate
        filtered_dedup = filtered.dropDuplicates(["map_id", "origin", "commit_version"])

         # Collect all unique formula map IDs that changed
        unique_formula_map_ids = [row.map_id for row in filtered_dedup.select("map_id").distinct().collect()]
        
        agg = (filtered_dedup.agg(
            F.countDistinct("map_id").alias("changed_keys"),
            F.max("business_ts").alias("max_business_ts"),
            F.min("business_ts").alias("min_business_ts_earliest"))
            .collect()[0])
            
        changed_keys = agg["changed_keys"]
        max_business_ts = agg["max_business_ts"]
        min_business_ts_earliest = agg["min_business_ts_earliest"]

        self.logger.info(f"Changed Formula Map IDs ({changed_keys} total): {unique_formula_map_ids}")

        self.logger.info(f"Batch aggregation results: max_business_ts={max_business_ts}, min_business_ts_earliest={min_business_ts_earliest}")
        
        # Convert earliest business timestamp to EST timezone for downstream processing
        est_tz = timezone('US/Eastern')
        
        # Handle timezone conversion properly for the earliest timestamp
        if min_business_ts_earliest.tzinfo is None:
            # Assume naive datetime is in UTC and convert to EST
            utc_tz = pytz.UTC
            min_business_ts_earliest_utc = utc_tz.localize(min_business_ts_earliest)
            min_business_ts_earliest_est = min_business_ts_earliest_utc.astimezone(est_tz)
            self.logger.info(f"Converted naive earliest timestamp (assumed UTC) to EST: {min_business_ts_earliest} -> {min_business_ts_earliest_est}")
        else:
            # Already timezone-aware, convert to EST
            min_business_ts_earliest_est = min_business_ts_earliest.astimezone(est_tz)
            self.logger.info(f"Converted timezone-aware earliest timestamp to EST: {min_business_ts_earliest} -> {min_business_ts_earliest_est}")
        
        # Call IHS Handler Jobs in sequence
        self.logger.info(f"Triggering processing for {changed_keys} changed keys with earliest timestamp: {min_business_ts_earliest_est}")
        filters = {"formula_map_ids": unique_formula_map_ids}
        if self.source_name == StreamType.IHS_FINANALYTIC.value:
            self.finanalytic_ihs_records(min_business_ts_earliest_est, filters)
        elif self.source_name == StreamType.BLS_FINANALYTIC.value:
            self.finanalytic_bls_records(min_business_ts_earliest_est, filters)
        elif self.source_name == StreamType.EDS_FINANALYTIC.value:
            self.finanalytic_eds_records(min_business_ts_earliest_est, filters)
        else:
            self.logger.error(f"Unknown source_name: {self.source_name}. Skipping processing.")

        self.logger.info(f"Processed batch: {changed_keys} changed keys, max_business_ts={max_business_ts}")

        return max_business_ts, True
    
    def finanalytic_ihs_records(self, timestamp: datetime, filters: dict[Any]) -> None:
        """
        Execute IHS finanalytics processing pipeline in sequence.
        
        This method orchestrates the complete IHS data processing workflow for finanalytics:
        1. IHS_MAIN: Core IHS data extraction and transformation
        2. IHS_PROC_LOG: Process logging and metadata updates
        3. IHS_MNEMONICMAPPING: Mnemonic mapping and standardization
        4. IHS_JSON_TO_APD: Final transformation to APD format
        
        All processes are executed sequentially to ensure proper data dependencies.
        If any process fails, the entire pipeline stops and raises an exception.
        
        Args:
            timestamp: EST timezone timestamp representing the earliest change time
                      Used by each process to determine the data processing window
            filters: which will contain formula map id's 
                      
        Raises:
            Exception: If any IHS process fails, with details about which step failed
        """
        self.logger.info(f"Processing IHS finanalytic records for timestamp: {timestamp}")
        
        user_name = get_config_value('databricks_user')
        environment = get_config_value('environment')
        
        # Define IHS processes in execution order
        processes = [
            ("IHS_MAIN", lambda: run_etl(user_name, environment, self.run_type, timestamp, filters)),
            ("IHS_PROC_LOG", lambda: run_proc_log(environment, user_name, self.run_type, timestamp, filters)),
            ("IHS_MNEMONICMAPPING", lambda: run_load_ecr_mnemonicmapping(environment, user_name, self.run_type, timestamp)),
            ("IHS_JSON_TO_APD", lambda: ihs_main(environment, user_name, self.run_type, timestamp, filters)),
        ]
        
        self._execute_processes_sequentially(processes, "IHS", timestamp)

    def finanalytic_bls_records(self, timestamp: datetime, filters: dict[Any]) -> None:
        """
        Execute BLS finanalytics processing pipeline in sequence.
        
        This method orchestrates the complete BLS data processing workflow for finanalytics:
        1. BLS_DATA_PNT: BLS data point extraction and processing
        2. BLS_SERIES: BLS series data processing and transformation
        3. BLS_JSON_TO_APD: Final transformation to APD format
        
        All processes are executed sequentially to ensure proper data dependencies.
        If any process fails, the entire pipeline stops and raises an exception.
        
        Args:
            timestamp: EST timezone timestamp representing the earliest change time
                      Used by each process to determine the data processing window
            frml_map_id: List of unique formula map IDs to process
        Raises:
            Exception: If any BLS process fails, with details about which step failed
        """
        self.logger.info(f"Processing BLS finanalytic records for timestamp: {timestamp}")
        
        user_name = get_config_value('databricks_user')
        environment = get_config_value('environment')
        
        
        # Define BLS processes in execution order  
        processes = [
            ("BLS_DATA_PNT", lambda: run_bls_data_pnt(environment, user_name, self.run_type, timestamp, filters)),
            ("BLS_SERIES", lambda: run_bls_series(environment, user_name, self.run_type, timestamp)),
            ("BLS_JSON_TO_APD", lambda: main(environment, user_name, self.run_type, filters)),
        ]
        
        self._execute_processes_sequentially(processes, "BLS", timestamp)
        
    
    def finanalytic_eds_records(self, timestamp: datetime, filters: dict[Any]) -> None:
        """
        Execute EDS finanalytics processing pipeline in sequence.
        
        This method orchestrates the complete EDS data processing workflow for finanalytics:
        1. EDS_JSON_TO_APD: Final transformation to APD format
        
        All processes are executed sequentially to ensure proper data dependencies.
        If any process fails, the entire pipeline stops and raises an exception.
        
        Args:
            timestamp: EST timezone timestamp representing the earliest change time
                      Used by each process to determine the data processing window
            frml_map_id: List of unique formula map IDs to process
        Raises:
            Exception: If any EDS process fails, with details about which step failed
        """
        self.logger.info(f"Processing EDS finanalytic records for timestamp: {timestamp}")
        
        user_name = get_config_value('databricks_user')
        environment = get_config_value('environment')
        
        
        # Define EDS processes in execution order
        processes = [
            ("EDS_JSON_TO_APD", lambda: load_eds_pipeline(environment, filters, self.run_type, user_name, self.process_status_table)),
        ]
        
        self._execute_processes_sequentially(processes, "EDS", timestamp)
        
    def _execute_processes_sequentially(self, processes: list, process_type: str, timestamp: datetime) -> None:
        """
        Execute a list of processing functions sequentially with comprehensive error handling.
        
        This helper method provides:
        1. Sequential execution ensuring proper data pipeline dependencies
        2. Detailed logging for each process start/completion
        3. Error handling with process-specific failure information
        4. Fail-fast behavior - stops on first error to prevent data corruption
        
        Args:
            processes: List of tuples (process_name, process_function)
                      Each process_function should be a callable that takes no arguments
            process_type: String identifier for the process type (e.g., "IHS", "BLS")
                         Used in error messages and logging
            timestamp: Timestamp passed to the original calling method
                      Used for logging context only
                      
        Raises:
            Exception: If any process fails, includes process name and original error details
        """
        for process_name, process_func in processes:
            try:
                self.logger.info(f"Starting {process_name} for timestamp {timestamp}")
                process_func()
                self.logger.info(f"Completed {process_name} successfully")
            except Exception as e:
                self.logger.error(f"Failed to execute {process_name}: {str(e)}")
                raise Exception(f"{process_type} finanalytic processing failed at {process_name}: {str(e)}")
        
        self.logger.info(f"All {process_type} finanalytic processes completed successfully for timestamp: {timestamp}")
        
        