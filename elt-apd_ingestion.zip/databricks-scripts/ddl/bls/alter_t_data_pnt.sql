ALTER TABLE idf_raw_${env:aws_service_env}.bls_econ.t_data_pnt ADD COLUMNS (
  cmp_indus_lvl2_clsf_cd STRING,
  ent_mnem_cd STRING
);