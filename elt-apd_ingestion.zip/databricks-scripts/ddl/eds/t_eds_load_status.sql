-- idf_raw_${env:aws_service_env}.eds.t_eds_load_status definition

CREATE TABLE idf_raw_${env:aws_service_env}.eds.t_eds_load_status (
  FILENAME STRING,
  FILETYPE STRING,
  STATUS STRING,
  CREATE_DATETIME TIMESTAMP)
USING delta
COMMENT 'This table is related APD Ingestion'
LOCATION 's3://spr-idf-${env:aws_service_env}-platform-landing/catalog/EDS/EDS_LOAD_STATUS'
TBLPROPERTIES (
  'delta.enableChangeDataFeed' = 'true',
  'delta.minReaderVersion' = '1',
  'delta.minWriterVersion' = '4');

CREATE OR REPLACE VIEW idf_raw_${env:aws_service_env}.eds.v_eds_load_status  AS SELECT * FROM  idf_raw_${env:aws_service_env}.eds.t_eds_load_status;