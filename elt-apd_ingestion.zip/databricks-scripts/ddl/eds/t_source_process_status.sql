CREATE TABLE idf_raw_${env:aws_service_env}.apd_control.t_source_process_status (
  SOURCE_NAME STRING,
  LAST_PROCESSED_DTTM TIMESTAMP,
  STATUS STRING,
  UPDATE_DATE TIMESTAMP,
  UPDATE_BY STRING)
USING delta
LOCATION 's3://spr-idf-${env:aws_service_env}-platform-landing/catalog/APD_CONTROL/SOURCE_PROCESS_STATUS'
TBLPROPERTIES (
  'delta.minReaderVersion' = '1',
  'delta.minWriterVersion' = '4');
  
CREATE OR REPLACE VIEW idf_raw_${env:aws_service_env}.apd_control.v_source_process_status  AS SELECT * FROM  idf_raw_${env:aws_service_env}.apd_control.t_source_process_status;