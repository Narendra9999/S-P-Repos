-- idf_raw_${env:aws_service_env}.eds.t_eds_sch_reference definition

CREATE TABLE idf_raw_${env:aws_service_env}.eds.t_eds_sch_reference (
  SCHOOL_DISTRICT_CODE VARCHAR(10),
  SCHOOL_DISTRICT_NAME STRING,
  STATE_FIPS_CODE VARCHAR(2),
  COUNTY_FIPS_CODE VARCHAR(5),
  CBS_AREA_CODE VARCHAR(5),
  LONGITUDE STRING,
  LATITUDE STRING,
  CREATE_DATETIME TIMESTAMP,
  SOURCE_FILENAME STRING)
USING delta
COMMENT 'This table is related to School District Reference File Data'
LOCATION 's3://spr-idf-${env:aws_service_env}-platform-landing/catalog/EDS/EDS_SCHOOL_DISTRICT_REFERENCE'
TBLPROPERTIES (
  'delta.enableChangeDataFeed' = 'true',
  'delta.minReaderVersion' = '1',
  'delta.minWriterVersion' = '4');

CREATE OR REPLACE VIEW idf_raw_${env:aws_service_env}.eds.v_eds_sch_reference  AS SELECT * FROM  idf_raw_${env:aws_service_env}.eds.t_eds_sch_reference;