CREATE TABLE idf_raw_${env:aws_service_env}.eds.t_eds_mcd_reference (
  MCD_CODE STRING,
  MCD_NAME STRING,
  PLACE_CODE STRING,
  PLACE_NAME STRING,
  COUNTY_FIPS_CODE STRING,
  COUNTY_NAME STRING,
  STATE_FIPS_CODE STRING,
  STATE_NAME STRING,
  CBS_AREA_CODE STRING,
  CBS_AREA_NAME STRING,
  CREATE_DATETIME TIMESTAMP,
  SOURCE_FILENAME STRING)
USING delta
COMMENT 'This table is related to MINOR CIVIL DIVISION Reference File Data'
LOCATION 's3://spr-idf-${env:aws_service_env}-platform-landing/catalog/EDS/EDS_MCD_REFERENCE'
TBLPROPERTIES (
  'delta.enableChangeDataFeed' = 'true',
  'delta.minReaderVersion' = '1',
  'delta.minWriterVersion' = '2');

CREATE OR REPLACE VIEW idf_raw_${env:aws_service_env}.eds.v_eds_mcd_reference  AS SELECT * FROM  idf_raw_${env:aws_service_env}.eds.t_eds_mcd_reference;