
CREATE TABLE idf_curated_${env:aws_service_env}.eds.t_eds_data_element (
  VAR_CODE INT,
  VARIABLE_DESC STRING,
  SHORT_VARIABLE_DESC STRING,
  DE_DATA_TYPE STRING,
  DE_DATA_UNIT_TYPE STRING,
  PROCESS_ID BIGINT,
  CREATE_DATETIME TIMESTAMP,
  UPDATE_DATETIME TIMESTAMP,
  ACTION STRING,
  LATEST_VALUE_FLAG STRING,
  SOURCE_FILENAME STRING)
USING delta
COMMENT 'This table is related to the RDBMS table: EDS_DATA_ELEMENT'
LOCATION 's3://spr-idf-${env:aws_service_env}-platform-landing/catalog/CURATED/EDS/EDS_DATA_ELEMENT'
TBLPROPERTIES (
  'delta.enableChangeDataFeed' = 'true',
  'delta.minReaderVersion' = '1',
  'delta.minWriterVersion' = '4');

CREATE OR REPLACE VIEW idf_curated_${env:aws_service_env}.eds.v_eds_data_element  AS SELECT * FROM  idf_curated_${env:aws_service_env}.eds.t_eds_data_element;

INSERT INTO idf_curated_${env:aws_service_env}.eds.t_eds_data_element
SELECT * FROM idf_${env:aws_service_env}.eds.t_eds_data_element;
