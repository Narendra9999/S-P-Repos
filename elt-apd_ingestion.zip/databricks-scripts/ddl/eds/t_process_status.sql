CREATE TABLE idf_raw_${env:aws_service_env}.apd_control.t_process_status (
  PROCESS_ID STRING NOT NULL,
  TABLE_NAME STRING,
  RUN_TYPE STRING,
  FILE_TIMESTAMP TIMESTAMP,
  STATUS STRING,
  PROCESS_STARTTIME TIMESTAMP,
  PROCESS_ENDTIME TIMESTAMP,
  ERROR STRING,
  THRESHOLD DOUBLE,
  CREATE_DATE TIMESTAMP,
  CREATE_BY STRING,
  UPDATE_DATE TIMESTAMP,
  UPDATE_BY STRING,
  LAST_PROCESSED_DTTM TIMESTAMP,
  PROCESS_NAME STRING,
  CONSTRAINT `process_status_pk` PRIMARY KEY (`PROCESS_ID`))
USING delta
LOCATION 's3://spr-idf-${env:aws_service_env}-platform-landing/catalog/APD_CONTROL/PROCESS_STATUS'
CLUSTER BY (TABLE_NAME,RUN_TYPE)
TBLPROPERTIES (
  'delta.checkpointPolicy' = 'v2',
  'delta.enableDeletionVectors' = 'true',
  'delta.enableRowTracking' = 'true',
  'delta.feature.appendOnly' = 'supported',
  'delta.feature.deletionVectors' = 'supported',
  'delta.feature.invariants' = 'supported',
  'delta.feature.rowTracking' = 'supported',
  'delta.feature.v2Checkpoint' = 'supported');
  
  CREATE OR REPLACE VIEW idf_raw_${env:aws_service_env}.apd_control.v_process_status  AS SELECT * FROM  idf_raw_${env:aws_service_env}.apd_control.t_process_status;